using Microsoft.Xna.Framework.Graphics;

namespace Common.Data;

public interface IStorageAsset
{
	float getStorageMass { get; }

	string getName { get; }

	string getDescription { get; }

	Texture2D getIconTexture { get; }

	StorageAssetEnum getType { get; }

	short ID { get; }
}
