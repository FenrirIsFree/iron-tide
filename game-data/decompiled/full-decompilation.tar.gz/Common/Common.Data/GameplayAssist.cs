#define DEBUG
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using Common.Components;
using Common.Game;
using Common.Resources;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using SDL2;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Core;
using TheraEngine.Graphics.Models;
using TheraEngine.Helpers;

namespace Common.Data;

public class GameplayAssist
{
	internal static ValueCounter[] avgShipRankHp;

	internal static IslePortInfoToken[] worldMapPorts;

	private ShipStaticInfoToken[] _007B3534_007D;

	private Dictionary<string, (Model main, Model externalHb)> _007B3535_007D;

	internal void LoadModels(GameLoader _007B3510_007D, ContentManager _007B3511_007D)
	{
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_030b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0330: Unknown result type (might be due to invalid IL or missing references)
		//IL_0355: Unknown result type (might be due to invalid IL or missing references)
		//IL_037a: Unknown result type (might be due to invalid IL or missing references)
		//IL_039f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c4: Unknown result type (might be due to invalid IL or missing references)
		_007B3510_007D.EmptyShapeModel = UWOpenModel.CreateAll(null, _007B3511_007D.TryLoadOrNull<Model>("Models\\newWorld\\emshape"));
		_007B3510_007D.FactoryShapeModel = UWOpenModel.CreateAll(null, _007B3511_007D.TryLoadOrNull<Model>("Models\\newWorld\\buildings\\factory_any_shape"));
		_007B3534_007D = LoadJsonArray<ShipStaticInfoToken>(_007B3511_007D, "_lzcommon//ShipsBasics_j");
		_007B3535_007D = new Dictionary<string, (Model, Model)>();
		ShipStaticInfoToken[] array = _007B3534_007D;
		foreach (ShipStaticInfoToken shipStaticInfoToken in array)
		{
			if (!string.IsNullOrEmpty(shipStaticInfoToken.ModelName))
			{
				Model val = _007B3511_007D.TryLoadOrNull<Model>("Models\\Ships\\" + shipStaticInfoToken.ModelName);
				if (val == null)
				{
					throw new Exception("There is no model " + shipStaticInfoToken.ModelName);
				}
				_007B3535_007D.Add(shipStaticInfoToken.ModelName, (val, _007B3511_007D.TryLoadOrNull<Model>("Models\\Ships\\" + shipStaticInfoToken.ModelName + "_externalHitbox")));
			}
		}
		Gameplay.DyanmicBuildingsDictionary = new LinkedDictionrary<InitialDynamicBuildingId, DynamicBuildingInfo>();
		Gameplay.DyanmicBuildingsTable = new Tlist<DynamicBuildingInfo>();
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.FortMain, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\forts\\guildfort_level1")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.FortMain, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\forts\\guildfort_level2")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.FortMain, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\forts\\guildfort_level3")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.FortMain, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\forts\\guildfort_level4")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.FortMain, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\forts\\guildfort_level4")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.FortTowerMortar, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\towers\\t_mortar1")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.FortTowerMortar, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\towers\\t_mortar2")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.FortTowerMortar, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\towers\\t_mortar3")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.FortTowerFire, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\towers\\t_fire1")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.FortTowerFire, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\towers\\t_fire2")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.FortTowerFire, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\towers\\t_fire3")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.FortTowerCannons, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\towers\\t_cannonsstr1")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.FortTowerCannons, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\towers\\t_cannonsstr2")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.FortTowerCannons, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\towers\\t_cannonsstr3")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.Watchtower, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\towers\\watchtower1")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.AvanpostAttacker, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\forts\\avanpost_attack")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.AvanpostDefender, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\forts\\avanpost_defend")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.WorldFort, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\world\\worldfort1")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.WorldFort, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\world\\worldfort2")));
		Bappend(new DynamicBuildingInfo(InitialDynamicBuildingId.WorldFort, new Vector3(0.5f), GameLoader.Current.GetModelOrLoad("special\\world\\worldfort3")));
		static void Bappend(DynamicBuildingInfo _007B3533_007D)
		{
			Gameplay.DyanmicBuildingsDictionary.Add(_007B3533_007D.InitialID, _007B3533_007D);
			_007B3533_007D.TableID = Gameplay.DyanmicBuildingsTable.Size;
			Gameplay.DyanmicBuildingsTable.Add(in _007B3533_007D);
		}
	}

	private static T[] LoadJsonArray<T>(ContentManager _007B3512_007D, string _007B3513_007D) where T : new()
	{
		using Stream stream = _007B3512_007D.OpenStreamPublic(_007B3513_007D);
		using StreamReader streamReader = new StreamReader(stream, Encoding.UTF8);
		JSPContext jSPContext = new JSPContext(_007B3513_007D)
		{
			WriteAlerts = false
		};
		T[] result = QuickJsonReflectiveParser.ParseJsonList<T>(jSPContext, streamReader.ReadToEnd()).ToArray();
		if (jSPContext.AlertsOrNull != null && jSPContext.AlertsOrNull.Any())
		{
			StringBuilder stringBuilder = new StringBuilder();
			foreach (string item in jSPContext.AlertsOrNull)
			{
				stringBuilder.AppendLine(item);
			}
			Engine.ShowMessageBox(stringBuilder.ToString(), "JsonParser", (SDL_MessageBoxFlags)64);
		}
		return result;
	}

	private static void DebugDiffs<T>(ContentManager _007B3514_007D, string _007B3515_007D, T[] _007B3516_007D)
	{
		T[] _007B3518_007D = ((!_007B3515_007D.Contains("StartMap_")) ? _007B3514_007D.Load<T[]>(_007B3515_007D.Replace("_j", "")) : new T[1] { _007B3514_007D.Load<T>(_007B3515_007D.Replace("_j", "")) });
		IReadOnlyCollection<string> differences = GetDifferences(_007B3516_007D, _007B3518_007D);
		if (differences == null || !differences.Any())
		{
			return;
		}
		string path = Path.Combine("TestDiffs", Path.GetFileName(_007B3515_007D) + "_diffs");
		using StreamWriter streamWriter = new StreamWriter(path, Encoding.Default, new FileStreamOptions
		{
			Mode = FileMode.OpenOrCreate,
			Access = FileAccess.ReadWrite
		});
		foreach (string item in differences)
		{
			streamWriter.WriteLine(item);
		}
	}

	private static IReadOnlyCollection<string> GetDifferences<T>(T[] _007B3517_007D, T[] _007B3518_007D)
	{
		List<string> list = new List<string>();
		for (int i = 0; i < _007B3517_007D.Length; i++)
		{
			Dictionary<string, object> _007B3523_007D = new Dictionary<string, object>();
			LoadProps(_007B3518_007D[i], _007B3523_007D, "");
			Dictionary<string, object> dictionary = new Dictionary<string, object>();
			LoadFields(_007B3518_007D[i], dictionary, "");
			Dictionary<string, object> _007B3523_007D2 = new Dictionary<string, object>();
			LoadProps(_007B3517_007D[i], _007B3523_007D2, "");
			Dictionary<string, object> dictionary2 = new Dictionary<string, object>();
			LoadFields(_007B3517_007D[i], dictionary2, "");
			foreach (KeyValuePair<string, object> item in dictionary)
			{
				dictionary2.TryGetValue(item.Key, out var value);
				if (value == null)
				{
					list.Add("Field " + item.Key + " not found in Json.");
				}
				else if (!value.Equals(item.Value))
				{
					list.Add($"Field {item.Key} is not same, values xml {item.Value}, {value}.");
				}
			}
		}
		return list;
	}

	private static void LoadFields<T>(T _007B3519_007D, Dictionary<string, object?> _007B3520_007D, string _007B3521_007D)
	{
		FieldInfo[] fields = _007B3519_007D.GetType().GetFields();
		foreach (FieldInfo fieldInfo in fields)
		{
			if (fieldInfo.FieldType.IsClass && fieldInfo.FieldType != typeof(string))
			{
				if (fieldInfo.FieldType.IsArray)
				{
					foreach (object item in fieldInfo.GetValue(_007B3519_007D) as IEnumerable)
					{
						LoadProps(item, _007B3520_007D, _007B3521_007D + ".Arrr." + fieldInfo.Name);
					}
				}
				else
				{
					LoadProps(fieldInfo.GetValue(_007B3519_007D), _007B3520_007D, _007B3521_007D + "." + fieldInfo.Name);
				}
				LoadFields(fieldInfo.GetValue(_007B3519_007D), _007B3520_007D, _007B3521_007D + "." + fieldInfo.Name);
			}
			else
			{
				_007B3520_007D.Add(_007B3521_007D + "." + fieldInfo.Name, fieldInfo.GetValue(_007B3519_007D));
			}
		}
	}

	private static void LoadProps<T>(T _007B3522_007D, Dictionary<string, object?> _007B3523_007D, string _007B3524_007D)
	{
		PropertyInfo[] properties = _007B3522_007D.GetType().GetProperties();
		foreach (PropertyInfo propertyInfo in properties)
		{
			if (propertyInfo.PropertyType.IsClass && propertyInfo.PropertyType != typeof(string))
			{
				if (propertyInfo.PropertyType.IsArray)
				{
					int num = 0;
					foreach (object item in propertyInfo.GetValue(_007B3522_007D) as IEnumerable)
					{
						LoadProps(item, _007B3523_007D, $"{_007B3524_007D}.[{num}].{propertyInfo.Name}");
						num++;
					}
				}
				else
				{
					LoadProps(propertyInfo.GetValue(_007B3522_007D), _007B3523_007D, _007B3524_007D + "." + propertyInfo.Name);
				}
			}
			else
			{
				_007B3523_007D.Add(_007B3524_007D + "." + propertyInfo.Name, propertyInfo.GetValue(_007B3522_007D));
			}
		}
	}

	public static void MakeHotReload(string _007B3525_007D)
	{
		string rootDir = Engine.Game.Content.RootDir;
		Engine.Game.Content.RootDir = "";
		LoadNamesWithHotReload(_007B3525_007D, GameLoader.Current, Engine.Game.Content);
		Engine.Game.Content.RootDir = rootDir;
	}

	internal static void LoadNamesWithHotReload(string _007B3526_007D, GameLoader _007B3527_007D, ContentManager _007B3528_007D)
	{
		string text = (string.IsNullOrEmpty(_007B3528_007D.RootDir) ? ".json" : "");
		CaptainSkillBonusInfoToken[] captainSkills = LoadJsonArray<CaptainSkillBonusInfoToken>(_007B3528_007D, _007B3526_007D + "/CaptainSkills_j" + text);
		ShipDesingElementInfoToken[] shipDesignElements = LoadJsonArray<ShipDesingElementInfoToken>(_007B3528_007D, _007B3526_007D + "/ShipDesingElements_j" + text);
		ShipUpgradeInfoTokenNew[] shipUpgrades = LoadJsonArray<ShipUpgradeInfoTokenNew>(_007B3528_007D, _007B3526_007D + "/ShipUpgradesNew_j" + text);
		InterestPointInfoToken[] interestPoints = LoadJsonArray<InterestPointInfoToken>(_007B3528_007D, _007B3526_007D + "/InterestPoints_j" + text);
		GamepediaArticleInfoToken[] gamepedia = LoadJsonArray<GamepediaArticleInfoToken>(_007B3528_007D, _007B3526_007D + "/Gamepedia_j" + text);
		Gameplay.ShipUpgradesInfo = new XmlAssetLibrary<ShipUpgradeInfo, ShipUpgradeInfoTokenNew>(shipUpgrades, (int _007B3547_007D) => new ShipUpgradeInfo(_007B3528_007D, shipUpgrades[_007B3547_007D], _007B3547_007D + 1));
		Gameplay.DesignsInfo = new XmlAssetLibrary<ShipDesignInfo, ShipDesingElementInfoToken>(shipDesignElements, (int _007B3548_007D) => new ShipDesignInfo(_007B3527_007D.materialsDatabase, _007B3528_007D, shipDesignElements[_007B3548_007D], _007B3548_007D + 1));
		Gameplay.CaptainSkillsInfo = new XmlAssetLibrary<CaptainSkillInfo, CaptainSkillBonusInfoToken>(captainSkills, (int _007B3549_007D) => new CaptainSkillInfo(_007B3528_007D, captainSkills[_007B3549_007D], _007B3549_007D + 1));
		for (int num = 0; num < Gameplay.CaptainSkillsInfo.Count; num++)
		{
			Gameplay.CaptainSkillsInfo.FromIndex(num).OnInit();
		}
		Gameplay.CaptainSkillsIDs = new LinkedDictionrary<PDynamicAccountBonus, CaptainSkillInfo>(512);
		for (int num2 = 0; num2 < Gameplay.CaptainSkillsInfo.Count; num2++)
		{
			CaptainSkillInfo captainSkillInfo = Gameplay.CaptainSkillsInfo.FromIndex(num2);
			Gameplay.CaptainSkillsIDs.Add(captainSkillInfo.Effect, captainSkillInfo);
		}
		Gameplay.InterestPointsInfo = new XmlAssetLibrary<InterestPointInfo, InterestPointInfoToken>(interestPoints, (int _007B3550_007D) => new InterestPointInfo(_007B3550_007D + 1, interestPoints[_007B3550_007D]));
		Gameplay.Gamepedia = new XmlAssetLibrary<GamepediaArticleInfo, GamepediaArticleInfoToken>(gamepedia, (int _007B3551_007D) => new GamepediaArticleInfo(gamepedia[_007B3551_007D], _007B3551_007D + 1));
	}

	internal void LoadNames(GameLoader _007B3529_007D, ContentManager _007B3530_007D, Sequence _007B3531_007D)
	{
		MapInfoToken _007B3037_007D = LoadJsonArray<MapInfoToken>(_007B3530_007D, "_lzcommon/World_j")[0];
		MapInfoToken _007B3037_007D2 = LoadJsonArray<MapInfoToken>(_007B3530_007D, "_lzcommon/StartMap_j")[0];
		AchievementDisplayInfoToken[] achievements = LoadJsonArray<AchievementDisplayInfoToken>(_007B3530_007D, "_lzcommon/Achievements_j");
		RangInfoToken[] rangs = LoadJsonArray<RangInfoToken>(_007B3530_007D, "_lzcommon//RangInfo_j");
		CannonBallInfoToken[] cannonBalls = LoadJsonArray<CannonBallInfoToken>(_007B3530_007D, "_lzcommon//CannonBalls_j");
		CannonGameInfoToken2[] shipCannons = LoadJsonArray<CannonGameInfoToken2>(_007B3530_007D, "_lzcommon//Cannons_j");
		ShipToPlayToken[] array = LoadJsonArray<ShipToPlayToken>(_007B3530_007D, "_lzcommon//ShipsToPlay_j");
		UnitInfoToken[] unitsInfo = LoadJsonArray<UnitInfoToken>(_007B3530_007D, "_lzcommon//UnitsInfo_j");
		ShipDesingElementInfoToken[] envDesignElements = LoadJsonArray<ShipDesingElementInfoToken>(_007B3530_007D, "_lzcommon//EnvDesingElements_j");
		MapForPassingInfoToken[] mapsForPassing = LoadJsonArray<MapForPassingInfoToken>(_007B3530_007D, "_lzcommon//MapsForPassing_j");
		ResourceInfoToken[] resources = LoadJsonArray<ResourceInfoToken>(_007B3530_007D, "_lzcommon//Resources_j");
		PowderKegInfoToken[] powderKegs = LoadJsonArray<PowderKegInfoToken>(_007B3530_007D, "_lzcommon/PowderKegs_j");
		ArenaUpgradeInfoToken[] arenaUpgrades = LoadJsonArray<ArenaUpgradeInfoToken>(_007B3530_007D, "_lzcommon/ArenaUpgrades_j");
		MapArenaInfoToken[] mapsArena = LoadJsonArray<MapArenaInfoToken>(_007B3530_007D, "_lzcommon/MapsArena_j");
		worldMapPorts = LoadJsonArray<IslePortInfoToken>(_007B3530_007D, "_lzcommon/WorldPorts_j");
		GuildTitleToken[] guildTitles = LoadJsonArray<GuildTitleToken>(_007B3530_007D, "_lzcommon/GuildTitles_j");
		PortLevelBonusToken[] portLevelBonuses = LoadJsonArray<PortLevelBonusToken>(_007B3530_007D, "_lzcommon/PortLevelBonuses_j");
		List<Vector2>[] tradingRoutesInfo = LoadJsonArray<List<Vector2>>(_007B3530_007D, "_lzcommon/TradingRoutesInfo");
		Gameplay.ProceduralGeneratorPresets = LoadJsonArray<GeneratorPreset>(_007B3530_007D, "_lzcommon/ProceduralPresets_j").ToDictionary((GeneratorPreset _007B3536_007D) => _007B3536_007D.Name, (GeneratorPreset _007B3537_007D) => _007B3537_007D);
		CommonEnums.Validate();
		Gameplay.ItemsInfo = new XmlAssetLibrary<ResourceInfo, ResourceInfoToken>(resources, (int _007B3552_007D) => new ResourceInfo(_007B3530_007D, resources[_007B3552_007D], _007B3552_007D + 1));
		Gameplay.ShipsStaticInfo = new XmlAssetLibrary<ShipStaticInfo, ShipStaticInfoToken>(_007B3534_007D, delegate(int _007B3553_007D)
		{
			ShipStaticInfoToken shipStaticInfoToken = _007B3534_007D[_007B3553_007D];
			(Model, Model) value2;
			return _007B3535_007D.TryGetValue(shipStaticInfoToken.ModelName, out value2) ? new ShipStaticInfo(shipStaticInfoToken, _007B3553_007D + 1, value2.Item1, value2.Item2) : null;
		});
		_007B3535_007D.Clear();
		_007B3535_007D = null;
		for (int num = 0; num < Gameplay.ShipsStaticInfo.Size; num++)
		{
			if (Gameplay.ShipsStaticInfo.Array[num] == null)
			{
				Gameplay.ShipsStaticInfo.Array[num] = Gameplay.ShipsStaticInfo.Array[0];
			}
		}
		if (CommonGlobal.IsServer)
		{
			for (int num2 = 0; num2 < Gameplay.ShipsStaticInfo.Count; num2++)
			{
				Gameplay.ShipsStaticInfo.FromIndex(num2).Model.corpus.DisposeWithSourceData();
				Gameplay.ShipsStaticInfo.FromIndex(num2).Model.corpusLow.DisposeWithSourceData();
				Gameplay.ShipsStaticInfo.FromIndex(num2).Model.shipMin.DisposeWithSourceData();
			}
		}
		Gameplay.RangsInfo = new XmlAssetLibrary<RangInfo, RangInfoToken>(rangs, (int _007B3554_007D) => new RangInfo(rangs[_007B3554_007D], _007B3554_007D + 1));
		Gameplay.BallsInfo = new XmlAssetLibrary<CannonBallInfo, CannonBallInfoToken>(cannonBalls, (int _007B3555_007D) => new CannonBallInfo(_007B3530_007D, cannonBalls[_007B3555_007D], _007B3555_007D + 1, _007B2226_007D: false));
		Gameplay.CannonsGameInfo = new XmlAssetLibrary<CannonGameInfo, CannonGameInfoToken2>(shipCannons, (int _007B3556_007D) => new CannonGameInfo(_007B3530_007D, shipCannons[_007B3556_007D], _007B3556_007D + 1));
		avgShipRankHp = new ValueCounter[10];
		ShipToPlayToken[] array2 = array;
		foreach (ShipToPlayToken shipToPlayToken in array2)
		{
			if (avgShipRankHp[shipToPlayToken.Rank] == null)
			{
				avgShipRankHp[shipToPlayToken.Rank] = new ValueCounter();
			}
			avgShipRankHp[shipToPlayToken.Rank].Push(shipToPlayToken.Health);
		}
		PlayerShipInfo filler = new PlayerShipInfo(array[0]);
		Gameplay.PlayersInfo = new XmlAssetLibrary<PlayerShipInfo, ShipToPlayToken>(array, (ShipToPlayToken _007B3538_007D) => new PlayerShipInfo(_007B3538_007D), (int _007B3557_007D) => filler, (PlayerShipInfo _007B3539_007D) => _007B3539_007D.ID);
		Gameplay.SortedPlayersInfoList = new Tlist<PlayerShipInfo>(array.Length);
		for (int num4 = 0; num4 < Gameplay.PlayersInfo.Count; num4++)
		{
			Gameplay.SortedPlayersInfoList.Add(Gameplay.PlayersInfo.FromIndex(num4));
		}
		Gameplay.SortedPlayersInfoList.SortTop((PlayerShipInfo _007B3540_007D) => -_007B3540_007D.Rank);
		Gameplay.ResearchShipTable = new Dictionary<ShipClass, ResearchShipClassTable>(1000);
		foreach (ShipClass classType in Enum.GetValues(typeof(ShipClass)))
		{
			Gameplay.ResearchShipTable.Add(classType, new ResearchShipClassTable(Gameplay.SortedPlayersInfoList.Where((PlayerShipInfo _007B3569_007D) => _007B3569_007D.Class == classType && _007B3569_007D.Coolness == PlayerShipCoolness.Default)));
		}
		Gameplay.WorldMap = new WorldMapInfo(_007B3037_007D, 1);
		Gameplay.StartMap = new WorldMapInfo(_007B3037_007D2, 0);
		foreach (WorldMapRegionInfo hazardArea in (IEnumerable<WorldMapRegionInfo>)Gameplay.WorldMap.RegionsInfo)
		{
			if (!Gameplay.WorldMap.Ports.Any((IslePortInfo _007B3570_007D) => _007B3570_007D.NearRegion == hazardArea))
			{
				GameLoader.Current.AddImportant("Important: there are not ports for region ID: " + hazardArea.ID);
				throw new InvalidOperationException("Loading cannot be finished");
			}
		}
		foreach (PlayerShipInfo item2 in (IEnumerable<PlayerShipInfo>)Gameplay.PlayersInfo)
		{
			item2.PostInit();
		}
		LoadNamesWithHotReload("_lzcommon", _007B3529_007D, _007B3530_007D);
		Tlist<NpcGenerator> tlist = new Tlist<NpcGenerator>(10);
		tlist.Add(WosbNpcs.EducationMapNpcs());
		foreach (WorldMapRegionInfo item3 in (IEnumerable<WorldMapRegionInfo>)Gameplay.WorldMap.RegionsInfo)
		{
			tlist.Add(WosbNpcs.AutogeneratedNpcForMap(_007B3531_007D, item3));
		}
		foreach (IslePortInfo item4 in (IEnumerable<IslePortInfo>)Gameplay.WorldMap.Ports)
		{
			tlist.Add(WosbNpcs.AutogeneratedNpcForPort(_007B3531_007D, item4));
		}
		NpcGenerator[] npcArr = tlist.ToArray();
		Gameplay.NpcsInfo = new XmlAssetLibrary<NpcInfo, NpcGenerator>(npcArr, (int _007B3558_007D) => new NpcInfo(_007B3558_007D + 1, npcArr[_007B3558_007D], _007B2343_007D: false));
		for (int num5 = 0; num5 < Gameplay.NpcsInfo.Size; num5++)
		{
			NpcInfo item = Gameplay.NpcsInfo.FromIndex(num5);
			item.IntializeDefenceWaves();
			if (item.Location.AsWorldRegion != null)
			{
				continue;
			}
			IslePortInfo[] array3 = Gameplay.WorldMap.Ports.Where((IslePortInfo _007B3571_007D) => _007B3571_007D.NearRegion == item.Location.AsWorldRegion).ToArray();
			if (array3.Length != 0)
			{
				int num6 = array3.Min((IslePortInfo _007B3541_007D) => _007B3541_007D.ShallowUpperRang);
				if (item.BasedOn.Rank < num6 - 1)
				{
					GameLoader.Current.AddImportant("Shallow test failed: npc in hzLevel " + item.Location.AsWorldRegion.Name + " level " + item.Location.HzLevel + " with ship rank " + item.BasedOn.Rank + ", hzArea of ship: " + item.BasedOn.AssotiatedHazardZoneLevel);
				}
			}
		}
		Gameplay.PowerupItems = new Tlist<PowerupItemInfo>(new List<PowerupItemInfo>(PowerupItemsGenerator.InitializePowerupItems(_007B3530_007D)).ToArray());
		for (int num7 = 0; num7 < Gameplay.PowerupItems.Size; num7++)
		{
			Gameplay.PowerupItems.Array[num7].Index = num7;
		}
		Gameplay.UnitsInfo = new XmlAssetLibrary<UnitInfo, UnitInfoToken>(unitsInfo, (int _007B3559_007D) => new UnitInfo(_007B3530_007D, unitsInfo[_007B3559_007D], _007B3559_007D + 1));
		Gameplay.AllSpecialUnits = new Tlist<UnitInfo>(Gameplay.UnitsInfo.Where((UnitInfo _007B3542_007D) => _007B3542_007D.Type == UnitType.Special));
		Gameplay.EnvDecorElementsInfo = new XmlAssetLibrary<ShipDesignInfo, ShipDesingElementInfoToken>(envDesignElements, (int _007B3560_007D) => new ShipDesignInfo(_007B3529_007D.materialsDatabase, _007B3530_007D, envDesignElements[_007B3560_007D], _007B3560_007D + 1));
		Gameplay.RandomSailesForNpcs = new Tlist<ShipDesignInfo>(Gameplay.DesignsInfo.Where((ShipDesignInfo _007B3543_007D) => _007B3543_007D.Category == ShipDesignCategory.Decal1 && _007B3543_007D.InShop));
		Gameplay.RandomDesignsForAltar = new Tlist<ShipDesignInfo>(Gameplay.DesignsInfo.Where((ShipDesignInfo _007B3544_007D) => (_007B3544_007D.Category == ShipDesignCategory.Decal2 || _007B3544_007D.Category == ShipDesignCategory.Flag) && _007B3544_007D.InShop));
		Gameplay.ArenaMaps = new XmlAssetLibrary<MapArenaInfo, MapArenaInfoToken>(mapsArena, (int _007B3561_007D) => new MapArenaInfo(mapsArena[_007B3561_007D], _007B3561_007D + 1));
		ArenaMode[] values = Enum.GetValues<ArenaMode>();
		foreach (ArenaMode mode in values)
		{
			if (!Gameplay.ArenaMaps.Any((MapArenaInfo _007B3572_007D) => _007B3572_007D.GameplayMode.Contains(mode)))
			{
				throw new InvalidOperationException($"There's no MapsArena_j for {mode}");
			}
		}
		Gameplay.GuildTitles = new XmlAssetLibrary<GuildTitle, GuildTitleToken>(guildTitles, (int _007B3562_007D) => new GuildTitle(_007B3562_007D + 1, guildTitles[_007B3562_007D]));
		Gameplay.GuildTitlesByFraction = new LinkedDictionrary<FractionID, GuildTitle>();
		foreach (GuildTitle item5 in (IEnumerable<GuildTitle>)Gameplay.GuildTitles)
		{
			Gameplay.GuildTitlesByFraction.Add(item5.Fraction, item5);
		}
		Gameplay.MapsForPassing = new XmlAssetLibrary<MapForPassingInfo, MapForPassingInfoToken>(mapsForPassing, (int _007B3563_007D) => new MapForPassingInfo(mapsForPassing[_007B3563_007D], _007B3563_007D + 1));
		Gameplay.PowderKegsInfo = new XmlAssetLibrary<PowderKegInfo, PowderKegInfoToken>(powderKegs, (int _007B3564_007D) => new PowderKegInfo(_007B3530_007D, powderKegs[_007B3564_007D], _007B3564_007D + 1));
		Gameplay.AchievementsDisplayInfo = new XmlAssetLibrary<AchievementDisplayInfo, AchievementDisplayInfoToken>(achievements, (int _007B3565_007D) => new AchievementDisplayInfo(_007B3530_007D, achievements[_007B3565_007D], _007B3565_007D + 1));
		Gameplay.AchievementsByEnum = new Dictionary<AchievementEnum, AchievementDisplayInfo>(512);
		for (int num9 = 0; num9 < Gameplay.AchievementsDisplayInfo.Count; num9++)
		{
			AchievementDisplayInfo achievementDisplayInfo = Gameplay.AchievementsDisplayInfo.FromIndex(num9);
			Gameplay.AchievementsByEnum.Add(achievementDisplayInfo.AchievementEnum, achievementDisplayInfo);
		}
		Gameplay.ArenaUpgrades = new XmlAssetLibrary<ArenaUpgradeInfo, ArenaUpgradeInfoToken>(arenaUpgrades, (int _007B3566_007D) => new ArenaUpgradeInfo(arenaUpgrades[_007B3566_007D], _007B3566_007D + 1));
		FractionAPI.LoadIcons();
		XmlAssetLibrary<PortLevelBonus, PortLevelBonusToken> xmlAssetLibrary = new XmlAssetLibrary<PortLevelBonus, PortLevelBonusToken>(portLevelBonuses, (int _007B3567_007D) => new PortLevelBonus(portLevelBonuses[_007B3567_007D]));
		Gameplay.PortLevelBonuses = new LinkedDictionrary<PortLevelBonusType, PortLevelBonus>();
		foreach (PortLevelBonus item6 in (IEnumerable<PortLevelBonus>)xmlAssetLibrary)
		{
			Gameplay.PortLevelBonuses.Add(item6.Type, item6);
		}
		CommonGlobal.MagicNumber += (CommonGlobal.MagicNumberQuestsOnly = ReloadQuests());
		foreach (ShipStaticInfo item7 in (IEnumerable<ShipStaticInfo>)Gameplay.ShipsStaticInfo)
		{
			item7.FinalInit();
		}
		WosbCrafting.InitFactories();
		Gameplay.TradingRoutesInfo = new XmlAssetLibrary<TradingRouteInfo, List<Vector2>>(tradingRoutesInfo, (int _007B3568_007D) => new TradingRouteInfo(_007B3568_007D + 1, tradingRoutesInfo[_007B3568_007D]));
		if (!Debugger.IsAttached)
		{
			return;
		}
		Debug.WriteLine("-----------");
		foreach (UnitInfo item8 in (IEnumerable<UnitInfo>)Gameplay.UnitsInfo)
		{
			Debug.WriteLine(item8.Name + ": " + item8.GetBonusDescription());
		}
		Debug.WriteLine("-----------");
		foreach (ShipUpgradeInfo item9 in (IEnumerable<ShipUpgradeInfo>)Gameplay.ShipUpgradesInfo)
		{
			string text = "";
			foreach (ShipBonus effect in item9.GetEffects(Gameplay.PlayersInfo.First()))
			{
				text = text + effect.ToString() + "; ";
			}
			Debug.WriteLine(item9.Name + " " + text);
		}
		Debug.WriteLine("-----------");
		foreach (CaptainSkillInfo item10 in (IEnumerable<CaptainSkillInfo>)Gameplay.CaptainSkillsInfo)
		{
			Debug.WriteLine(item10.Name + ": " + item10.Description);
		}
		Debug.WriteLine("-----------");
		foreach (KeyValuePair<FactoryType, FactoryGameInfo> item11 in WosbCrafting.FactoriesInfo)
		{
			Debug.WriteLine("");
			Debug.WriteLine(item11.Value.Name);
			if (item11.Value.Type != FactoryType.Temp_PersonalIsle)
			{
				FactoryMineLivelInfo[] levels = item11.Value.Levels;
				foreach (FactoryMineLivelInfo factoryMineLivelInfo in levels)
				{
					Debug.WriteLine("+" + factoryMineLivelInfo.ProducedResCount + " " + factoryMineLivelInfo.DisplayOutputRes.Name);
					Debug.WriteLine("-" + factoryMineLivelInfo.ConsumedResCount + " " + ((factoryMineLivelInfo.ConsumedResId == 0) ? "(нет потребления)" : Gameplay.ItemsInfo.FromID(factoryMineLivelInfo.ConsumedResId).Name));
				}
			}
		}
		Debug.WriteLine("-----------");
		foreach (string item12 in ShopChestApplyHelper.BigChest.ToStringAllChestOffers())
		{
			Debug.WriteLine(item12);
		}
		Debug.WriteLine("-----------");
		foreach (IslePortInfo item13 in (IEnumerable<IslePortInfo>)Gameplay.WorldMap.Ports)
		{
			if (item13.AllowCapture)
			{
				PbsBuildingPlaceInfo value = item13.PbSystem.First<KeyValuePair<int, PbsBuildingPlaceInfo>>((KeyValuePair<int, PbsBuildingPlaceInfo> _007B3545_007D) => _007B3545_007D.Value.GroupID == WorldObjectID.WGuildFortTower).Value;
				float num11 = 12000f * item13.Leveling;
				float num12 = 2327.5002f * ((float)Math.Min(20, item13.PortBattleTeamLimitation) * 0.075f + 1f) * ((float)(6 - ((item13.ShallowUpperRang == -1) ? 1 : item13.ShallowUpperRang)) * 0.25f + 1f);
				Debug.WriteLine(item13.PortName);
				Debug.WriteLine("Уровнь мелководки: " + item13.ShallowUpperRang);
				Debug.WriteLine("Уровень региона: " + item13.NearRegion.LevelInt);
				Debug.WriteLine("Число башен: " + item13.PbSystem.Count<KeyValuePair<int, PbsBuildingPlaceInfo>>((KeyValuePair<int, PbsBuildingPlaceInfo> _007B3546_007D) => _007B3546_007D.Value.GroupID == WorldObjectID.WGuildFortTower));
				Debug.WriteLine("Прочка: " + (int)num11 + " -> " + (int)num12);
				Debug.WriteLine("");
			}
		}
	}

	public static int ReloadQuests()
	{
		return new GeneratedQuests().Generate();
	}

	internal static int DynamicBuildigIdFromName(string _007B3532_007D)
	{
		for (int i = 0; i < Gameplay.DyanmicBuildingsTable.Size; i++)
		{
			if (Gameplay.DyanmicBuildingsTable.Array[i].Model.Model.ModelName.Contains(_007B3532_007D))
			{
				return i;
			}
		}
		throw new KeyNotFoundException();
	}
}
