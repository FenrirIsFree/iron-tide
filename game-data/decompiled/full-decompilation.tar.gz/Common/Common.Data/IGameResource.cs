namespace Common.Data;

public interface IGameResource
{
	short ID { get; }
}
