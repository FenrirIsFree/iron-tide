namespace Common.Data;

public enum InitialDynamicBuildingId
{
	Watchtower,
	FortMain,
	FortTowerFire,
	FortTowerMortar,
	FortTowerCannons,
	AvanpostAttacker,
	AvanpostDefender,
	WorldFort
}
