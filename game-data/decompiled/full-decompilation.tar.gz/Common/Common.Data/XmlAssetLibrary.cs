using System;
using System.Linq;
using TheraEngine.Collections;

namespace Common.Data;

public class XmlAssetLibrary<TAsset> : Tlist<TAsset>
{
	internal int NextID => Size + 1;

	public new TAsset this[int _007B3489_007D] => Array[_007B3489_007D - 1];

	public TAsset FromID(int _007B3490_007D)
	{
		return Array[_007B3490_007D - 1];
	}

	public TAsset FromIndex(int _007B3491_007D)
	{
		return Array[_007B3491_007D];
	}
}
public class XmlAssetLibrary<TAsset, TToken> : Tlist<TAsset>
{
	public new TAsset this[int _007B3498_007D] => Array[_007B3498_007D - 1];

	public new int Count => Size;

	internal XmlAssetLibrary(TToken[] _007B3499_007D, Func<int, TAsset> _007B3500_007D)
	{
		if (_007B3499_007D == null || _007B3499_007D.Length == 0)
		{
			throw new ArgumentException();
		}
		Size = _007B3499_007D.Length;
		Array = new TAsset[Size];
		for (int i = 0; i < Size; i++)
		{
			TAsset val = _007B3500_007D(i);
			Array[i] = val;
		}
	}

	internal XmlAssetLibrary(TToken[] _007B3501_007D, Func<TToken, TAsset> _007B3502_007D, Func<int, TAsset> _007B3503_007D, Func<TAsset, int> _007B3504_007D)
	{
		if (_007B3501_007D == null || _007B3501_007D.Length == 0)
		{
			throw new ArgumentException();
		}
		Tlist<TAsset> tlist = new Tlist<TAsset>();
		for (int i = 0; i < _007B3501_007D.Length; i++)
		{
			tlist.Add(_007B3502_007D(_007B3501_007D[i]));
		}
		int num = tlist.Max((TAsset _007B3508_007D) => _007B3504_007D(_007B3508_007D));
		int id;
		for (id = 1; id <= num; id++)
		{
			int num2 = tlist.FindIndex((TAsset _007B3509_007D) => _007B3504_007D(_007B3509_007D) == id);
			if (num2 == -1)
			{
				Add(_007B3503_007D(id));
			}
			else
			{
				Add(in tlist.Array[num2]);
			}
		}
	}

	internal void ConvertAssets(Func<TAsset[], TAsset[]> _007B3505_007D)
	{
		Size = (Array = _007B3505_007D(Array)).Length;
	}

	public TAsset FromID(int _007B3506_007D)
	{
		return Array[_007B3506_007D - 1];
	}

	public TAsset FromIndex(int _007B3507_007D)
	{
		return Array[_007B3507_007D];
	}
}
