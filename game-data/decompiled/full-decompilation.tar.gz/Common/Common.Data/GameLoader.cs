#define DEBUG
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using Common.Resources;
using TheraEngine.Assets.Graphics;
using TheraEngine.Collections;
using TheraEngine.Core;
using TheraEngine.Graphics.Models;
using TheraEngine.Helpers;

namespace Common.Data;

public class GameLoader
{
	public static GameLoader Current;

	internal static int ParallelWorkers;

	internal static object ParallelWorkersSyncRoot = new object();

	private WOSBInstancedModelDictionary _007B3472_007D;

	public UWOpenModel EmptyShapeModel;

	public UWOpenModel FactoryShapeModel;

	public Tlist<string> ImportantMessages = new Tlist<string>();

	private Stopwatch _007B3473_007D;

	private Stopwatch _007B3474_007D;

	private Stopwatch _007B3475_007D;

	private Stopwatch _007B3476_007D;

	internal InstancedMaterialDictionary materialsDatabase;

	internal ContentManager InternalContentManager;

	public float LoadingTimeMs => (float)_007B3473_007D.Elapsed.TotalMilliseconds;

	public float ModelsLoadingTimeMs => (float)_007B3475_007D.Elapsed.TotalMilliseconds;

	public float BuildTimeMs => (float)_007B3476_007D.Elapsed.TotalMilliseconds;

	internal static void RunWorker(Action _007B3465_007D)
	{
		ThreadPool.QueueUserWorkItem(delegate
		{
			lock (ParallelWorkersSyncRoot)
			{
				ParallelWorkers++;
			}
			try
			{
				_007B3465_007D();
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				lock (ParallelWorkersSyncRoot)
				{
					ParallelWorkers--;
				}
			}
		});
	}

	public IsleModelInfo GetModelOrLoad(string _007B3466_007D)
	{
		return (IsleModelInfo)_007B3472_007D.Contains(_007B3466_007D);
	}

	public Dictionary<string, TheraEngine.Assets.Models.InstancedModel>.KeyCollection GetLoadedNames()
	{
		return _007B3472_007D.LoadedNames();
	}

	public GameLoader()
	{
		Current = this;
	}

	public void StartLoading(ContentManager _007B3467_007D, InstancedMaterialDictionary _007B3468_007D)
	{
		materialsDatabase = _007B3468_007D;
		InternalContentManager = new ContentManager(new HeapLoader(_007B3467_007D.ContentService, "CommonData"));
		_007B3472_007D = new WOSBInstancedModelDictionary(_007B3468_007D, InternalContentManager, "Models\\newWorld\\");
		_007B3473_007D = new Stopwatch();
		_007B3475_007D = new Stopwatch();
		_007B3476_007D = new Stopwatch();
		_007B3473_007D.Start();
		_007B3470_007D(new GameplayAssist());
		_007B3473_007D.Stop();
	}

	public void AddImportant(string _007B3469_007D)
	{
		Debug.WriteLine(_007B3469_007D);
		ImportantMessages.Add(in _007B3469_007D);
	}

	private void _007B3470_007D(GameplayAssist _007B3471_007D)
	{
		Sequence sequence = new Sequence(11344);
		_007B3475_007D.Start();
		_007B3471_007D.LoadModels(this, InternalContentManager);
		_007B3475_007D.Stop();
		_007B3476_007D.Start();
		_007B3471_007D.LoadNames(this, InternalContentManager, sequence);
		_007B3476_007D.Stop();
		CommonGlobal.MagicNumber += sequence.RangeInt(1, 10000000);
		CommonGlobal.DebugMagicNumber = $"{CommonGlobal.MagicNumber % 1000}-v{sequence.Version}-q{CommonGlobal.MagicNumberQuestsOnly % 1000}";
		while (true)
		{
			Thread.Sleep(1);
			lock (ParallelWorkersSyncRoot)
			{
				if (ParallelWorkers == 0)
				{
					break;
				}
			}
		}
	}
}
