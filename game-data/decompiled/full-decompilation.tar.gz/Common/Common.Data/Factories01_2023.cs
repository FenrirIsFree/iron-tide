using System;
using Common.Game;
using Microsoft.Xna.Framework;
using TheraEngine.Collections;

namespace Common.Data;

internal static class Factories01_2023
{
	[Serializable]
	public struct DInfo
	{
		public int FcID;

		public Vector2 Position;

		public FactoryType Type;

		public DInfo(FactoryPlaceIsleInfo _007B3483_007D)
		{
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			FcID = _007B3483_007D.FcID;
			Position = _007B3483_007D.GlobalPosition;
			Type = _007B3483_007D.Predefines.First();
		}

		public DInfo(int _007B3484_007D, Vector2 _007B3485_007D, FactoryType _007B3486_007D)
		{
			//IL_0009: Unknown result type (might be due to invalid IL or missing references)
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			FcID = _007B3484_007D;
			Position = _007B3485_007D;
			Type = _007B3486_007D;
		}

		public unsafe override string ToString()
		{
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			string text = FcID.ToString();
			Vector2 position = Position;
			return text + " " + ((object)(*(Vector2*)(&position))/*cast due to .constrained prefix*/).ToString() + Type;
		}
	}

	public static readonly Tlist<DInfo> MainServerPlaces = new Tlist<DInfo>
	{
		new DInfo(0, new Vector2(-5822f, 7503f), FactoryType.NIronMine),
		new DInfo(1, new Vector2(-5895f, 5175f), FactoryType.NWoodcutter),
		new DInfo(2, new Vector2(-3841f, 7404f), FactoryType.NResinFactory),
		new DInfo(3, new Vector2(-2143f, 7497f), FactoryType.NFarm),
		new DInfo(4, new Vector2(-5269f, 2849f), FactoryType.NResinFactory),
		new DInfo(5, new Vector2(-3583f, 1534f), FactoryType.NFarm),
		new DInfo(6, new Vector2(-5326f, -303f), FactoryType.NWoodcutter),
		new DInfo(7, new Vector2(-2778f, -3651f), FactoryType.NWoodcutter),
		new DInfo(8, new Vector2(-2449f, 4689f), FactoryType.NFarm),
		new DInfo(9, new Vector2(-1346f, 6080f), FactoryType.NWoodcutter),
		new DInfo(10, new Vector2(-1134f, 3959f), FactoryType.NWoodcutter),
		new DInfo(11, new Vector2(674f, 6092f), FactoryType.NRumFactory),
		new DInfo(12, new Vector2(1781f, 7372f), FactoryType.NIronMine),
		new DInfo(13, new Vector2(2110f, 4824f), FactoryType.NWoodcutter),
		new DInfo(14, new Vector2(-1048f, 826f), FactoryType.NCopperMine),
		new DInfo(15, new Vector2(1252f, -1081f), FactoryType.NCopperMine),
		new DInfo(16, new Vector2(1598f, 2313f), FactoryType.NIronMine),
		new DInfo(17, new Vector2(-5673f, 4226f), FactoryType.Temp_PersonalIsle),
		new DInfo(18, new Vector2(-4229f, 6058f), FactoryType.Temp_PersonalIsle),
		new DInfo(19, new Vector2(-2743f, 7429f), FactoryType.Temp_PersonalIsle),
		new DInfo(20, new Vector2(-3192f, 5534f), FactoryType.Temp_PersonalIsle),
		new DInfo(21, new Vector2(-3605f, 3465f), FactoryType.Temp_PersonalIsle),
		new DInfo(22, new Vector2(-6036f, 2732f), FactoryType.Temp_PersonalIsle),
		new DInfo(23, new Vector2(-3886f, 2502f), FactoryType.Temp_PersonalIsle),
		new DInfo(24, new Vector2(-4448f, 686f), FactoryType.Temp_PersonalIsle),
		new DInfo(25, new Vector2(-2552f, -722f), FactoryType.Temp_PersonalIsle),
		new DInfo(26, new Vector2(-2025f, -3396f), FactoryType.Temp_PersonalIsle),
		new DInfo(27, new Vector2(-2238f, 3858f), FactoryType.Temp_PersonalIsle),
		new DInfo(28, new Vector2(-1395f, 4887f), FactoryType.Temp_PersonalIsle),
		new DInfo(29, new Vector2(1525f, 6310f), FactoryType.Temp_PersonalIsle),
		new DInfo(30, new Vector2(18f, 4072f), FactoryType.Temp_PersonalIsle),
		new DInfo(31, new Vector2(-406f, 2968f), FactoryType.Temp_PersonalIsle),
		new DInfo(32, new Vector2(-2518f, 2339f), FactoryType.Temp_PersonalIsle),
		new DInfo(33, new Vector2(-630f, 1962f), FactoryType.Temp_PersonalIsle),
		new DInfo(34, new Vector2(-1261f, -463f), FactoryType.Temp_PersonalIsle),
		new DInfo(35, new Vector2(-1445f, 1726f), FactoryType.Temp_PersonalIsle),
		new DInfo(36, new Vector2(-2883f, -2675f), FactoryType.Temp_PersonalIsle),
		new DInfo(37, new Vector2(-634f, 6485f), FactoryType.Temp_PersonalIsle),
		new DInfo(38, new Vector2(5676f, -676f), FactoryType.NIceFactory),
		new DInfo(39, new Vector2(5842f, 583f), FactoryType.NIceFactory),
		new DInfo(40, new Vector2(5702f, 1501f), FactoryType.NIceFactory),
		new DInfo(41, new Vector2(5046f, 2116f), FactoryType.Temp_PersonalIsle),
		new DInfo(42, new Vector2(4488f, 3340f), FactoryType.NIronMine),
		new DInfo(43, new Vector2(4233f, 922f), FactoryType.NCopperMine),
		new DInfo(44, new Vector2(5553f, 4446f), FactoryType.Temp_PersonalIsle),
		new DInfo(45, new Vector2(4674f, 4779f), FactoryType.Temp_PersonalIsle),
		new DInfo(46, new Vector2(5905f, 6429f), FactoryType.NIceFactory),
		new DInfo(47, new Vector2(5357f, 7519f), FactoryType.NIronMine),
		new DInfo(48, new Vector2(5264f, 6627f), FactoryType.Temp_PersonalIsle),
		new DInfo(49, new Vector2(3195f, 5791f), FactoryType.NRumFactory),
		new DInfo(50, new Vector2(4549f, 7521f), FactoryType.Temp_PersonalIsle),
		new DInfo(51, new Vector2(3039f, 3322f), FactoryType.NCopperMine),
		new DInfo(52, new Vector2(3103f, 4279f), FactoryType.Temp_PersonalIsle),
		new DInfo(53, new Vector2(3698f, -100f), FactoryType.NIronMine),
		new DInfo(54, new Vector2(3066f, 197f), FactoryType.Temp_PersonalIsle),
		new DInfo(55, new Vector2(2678f, 2524f), FactoryType.Temp_PersonalIsle),
		new DInfo(56, new Vector2(2493f, -2164f), FactoryType.NWoodcutter),
		new DInfo(57, new Vector2(-1286f, -3325f), FactoryType.NResinFactory),
		new DInfo(58, new Vector2(-1336f, -4766f), FactoryType.Temp_PersonalIsle),
		new DInfo(59, new Vector2(-1448f, -5282f), FactoryType.NFarm),
		new DInfo(60, new Vector2(65f, -3102f), FactoryType.NWoodcutter),
		new DInfo(61, new Vector2(586f, -3683f), FactoryType.Temp_PersonalIsle),
		new DInfo(62, new Vector2(1165f, -3842f), FactoryType.NIronMine),
		new DInfo(63, new Vector2(425f, -5102f), FactoryType.NRumFactory),
		new DInfo(64, new Vector2(2593f, -5045f), FactoryType.NFarm),
		new DInfo(65, new Vector2(1545f, -4719f), FactoryType.Temp_PersonalIsle),
		new DInfo(66, new Vector2(3798f, -3561f), FactoryType.Temp_PersonalIsle),
		new DInfo(67, new Vector2(3678f, -4863f), FactoryType.Temp_PersonalIsle),
		new DInfo(68, new Vector2(2426f, -3266f), FactoryType.Temp_PersonalIsle),
		new DInfo(69, new Vector2(5891f, -4827f), FactoryType.NIronMine),
		new DInfo(70, new Vector2(6080f, -3869f), FactoryType.Temp_PersonalIsle),
		new DInfo(71, new Vector2(6070f, -3249f), FactoryType.NIceFactory),
		new DInfo(72, new Vector2(3838f, -2085f), FactoryType.Temp_PersonalIsle),
		new DInfo(73, new Vector2(4898f, -1902f), FactoryType.Temp_PersonalIsle),
		new DInfo(74, new Vector2(4627f, -549f), FactoryType.Temp_PersonalIsle),
		new DInfo(75, new Vector2(-6011f, 7048f), FactoryType.Temp_PersonalIsle),
		new DInfo(76, new Vector2(1001f, 7187f), FactoryType.Temp_PersonalIsle),
		new DInfo(77, new Vector2(-1803f, 5543f), FactoryType.Temp_PersonalIsle),
		new DInfo(78, new Vector2(-4336f, 5132f), FactoryType.Temp_PersonalIsle),
		new DInfo(79, new Vector2(-3848f, -408f), FactoryType.Temp_PersonalIsle),
		new DInfo(80, new Vector2(-4928f, -770f), FactoryType.Temp_PersonalIsle),
		new DInfo(81, new Vector2(746f, 1891f), FactoryType.Temp_PersonalIsle),
		new DInfo(82, new Vector2(2511f, 5641f), FactoryType.Temp_PersonalIsle),
		new DInfo(83, new Vector2(-3038f, 4696f), FactoryType.Temp_PersonalIsle),
		new DInfo(84, new Vector2(3213f, 6362f), FactoryType.Temp_PersonalIsle),
		new DInfo(85, new Vector2(280f, -2486f), FactoryType.Temp_PersonalIsle),
		new DInfo(86, new Vector2(-4592f, 7202f), FactoryType.Temp_PersonalIsle),
		new DInfo(87, new Vector2(4370f, -2809f), FactoryType.NRumFactory),
		new DInfo(88, new Vector2(5995f, 5102f), FactoryType.NIceFactory),
		new DInfo(89, new Vector2(4156f, 2931f), FactoryType.Temp_PersonalIsle),
		new DInfo(90, new Vector2(-7647f, -483f), FactoryType.NUnderground),
		new DInfo(91, new Vector2(5117f, 8911f), FactoryType.NUnderground),
		new DInfo(92, new Vector2(-7173f, 9046f), FactoryType.NUnderground),
		new DInfo(93, new Vector2(-2010f, -743f), FactoryType.NCoalMine),
		new DInfo(94, new Vector2(-3879f, -2610f), FactoryType.NCoalMine),
		new DInfo(95, new Vector2(-3551f, 3668f), FactoryType.NCoalMine),
		new DInfo(96, new Vector2(-2094f, 2243f), FactoryType.NCoalMine),
		new DInfo(97, new Vector2(692f, 3583f), FactoryType.NIronMine),
		new DInfo(98, new Vector2(64f, 1088f), FactoryType.NCoalMine),
		new DInfo(99, new Vector2(4212f, -1659f), FactoryType.NRumFactory),
		new DInfo(100, new Vector2(7094f, 3665f), FactoryType.NIceFactory)
	};
}
