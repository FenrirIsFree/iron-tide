namespace Common.Data;

public enum VoiceSoundEffect
{
	SloopsToWater,
	ToWind,
	WithWind,
	RaiseSailes,
	FreeSailes,
	AllSailes,
	SailesToWind,
	LowHp1,
	LowHp2,
	CorpusHole,
	PrepareCannons1,
	PrepareCannons2,
	SetOffLafets,
	DangerTilt,
	LiftAnchor,
	Charge,
	LowAmmo,
	WellDone,
	Fire
}
