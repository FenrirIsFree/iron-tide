using System;
using Common.Resources;

namespace Common.Data;

public class XmlAsset<TToken> : IGameResource
{
	protected short id;

	public short ID => id;

	internal XmlAsset(int _007B3488_007D)
	{
		if ((_007B3488_007D == 0 && !(this is WorldMapInfo)) || _007B3488_007D > 32767)
		{
			throw new ArgumentException("Invalid ID");
		}
		id = (short)_007B3488_007D;
	}
}
