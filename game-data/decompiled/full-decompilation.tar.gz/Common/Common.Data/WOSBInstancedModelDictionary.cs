using Common.Resources;
using Microsoft.Xna.Framework.Graphics;
using TheraEngine.Assets.Graphics;
using TheraEngine.Assets.Models;
using TheraEngine.Core;
using TheraEngine.Graphics.Models;

namespace Common.Data;

internal class WOSBInstancedModelDictionary : InstancedModelDictionary
{
	protected override bool IsServerBuild => CommonGlobal.IsServer;

	protected override bool LoadNullShapes => false;

	public WOSBInstancedModelDictionary(InstancedMaterialDictionary _007B3457_007D, ContentManager _007B3458_007D, string _007B3459_007D)
		: base(_007B3457_007D, _007B3458_007D, _007B3459_007D)
	{
	}

	protected override InstancedModel CreateModel(InstancedMaterialDictionary _007B3460_007D, Model _007B3461_007D, Model _007B3462_007D, UWOpenModel _007B3463_007D, string _007B3464_007D)
	{
		return new IsleModelInfo(_007B3460_007D, _007B3461_007D, _007B3462_007D, (_007B3463_007D == null && _007B3464_007D.Contains("factory_")) ? GameLoader.Current.FactoryShapeModel : _007B3463_007D, GameLoader.Current.EmptyShapeModel, _007B3464_007D);
	}
}
