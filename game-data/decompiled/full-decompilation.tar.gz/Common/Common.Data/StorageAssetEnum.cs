namespace Common.Data;

public enum StorageAssetEnum
{
	SimpleItem,
	removed,
	Ammo,
	PowderKeg,
	Ship_DisplayOnly,
	Cannon_DiplayOnly,
	Unit_DiplayOnly,
	Powerup_DisplayOnly
}
