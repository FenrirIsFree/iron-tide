using System;
using System.Collections.Generic;
using Common.Game;

namespace Common.Data;

internal static class Crew01_2023
{
	private static Dictionary<int, int> table = new Dictionary<int, int>
	{
		[1] = 1,
		[2] = 2,
		[3] = 3,
		[4] = 4,
		[5] = 1,
		[6] = 4,
		[7] = 3,
		[8] = 1,
		[9] = 1
	};

	public static GSI Make(GSI _007B3478_007D)
	{
		GSI gSI = new GSI();
		foreach (GSILocalPair item in (IEnumerable<GSILocalPair>)_007B3478_007D)
		{
			gSI[table[item.ID]] += item.Count * Math.Max(1, 2);
		}
		return gSI;
	}
}
