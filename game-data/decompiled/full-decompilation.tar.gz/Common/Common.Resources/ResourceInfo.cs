using System;
using Common.Data;
using Common.Game;
using CommonDataTypes;
using Microsoft.Xna.Framework.Graphics;
using TheraEngine;
using TheraEngine.Core;

namespace Common.Resources;

public class ResourceInfo : XmlAsset<ResourceInfoToken>, IStorageAsset
{
	internal string nameKey;

	private string _007B2864_007D;

	public readonly RTI MediumCost;

	public readonly float Mass;

	public readonly Texture2D IconTexture;

	public readonly ResourceIDStatus AllowStorage;

	public readonly float DestroyInHold;

	public readonly float BasicFoodValue;

	public readonly float DestroyWhenDamage;

	public readonly bool CannotBeStoredInPort;

	public readonly ResoruceDropMode DropMode;

	public readonly bool IsTradingItem;

	public readonly bool IsMap;

	public EconomyRegion TradingItemEconomyRegion;

	public bool TradingItemShouldBeOnIsle;

	public bool TradingItemShouldBeInNps;

	public string Name => Local.Current(nameKey);

	public string Description => Local.Current(_007B2864_007D);

	public bool CannotBeMovedBetweenPlayers => base.ID == 25 || base.ID == 68;

	public bool CanScaleWithBonuses => base.ID != 43 && base.ID != 67 && (!IsMap || base.ID == 72);

	public bool CantTransferWithPeacefulFlag => base.ID == 25;

	public bool IsRareItem => base.ID == 37 || base.ID == 38 || base.ID == 15 || base.ID == 40 || base.ID == 33 || base.ID == 43 || base.ID == 24 || base.ID == 67 || base.ID == 68;

	float IStorageAsset.getStorageMass => Mass;

	string IStorageAsset.getName => Name;

	string IStorageAsset.getDescription => Description;

	Texture2D IStorageAsset.getIconTexture => IconTexture;

	StorageAssetEnum IStorageAsset.getType => StorageAssetEnum.SimpleItem;

	public ResourceInfo(ContentManager _007B2860_007D, ResourceInfoToken _007B2861_007D, int _007B2862_007D)
		: base(_007B2862_007D)
	{
		nameKey = ((_007B2861_007D.ID == "removed") ? _007B2861_007D.ID : (_007B2861_007D.ID + "_name"));
		_007B2864_007D = ((_007B2861_007D.ID == "removed") ? _007B2861_007D.ID : (_007B2861_007D.ID + "_desc"));
		AllowStorage = _007B2861_007D.Status;
		MediumCost = new RTI(_007B2861_007D.MediumCost);
		Mass = _007B2861_007D.Mass;
		IconTexture = _007B2860_007D.Load<Texture2D>("_lzcommon\\Items\\Resources\\" + _007B2861_007D.IconName);
		if (!string.IsNullOrEmpty(_007B2861_007D.Effects))
		{
			string[] array = _007B2861_007D.Effects.Split(' ');
			for (int i = 0; i < array.Length; i++)
			{
				if (array[i] == "Corruption")
				{
					DestroyInHold = array[i++ + 1].ParseSafe();
				}
				else if (array[i] == "FoodValue")
				{
					BasicFoodValue = array[i++ + 1].ParseSafe();
				}
				else if (array[i] == "DestroyWhenDamage")
				{
					DestroyWhenDamage = array[i++ + 1].ParseSafe();
				}
				else if (array[i] == "CannotBeStoredInPort")
				{
					CannotBeStoredInPort = true;
				}
				else if (array[i] == "DisallowDrop")
				{
					DropMode = ResoruceDropMode.DisallowDrop;
				}
				else if (array[i] == "DisallowDropAndBoarding")
				{
					DropMode = ResoruceDropMode.DisallowDropAndBoarding;
				}
				else if (!(array[i] == "HasSpeedBonus"))
				{
					EconomyRegion result;
					if (array[i] == "TradingItem")
					{
						IsTradingItem = true;
					}
					else if (array[i] == "ShouldBeOnIsle")
					{
						TradingItemShouldBeOnIsle = true;
					}
					else if (array[i] == "ShouldBeInNps")
					{
						TradingItemShouldBeInNps = true;
					}
					else if (Enum.TryParse<EconomyRegion>(array[i], out result))
					{
						TradingItemEconomyRegion = result;
					}
					else if (array[i] == "Map")
					{
						IsMap = true;
					}
				}
			}
		}
		if (IsTradingItem && TradingItemEconomyRegion == EconomyRegion.None && base.ID != 34)
		{
			throw new InvalidOperationException("Economy region wasn't set " + nameKey);
		}
	}

	public float FoodValue(Player _007B2863_007D)
	{
		return (base.ID != 22) ? BasicFoodValue : (_007B2863_007D.UsedShip.AllowEatAnimals ? BasicFoodValue : 0f);
	}
}
