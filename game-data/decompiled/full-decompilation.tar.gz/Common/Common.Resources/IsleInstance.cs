using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Common.Game;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Components;
using UWContentPipelineExtensionRuntime;
using UWPhysicsWOSLib.Shapes;

namespace Common.Resources;

public class IsleInstance
{
	public IsleModelInfo ModelData;

	public IsleInfoToken SoruceTokenOrNull;

	public int ReplacebleXfxID = -1;

	public readonly WorldObjectID GroupID;

	public readonly Transform3D GlobalTransform;

	public Matrix GlobalTransformWorld;

	public Vector2 GlobalPosition;

	public Vector2 ModelGlobalBSxz;

	public BoundingSphere ModelGlobalBS;

	public string Preset;

	public Tlist<Vector2> TransformedShallowsPoints;

	public readonly Tlist<FenceSphere> TransformedFenceSpheres;

	public NonConvexShape2D TestConvexShape;

	public Tlist<Vector3> UnitsPositionCloud;

	public readonly float AdditionalScale;

	public IsleInstance(WorldObjectID _007B3254_007D, IsleBaseInfoToken _007B3255_007D, WorldMapInfo _007B3256_007D, IsleModelInfo _007B3257_007D, int _007B3258_007D, IsleInfoToken _007B3259_007D = null)
		: this(_007B3254_007D, _007B3255_007D.AdditionalScale, DecomposePosition(_007B3255_007D.LocalPosition).XY() * ((_007B3256_007D.IsWorldmap || _007B3256_007D.IsEducationMap) ? 0.82f : 1f), DecomposePosition(_007B3255_007D.LocalPosition).Z * ((_007B3256_007D.IsWorldmap || _007B3256_007D.IsEducationMap) ? 0.82f : 1f), _007B3255_007D.Rotation, _007B3268_007D: true, _007B3257_007D)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		if (ModelData.Path.Contains("reef_cluster") && _007B3258_007D == 22)
		{
			_007B3258_007D = 7;
		}
		if (ModelData.Path.Contains("reefunderwater"))
		{
			_007B3258_007D = -1;
		}
		ReplacebleXfxID = _007B3258_007D;
		SoruceTokenOrNull = _007B3259_007D;
	}

	public IsleInstance(DynamicBuildCreatePacket _007B3260_007D, bool _007B3261_007D)
		: this(_007B3260_007D.Flags, 1f, _007B3260_007D.Position, 0f, _007B3260_007D.Axis, _007B3261_007D, Gameplay.DyanmicBuildingsTable.Array[_007B3260_007D.ModelID].Model)
	{
	}//IL_000d: Unknown result type (might be due to invalid IL or missing references)


	public static float Old_ExtraScale(string _007B3262_007D)
	{
		if (_007B3262_007D.Contains("port_center_big_1"))
		{
			return 1.05f;
		}
		if (_007B3262_007D.Contains("port_Center_big_2"))
		{
			return 0.95f;
		}
		if (_007B3262_007D.Contains("port_center_arab_small"))
		{
			return 1.1f;
		}
		if (_007B3262_007D.Contains("personal_isle"))
		{
			return 1.1f;
		}
		return 1f;
	}

	public IsleInstance(WorldObjectID _007B3263_007D, float _007B3264_007D, Vector2 _007B3265_007D, float _007B3266_007D, float _007B3267_007D, bool _007B3268_007D, IsleModelInfo _007B3269_007D)
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c1: Unknown result type (might be due to invalid IL or missing references)
		if (_007B3264_007D == 0f)
		{
			throw new ArgumentException("additionalScale");
		}
		_007B3264_007D *= Old_ExtraScale(_007B3269_007D.Model.ModelName);
		AdditionalScale = _007B3264_007D;
		ModelData = _007B3269_007D;
		GroupID = _007B3263_007D;
		GlobalPosition = _007B3265_007D;
		GlobalTransform = new Transform3D(new Vector3(_007B3265_007D.X, _007B3266_007D * 1.0365855f, _007B3265_007D.Y), new Vector3(0f, _007B3267_007D, 0f), Gcc.GetExactIsleScale(ModelData.Path) * _007B3264_007D);
		GlobalTransformWorld = GlobalTransform.CreateWorldMatrix();
		BoundingSphere commonSphere = _007B3269_007D.Model.CommonSphere;
		ModelGlobalBS = ((BoundingSphere)(ref commonSphere)).Transform(GlobalTransform.CreateWorldMatrix());
		ModelGlobalBSxz = new Vector2(ModelGlobalBS.Center.X, ModelGlobalBS.Center.Z);
		TransformedFenceSpheres = new Tlist<FenceSphere>();
		if (ModelData.NpcFencesRaw.Size > 0)
		{
			BoundingSphere val = default(BoundingSphere);
			BoundingSphere val2 = default(BoundingSphere);
			foreach (var item in (IEnumerable<(Vector2, float)>)ModelData.NpcFencesRaw)
			{
				((BoundingSphere)(ref val))._002Ector(new Vector3(item.Item1.X, 0f, item.Item1.Y), item.Item2);
				((BoundingSphere)(ref val)).Transform(ref GlobalTransformWorld, ref val2);
				TransformedFenceSpheres.Add(new FenceSphere(new Vector2(val2.Center.X, val2.Center.Z), val2.Radius));
			}
		}
		else
		{
			int num = 3;
			BoundingSphere shapeModelBs = ModelData.ShapeModelBs;
			BoundingSphere val3 = default(BoundingSphere);
			((BoundingSphere)(ref shapeModelBs)).Transform(ref GlobalTransformWorld, ref val3);
			TransformedFenceSpheres.Add(new FenceSphere(new Vector2(val3.Center.X, val3.Center.Z), val3.Radius + (float)num));
		}
		ModelData.ApplyWithWorker(delegate
		{
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0053: Unknown result type (might be due to invalid IL or missing references)
			//IL_0058: Unknown result type (might be due to invalid IL or missing references)
			//IL_005d: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0075: Unknown result type (might be due to invalid IL or missing references)
			//IL_0076: Unknown result type (might be due to invalid IL or missing references)
			//IL_007b: Unknown result type (might be due to invalid IL or missing references)
			if (ModelData.ShallowPointsRaw != null)
			{
				TransformedShallowsPoints = new Tlist<Vector2>(ModelData.ShallowPointsRaw.Size);
				for (int i = 0; i < ModelData.ShallowPointsRaw.Size; i++)
				{
					Vector3 val4 = Vector3.Transform(ModelData.ShallowPointsRaw.Array[i].X0Y(), GlobalTransformWorld);
					if (val4.Y > -2f)
					{
						TransformedShallowsPoints.Add(val4.XZ());
					}
				}
				if (TransformedShallowsPoints.Size == 0)
				{
					TransformedShallowsPoints = null;
				}
			}
		});
		UnitsPositionCloud = new Tlist<Vector3>();
		ModelHardpoint[] externalHardpoints = _007B3269_007D.Model.ExternalHardpoints;
		foreach (ModelHardpoint modelHardpoint in externalHardpoints)
		{
			if (modelHardpoint.HardpointID == WorldOfSeaBattleHardpointID.ShipUnit1 || modelHardpoint.HardpointID == WorldOfSeaBattleHardpointID.ShipUnit2 || modelHardpoint.HardpointID == WorldOfSeaBattleHardpointID.ShipUnit3)
			{
				UnitsPositionCloud.Add(((Matrix)(ref modelHardpoint.Transform)).Translation);
			}
		}
	}

	public static string ComposePosition(Vector2 _007B3270_007D, float _007B3271_007D)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		return Math.Round(_007B3270_007D.X, 2) + " " + Math.Round(_007B3270_007D.Y, 2) + ((_007B3271_007D == 0f) ? "" : (" " + Math.Round(_007B3271_007D, 2)));
	}

	public static Vector3 DecomposePosition(string _007B3272_007D)
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		string[] array = _007B3272_007D.Split(' ');
		return new Vector3(array[0].ParseSafe(), array[1].ParseSafe(), (array.Length == 3) ? array[2].ParseSafe() : 0f);
	}

	[CompilerGenerated]
	private void _007B3273_007D()
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		if (ModelData.ShallowPointsRaw == null)
		{
			return;
		}
		TransformedShallowsPoints = new Tlist<Vector2>(ModelData.ShallowPointsRaw.Size);
		for (int i = 0; i < ModelData.ShallowPointsRaw.Size; i++)
		{
			Vector3 val = Vector3.Transform(ModelData.ShallowPointsRaw.Array[i].X0Y(), GlobalTransformWorld);
			if (val.Y > -2f)
			{
				TransformedShallowsPoints.Add(val.XZ());
			}
		}
		if (TransformedShallowsPoints.Size == 0)
		{
			TransformedShallowsPoints = null;
		}
	}
}
