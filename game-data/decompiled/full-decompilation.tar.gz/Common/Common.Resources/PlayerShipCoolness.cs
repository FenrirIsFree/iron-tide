namespace Common.Resources;

public enum PlayerShipCoolness
{
	Default,
	Unique,
	Elite,
	Empire
}
