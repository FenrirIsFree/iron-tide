namespace Common.Resources;

public class NpcGenerator
{
	public string Name;

	public int Generation;

	public int FleetSize = 1;

	public NpcType Class;

	public float SpecialSpawnIntervalMin;

	public NpcLocation Location;

	public float Hp;

	public float Armor;

	public float Mobility;

	public float AttackDistance;

	public int AttackID;

	public float DamagePerShot;

	public float ReloadCannonTime;

	public float CannonsAngle;

	public float Speed;

	public NpcVisualEffect Visual;

	public int Ship;

	public (NpcGenerator, int)[] DefenceWaves;

	public float? OverrideMortarDamage;

	public int? OverrideCrewCount;

	public object Tag;

	public NpcEducationMap EducationMapScenario;
}
