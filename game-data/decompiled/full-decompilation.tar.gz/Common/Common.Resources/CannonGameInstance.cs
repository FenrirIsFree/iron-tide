using System;
using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Resources;

public class CannonGameInstance : IMPSerializable
{
	public byte InfoID;

	public ushort RemainReserve;

	public CannonGameInfo Info;

	public int MortarResourceLimit => Gameplay.DestroyMortarResource(Info);

	public bool IsWholeMortar => RemainReserve == MortarResourceLimit;

	public float MortarResourceFactor => (float)(int)RemainReserve / (float)MortarResourceLimit;

	public CannonGameInstance()
	{
	}

	public CannonGameInstance(int _007B2285_007D, int _007B2286_007D)
		: this((byte)_007B2285_007D, (ushort)_007B2286_007D)
	{
	}

	public CannonGameInstance(byte _007B2287_007D, ushort _007B2288_007D)
	{
		InfoID = _007B2287_007D;
		RemainReserve = _007B2288_007D;
		Info = Gameplay.CannonsGameInfo.FromID(InfoID);
	}

	private void _007B2289_007D(WriterExtern _007B2290_007D)
	{
		_007B2290_007D.WriteByte(InfoID);
		_007B2290_007D.WriteStruct<ushort>(RemainReserve);
	}

	private void _007B2291_007D(WriterExtern _007B2292_007D)
	{
		InfoID = _007B2292_007D.ReadByte();
		_007B2292_007D.ReadStruct<ushort>(ref RemainReserve);
		Info = Gameplay.CannonsGameInfo.FromID(InfoID);
		RemainReserve = (ushort)Math.Min(MortarResourceLimit, RemainReserve);
	}
}
