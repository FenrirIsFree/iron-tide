namespace Common.Resources;

public enum WorldObjectID
{
	WPort,
	WTradePort,
	WAltar,
	WSomeObject,
	ArenaTower,
	ArenaFort,
	WGuildFort,
	WGuildFortTower,
	WGuildAvanpost,
	WorldFort
}
