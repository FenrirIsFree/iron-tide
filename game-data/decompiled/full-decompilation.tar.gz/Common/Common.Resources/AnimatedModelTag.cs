using TheraEngine.Graphics.Models;

namespace Common.Resources;

public class AnimatedModelTag
{
	public PivotInfo Pivot;

	public SailRollData SailInfo;

	public AnimatedModelTag(PivotInfo _007B2424_007D, SailRollData _007B2425_007D)
	{
		Pivot = _007B2424_007D;
		SailInfo = _007B2425_007D;
	}

	public static void Append(UWModel _007B2426_007D, PivotInfo _007B2427_007D)
	{
		if (_007B2426_007D.Tag is AnimatedModelTag animatedModelTag)
		{
			animatedModelTag.Pivot = _007B2427_007D;
		}
		else
		{
			_007B2426_007D.Tag = new AnimatedModelTag(_007B2427_007D, default(SailRollData));
		}
	}

	public static void Append(UWModel _007B2428_007D, SailRollData _007B2429_007D)
	{
		if (_007B2428_007D.Tag is AnimatedModelTag animatedModelTag)
		{
			animatedModelTag.SailInfo = _007B2429_007D;
		}
		else
		{
			_007B2428_007D.Tag = new AnimatedModelTag(null, _007B2429_007D);
		}
	}
}
