using System;
using Common.Data;
using Common.Game;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Components;

namespace Common.Resources;

public class PbsBuildingPlaceInfo
{
	public IslePortInfo AssociatedPort;

	public Vector2 Position;

	public float Axis;

	public WorldObjectID GroupID;

	public int PlaceIDInPort;

	public int ReplaceTerrainID;

	public float MaximalRadius;

	public float MaximalRadiusP2;

	private Transform3D _007B2999_007D;

	private BoundingSphere _007B3000_007D;

	public float EntryPointPerRadius => _007B3000_007D.Radius;

	public Vector2 EntryPointPier => _007B3000_007D.Center.XZ();

	public float TowerCapturingRadius => 30f;

	public PbsBuildingPlaceInfo(int _007B2993_007D, IslePortInfo _007B2994_007D, Vector2 _007B2995_007D, float _007B2996_007D, WorldObjectID _007B2997_007D, int _007B2998_007D)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		PlaceIDInPort = _007B2993_007D;
		Position = _007B2995_007D;
		AssociatedPort = _007B2994_007D;
		Axis = _007B2996_007D;
		GroupID = _007B2997_007D;
		ReplaceTerrainID = _007B2998_007D;
		MaximalRadius = ((GroupID == WorldObjectID.WGuildFortTower) ? Gameplay.DyanmicBuildingsDictionary[InitialDynamicBuildingId.FortTowerCannons].Array[0].Model.ShapeModelBs.Radius : Gameplay.DyanmicBuildingsDictionary[InitialDynamicBuildingId.FortMain].Array[3].Model.ShapeModelBs.Radius);
		MaximalRadiusP2 = MaximalRadius * MaximalRadius;
		_007B2999_007D = new Transform3D(new Vector3(Position.X, 0f, Position.Y), new Vector3(0f, Axis, 0f), Gcc.GetExactIsleScale(_007B2997_007D.ToString()));
		if (_007B2997_007D == WorldObjectID.WGuildFort)
		{
			int num = 0;
			_007B3000_007D = Gameplay.DyanmicBuildingsTable.Array[num].Model.Connections["ConnectionEntryPierZone"].CommonSphere;
			_007B3000_007D = ((BoundingSphere)(ref _007B3000_007D)).Transform(_007B2999_007D.CreateWorldMatrix());
			if (_007B3000_007D.Radius == 0f)
			{
				throw new Exception();
			}
		}
	}

	public override string ToString()
	{
		return $"id {PlaceIDInPort} {GroupID}";
	}
}
