using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UWPhysicsWOSLib.Shapes;

namespace Common.Resources;

public class CorpusHitbox : IShipHitbox
{
	[CompilerGenerated]
	private sealed class _003CEnumerateBaseShapes_003Ed__9 : IEnumerable<BoxShape>, IEnumerable, IEnumerator<BoxShape>, IEnumerator, IDisposable
	{
		private int _007B2467_007D;

		private BoxShape _007B2468_007D;

		private int _007B2469_007D;

		public CorpusHitbox _003C_003E4__this;

		BoxShape IEnumerator<BoxShape>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B2468_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B2468_007D;
			}
		}

		[DebuggerHidden]
		public _003CEnumerateBaseShapes_003Ed__9(int _007B2462_007D)
		{
			_007B2467_007D = _007B2462_007D;
			_007B2469_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B2463_007D()
		{
			_007B2467_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2463}
			this._007B2463_007D();
		}

		private bool _007B2464_007D()
		{
			switch (_007B2467_007D)
			{
			default:
				return false;
			case 0:
				_007B2467_007D = -1;
				_007B2468_007D = _003C_003E4__this.Shape;
				_007B2467_007D = 1;
				return true;
			case 1:
				_007B2467_007D = -1;
				return false;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2464}
			return this._007B2464_007D();
		}

		[DebuggerHidden]
		private void _007B2465_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2465}
			this._007B2465_007D();
		}

		[DebuggerHidden]
		IEnumerator<BoxShape> IEnumerable<BoxShape>.GetEnumerator()
		{
			_003CEnumerateBaseShapes_003Ed__9 result;
			if (_007B2467_007D == -2 && _007B2469_007D == Environment.CurrentManagedThreadId)
			{
				_007B2467_007D = 0;
				result = this;
			}
			else
			{
				result = new _003CEnumerateBaseShapes_003Ed__9(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			return result;
		}

		[DebuggerHidden]
		private IEnumerator _007B2466_007D()
		{
			return ((IEnumerable<BoxShape>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2466}
			return this._007B2466_007D();
		}
	}

	public byte CollisionNodeID;

	public BoxShape Shape;

	public TriangleMeshShape Hitmesh;

	public byte NodeID
	{
		get
		{
			return CollisionNodeID;
		}
		set
		{
			CollisionNodeID = value;
		}
	}

	public HitboxType Type => HitboxType.Corpus;

	public CorpusHitbox(BoxShape _007B2458_007D, TriangleMeshShape _007B2459_007D)
	{
		Shape = _007B2458_007D;
		Hitmesh = _007B2459_007D;
	}

	[IteratorStateMachine(typeof(_003CEnumerateBaseShapes_003Ed__9))]
	public IEnumerable<BoxShape> EnumerateBaseShapes()
	{
		//yield-return decompiler failed: Method not found
		return new _003CEnumerateBaseShapes_003Ed__9(-2)
		{
			_003C_003E4__this = this
		};
	}
}
