using Common.Data;
using Common.Game;
using CommonDataTypes;

namespace Common.Resources;

public class ArenaUpgradeInfo : XmlAsset<ArenaUpgradeInfoToken>
{
	public readonly int MaxQuantity;

	public ShipBonus Effect;

	public float Probability;

	public ArenaUpgradeInfo(ArenaUpgradeInfoToken _007B3310_007D, int _007B3311_007D)
		: base(_007B3311_007D)
	{
		MaxQuantity = _007B3310_007D.MaxQuantity;
		Effect = ShipUpgradeInfo.ParseHelper(_007B3310_007D.Effects)[0];
		Probability = _007B3310_007D.Probability;
	}

	public (int used, int max) GetQuantity(Player _007B3312_007D)
	{
		return (used: _007B3312_007D.UsedShipPlayer.DynamicBonus.CountArenaUpgrade(this), max: MaxQuantity);
	}
}
