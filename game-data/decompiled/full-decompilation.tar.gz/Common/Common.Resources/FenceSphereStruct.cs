using Microsoft.Xna.Framework;

namespace Common.Resources;

public struct FenceSphereStruct
{
	public Vector2 C;

	public float R;

	public FenceSphereStruct(in Vector2 _007B3233_007D, float _007B3234_007D)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		C = _007B3233_007D;
		R = _007B3234_007D;
	}
}
