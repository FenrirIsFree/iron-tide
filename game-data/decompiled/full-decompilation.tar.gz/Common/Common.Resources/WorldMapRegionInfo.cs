using System;
using Common.Game;
using Microsoft.Xna.Framework;

namespace Common.Resources;

public class WorldMapRegionInfo
{
	public enum FeatureType
	{
		None,
		NorthRegion
	}

	public static readonly WorldMapRegionInfo IdentityRegion = new WorldMapRegionInfo(0, Vector2.Zero, 1f, "removed", 3, Color.Black, EconomyRegion.None);

	private string _007B3230_007D;

	public readonly FeatureType Feature;

	public readonly int LevelInt;

	public readonly int ID;

	public readonly Vector2 CenterPos;

	public readonly Color TextureMask;

	public EconomyRegion ItemsEconomyReigion;

	internal float AreaFactor;

	public string Name => Local.Current(_007B3230_007D);

	public float Level => (float)LevelInt / 7f;

	public WorldMapRegionInfo(int _007B3222_007D, Vector2 _007B3223_007D, float _007B3224_007D, string _007B3225_007D, int _007B3226_007D, Color _007B3227_007D, EconomyRegion _007B3228_007D, FeatureType _007B3229_007D = FeatureType.None)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		ID = _007B3222_007D;
		CenterPos = _007B3223_007D;
		_007B3230_007D = _007B3225_007D;
		Feature = _007B3229_007D;
		LevelInt = _007B3226_007D;
		AreaFactor = _007B3224_007D;
		TextureMask = _007B3227_007D;
		ItemsEconomyReigion = _007B3228_007D;
		if (string.IsNullOrEmpty(Name))
		{
			throw new InvalidOperationException();
		}
	}
}
