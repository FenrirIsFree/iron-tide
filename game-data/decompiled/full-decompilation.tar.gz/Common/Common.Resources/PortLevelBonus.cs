using System;
using System.Collections.Generic;
using CommonDataTypes;

namespace Common.Resources;

public class PortLevelBonus
{
	public readonly PortLevelBonusType Type;

	public readonly PortBonusCriteria Criteria;

	private readonly Dictionary<int, int> _007B3412_007D;

	public PortLevelBonus(PortLevelBonusToken _007B3408_007D)
	{
		Criteria = PortBonusCriteria.None;
		string[] array = _007B3408_007D.Receiver.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
		foreach (string value in array)
		{
			Criteria |= Enum.Parse<PortBonusCriteria>(value);
		}
		Type = _007B3408_007D.Type;
		_007B3412_007D = ParseCustomLevelValues(_007B3408_007D.LevelValues);
		static Dictionary<int, int> ParseCustomLevelValues(string _007B3411_007D)
		{
			Dictionary<int, int> dictionary = new Dictionary<int, int>();
			if (!string.IsNullOrEmpty(_007B3411_007D))
			{
				string[] array2 = _007B3411_007D.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
				for (int j = 0; j < array2.Length; j++)
				{
					dictionary.Add(j + 1, int.Parse(array2[j]));
				}
			}
			return dictionary;
		}
	}

	public float GetValue(int _007B3409_007D, bool _007B3410_007D)
	{
		_007B3410_007D &= Type.IsPercent();
		return (float)_007B3412_007D[_007B3409_007D] / (_007B3410_007D ? 100f : 1f);
	}
}
