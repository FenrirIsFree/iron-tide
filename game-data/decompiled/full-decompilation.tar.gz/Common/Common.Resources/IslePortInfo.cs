using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using Common.Account;
using Common.Data;
using Common.Game;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Graphics.Models;
using TheraEngine.Helpers;
using UWContentPipelineExtensionRuntime;

namespace Common.Resources;

public class IslePortInfo : IsleInstance
{
	public readonly int PortID;

	public readonly ShipPositionInfo Entry;

	public readonly float GlobalEntryRadius;

	public readonly Vector2 EntryPos;

	public Tlist<Vector2> BouysPositionsGlobal;

	public readonly int BuildShipRangs;

	public readonly PortType Type;

	public readonly string portNameKey;

	public WorldMapRegionInfo NearRegion;

	public readonly LinkedDictionrary<PortTipConnection, Vector3> VisualTips;

	public readonly Vector3 MiddleInfrastructurePostion;

	public readonly bool HasWaterConsumption;

	public readonly int PortBattleTeamLimitation;

	public readonly bool CaptureWithoutWindow;

	public readonly bool LongWindowAnd24hPb;

	public ResourceInfo? PbsManufacture;

	public readonly FractionID LegalFraction;

	public readonly Tlist<IslePortPharosInfo> ReferencedPharosesTransformed = new Tlist<IslePortPharosInfo>();

	public Vector2 FortPosition;

	public readonly Dictionary<PbsBatlleSide, PbsAvanpostShortInfo> PbRespawn = new Dictionary<PbsBatlleSide, PbsAvanpostShortInfo>();

	public readonly Dictionary<int, PbsBuildingPlaceInfo> PbSystem = new Dictionary<int, PbsBuildingPlaceInfo>(1000);

	public readonly bool IsStronghold;

	public readonly bool IsArabPort;

	public readonly bool IsStartPort;

	public readonly GSI LiveTrading;

	public GSI ShopResources;

	public GSI SellResources;

	public readonly int ShallowUpperRang;

	public readonly float Leveling;

	public readonly Tlist<IslePortInfo> PortsToJump;

	public readonly Tlist<OpenWorldFlag> FlagsAllowedToEnter;

	public readonly Tlist<OpenWorldFlag> FlagsAllowedToChoose;

	public int FixedPortLevel;

	internal readonly PortCaptureStatus FixedLevelBonuses;

	internal string Flags;

	public string PortName => Local.Current(portNameKey);

	public string PortNameShort => Local.Current(portNameKey + "_f");

	public bool AllowCapture => Type != PortType.Event && Type != PortType.NeutralBay && Type != PortType.PirateBay && !IsArabPort;

	public int PbWindowDuration => 2;

	public bool AllowToVisitEmpireShipbuilder => ShallowUpperRang <= 4 && Type != PortType.NeutralBay && Type != PortType.PirateBay;

	public bool HasGoodsTradingPage => Type != PortType.PirateBay && Type != PortType.Event;

	public bool LessGoodsTradingPage => Type == PortType.NeutralBay;

	public float InternalTradingTax => (Type != PortType.NeutralBay) ? (IsArabPort ? 0.06f : ((Type == PortType.PirateBay) ? 0.04f : 0.08f)) : (IsStartPort ? 0.08f : 0.12f);

	public bool AllowCapturePiratePort => Type == PortType.PirateBay;

	internal bool MustHavePharoses => Type != PortType.PirateBay;

	public int MooringChargeBasic(MooringChargePolicy _007B2957_007D, int _007B2958_007D, int _007B2959_007D)
	{
		if (!AllowCapture || _007B2957_007D == MooringChargePolicy.Free)
		{
			return 0;
		}
		int num;
		int num2;
		switch (_007B2957_007D)
		{
		default:
			throw new NotImplementedException();
		case MooringChargePolicy.Extreme:
			num = 300;
			num2 = 1800;
			break;
		case MooringChargePolicy.High:
			num = 100;
			num2 = 900;
			break;
		case MooringChargePolicy.Normal:
			num = 30;
			num2 = 300;
			break;
		}
		if (1 == 0)
		{
		}
		float num3 = _007B2958_007D switch
		{
			7 => 0f, 
			6 => 0.15f, 
			5 => 0.25f, 
			4 => 0.4f, 
			3 => 0.6f, 
			2 => 0.8f, 
			1 => 1f, 
			_ => 0f, 
		};
		if (1 == 0)
		{
		}
		float num4 = num3;
		float num5 = ((_007B2959_007D >= 30) ? 1f : ((_007B2959_007D >= 25) ? 0.9f : ((_007B2959_007D >= 20) ? 0.8f : ((_007B2959_007D >= 15) ? 0.75f : ((_007B2959_007D >= 10) ? 0.7f : ((_007B2959_007D >= 5) ? 0.65f : 0.6f))))));
		float num6 = MathHelper.Lerp((float)num, (float)num2, num4) * num5;
		return (int)Math.Round(num6 / 10f) * 10;
	}

	public bool MakeLockedForPlayer(PlayerAccount _007B2960_007D)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		if (_007B2960_007D.ResourcesInPorts.PortHasResources(PortID) || _007B2960_007D.FogOfWar.IsOpened(EntryPos) || _007B2960_007D.Quests.ProgressRunningQuests.Any((QuestRunningProgress _007B2969_007D) => _007B2969_007D.Info.FirstStep is QuestTransferOrder questTransferOrder && questTransferOrder.TargetAsPort == this))
		{
			return false;
		}
		if (_007B2960_007D.StartPortId == PortID)
		{
			return false;
		}
		return true;
	}

	internal IslePortInfo(IsleInfoToken _007B2961_007D, IslePortInfoToken _007B2962_007D, WorldMapInfo _007B2963_007D, IsleModelInfo _007B2964_007D, int _007B2965_007D)
		: base(WorldObjectID.WPort, _007B2961_007D, _007B2963_007D, _007B2964_007D, _007B2961_007D.Terrain, _007B2961_007D)
	{
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0403: Unknown result type (might be due to invalid IL or missing references)
		//IL_0408: Unknown result type (might be due to invalid IL or missing references)
		//IL_041f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0424: Unknown result type (might be due to invalid IL or missing references)
		//IL_043b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0440: Unknown result type (might be due to invalid IL or missing references)
		//IL_0457: Unknown result type (might be due to invalid IL or missing references)
		//IL_045c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0474: Unknown result type (might be due to invalid IL or missing references)
		//IL_0479: Unknown result type (might be due to invalid IL or missing references)
		//IL_0483: Unknown result type (might be due to invalid IL or missing references)
		//IL_0488: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_0244: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		//IL_025a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0512: Unknown result type (might be due to invalid IL or missing references)
		//IL_0519: Unknown result type (might be due to invalid IL or missing references)
		//IL_051e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0523: Unknown result type (might be due to invalid IL or missing references)
		//IL_0528: Unknown result type (might be due to invalid IL or missing references)
		//IL_052a: Unknown result type (might be due to invalid IL or missing references)
		//IL_052b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0284: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_029a: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		//IL_0313: Unknown result type (might be due to invalid IL or missing references)
		//IL_0318: Unknown result type (might be due to invalid IL or missing references)
		//IL_0342: Unknown result type (might be due to invalid IL or missing references)
		//IL_0353: Unknown result type (might be due to invalid IL or missing references)
		//IL_0358: Unknown result type (might be due to invalid IL or missing references)
		//IL_0382: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d6: Unknown result type (might be due to invalid IL or missing references)
		UWModel uWModel = _007B2964_007D.Connections["ConnectionEntryPoint"];
		Vector3 val = default(Vector3);
		val.X = uWModel.CommonSphere.Center.X;
		val.Y = 0f;
		val.Z = uWModel.CommonSphere.Center.Z;
		if (!ModelData.Model.ExternalHardpoints.Any((ModelHardpoint _007B2974_007D) => _007B2974_007D.HardpointID == WorldOfSeaBattleHardpointID.HPAnchoredShip))
		{
			throw new InvalidOperationException(_007B2964_007D.Path + "doesn't have anchored ships");
		}
		VisualTips = new LinkedDictionrary<PortTipConnection, Vector3>();
		foreach (KeyValuePair<string, UWModel> connection in ModelData.Connections)
		{
			Vector3 val2 = GlobalTransform.Transform3X3(connection.Value.CommonSphere.Center);
			if (connection.Key == "ConnectionVerf")
			{
				VisualTips.Add(PortTipConnection.Verfy, val2);
			}
			if (connection.Key == "ConnectionTrade")
			{
				VisualTips.Add(PortTipConnection.Trade, val2);
			}
			if (connection.Key == "ConnectionWork")
			{
				VisualTips.Add(PortTipConnection.Workshop, val2);
			}
			if (connection.Key == "ConnectionShop")
			{
				VisualTips.Add(PortTipConnection.RealShop, val2);
			}
			if (connection.Key == "ConnectionModeWorld")
			{
				Vector3 _007B14806_007D = Vector3.Transform(connection.Value.CommonSphere.Center - val, Matrix.CreateRotationY(0.2f)) + val;
				_007B14806_007D = GlobalTransform.Transform3X3(_007B14806_007D);
				VisualTips.Add(PortTipConnection.ExitWorld, val2 + new Vector3(0f, 12f, 0f));
				VisualTips.Add(PortTipConnection.ExitWorldLighthouse, _007B14806_007D + new Vector3(0f, 12f, 0f));
			}
			if (connection.Key == "ConnectionModeArena")
			{
				VisualTips.Add(PortTipConnection.OverseasTrader, val2 + new Vector3(0f, 13f, 0f));
			}
			if (connection.Key == "ConnectionModePassing")
			{
				VisualTips.Add(PortTipConnection.PirateTrader, val2 + new Vector3(0f, 10f, 0f));
			}
			if (connection.Key == "ConnectionTaverna")
			{
				VisualTips.Add(PortTipConnection.Taverna, val2 + new Vector3(0f, 2f, 0f));
			}
			if (connection.Key.Contains("ConnectionQuestUnit"))
			{
				VisualTips.Add(PortTipConnection.QuestUnit, val2 + new Vector3(0f, 1.5f, 0f));
			}
			if (connection.Key == "ConnectionTownHall")
			{
				VisualTips.Add(PortTipConnection.Hq, val2);
			}
		}
		if (UnitsPositionCloud.Size == 0)
		{
			throw new InvalidOperationException(_007B2964_007D.Path + "doesn't have units cloud for creating people (ShipUnit)");
		}
		MiddleInfrastructurePostion = new Tlist<Vector3>
		{
			VisualTips[PortTipConnection.Verfy].First(),
			VisualTips[PortTipConnection.Trade].First(),
			VisualTips[PortTipConnection.Workshop].First(),
			VisualTips[PortTipConnection.RealShop].First(),
			VisualTips[PortTipConnection.Taverna].First(),
			VisualTips[PortTipConnection.Hq].First()
		}.GetMiddlePos();
		if (VisualTips[PortTipConnection.PirateTrader].Size == 0 || VisualTips[PortTipConnection.OverseasTrader].Size == 0 || VisualTips[PortTipConnection.ExitWorld].Size == 0 || VisualTips[PortTipConnection.ExitWorldLighthouse].Size == 0 || VisualTips[PortTipConnection.QuestUnit].Size == 0)
		{
			throw new InvalidOperationException("Port doesn't have some connections: " + ModelData.Path);
		}
		Vector2 _007B5936_007D = (EntryPos = Vector3.Transform(val, GlobalTransform.CreateWorldMatrix()).XZ());
		GlobalEntryRadius = (float)((Type == PortType.PirateBay) ? 410 : ((Type == PortType.City) ? 340 : 240)) * 0.3f * 0.85f;
		Type = _007B2962_007D.Type;
		portNameKey = _007B2962_007D.PortName;
		BuildShipRangs = _007B2962_007D.BuildShipRangs;
		PortBattleTeamLimitation = ((_007B2962_007D.PbsTeamLimitation.Length == 0) ? 20 : int.Parse(_007B2962_007D.PbsTeamLimitation));
		byte b = _007B2963_007D.Shallows.Get(in _007B5936_007D);
		ShallowUpperRang = ((b == 0) ? (-1) : b);
		Vector2 _007B5191_007D = _007B5936_007D;
		Vector2 val3 = MiddleInfrastructurePostion.XZ();
		Entry = new ShipPositionInfo(_007B5191_007D, Geometry.GetRotate(ref val3, ref _007B5936_007D));
		PortID = _007B2965_007D;
		IsStartPort = _007B2962_007D.Flags.Contains("StartPort");
		CaptureWithoutWindow = _007B2962_007D.Flags.Contains("CaptureWithoutWindow");
		LongWindowAnd24hPb = CaptureWithoutWindow;
		CaptureWithoutWindow = false;
		IsStronghold = _007B2962_007D.Flags.Contains("Stronghold");
		IsArabPort = _007B2962_007D.Flags.Contains("Arab");
		Flags = _007B2962_007D.Flags;
		HasWaterConsumption = AllowCapture && !_007B2962_007D.Flags.Contains("NearIce");
		if (ShallowUpperRang >= 3)
		{
			Leveling = 0.4f + (6f - (float)BuildShipRangs) / 5f * 0.6f;
		}
		else
		{
			Leveling = 0.4f + (6f - (float)Math.Max(1, BuildShipRangs - 1)) / 5f * 0.6f;
		}
		if (BuildShipRangs == -1)
		{
			throw new InvalidOperationException();
		}
		if (BuildShipRangs < ShallowUpperRang)
		{
			GameLoader.Current.AddImportant("BuildShipRangs < ShallowUpperRang " + PortName);
		}
		PortsToJump = new Tlist<IslePortInfo>();
		FlagsAllowedToEnter = new Tlist<OpenWorldFlag>();
		FlagsAllowedToChoose = new Tlist<OpenWorldFlag>();
		if (Type != PortType.PirateBay)
		{
			FlagsAllowedToEnter.Add(OpenWorldFlag.Peaceful);
			if (!Gameplay.IsInHazardZone(in Entry.Position))
			{
				FlagsAllowedToChoose.Add(OpenWorldFlag.Peaceful);
			}
		}
		FlagsAllowedToEnter.Add(OpenWorldFlag.Trader);
		FlagsAllowedToChoose.Add(OpenWorldFlag.Trader);
		FlagsAllowedToEnter.Add(OpenWorldFlag.War);
		FlagsAllowedToChoose.Add(OpenWorldFlag.War);
		FlagsAllowedToEnter.Add(OpenWorldFlag.Pirate);
		FlagsAllowedToChoose.Add(OpenWorldFlag.Pirate);
		FlagsAllowedToEnter.Add(OpenWorldFlag.Legendary);
		FlagsAllowedToChoose.Add(OpenWorldFlag.Legendary);
		FlagsAllowedToEnter.Add(OpenWorldFlag.NoFlag);
		FlagsAllowedToChoose.Add(OpenWorldFlag.NoFlag);
		int num = -1;
		if (!string.IsNullOrEmpty(_007B2962_007D.ProducedResourceId))
		{
			num = Gameplay.GetResIDByAnnotation(_007B2962_007D.ProducedResourceId);
		}
		PbsManufacture = ((num == -1) ? null : Gameplay.ItemsInfo.FromID(num));
		LiveTrading = WosbTrading.GetPortMiddles(Type, num);
		if (AllowCapture || _007B2962_007D.Flags.Contains("NearIce"))
		{
			LiveTrading.Add(WosbTrading.waterMiddles);
		}
		if (!string.IsNullOrEmpty(_007B2962_007D.LegalFraction))
		{
			LegalFraction = (FractionID)Enum.Parse(typeof(FractionID), _007B2962_007D.LegalFraction);
		}
		else
		{
			LegalFraction = FractionID.None;
		}
		FixedPortLevel = _007B2962_007D.FixedLevel;
		FixedLevelBonuses = new PortCaptureStatus(PortID);
	}

	internal void Initialize(WorldMapInfo _007B2966_007D)
	{
		NearRegion = _007B2966_007D.GetNearWorldRegion(in EntryPos);
	}

	internal void Initialize2(WorldMapInfo _007B2967_007D)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		WosbTrading.GetPortOtherTrading(EntryPos, Type, out SellResources, out ShopResources);
		for (int i = 0; i < 2; i++)
		{
			int num = 3 + i;
			foreach (IslePortInfo item4 in _007B2967_007D.Ports.OrderBy((IslePortInfo _007B2971_007D) => Vector2.DistanceSquared(_007B2971_007D.EntryPos, EntryPos)))
			{
				IslePortInfo item = item4;
				if (item != this && item.Type != PortType.PirateBay && Gameplay.IsInHazardZone(in EntryPos) == Gameplay.IsInHazardZone(in item.EntryPos))
				{
					if (PortsToJump.Size >= num)
					{
						break;
					}
					PortsToJump.AddIfNotContains(in item);
				}
			}
			foreach (IslePortInfo item5 in _007B2967_007D.Ports.OrderBy((IslePortInfo _007B2973_007D) => Vector2.DistanceSquared(_007B2973_007D.EntryPos, EntryPos)))
			{
				IslePortInfo item2 = item5;
				if (item2.PortsToJump.Contains(this))
				{
					PortsToJump.AddIfNotContains(in item2);
				}
			}
		}
		BouysPositionsGlobal = new Tlist<Vector2>();
		int num2 = (int)Math.Round(GlobalEntryRadius / 2.7f);
		float num3 = (float)Math.PI * 2f / (float)num2;
		Matrix val = default(Matrix);
		Matrix.Invert(ref GlobalTransformWorld, ref val);
		for (int num4 = 0; num4 < num2; num4++)
		{
			Vector2 item3 = EntryPos + new Vector2(GlobalEntryRadius * MathF.Cos(num3 * (float)num4), GlobalEntryRadius * MathF.Sin(num3 * (float)num4));
			BouysPositionsGlobal.Add(in item3);
		}
	}

	public override string ToString()
	{
		return PortName + " | " + Type;
	}

	[CompilerGenerated]
	private bool _007B2968_007D(QuestRunningProgress _007B2969_007D)
	{
		return _007B2969_007D.Info.FirstStep is QuestTransferOrder questTransferOrder && questTransferOrder.TargetAsPort == this;
	}

	[CompilerGenerated]
	private float _007B2970_007D(IslePortInfo _007B2971_007D)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		return Vector2.DistanceSquared(_007B2971_007D.EntryPos, EntryPos);
	}

	[CompilerGenerated]
	private float _007B2972_007D(IslePortInfo _007B2973_007D)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		return Vector2.DistanceSquared(_007B2973_007D.EntryPos, EntryPos);
	}
}
