using System;
using System.Collections.Generic;
using Common.Account;
using Common.Game;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Graphics.Models;

namespace Common.Resources;

public class TraderInSeaPlaceInfo
{
	public readonly TraderInSeaType Type;

	public readonly Vector2 Position;

	public IslePortInfo NearPort;

	public readonly WorldMapRegionInfo NearRegion;

	internal readonly Tlist<ShipPositionInfo> RespawnPositions;

	public Action<PlayerAccount> ResearchPointAction;

	public string Name => Local.Current(Type.ToString());

	public string Description => Local.Current(Type.ToString() + "_desc");

	public bool AlwaysVisibleInWorldMap => Type == TraderInSeaType.Town;

	public TraderInSeaPlaceInfo(WorldMapInfo _007B3006_007D, Vector2? _007B3007_007D, IsleInstance _007B3008_007D, TraderInSeaType _007B3009_007D, IslePortInfo _007B3010_007D)
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		Position = (Vector2)(((_003F?)_007B3007_007D) ?? _007B3008_007D.GlobalPosition);
		Type = _007B3009_007D;
		NearPort = _007B3010_007D;
		NearRegion = _007B3006_007D.GetNearWorldRegion(in Position);
		if (Type != TraderInSeaType.Altar)
		{
			RespawnPositions = new Tlist<ShipPositionInfo>();
			foreach (KeyValuePair<string, UWModel> connection in _007B3008_007D.ModelData.Connections)
			{
				if (connection.Key.Contains("Respawn"))
				{
					Vector2 val = _007B3008_007D.GlobalTransform.Transform3X3(connection.Value.CommonSphere.Center).XZ();
					RespawnPositions.Add(new ShipPositionInfo(val, MathF.Atan2(val.Y - _007B3008_007D.ModelGlobalBSxz.Y, val.X - _007B3008_007D.ModelGlobalBSxz.X)));
				}
			}
			if (RespawnPositions.Size == 0)
			{
				throw new InvalidOperationException("Vilage RespawnPositions.Size=0");
			}
		}
		string name = Name;
		string description = Description;
	}
}
