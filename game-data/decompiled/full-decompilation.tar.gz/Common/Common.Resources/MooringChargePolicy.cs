namespace Common.Resources;

public enum MooringChargePolicy : byte
{
	Free,
	Normal,
	High,
	Extreme
}
