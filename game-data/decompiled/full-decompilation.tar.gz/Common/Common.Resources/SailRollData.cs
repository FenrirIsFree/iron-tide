using Microsoft.Xna.Framework;

namespace Common.Resources;

public struct SailRollData
{
	public Vector3 Normal;

	public Vector3 RollPosition;

	public float CurvatureRoll;

	public SailRollData(float _007B2419_007D, Vector3 _007B2420_007D, Vector3 _007B2421_007D)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		CurvatureRoll = _007B2419_007D;
		Normal = _007B2420_007D;
		RollPosition = _007B2421_007D;
	}
}
