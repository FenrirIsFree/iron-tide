namespace Common.Resources;

public enum SpecialUnitClass
{
	Combats,
	Sailors,
	Pirates,
	Adventurers
}
