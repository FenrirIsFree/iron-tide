using Microsoft.Xna.Framework;

namespace Common.Resources;

public class FalkonetLocationInfo(Vector3 _007B2280_007D)
{
	public Vector3 LocalPosition = _007B2280_007D;
}
