namespace Common.Resources;

public enum UpgradeStrengthWear
{
	None,
	ShotsCount,
	MortarShotsCount,
	ReceivedDamage,
	SailingDistance
}
