namespace Common.Resources;

public enum UnitType
{
	Sailor,
	Boarding,
	Special
}
