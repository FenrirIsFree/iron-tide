using System;
using System.Collections.Generic;
using System.Linq;
using Common.Game;
using CommonDataTypes;
using TheraEngine.Collections;
using TheraEngine.Helpers;
using TheraEngine.PacketValues;

namespace Common.Resources;

public sealed class NpcShipDynamicInfo : ShipDynamicInfo
{
	public readonly NpcInfo Information;

	internal Tlist<int> Upgrades;

	public NPCBehaviorSettings Behavior;

	internal StaticEffectsCalculator upgradesEffects;

	internal int InitialPlacesForUnits;

	public ShipDesignInfo? SailDesign;

	public ShipDesignInfo? BowFigure;

	public ShipDesignInfo? ShipCorpusDesing;

	internal float MinAchievedSailStrength = 1f;

	public Bits32? UseDecalBits;

	protected override float BasicHp => Information.ShipProperties.MaxHp.Value;

	protected override float BasicArmor => Information.ShipProperties.Armor;

	protected override float BasicCapacity => Information.ShipProperties.CapacityCg;

	protected override int BasicCrewPlaces => InitialPlacesForUnits;

	protected override float BasicMobility => Information.Mobility;

	internal override float BasicSpeed => Information.ShipProperties.MaxBasicSpeed;

	protected override float GetBonus(ShipBonusEffect _007B2695_007D, bool _007B2696_007D = true)
	{
		float num = upgradesEffects[_007B2695_007D];
		if (_007B2696_007D && DynamicBonus != null)
		{
			num += DynamicBonus.Stats[_007B2695_007D];
		}
		return _007B2695_007D switch
		{
			ShipBonusEffect.PMarchingSpeed => Math.Max(0.3f, num), 
			ShipBonusEffect.PDecreaseSpeedLossMarchingMode => Math.Max(0.5f, num), 
			_ => num, 
		};
	}

	private void _007B2697_007D(WorldMapInfo _007B2698_007D, object _007B2699_007D, int _007B2700_007D)
	{
		upgradesEffects = new StaticEffectsCalculator();
		foreach (ShipUpgradeInfo item in Upgrades.Select((int _007B2714_007D) => Gameplay.ShipUpgradesInfo.FromID(_007B2714_007D)))
		{
			IEnumerable<ShipBonus> effects = item.GetEffects(Information.BasedOn);
			foreach (ShipBonus item2 in effects)
			{
				ShipBonus _007B5225_007D = item2;
				upgradesEffects.Add(in _007B5225_007D);
			}
		}
		if (Information.Ship.ID != 1 && _007B2699_007D != null)
		{
			if (_007B2698_007D.IsPassingUi)
			{
				NpcShipHelper.GenerateNpcStaticUpgrades(upgradesEffects, _007B2699_007D as PassingMapDiffCard[]);
			}
			if (Information.Descritpion == NpcType.Empire_Invasion)
			{
				NpcShipHelper.GenerateNpcStaticUpgradesEmpireInvasion(upgradesEffects, (float)_007B2699_007D);
			}
		}
		NpcShipHelper.GenerateNpcStaticUpgrades(upgradesEffects, Information);
		(SailDesign, BowFigure, ShipCorpusDesing) = GetDesignElements(Information, _007B2700_007D);
		if (Information.Descritpion == NpcType.Fanatics)
		{
			UseDecalBits = GetPartialSailDesign();
		}
		firstHP.SetFull(MaxHp);
		Cannons = new CannonCollection(Information, Information.Ship, Information.Extras.IsEmpire);
		Mortars = new Map<CannonGameInstance>();
		if (Information.MortarShipModification)
		{
			for (int num = 0; num < Information.Ship.MortarPorts.Length; num++)
			{
				CannonGameInfo cannonGameInfo = Gameplay.CannonsGameInfo.First((CannonGameInfo _007B2715_007D) => _007B2715_007D.Class == CannonClass.Mortar);
				Mortars[num] = new CannonGameInstance(cannonGameInfo.ID, Gameplay.DestroyMortarResource(cannonGameInfo));
			}
		}
		Behavior = new NPCBehaviorSettings(this, _007B2698_007D, _007B2699_007D as PassingMapDiffCard[]);
		hpFactorCached = base.HpFactor;
	}

	private Bits32? GetPartialSailDesign()
	{
		short iD = StaticInfo.ID;
		if ((iD == 22 || iD == 25 || iD == 38) ? true : false)
		{
			return null;
		}
		Bits32 animatedSailesBits = StaticInfo.AnimatedSailesBits;
		for (int i = 0; i < StaticInfo.SailHitboxes.Length; i++)
		{
			if (i % 2 == 0)
			{
				animatedSailesBits[i] = false;
			}
			if (StaticInfo.SailHitboxes[i].IsPerpendicular)
			{
				animatedSailesBits[i] = false;
			}
		}
		return animatedSailesBits;
	}

	public NpcShipDynamicInfo(NpcInfo _007B2701_007D, WorldMapInfo _007B2702_007D, object _007B2703_007D, int _007B2704_007D)
		: base(_007B2701_007D.Ship)
	{
		if (!CommonGlobal.IsServer)
		{
			throw new Exception();
		}
		Information = _007B2701_007D;
		if (Information.Ship.ID != 1)
		{
			if (_007B2702_007D.IsPassingUi)
			{
				Upgrades = NpcShipHelper.GenerateNpcUpgrades(_007B2701_007D, _007B2702_007D.IsPassingUi, (PassingMapDiffCard[])_007B2703_007D);
			}
			else
			{
				Upgrades = NpcShipHelper.GenerateNpcUpgrades(_007B2701_007D, _007B3854_007D: false);
			}
		}
		else
		{
			Upgrades = new Tlist<int>();
		}
		_007B2697_007D(_007B2702_007D, _007B2703_007D, _007B2704_007D);
		Crew = WosbCrew.CreateNpcCrew(_007B2701_007D, (int)GetBonus(ShipBonusEffect.MExtraPlaces, _007B2696_007D: false));
		InitialPlacesForUnits = Crew.Count - (int)GetBonus(ShipBonusEffect.MExtraPlaces, _007B2696_007D: false);
	}

	private NpcShipDynamicInfo(NpcInfo _007B2705_007D, WorldMapInfo _007B2706_007D, object _007B2707_007D, NpcCreatePacket _007B2708_007D)
		: base(_007B2705_007D.Ship)
	{
		Information = _007B2705_007D;
		Upgrades = _007B2708_007D.InstalleUdpgrades;
		DynamicBonus = _007B2708_007D.DynamicEffects;
		InitialPlacesForUnits = _007B2708_007D.InitialPlacesForUnits;
		_007B2697_007D(_007B2706_007D, _007B2707_007D, _007B2708_007D.uID);
		foreach (CannonSerializedInfo item in (IEnumerable<CannonSerializedInfo>)_007B2708_007D.BrokenCannons)
		{
			Cannons.MakeBroken(item.Location, _007B4533_007D: false);
		}
	}

	internal static NpcShipDynamicInfo CreateFromPacket(NpcCreatePacket _007B2709_007D, WorldMapInfo _007B2710_007D, object _007B2711_007D)
	{
		NpcInfo npcInfo = (_007B2709_007D.NpcInfoIDPassingMap ? (_007B2710_007D as MapForPassingInfo).NpcsIDTable[_007B2709_007D.NpcInfoID] : Gameplay.NpcsInfo[_007B2709_007D.NpcInfoID]);
		return new NpcShipDynamicInfo(npcInfo, _007B2710_007D, (npcInfo.Descritpion == NpcType.Empire_Invasion) ? ((object)_007B2709_007D.EmpireNpcLevel) : _007B2711_007D, _007B2709_007D);
	}

	public void SetBonusWhenCaptured()
	{
		DynamicBonus.RemoveAllArenaUpgrdaes();
		DynamicBonus.AddArenaUpgrade(new ShipBonus(ShipBonusEffect.PMarchingSpeed, 80f));
	}

	public static (ShipDesignInfo? sailDesign, ShipDesignInfo? bowFigure, ShipDesignInfo? corpusDesing) GetDesignElements(NpcInfo _007B2712_007D, int _007B2713_007D)
	{
		bool isHalloween = CalendarEvents.IsHalloween;
		bool flag = isHalloween;
		if (flag)
		{
			NpcType descritpion = _007B2712_007D.Descritpion;
			bool flag2 = (uint)(descritpion - 12) <= 1u;
			flag = flag2;
		}
		int num = (flag ? 232 : ((_007B2712_007D.SpecialEffect == NpcVisualEffect.BloodShip) ? 229 : ((_007B2712_007D.SpecialEffect == NpcVisualEffect.IceShip) ? 230 : ((_007B2712_007D.SpecialEffect == NpcVisualEffect.MagmaShip) ? 231 : ((_007B2712_007D.SpecialEffect == NpcVisualEffect.ShadowShip) ? 232 : ((_007B2712_007D.SpecialEffect == NpcVisualEffect.DirtShip) ? 233 : 0))))));
		if (_007B2712_007D.Extras.IsEmpire)
		{
			return (sailDesign: Gameplay.DesignsInfo[325], bowFigure: null, corpusDesing: (num == 0) ? null : Gameplay.DesignsInfo[num]);
		}
		if (num != 0)
		{
			return (sailDesign: null, bowFigure: null, corpusDesing: Gameplay.DesignsInfo[num]);
		}
		if (_007B2712_007D.Descritpion == NpcType.Fanatics)
		{
			return (sailDesign: Gameplay.DesignsInfo[465], bowFigure: Gameplay.DesignsInfo[168], corpusDesing: null);
		}
		if (_007B2712_007D.Extras.IsPirateFr2)
		{
			return (sailDesign: Gameplay.DesignsInfo[_007B2712_007D.Extras.IsReinforcedType ? 461 : 313], bowFigure: Gameplay.DesignsInfo[168], corpusDesing: null);
		}
		int goldSail = 222;
		int[] blackSailes = new int[3] { 18, 325, 320 };
		if (_007B2712_007D.Extras.IsPirate)
		{
			if (_007B2712_007D.Extras.IsReinforcedType)
			{
				return (sailDesign: Gameplay.DesignsInfo[Rand.Pick(blackSailes)], bowFigure: null, corpusDesing: null);
			}
			if (_007B2712_007D.IsDefenderOrPrivateer)
			{
				return (sailDesign: Gameplay.RandomSailesForNpcs.Rand((ShipDesignInfo _007B2716_007D) => !blackSailes.Contains(_007B2716_007D.ID) && _007B2716_007D.ID != goldSail && _007B2716_007D.ID != 41, new Sequence(_007B2713_007D)), bowFigure: null, corpusDesing: null);
			}
			return (sailDesign: null, bowFigure: null, corpusDesing: null);
		}
		if (_007B2712_007D.Descritpion == NpcType.HeadHunter)
		{
			return (sailDesign: Gameplay.RandomSailesForNpcs.Rand((ShipDesignInfo _007B2717_007D) => !blackSailes.Contains(_007B2717_007D.ID) && _007B2717_007D.ID != goldSail && _007B2717_007D.ID != 41, new Sequence(_007B2713_007D)), bowFigure: null, corpusDesing: null);
		}
		if (_007B2712_007D.Extras.IsTrader)
		{
			if (_007B2712_007D.Extras.IsReinforcedType)
			{
				return (sailDesign: Gameplay.DesignsInfo[goldSail], bowFigure: Gameplay.DesignsInfo[Rand.Pick<int>(153, 432, 154)], corpusDesing: Gameplay.DesignsInfo[435]);
			}
			return (sailDesign: Gameplay.DesignsInfo[222], bowFigure: null, corpusDesing: null);
		}
		return (sailDesign: null, bowFigure: null, corpusDesing: null);
	}
}
