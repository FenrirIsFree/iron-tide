using System;
using System.Linq;
using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine;
using TheraEngine.Helpers;

namespace Common.Resources;

public class FoodConsumption : IMPSerializable
{
	public enum Mode
	{
		None,
		JustForBonus,
		Full
	}

	private const float eatingDuration_sec = 800f;

	private const float timeHungerPerUnit_sec = 35f;

	public float CurrentHungerLevel = 0f;

	public float BonusAmount(ShipDynamicInfo _007B2877_007D)
	{
		return Geometry.InverseLerp(0.4f, 0.9f, 1f - CurrentHungerLevel) * _007B2877_007D.Crew.Effectivity(_007B2877_007D);
	}

	public Mode HasFoodConsumption(Player _007B2878_007D)
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		if (!_007B2878_007D.MapInfo.IsWorldmap || _007B2878_007D.IsPortEntry || _007B2878_007D.UsedShip.StaticInfo.IsBalloon)
		{
			return Mode.None;
		}
		return (Gameplay.GetNearWorldRegion(_007B2878_007D.Position).Feature != WorldMapRegionInfo.FeatureType.NorthRegion) ? Mode.JustForBonus : Mode.Full;
	}

	public void Update(Player _007B2879_007D, ref FrameTime _007B2880_007D, out bool _007B2881_007D)
	{
		_007B2881_007D = false;
		if (_007B2879_007D.IsPortEntry)
		{
			CurrentHungerLevel = 0f;
		}
		Mode mode = HasFoodConsumption(_007B2879_007D);
		if (mode == Mode.None)
		{
			CurrentHungerLevel -= _007B2880_007D.secElapsed / 800f;
			CurrentHungerLevel = Math.Max(0f, CurrentHungerLevel);
		}
		else if (CurrentHungerLevel <= ((mode == Mode.JustForBonus) ? 0.5f : 1f))
		{
			CurrentHungerLevel += _007B2880_007D.secElapsed / 800f * ((_007B2879_007D.GetBattleTimer > 0f) ? 0.5f : 1f) * ((mode == Mode.JustForBonus) ? 0.6f : 1f) * _007B2879_007D.UsedShip.CrewFactor;
			if (CurrentHungerLevel > 1f)
			{
				CurrentHungerLevel = 1f;
				_007B2881_007D = true;
			}
		}
	}

	public void ApplyDeathFromHunger(Player _007B2882_007D)
	{
		CurrentHungerLevel -= 7f / 160f * (17f / (float)(_007B2882_007D.UsedShip.CrewPlaces / 4));
	}

	public bool TryTakeFood(Player _007B2883_007D, GSI _007B2884_007D)
	{
		if (CurrentHungerLevel < 0.01f || !_007B2883_007D.UsedShipPlayer.PrivateResourcesOfHold.CanRemove(_007B2884_007D))
		{
			return false;
		}
		_007B2883_007D.UsedShipPlayer.PrivateResourcesOfHold.Remove(_007B2884_007D);
		CurrentHungerLevel -= _007B2884_007D.ResourceInfo.Sum<GSILocalEnumerablePair<ResourceInfo>>((GSILocalEnumerablePair<ResourceInfo> _007B2893_007D) => _007B2893_007D.Info.FoodValue(_007B2883_007D) * (float)_007B2893_007D.Count) / ((float)_007B2883_007D.UsedShip.CrewPlaces * _007B2887_007D(_007B2883_007D.UsedShipPlayer.CraftFrom) / 4f);
		CurrentHungerLevel = Math.Max(0f, CurrentHungerLevel);
		return true;
	}

	public int NeededCountOfSpecificFood(Player _007B2885_007D, ResourceInfo _007B2886_007D)
	{
		return Math.Min((int)Math.Floor((float)(_007B2885_007D.UsedShip.CrewPlaces / 4) * _007B2887_007D(_007B2885_007D.UsedShipPlayer.CraftFrom) * CurrentHungerLevel / _007B2886_007D.FoodValue(_007B2885_007D)), _007B2885_007D.UsedShipPlayer.PrivateResourcesOfHold[_007B2886_007D.ID]);
	}

	private float _007B2887_007D(PlayerShipInfo _007B2888_007D)
	{
		return 10f * ((_007B2888_007D.Rank >= 6) ? 0.5f : ((_007B2888_007D.Rank >= 5) ? 0.7f : 1f));
	}

	private void _007B2889_007D(WriterExtern _007B2890_007D)
	{
		_007B2890_007D.WriteStruct<float>(CurrentHungerLevel);
	}

	private void _007B2891_007D(WriterExtern _007B2892_007D)
	{
		_007B2892_007D.ReadStruct<float>(ref CurrentHungerLevel);
	}
}
