namespace Common.Resources;

public enum WorldBindingType
{
	None,
	PbAttackerRespawn,
	PbDefenderRespawn,
	RiverMarker,
	Fog,
	NpcFence
}
