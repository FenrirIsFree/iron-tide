using System;
using System.Collections.Generic;
using Common.Data;
using Common.Game;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Helpers;

namespace Common.Resources;

public class MapForPassingInfo : WorldMapInfo
{
	private string _007B3356_007D;

	public readonly bool OpenedInitially;

	public readonly PassingMapNpcWaveInfo[] WavesNPCS;

	public readonly NpcInfo[] MasterNPCS;

	public readonly NpcWaveInfo[] ExtraPowerfulBoss;

	public readonly XmlAssetLibrary<NpcInfo> NpcsIDTable = new XmlAssetLibrary<NpcInfo>();

	private RTI _007B3357_007D;

	public readonly PassingMapGameMode Mode;

	public readonly int PlayersCount;

	public readonly int MiddleСonsumptionCBalls;

	public readonly (int, int) RangRitriction;

	public readonly Tlist<Vector2> TowersPositions;

	public readonly float TowersStrength;

	public readonly int AllyNpcSourceRegionID;

	public readonly int SourceArenaMapID;

	public readonly int VisualEffects;

	public readonly Vector2 CenterRespawnPositin;

	public readonly GSI BasicRewards;

	public string Introduction => string.IsNullOrEmpty(_007B3356_007D) ? string.Empty : Local.Current(_007B3356_007D);

	public RTI ScrollsCost(int _007B3343_007D)
	{
		return PassingMapDiffCardHelper.ScrollsCount(_007B3357_007D.Value, _007B3343_007D);
	}

	internal static IsleInfoToken[] Objects(MapForPassingInfoToken _007B3344_007D, int _007B3345_007D)
	{
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		Tlist<IsleInfoToken> tlist = new Tlist<IsleInfoToken>();
		MapArenaInfo mapArenaInfo = Gameplay.ArenaMaps.FromID(_007B3344_007D.ArenaMapID);
		foreach (IsleInstance item in (IEnumerable<IsleInstance>)mapArenaInfo.Isles)
		{
			tlist.Add(in item.SoruceTokenOrNull);
		}
		tlist.Add(new IsleInfoToken
		{
			Path = "ports\\trader_fishingvil2",
			AdditionalScale = 1f,
			LocalPosition = IsleInstance.ComposePosition(new Vector2((0f - mapArenaInfo.MapSize.X) * 0.5f * 1.001f, 0f), 0f)
		});
		tlist.Add(new IsleInfoToken
		{
			Path = "ports\\trader_fishingvil2",
			AdditionalScale = 1f,
			LocalPosition = IsleInstance.ComposePosition(new Vector2(mapArenaInfo.MapSize.X * 0.5f * 1.001f, 0f), 0f)
		});
		return tlist.ToArray();
	}

	private static NpcInfo SelectNpc(PassingMapWaveGenerator _007B3346_007D, int _007B3347_007D)
	{
		if (_007B3346_007D.SourceType == "BossByName")
		{
			for (int i = 0; i < Gameplay.NpcsInfo.Count; i++)
			{
				NpcInfo npcInfo = Gameplay.NpcsInfo.FromIndex(i);
				NpcType descritpion = npcInfo.Descritpion;
				bool flag = (uint)(descritpion - 12) <= 1u;
				if (flag && string.Equals(npcInfo.NpcName, _007B3346_007D.Source, StringComparison.OrdinalIgnoreCase))
				{
					return npcInfo;
				}
			}
		}
		else
		{
			if (!(_007B3346_007D.SourceType == "Reinforced"))
			{
				LinkedDictionrary<NpcType, NpcInfo> linkedDictionrary = new LinkedDictionrary<NpcType, NpcInfo>();
				int num = HazardAreaLut011021.Lut[int.Parse(_007B3346_007D.Source) - 1];
				foreach (NpcInfo item in (IEnumerable<NpcInfo>)Gameplay.NpcsInfo)
				{
					bool flag2 = item.Location.AsWorldRegion != null;
					bool flag3 = flag2;
					if (flag3)
					{
						NpcType descritpion = item.Descritpion;
						bool flag = ((descritpion == NpcType.PirateFraction1_Regular || descritpion == NpcType.PirateFraction2_Regular || descritpion == NpcType.Trader_Regular) ? true : false);
						flag3 = flag;
					}
					if (flag3 && Math.Abs(item.Location.HzLevel - num) <= 1)
					{
						linkedDictionrary.Add(item.Descritpion, item);
					}
				}
				Tlist<NpcInfo> tlist = new Tlist<NpcInfo>();
				if (_007B3346_007D.SourceType == "Any")
				{
					tlist = new Tlist<NpcInfo>();
					foreach (KeyValuePair<NpcType, ObservableTlist<NpcInfo>> item2 in linkedDictionrary)
					{
						tlist.Add(item2.Value);
					}
				}
				else if (_007B3346_007D.SourceType == "Trader")
				{
					tlist.Add(linkedDictionrary[NpcType.Trader_Regular]);
				}
				else
				{
					tlist.Add(linkedDictionrary[NpcType.PirateFraction1_Regular]);
					tlist.Add(linkedDictionrary[NpcType.PirateFraction2_Regular]);
				}
				return tlist.Array[_007B3347_007D % tlist.Size];
			}
			int num2 = HazardAreaLut011021.Lut[int.Parse(_007B3346_007D.Source) - 1];
			for (int j = 0; j < Gameplay.NpcsInfo.Count; j++)
			{
				NpcInfo npcInfo2 = Gameplay.NpcsInfo.FromIndex(j);
				if (npcInfo2.Extras.IsReinforcedType && npcInfo2.Location.AsWorldRegion != null && npcInfo2.Location.AsWorldRegion.LevelInt == num2)
				{
					return npcInfo2;
				}
			}
		}
		throw new NotSupportedException("Generator " + _007B3346_007D.Source + " is  invalid");
	}

	public MapForPassingInfo(MapForPassingInfoToken _007B3348_007D, int _007B3349_007D)
		: base(3, _007B3348_007D.MapName, Gameplay.ArenaMaps.FromID(_007B3348_007D.ArenaMapID).Style, _007B3349_007D, Gameplay.ArenaMaps.FromID(_007B3348_007D.ArenaMapID).MapSize, Objects(_007B3348_007D, _007B3349_007D))
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c9: Unknown result type (might be due to invalid IL or missing references)
		Mode = _007B3348_007D.Mode;
		AllyNpcSourceRegionID = HazardAreaLut011021.Lut[_007B3348_007D.AllyNpcSourceRegionID - 1] + 1;
		SourceArenaMapID = _007B3348_007D.ArenaMapID;
		VisualEffects = _007B3348_007D.VisualEffects;
		BasicRewards = new GSI().Exs(37, _007B3348_007D.MarksBonus).Exs(38, _007B3348_007D.VSkullsBonus);
		_007B3356_007D = _007B3348_007D.IntroductionKey;
		OpenedInitially = true;
		if (Introduction.Length == -1)
		{
			throw new Exception();
		}
		ClonePresets();
		float num = 0f;
		foreach (IsleInstance item4 in (IEnumerable<IsleInstance>)CollisableObjects)
		{
			if (item4.ModelData.Model.ModelName.Contains("npcfence"))
			{
				CenterRespawnPositin = item4.GlobalPosition;
			}
		}
		if (CenterRespawnPositin.X == 0f && CenterRespawnPositin.Y == 0f)
		{
			GameLoader.Current.AddImportant($"Arena map ID {_007B3348_007D.ArenaMapID} doens't have rewspawn position 'npcfence' used to create player when Game Modes is started");
		}
		WavesNPCS = new PassingMapNpcWaveInfo[_007B3348_007D.Waves.Length];
		float num2 = 0f;
		int num3 = 0;
		int num4 = 0;
		MapForPassingWaveInfoToken[] waves = _007B3348_007D.Waves;
		foreach (MapForPassingWaveInfoToken mapForPassingWaveInfoToken in waves)
		{
			NpcWaveInfo[] array = new NpcWaveInfo[mapForPassingWaveInfoToken.NPCS.Length];
			for (int j = 0; j < mapForPassingWaveInfoToken.NPCS.Length; j++)
			{
				int num5 = 11 * _007B3349_007D * _007B3349_007D + num4 * 553 + j;
				NpcInfo npcInfo = SelectNpc(mapForPassingWaveInfoToken.NPCS[j], num5);
				NpcWaveInfo npcWaveInfo = _007B3350_007D(npcInfo, mapForPassingWaveInfoToken.NPCS[j].Count, num4, j, num5);
				array[j] = npcWaveInfo;
				num += array[j].Info.ShipProperties.MaxHp.Value * (float)array[j].Count;
				num2 += (float)npcInfo.Location.HzLevel;
			}
			num3 += mapForPassingWaveInfoToken.NPCS.Length;
			WavesNPCS[num4] = new PassingMapNpcWaveInfo(array);
			num4++;
		}
		if (num3 > 0)
		{
			num2 /= (float)num3;
			MasterNPCS = new NpcInfo[2];
			Tlist<NpcInfo> tlist = new Tlist<NpcInfo>();
			foreach (NpcInfo item5 in (IEnumerable<NpcInfo>)Gameplay.NpcsInfo)
			{
				NpcInfo item = item5;
				if (item.Location.HzLevel == (int)Math.Round(num2) && item.Descritpion == NpcType.PirateFraction1_Regular)
				{
					tlist.Add(in item);
				}
			}
			tlist.SortTop((NpcInfo _007B3358_007D) => _007B3358_007D.ShipProperties.MaxBasicSpeed + _007B3358_007D.AttackDistance / 10f);
			for (int num6 = 0; num6 < 2; num6++)
			{
				NpcInfo item2 = tlist.Array[0].Clone(NpcsIDTable.Size + 1);
				item2.Descritpion = NpcType.BonusMap;
				item2.NpcName = "Patrol";
				item2.DamagePerShot *= 0.57f;
				item2.ShipProperties.MaxHp.Value *= 0.6f;
				(int, int, int) tuple = WosbNpcs.MatchBasicReward(item2, _007B4063_007D: false);
				item2.RewardAmount = new Bonus(tuple.Item2 / 2, tuple.Item1 / 2);
				NpcsIDTable.Add(in item2);
				MasterNPCS[num6] = item2;
			}
		}
		else
		{
			MasterNPCS = new NpcInfo[0];
		}
		int num7 = (RangRitriction.Item1 + RangRitriction.Item2) / 2;
		string[] array2 = new string[4] { "Envoy", "Green Eye", "Lighting", "Sand Storm" };
		string[] array3 = new string[3] { "Belian", "Chief Privateer", "Ruiner" };
		string[] array4 = new string[3] { "POWDER GOD", "Exole", "JOHNY" };
		string[] array5 = ((num7 >= 5) ? array2 : ((num7 >= 3) ? array3 : array4));
		ExtraPowerfulBoss = new NpcWaveInfo[array5.Length];
		int num8 = 0;
		string[] array6 = array5;
		foreach (string text in array6)
		{
			NpcWaveInfo npcWaveInfo2 = _007B3350_007D(SelectNpc(new PassingMapWaveGenerator
			{
				SourceType = "BossByName",
				Count = 1,
				Source = text
			}, text.GetHashCode()), 1, 254, num8, 0);
			npcWaveInfo2.Info.ShipProperties.MaxHp.Value = Math.Min(8000f, npcWaveInfo2.Info.ShipProperties.MaxHp.Value);
			ExtraPowerfulBoss[num8] = npcWaveInfo2;
			num8++;
		}
		_007B3357_007D = new RTI(_007B3348_007D.ScrollsCost);
		PlayersCount = _007B3348_007D.PlayersCount;
		MiddleСonsumptionCBalls = (int)(1f + num / 10f * 1.9f / (float)_007B3348_007D.PlayersCount);
		RangRitriction = (int.Parse(_007B3348_007D.MaxShipRank.Split('-')[0]), int.Parse(_007B3348_007D.MaxShipRank.Split('-')[1]));
		if (RangRitriction.Item1 > RangRitriction.Item2)
		{
			throw new Exception("PassingMap-RangRitriction");
		}
		TowersStrength = (float)(500 + (7 - RangRitriction.Item1) * 350) * (1f + ((float)PlayersCount - 1f) * 0.77f);
		TowersPositions = new Tlist<Vector2>();
		for (int num10 = 0; num10 < 7; num10++)
		{
			Vector2 item3 = Geometry.SubstructRotate((float)num10 / 7f * ((float)Math.PI * 2f), 270f + 100f * HashHelper.greater(num10 * num10 + 531));
			TowersPositions.Add(in item3);
		}
		foreach (NpcInfo item6 in (IEnumerable<NpcInfo>)NpcsIDTable)
		{
			item6.NpcInfoIDPassingMap = true;
		}
	}

	private NpcWaveInfo _007B3350_007D(NpcInfo _007B3351_007D, int _007B3352_007D, int _007B3353_007D, int _007B3354_007D, int _007B3355_007D)
	{
		_007B3351_007D = _007B3351_007D.Clone(NpcsIDTable.Size + 1);
		NpcInfo npcInfo = _007B3351_007D;
		NpcType descritpion = _007B3351_007D.Descritpion;
		bool flag = (uint)(descritpion - 12) <= 1u;
		npcInfo.Descritpion = (flag ? NpcType.BonusMapBoss : NpcType.BonusMap);
		if (_007B3351_007D.Descritpion == NpcType.BonusMapBoss)
		{
			_007B3351_007D.NpcName = "Legendary " + NpcShipHelper.ancientNames[_007B3355_007D % NpcShipHelper.ancientNames.Length];
		}
		_007B3351_007D.DamagePerShot *= 0.55f;
		_007B3351_007D.ShipProperties.MaxHp.Value = _007B3351_007D.ShipProperties.MaxHp.Value * ((_007B3351_007D.ShipProperties.MaxHp.Value > 3000f) ? 0.35f : 0.7f);
		(int, int, int) tuple = WosbNpcs.MatchBasicReward(_007B3351_007D, _007B4063_007D: false);
		_007B3351_007D.RewardAmount = new Bonus(tuple.Item2, tuple.Item1);
		if (_007B3353_007D % 3 == 0 && _007B3354_007D % 2 == 0 && !_007B3351_007D.OverrideCannonBalls.HasValue)
		{
			_007B3351_007D.OverrideCannonBalls = Rand.Pick<int>(500, 9);
			_007B3351_007D.Descritpion = NpcType.BonusMapBoss;
			_007B3351_007D.ShipProperties.MaxBasicSpeed += 2f;
		}
		NpcsIDTable.Add(in _007B3351_007D);
		return new NpcWaveInfo(_007B3351_007D, _007B3352_007D);
	}
}
