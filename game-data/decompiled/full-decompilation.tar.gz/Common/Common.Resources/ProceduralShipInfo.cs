using Common.Data;
using Common.Game;
using Microsoft.Xna.Framework.Graphics;

namespace Common.Resources;

public readonly struct ProceduralShipInfo : IStorageAsset, IGameResource
{
	public readonly short CompressedID;

	public readonly byte ShipID;

	public readonly byte ModificationID;

	public PlayerShipInfo ShipInfo => Gameplay.PlayersInfo.FromID(ShipID);

	public ShipUpgradeInfo? ModificationInfo => (ModificationID == 0) ? null : Gameplay.ShipUpgradesInfo.FromID(ModificationID);

	float IStorageAsset.getStorageMass => 1f;

	string IStorageAsset.getName
	{
		get
		{
			ShipUpgradeInfo modificationInfo = ModificationInfo;
			if (modificationInfo != null)
			{
				return ShipInfo.ShipName + " (" + modificationInfo.Name + ")";
			}
			return ShipInfo.ShipName;
		}
	}

	Texture2D IStorageAsset.getIconTexture => ShipInfo.IconTexture;

	StorageAssetEnum IStorageAsset.getType => StorageAssetEnum.Ship_DisplayOnly;

	short IStorageAsset.ID => CompressedID;

	short IGameResource.ID => CompressedID;

	string IStorageAsset.getDescription => string.Empty;

	public ProceduralShipInfo(PlayerShipDynamicInfo _007B2371_007D)
	{
		ShipID = (byte)_007B2371_007D.CraftFrom.ID;
		ModificationID = (byte)(_007B2371_007D.Upgrades.HavingModification?.ID ?? 0);
		CompressedID = (short)((ModificationID << 8) + ShipID);
	}

	public ProceduralShipInfo(int _007B2372_007D, int _007B2373_007D)
	{
		ShipID = (byte)_007B2372_007D;
		ModificationID = (byte)_007B2373_007D;
		CompressedID = (short)((ModificationID << 8) + ShipID);
	}

	public ProceduralShipInfo(short _007B2374_007D)
	{
		ModificationID = (byte)(_007B2374_007D >> 8);
		ShipID = (byte)(_007B2374_007D & 0xFF);
		CompressedID = _007B2374_007D;
	}

	public override int GetHashCode()
	{
		return CompressedID.GetHashCode();
	}

	public override bool Equals(object? _007B2375_007D)
	{
		if (_007B2375_007D is ProceduralShipInfo proceduralShipInfo)
		{
			return proceduralShipInfo.CompressedID == CompressedID;
		}
		return false;
	}

	public static bool operator ==(ProceduralShipInfo _007B2376_007D, ProceduralShipInfo _007B2377_007D)
	{
		return _007B2376_007D.Equals(_007B2377_007D);
	}

	public static bool operator !=(ProceduralShipInfo _007B2378_007D, ProceduralShipInfo _007B2379_007D)
	{
		return !(_007B2378_007D == _007B2379_007D);
	}
}
