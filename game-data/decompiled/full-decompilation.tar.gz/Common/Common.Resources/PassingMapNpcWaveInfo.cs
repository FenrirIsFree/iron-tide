namespace Common.Resources;

public class PassingMapNpcWaveInfo
{
	public readonly NpcWaveInfo[] WaveInfo;

	public PassingMapNpcWaveInfo(NpcWaveInfo[] _007B3340_007D)
	{
		WaveInfo = _007B3340_007D;
	}
}
