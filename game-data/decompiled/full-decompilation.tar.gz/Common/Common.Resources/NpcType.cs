namespace Common.Resources;

public enum NpcType
{
	Seafarer,
	PirateFraction1_Regular,
	PirateFraction1_Reinforced,
	PirateFraction1_Fleet,
	PirateFraction2_Regular,
	PirateFraction2_Reinforced,
	PirateFraction2_Fleet,
	Trader_Regular,
	Trader_Ferryman,
	PortPatrol,
	Empire_Regular,
	Empire_Invasion,
	Empire_Legendary2l,
	Empire_Legendary3l,
	Fanatics,
	BonusMap,
	BonusMapBoss,
	SpecialNoReward,
	HeadHunter,
	NyEventNpc,
	Rem_PirateAmbush
}
