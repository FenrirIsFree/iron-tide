using TheraEngine.Collections;

namespace Common.Resources;

internal class WorldHashingSector
{
	public readonly IslePortInfo NearPort;

	public readonly Tlist<IsleInstance> VisibleCollisableObjects;

	public readonly Tlist<IsleInstance> ContainsCollisableObjects;

	public readonly Tlist<PbsBuildingPlaceInfo> DynamicBuilding;

	public readonly TraderInSeaPlaceInfo NearTraderInSea;

	public readonly float WaterDeepnessLevel;

	public readonly Tlist<FenceSphereStruct> WaterRiverAnchors;

	public WorldHashingSector(IslePortInfo _007B3207_007D, Tlist<IsleInstance> _007B3208_007D, Tlist<IsleInstance> _007B3209_007D, Tlist<PbsBuildingPlaceInfo> _007B3210_007D, TraderInSeaPlaceInfo _007B3211_007D, Tlist<FenceSphereStruct> _007B3212_007D, float _007B3213_007D)
	{
		NearPort = _007B3207_007D;
		VisibleCollisableObjects = _007B3208_007D;
		ContainsCollisableObjects = _007B3209_007D;
		DynamicBuilding = _007B3210_007D;
		NearTraderInSea = _007B3211_007D;
		WaterRiverAnchors = _007B3212_007D;
		WaterDeepnessLevel = _007B3213_007D;
	}
}
