using System;
using System.Linq;
using Common.Game;
using TheraEngine.Helpers;

namespace Common.Resources;

public static class PassingMapDiffCardHelper
{
	private static readonly PassingMapDiffCard[] allCards = (PassingMapDiffCard[])Enum.GetValues(typeof(PassingMapDiffCard));

	public static string GetDescription(this PassingMapDiffCard _007B3328_007D)
	{
		return _007B3328_007D switch
		{
			PassingMapDiffCard.StrongFog => Local.pmd_StrongFog, 
			PassingMapDiffCard.ImprovedNpcSpeedAndMobility => Local.pmd_ImprovedNpcSpeedAndMobility, 
			PassingMapDiffCard.ImprovedNpcStrength => Local.pmd_ImprovedNpcStrength, 
			PassingMapDiffCard.ImprovedNpcCrewAndReload => Local.pmd_ImprovedNpcCrewAndReload, 
			PassingMapDiffCard.ImprovedNpcsAmmo => Local.pmd_ImprovedNpcsAmmo, 
			PassingMapDiffCard.ExtraRegularNpcs => Local.pmd_ExtraRegularNpcs, 
			PassingMapDiffCard.ExtraWaveNpcs => Local.pmd_ExtraWaveNpcs, 
			PassingMapDiffCard.PowderKegsEverywhere => Local.pmd_PowderKegsEverywhere, 
			PassingMapDiffCard.PlayerCurse => Local.pmd_PlayerCurse, 
			PassingMapDiffCard.StrongWind => Local.pmd_StrongWind, 
			PassingMapDiffCard.PowefulBoss => Local.pmd_PowefulBoss, 
			PassingMapDiffCard.Towers => Local.pmd_Towers, 
			PassingMapDiffCard.FastWavesCooldown => Local.pmd_FastWavesCooldown, 
			_ => throw new NotSupportedException(), 
		};
	}

	public static PassingMapDiffCard[] PickCards(int _007B3329_007D)
	{
		int num = _007B3329_007D switch
		{
			2 => 3, 
			1 => 1, 
			_ => 6, 
		};
		PassingMapDiffCard[] array = new PassingMapDiffCard[num];
		for (int i = 0; i < num; i++)
		{
			PassingMapDiffCard passingMapDiffCard;
			do
			{
				passingMapDiffCard = Rand.Pick(allCards);
			}
			while (Array.IndexOf(array, passingMapDiffCard) != -1);
			array[i] = passingMapDiffCard;
		}
		return array;
	}

	public static float DoublonsMultiplier(int _007B3330_007D)
	{
		return _007B3330_007D switch
		{
			2 => 1.2f, 
			1 => 1f, 
			_ => 1.5f, 
		};
	}

	public static int WaveInterval(int _007B3331_007D, PassingMapDiffCard[] _007B3332_007D)
	{
		return _007B3332_007D.Contains(PassingMapDiffCard.FastWavesCooldown) ? 10 : 25;
	}

	public static int ExtraNpcInterval(int _007B3333_007D)
	{
		return 150;
	}

	internal static int ScrollsCount(int _007B3334_007D, int _007B3335_007D)
	{
		return _007B3335_007D switch
		{
			2 => (int)((float)_007B3334_007D * 1.25f), 
			3 => (int)((float)_007B3334_007D * 1.5f), 
			_ => _007B3334_007D, 
		};
	}

	public static GSI GetRewards(MapForPassingInfo _007B3336_007D, int _007B3337_007D, out float _007B3338_007D)
	{
		GSI basicRewards = _007B3336_007D.BasicRewards;
		switch (_007B3337_007D)
		{
		case 1:
			basicRewards = basicRewards.Clone(0.8f, RoundMode.Round);
			_007B3338_007D = 0.95f;
			break;
		case 2:
			basicRewards = basicRewards.Clone();
			_007B3338_007D = 1.1f;
			break;
		default:
			basicRewards = basicRewards.Clone(1.5f, RoundMode.Round).Exs(15, (_007B3336_007D.ID <= 2) ? 3 : 4);
			_007B3338_007D = 1.5f;
			break;
		}
		return basicRewards;
	}
}
