using Common.Data;
using CommonDataTypes;
using TheraEngine;

namespace Common.Resources;

public class RangInfo : XmlAsset<RangInfoToken>
{
	public readonly RTI XpToRang;

	public RangInfo(RangInfoToken _007B2855_007D, int _007B2856_007D)
		: base(_007B2856_007D)
	{
		XpToRang = new RTI(_007B2855_007D.Xp);
	}
}
