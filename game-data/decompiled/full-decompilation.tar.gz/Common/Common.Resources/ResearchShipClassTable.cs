using System.Collections.Generic;
using System.Linq;
using TheraEngine.Collections;

namespace Common.Resources;

public class ResearchShipClassTable
{
	private readonly Tlist<int> _007B2385_007D = new Tlist<int>(10);

	public int TotalLevels => _007B2385_007D.Size;

	public ResearchShipClassTable(IEnumerable<PlayerShipInfo> _007B2381_007D)
	{
		List<PlayerShipInfo> list = _007B2381_007D.OrderBy((PlayerShipInfo _007B2386_007D) => _007B2386_007D.Rank).Reverse().ToList();
		foreach (PlayerShipInfo item in list)
		{
			_007B2385_007D.AddIfNotContains(in item.Rank);
		}
	}

	public int FirstShipRank()
	{
		return _007B2385_007D.Array[0];
	}

	public int LastShipRank()
	{
		return _007B2385_007D.Array[_007B2385_007D.Size - 1];
	}

	public int GetIndexInResearchSquence(int _007B2382_007D)
	{
		return _007B2385_007D.IndexOf(in _007B2382_007D);
	}

	public int GetReseacrehdShipRank(int _007B2383_007D)
	{
		return _007B2385_007D.Array[_007B2383_007D];
	}

	public int PreviousShipRank(int _007B2384_007D)
	{
		int indexInResearchSquence = GetIndexInResearchSquence(_007B2384_007D);
		if (indexInResearchSquence == 0 || indexInResearchSquence == -1)
		{
			return -1;
		}
		return _007B2385_007D.Array[indexInResearchSquence - 1];
	}
}
