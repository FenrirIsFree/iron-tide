namespace Common.Resources;

public class NpcWaveInfo
{
	public readonly NpcInfo Info;

	public readonly int Count;

	public NpcWaveInfo(NpcInfo _007B2323_007D, int _007B2324_007D)
	{
		Info = _007B2323_007D;
		Count = _007B2324_007D;
	}
}
