namespace Common.Resources;

public enum HitboxType
{
	Corpus,
	Mast,
	Sail,
	ServerOnly_SailClosed
}
