using System.Diagnostics.CodeAnalysis;

namespace Common.Resources;

public class SelectedCannonBalls
{
	private const int cMax = 32;

	private int[] _007B2302_007D;

	private int _007B2303_007D;

	public int this[CannonLocation _007B2294_007D]
	{
		get
		{
			return _007B2302_007D[(int)_007B2294_007D];
		}
		set
		{
			_007B2302_007D[(int)_007B2295_007D] = value;
		}
	}

	public int Value
	{
		get
		{
			_007B2299_007D();
			return _007B2303_007D;
		}
		[MemberNotNull("decompressed")]
		set
		{
			_007B2303_007D = value;
			_007B2300_007D();
		}
	}

	public bool IsSingleSetted => _007B2302_007D[0] == _007B2302_007D[1] && _007B2302_007D[0] == _007B2302_007D[2] && _007B2302_007D[0] == _007B2302_007D[3];

	public SelectedCannonBalls()
	{
		_007B2302_007D = new int[4] { 1, 1, 1, 1 };
	}

	public SelectedCannonBalls(int _007B2298_007D)
	{
		Value = _007B2298_007D;
	}

	private void _007B2299_007D()
	{
		_007B2303_007D = _007B2302_007D[0] + _007B2302_007D[1] * 32 + _007B2302_007D[2] * 32 * 32 + _007B2302_007D[3] * 32 * 32 * 32;
	}

	[MemberNotNull("decompressed")]
	private void _007B2300_007D()
	{
		_007B2302_007D = new int[4];
		int num = _007B2303_007D;
		_007B2302_007D[3] = num / 32768;
		num -= _007B2302_007D[3] * 32 * 32 * 32;
		_007B2302_007D[2] = num / 1024;
		num -= _007B2302_007D[2] * 32 * 32;
		_007B2302_007D[1] = num / 32;
		num -= _007B2302_007D[1] * 32;
		_007B2302_007D[0] = num;
	}

	public bool Equals(SelectedCannonBalls _007B2301_007D)
	{
		for (int i = 0; i < _007B2301_007D._007B2302_007D.Length; i++)
		{
			if (_007B2301_007D._007B2302_007D[i] != _007B2302_007D[i])
			{
				return false;
			}
		}
		return true;
	}
}
