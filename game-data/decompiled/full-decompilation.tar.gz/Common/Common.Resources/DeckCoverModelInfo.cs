using Microsoft.Xna.Framework;

namespace Common.Resources;

public class DeckCoverModelInfo
{
	public Matrix World;

	public readonly bool FullOpen;

	public int? NearSectionId;

	public DeckCoverModelInfo(Matrix _007B2598_007D, bool _007B2599_007D, int? _007B2600_007D)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		World = _007B2598_007D;
		FullOpen = _007B2599_007D;
		NearSectionId = _007B2600_007D;
	}
}
