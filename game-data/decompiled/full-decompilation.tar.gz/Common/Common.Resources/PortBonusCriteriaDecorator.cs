using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using Common.Game;
using CommonDataTypes;
using TheraEngine.Helpers;

namespace Common.Resources;

public static class PortBonusCriteriaDecorator
{
	[CompilerGenerated]
	private sealed class _003CGetPortBonusCriterias_003Ed__4 : IEnumerable<PortBonusCriteria>, IEnumerable, IEnumerator<PortBonusCriteria>, IEnumerator, IDisposable
	{
		private int _007B3402_007D;

		private PortBonusCriteria _007B3403_007D;

		private int _007B3404_007D;

		private Decorator _007B3405_007D;

		public Decorator _003C_003E3__game;

		private PortCaptureStatus _007B3406_007D;

		public PortCaptureStatus _003C_003E3__inPort;

		PortBonusCriteria IEnumerator<PortBonusCriteria>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B3403_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B3403_007D;
			}
		}

		[DebuggerHidden]
		public _003CGetPortBonusCriterias_003Ed__4(int _007B3397_007D)
		{
			_007B3402_007D = _007B3397_007D;
			_007B3404_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B3398_007D()
		{
			_007B3402_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3398}
			this._007B3398_007D();
		}

		private bool _007B3399_007D()
		{
			switch (_007B3402_007D)
			{
			default:
				return false;
			case 0:
				_007B3402_007D = -1;
				_007B3403_007D = PortBonusCriteria.All;
				_007B3402_007D = 1;
				return true;
			case 1:
				_007B3402_007D = -1;
				if (!_007B3406_007D.IsCapturedByGuild && _007B3406_007D.PortInstance.Type != PortType.PirateBay)
				{
					_007B3403_007D = PortBonusCriteria.AllWhenEmpire;
					_007B3402_007D = 2;
					return true;
				}
				if (_007B3406_007D.CapturerFraction == FractionID.Pirate || _007B3406_007D.PortInstance.Type == PortType.PirateBay)
				{
					_007B3403_007D = PortBonusCriteria.AllWhenPirateOwner;
					_007B3402_007D = 3;
					return true;
				}
				if (_007B3406_007D.CapturerFraction == FractionID.TradeUnion || _007B3406_007D.PortInstance.IsArabPort)
				{
					if (_007B3405_007D.guild != null && !_007B3405_007D.guild.IsFlotilia && (_007B3405_007D.guild.Tag == _007B3406_007D.CapturedBy || _007B3405_007D.guild.IsTrusted(_007B3406_007D.CapturedBy)))
					{
						_007B3403_007D = PortBonusCriteria.TraderOwnerAndTrusted;
						_007B3402_007D = 8;
						return true;
					}
					break;
				}
				if (_007B3405_007D.guild?.Fraction == _007B3406_007D.CapturerFraction)
				{
					_007B3403_007D = PortBonusCriteria.AllNation;
					_007B3402_007D = 9;
					return true;
				}
				goto IL_036a;
			case 2:
				_007B3402_007D = -1;
				break;
			case 3:
				_007B3402_007D = -1;
				if (_007B3406_007D.PortInstance.Type == PortType.PirateBay && _007B3405_007D.guild != null && _007B3405_007D.guild.Fraction == FractionID.Pirate)
				{
					_007B3403_007D = PortBonusCriteria.PirateOwner;
					_007B3402_007D = 4;
					return true;
				}
				if (_007B3405_007D.guild == null || _007B3405_007D.guild.IsFlotilia)
				{
					_007B3403_007D = PortBonusCriteria.NeutralPirateReputation;
					_007B3402_007D = 5;
					return true;
				}
				if (_007B3405_007D.guild.Tag == _007B3406_007D.CapturedBy)
				{
					_007B3403_007D = PortBonusCriteria.PirateOwner;
					_007B3402_007D = 6;
					return true;
				}
				if (_007B3405_007D.guild.IsTrusted(_007B3406_007D.CapturedBy))
				{
					_007B3403_007D = PortBonusCriteria.PirateTrustedSupply;
					_007B3402_007D = 7;
					return true;
				}
				break;
			case 4:
				_007B3402_007D = -1;
				break;
			case 5:
				_007B3402_007D = -1;
				break;
			case 6:
				_007B3402_007D = -1;
				break;
			case 7:
				_007B3402_007D = -1;
				break;
			case 8:
				_007B3402_007D = -1;
				break;
			case 9:
				_007B3402_007D = -1;
				goto IL_036a;
			case 10:
				_007B3402_007D = -1;
				break;
			case 11:
				_007B3402_007D = -1;
				break;
			case 12:
				_007B3402_007D = -1;
				break;
			case 13:
				{
					_007B3402_007D = -1;
					break;
				}
				IL_036a:
				if (_007B3405_007D.guild == null || _007B3405_007D.guild.IsFlotilia)
				{
					_007B3403_007D = PortBonusCriteria.NeutralNationReputation;
					_007B3402_007D = 10;
					return true;
				}
				if (_007B3405_007D.guild.Tag == _007B3406_007D.CapturedBy)
				{
					_007B3403_007D = PortBonusCriteria.NationOwner;
					_007B3402_007D = 11;
					return true;
				}
				if (_007B3405_007D.guild.Fraction == _007B3406_007D.CapturerFraction)
				{
					_007B3403_007D = PortBonusCriteria.NationSupply;
					_007B3402_007D = 12;
					return true;
				}
				if (_007B3405_007D.guild.Fraction == FractionID.TradeUnion)
				{
					_007B3403_007D = PortBonusCriteria.TradeHqInNation;
					_007B3402_007D = 13;
					return true;
				}
				break;
			}
			return false;
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3399}
			return this._007B3399_007D();
		}

		[DebuggerHidden]
		private void _007B3400_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3400}
			this._007B3400_007D();
		}

		[DebuggerHidden]
		IEnumerator<PortBonusCriteria> IEnumerable<PortBonusCriteria>.GetEnumerator()
		{
			_003CGetPortBonusCriterias_003Ed__4 _003CGetPortBonusCriterias_003Ed__;
			if (_007B3402_007D == -2 && _007B3404_007D == Environment.CurrentManagedThreadId)
			{
				_007B3402_007D = 0;
				_003CGetPortBonusCriterias_003Ed__ = this;
			}
			else
			{
				_003CGetPortBonusCriterias_003Ed__ = new _003CGetPortBonusCriterias_003Ed__4(0);
			}
			_003CGetPortBonusCriterias_003Ed__._007B3405_007D = _003C_003E3__game;
			_003CGetPortBonusCriterias_003Ed__._007B3406_007D = _003C_003E3__inPort;
			return _003CGetPortBonusCriterias_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B3401_007D()
		{
			return ((IEnumerable<PortBonusCriteria>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3401}
			return this._007B3401_007D();
		}
	}

	public static bool IsAllCategory(this PortBonusCriteria _007B3381_007D)
	{
		return _007B3381_007D.HasFlag(PortBonusCriteria.All) || _007B3381_007D.HasFlag(PortBonusCriteria.AllWhenEmpire) || _007B3381_007D.HasFlag(PortBonusCriteria.AllWhenPirateOwner);
	}

	public static bool IsPirateCategory(this PortBonusCriteria _007B3382_007D)
	{
		return _007B3382_007D.HasFlag(PortBonusCriteria.AllWhenPirateOwner) || _007B3382_007D.HasFlag(PortBonusCriteria.PirateTrustedSupply) || _007B3382_007D.HasFlag(PortBonusCriteria.PirateOwner);
	}

	public static bool IsNationCategory(this PortBonusCriteria _007B3383_007D)
	{
		return _007B3383_007D.HasFlag(PortBonusCriteria.NationSupply) || _007B3383_007D.HasFlag(PortBonusCriteria.AllNation) || _007B3383_007D.HasFlag(PortBonusCriteria.NationOwner);
	}

	public static bool IsTraderCategory(this PortBonusCriteria _007B3384_007D)
	{
		return _007B3384_007D.HasFlag(PortBonusCriteria.TradeHqInNation) || _007B3384_007D.HasFlag(PortBonusCriteria.TraderOwnerAndTrusted);
	}

	[IteratorStateMachine(typeof(_003CGetPortBonusCriterias_003Ed__4))]
	public static IEnumerable<PortBonusCriteria> GetPortBonusCriterias(this Decorator _007B3385_007D, PortCaptureStatus _007B3386_007D)
	{
		//yield-return decompiler failed: Method not found
		return new _003CGetPortBonusCriterias_003Ed__4(-2)
		{
			_003C_003E3__game = _007B3385_007D,
			_003C_003E3__inPort = _007B3386_007D
		};
	}

	public static int GetPortBonusMaxLevel(this Decorator _007B3387_007D, IEnumerable<PortBonusCriteria> _007B3388_007D, PortLevelBonus _007B3389_007D, PortCaptureStatus _007B3390_007D, out PortBonusCriteria _007B3391_007D)
	{
		PortBonusCriteria[] source = new PortBonusCriteria[8]
		{
			PortBonusCriteria.PirateOwner,
			PortBonusCriteria.NationOwner,
			PortBonusCriteria.TraderOwnerAndTrusted,
			PortBonusCriteria.AllNation,
			PortBonusCriteria.AllWhenEmpire,
			PortBonusCriteria.AllWhenPirateOwner,
			PortBonusCriteria.NationSupply,
			PortBonusCriteria.PirateTrustedSupply
		};
		List<PortBonusCriteria> list = _007B3388_007D.Where((PortBonusCriteria _007B3395_007D) => _007B3389_007D.Criteria.HasFlag(_007B3395_007D)).ToList();
		_007B3391_007D = source.FirstOrDefault(list.Contains);
		if (_007B3391_007D == PortBonusCriteria.None)
		{
			_007B3391_007D = list.FirstOrDefault(PortBonusCriteria.None);
		}
		if (_007B3391_007D == PortBonusCriteria.None)
		{
			return 0;
		}
		return _007B3387_007D.GetPortBonusMaxLevel(_007B3391_007D, _007B3390_007D);
	}

	public static int GetPortBonusMaxLevel(this Decorator _007B3392_007D, PortBonusCriteria _007B3393_007D, PortCaptureStatus _007B3394_007D)
	{
		int num = 7;
		switch (_007B3393_007D)
		{
		case PortBonusCriteria.All:
		case PortBonusCriteria.NationOwner:
		case PortBonusCriteria.PirateOwner:
		case PortBonusCriteria.TraderOwnerAndTrusted:
		case PortBonusCriteria.AllNation:
			return num;
		case PortBonusCriteria.AllWhenEmpire:
			return (_007B3394_007D.CapturerFraction == FractionID.Empire) ? num : 0;
		case PortBonusCriteria.AllWhenPirateOwner:
			return (_007B3394_007D.CapturerFraction == FractionID.Pirate) ? num : 0;
		case PortBonusCriteria.NationSupply:
			return (_007B3392_007D.guild != null) ? Math.Min(_007B3392_007D.guild.CachedSupplyMissionCount, num) : 0;
		case PortBonusCriteria.PirateTrustedSupply:
			return (_007B3392_007D.guild != null) ? Math.Min(_007B3392_007D.guild.CachedSupplyMissionCount, num) : 0;
		case PortBonusCriteria.NeutralNationReputation:
		{
			float num3 = _007B3392_007D.account.Reputations[_007B3394_007D.CapturerFraction];
			float num4 = Geometry.InverseLerp(33f, 100f, num3);
			return (int)MathF.Round(num4 * (float)num);
		}
		case PortBonusCriteria.NeutralPirateReputation:
		{
			float averageRound = _007B3392_007D.account.Reputations.AverageRound;
			float num2 = Geometry.InverseLerp(33f, 100f, 0f - averageRound);
			return (int)MathF.Round(num2 * (float)num);
		}
		case PortBonusCriteria.TradeHqInNation:
			return (_007B3392_007D.guild != null) ? (_007B3392_007D.guild.HasHqOrLicense(_007B3394_007D.PortID) ? num : 0) : 0;
		default:
			return 0;
		}
	}
}
