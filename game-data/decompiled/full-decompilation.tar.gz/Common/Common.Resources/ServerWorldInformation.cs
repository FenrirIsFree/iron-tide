using Common.Game;
using Common.Packets;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine;

namespace Common.Resources;

public struct ServerWorldInformation : IMPSerializable
{
	public PortCaputreStatusList? WorldPorts;

	public bool NearPortHasTensitytempHq;

	public PbsEngageProblem NearPbAvanpostStatus;

	public bool NearPortAlwaysRespawn;

	public bool NearPortWindowOpenedAndNotInBattle;

	public bool NearPortHasDisorder;

	public bool NearPortHasManyPvpShips;

	private RTI _007B3307_007D;

	public int NearPortMooringCharge
	{
		get
		{
			return _007B3307_007D.IsInitialized ? _007B3307_007D.Value : 0;
		}
		set
		{
			_007B3307_007D = value;
		}
	}

	public bool Update(PortCaputreStatusList _007B3297_007D, bool _007B3298_007D, PbsEngageProblem _007B3299_007D, int _007B3300_007D, bool _007B3301_007D, bool _007B3302_007D, bool _007B3303_007D, bool _007B3304_007D)
	{
		bool flag = WorldPorts == null || !WorldPorts.Equals(_007B3297_007D) || NearPortHasTensitytempHq != _007B3298_007D || NearPbAvanpostStatus != _007B3299_007D || NearPortMooringCharge != _007B3300_007D || NearPortAlwaysRespawn != _007B3301_007D || NearPortWindowOpenedAndNotInBattle != _007B3302_007D || NearPortHasDisorder != _007B3303_007D || NearPortHasManyPvpShips != _007B3304_007D;
		if (flag)
		{
			WorldPorts = _007B3297_007D;
			NearPortHasTensitytempHq = _007B3298_007D;
			NearPbAvanpostStatus = _007B3299_007D;
			NearPortMooringCharge = _007B3300_007D;
			NearPortAlwaysRespawn = _007B3301_007D;
			NearPortWindowOpenedAndNotInBattle = _007B3302_007D;
			NearPortHasDisorder = _007B3303_007D;
			NearPortHasManyPvpShips = _007B3304_007D;
		}
		return flag;
	}

	public void Boxing(WriterExtern _007B3305_007D)
	{
		_007B3305_007D.WriteNoNull<PortCaputreStatusList>(WorldPorts);
		_007B3305_007D.Write(NearPortHasTensitytempHq);
		_007B3305_007D.WriteByte((byte)NearPbAvanpostStatus);
		_007B3305_007D.WriteStruct<int>(NearPortMooringCharge);
		_007B3305_007D.Write(NearPortAlwaysRespawn);
		_007B3305_007D.Write(NearPortWindowOpenedAndNotInBattle);
		_007B3305_007D.Write(NearPortHasDisorder);
		_007B3305_007D.Write(NearPortHasManyPvpShips);
	}

	public void Unboxing(WriterExtern _007B3306_007D)
	{
		_007B3306_007D.ReadIMPSNoNull<PortCaputreStatusList>(ref WorldPorts);
		_007B3306_007D.ReadBoolean(ref NearPortHasTensitytempHq);
		NearPbAvanpostStatus = (PbsEngageProblem)_007B3306_007D.ReadByte();
		int nearPortMooringCharge = default(int);
		_007B3306_007D.ReadStruct<int>(ref nearPortMooringCharge);
		NearPortMooringCharge = nearPortMooringCharge;
		_007B3306_007D.ReadBoolean(ref NearPortAlwaysRespawn);
		_007B3306_007D.ReadBoolean(ref NearPortWindowOpenedAndNotInBattle);
		_007B3306_007D.ReadBoolean(ref NearPortHasDisorder);
		_007B3306_007D.ReadBoolean(ref NearPortHasManyPvpShips);
	}
}
