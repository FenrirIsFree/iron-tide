using System;
using Microsoft.Xna.Framework;
using TheraEngine.Collections;
using TheraEngine.Helpers;

namespace Common.Resources;

public class FreePositionsSpace
{
	private const float minExtraRadius = 40f;

	private const float maxRandomOffset = 0.3f;

	public readonly Tlist<Vector2> Positions;

	public readonly WorldMapInfo Map;

	public bool IsLocatedOutside;

	public readonly float StepSize;

	public Vector2 RandomPosition => Positions.Array[Rand.RangeInt(0, Positions.Size)];

	public Vector2 RandomPositionShuffled
	{
		get
		{
			//IL_0005: Unknown result type (might be due to invalid IL or missing references)
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			//IL_0028: Unknown result type (might be due to invalid IL or missing references)
			//IL_0058: Unknown result type (might be due to invalid IL or missing references)
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_0069: Unknown result type (might be due to invalid IL or missing references)
			//IL_006a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0074: Unknown result type (might be due to invalid IL or missing references)
			Vector2 val2 = default(Vector2);
			do
			{
				Vector2 randomPosition = RandomPosition;
				Vector2 val = Rand.NextVector2(-0.3f * StepSize, 0.3f * StepSize);
				Vector2.Add(ref randomPosition, ref val, ref val2);
			}
			while (!(IsLocatedOutside ? Map.CheckPositionWithoutBorder(val2, 40f, _007B3086_007D: false) : Map.CheckPosition(val2, 40f)));
			return val2;
		}
	}

	internal FreePositionsSpace(int _007B3187_007D, WorldMapInfo _007B3188_007D, float _007B3189_007D)
	{
		StepSize = _007B3189_007D;
		Positions = new Tlist<Vector2>(_007B3187_007D);
		Map = _007B3188_007D;
	}

	public static FreePositionsSpace BuildFreePositions(WorldMapInfo _007B3190_007D, float _007B3191_007D, int _007B3192_007D = 32, float _007B3193_007D = 40f)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		FreePositionsSpace freePositionsSpace = new FreePositionsSpace(_007B3192_007D * _007B3192_007D, _007B3190_007D, Math.Min(_007B3190_007D.MapSize.X, _007B3190_007D.MapSize.Y) / (float)_007B3192_007D);
		Vector2 val = _007B3190_007D.MapSize / 2f;
		Vector2 item = default(Vector2);
		for (float num = _007B3191_007D; num < _007B3190_007D.MapSize.X - _007B3191_007D; num += freePositionsSpace.StepSize)
		{
			item.X = num - val.X;
			for (float num2 = _007B3191_007D; num2 < _007B3190_007D.MapSize.Y - _007B3191_007D; num2 += freePositionsSpace.StepSize)
			{
				item.Y = num2 - val.Y;
				if (_007B3190_007D.CheckPositionWithoutBorder(item, _007B3193_007D, _007B3086_007D: false))
				{
					freePositionsSpace.Positions.Add(in item);
				}
			}
		}
		freePositionsSpace.Positions.Trim();
		return freePositionsSpace;
	}

	public static FreePositionsSpace BuildFreePositionsOutside(WorldMapInfo _007B3194_007D, Vector2 _007B3195_007D, int _007B3196_007D = 32)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		FreePositionsSpace freePositionsSpace = new FreePositionsSpace(_007B3196_007D * _007B3196_007D / 10, _007B3194_007D, Math.Min(_007B3194_007D.MapSize.X, _007B3194_007D.MapSize.Y) / (float)_007B3196_007D)
		{
			IsLocatedOutside = true
		};
		Vector2 val = _007B3195_007D / 2f;
		Vector2 item = default(Vector2);
		for (float num = 0f; num < _007B3195_007D.X; num += freePositionsSpace.StepSize)
		{
			item.X = num - val.X;
			for (float num2 = 0f; num2 < _007B3195_007D.Y; num2 += freePositionsSpace.StepSize)
			{
				item.Y = num2 - val.Y;
				if ((item.Y < _007B3194_007D.EndCoordinates.Y - 50f || item.Y > _007B3194_007D.EndCoordinates.W + 50f || item.X < _007B3194_007D.EndCoordinates.X - 50f || item.X > _007B3194_007D.EndCoordinates.Z + 50f) && _007B3194_007D.CheckPositionWithoutBorder(item, 40f, _007B3086_007D: false))
				{
					freePositionsSpace.Positions.Add(in item);
				}
			}
		}
		freePositionsSpace.Positions.Trim();
		return freePositionsSpace;
	}

	public static FreePositionsSpace BuildPositionsNearObjects(WorldMapInfo _007B3197_007D, float _007B3198_007D, int _007B3199_007D = 31)
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		int num = 18;
		int num2 = 20;
		int num3 = 340;
		FreePositionsSpace freePositionsSpace = new FreePositionsSpace(_007B3199_007D * _007B3199_007D / 4, _007B3197_007D, Math.Min(_007B3197_007D.MapSize.X, _007B3197_007D.MapSize.Y) / (float)_007B3199_007D);
		Vector2 val = _007B3197_007D.MapSize / 2f;
		Vector2 _007B3057_007D = default(Vector2);
		float num7 = default(float);
		for (float num4 = _007B3198_007D; num4 < _007B3197_007D.MapSize.X - _007B3198_007D; num4 += freePositionsSpace.StepSize)
		{
			_007B3057_007D.X = num4 - val.X;
			for (float num5 = _007B3198_007D; num5 < _007B3197_007D.MapSize.Y - _007B3198_007D; num5 += freePositionsSpace.StepSize)
			{
				_007B3057_007D.Y = num5 - val.Y;
				if (!_007B3197_007D.CheckPosition(_007B3057_007D, num2))
				{
					continue;
				}
				Tlist<IsleInstance> visibleIsles = _007B3197_007D.GetVisibleIsles(in _007B3057_007D);
				int num6 = 0;
				for (int i = 0; i < visibleIsles.Size; i++)
				{
					IsleInstance isleInstance = visibleIsles.Array[i];
					if (!(isleInstance.ModelGlobalBS.Radius > (float)num))
					{
						continue;
					}
					for (int j = 0; j < isleInstance.TransformedFenceSpheres.Size; j++)
					{
						FenceSphere fenceSphere = isleInstance.TransformedFenceSpheres.Array[j];
						Vector2.DistanceSquared(ref fenceSphere.C, ref _007B3057_007D, ref num7);
						if (num7 < (fenceSphere.R + (float)num3) * (fenceSphere.R + (float)num3))
						{
							num6++;
						}
					}
				}
				if (num6 > 0)
				{
					freePositionsSpace.Positions.Add(in _007B3057_007D);
				}
			}
		}
		freePositionsSpace.Positions.Trim();
		return freePositionsSpace;
	}
}
