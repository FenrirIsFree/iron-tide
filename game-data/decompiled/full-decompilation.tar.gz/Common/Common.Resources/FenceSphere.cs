using Microsoft.Xna.Framework;

namespace Common.Resources;

public class FenceSphere
{
	public Vector2 C;

	public float R;

	public float Rpow2;

	public FenceSphere(in Vector2 _007B3237_007D, float _007B3238_007D)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		C = _007B3237_007D;
		R = _007B3238_007D;
		Rpow2 = _007B3238_007D * _007B3238_007D;
	}
}
