using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Account;
using Common.Game;
using Common.Packets;

namespace Common.Resources;

public sealed class RemotePlayerDynamicInfo : PlayerShipDynamicInfo
{
	private ShipProperties _007B2811_007D;

	private float _007B2812_007D;

	private float[] _007B2813_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private OpenWorldFlag _007B2814_007D;

	public int VisibleAccRank;

	public uint AccountSID;

	public CaptainTitle SelectedCaptainTitle;

	public PlayerReputations Reputations;

	public bool FlagsTensityMode;

	public OpenWorldFlag Flags
	{
		[CompilerGenerated]
		get
		{
			return _007B2814_007D;
		}
		[CompilerGenerated]
		set
		{
			_007B2814_007D = value;
		}
	}

	protected override float BasicArmor => _007B2811_007D.Armor;

	protected override float BasicCapacity => _007B2811_007D.CapacityCg;

	protected override float BasicHp => _007B2811_007D.MaxHp.Value;

	protected override float BasicMobility => _007B2812_007D;

	internal override float BasicSpeed => _007B2811_007D.MaxBasicSpeed;

	protected override int BasicCrewPlaces => (int)_007B2813_007D[4];

	public override float MendingKitEffectivityBonus => _007B2813_007D[0];

	public override float EffectJerkBonusSpeed => _007B2813_007D[1];

	public override float SpeedChangeBonus => _007B2813_007D[2];

	public override bool MakeCrewInvisible => _007B2813_007D[3] > 0f;

	public override float TiltReduce => _007B2813_007D[5];

	public override float MarchingModeSpeed => _007B2813_007D[7];

	public override bool HasExtraMortarUpgrade => _007B2813_007D[8] != 0f;

	public override float SpeedLossInMarchingMode => _007B2813_007D[9];

	public override int ExtraCrewLimit => (int)_007B2813_007D[10];

	public override float MobilityWithLowHp => _007B2813_007D[11];

	public float RemoteMarchingBonusSkill => _007B2813_007D[6];

	public bool PlayerDisableDestructionTilt => _007B2813_007D[13] > 0f;

	public override GSI BallsOfHold
	{
		get
		{
			throw new NotSupportedException();
		}
	}

	public override bool IsRemoteOrSlim => true;

	protected override float GetBonus(ShipBonusEffect _007B2806_007D, bool _007B2807_007D = true)
	{
		if (_007B2807_007D && DynamicBonus != null)
		{
			return DynamicBonus.Stats[_007B2806_007D];
		}
		return 0f;
	}

	public void UpdatePlayerMaxSpeed(OnPlayerCapacityUpdate _007B2808_007D)
	{
		_007B2811_007D.MaxBasicSpeed = _007B2808_007D.MaxSpeedWithoutCapacityFactor;
		_007B2813_007D[6] = _007B2808_007D.marchingSpeedBonusBySkill;
		_007B2813_007D[12] = _007B2808_007D.marchingSpeedBonusBySatiety;
	}

	private RemotePlayerDynamicInfo(PlayerShipInfo _007B2809_007D)
		: base(_007B2809_007D)
	{
	}

	public static RemotePlayerDynamicInfo Create(PlayerCreatePacket _007B2810_007D)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		RemotePlayerDynamicInfo remotePlayerDynamicInfo = new RemotePlayerDynamicInfo(Gameplay.PlayersInfo.FromID(_007B2810_007D.PlayerInfoID));
		remotePlayerDynamicInfo.DynamicBonus = _007B2810_007D.DynamicEffects;
		remotePlayerDynamicInfo.BigLampPosition = _007B2810_007D.DesignBigLampPosition;
		remotePlayerDynamicInfo.BowFigurePosition = _007B2810_007D.DesignBowFigurePosition;
		remotePlayerDynamicInfo._007B2811_007D = _007B2810_007D.FinalShipProperties;
		remotePlayerDynamicInfo.Cannons = _007B2810_007D.Cannons;
		remotePlayerDynamicInfo.Mortars = _007B2810_007D.Mortars;
		remotePlayerDynamicInfo.firstHP = _007B2810_007D.NowHP;
		remotePlayerDynamicInfo.ballsOfHold = new GSI();
		remotePlayerDynamicInfo.designEmenents = _007B2810_007D.DesingElements;
		remotePlayerDynamicInfo.UpdateDesingElementsBonuses();
		remotePlayerDynamicInfo._007B2812_007D = _007B2810_007D.StaticMobility;
		remotePlayerDynamicInfo.Upgrades = new UpgradesCollection();
		remotePlayerDynamicInfo.Crew = _007B2810_007D.Crew;
		remotePlayerDynamicInfo.Decal1SelectedSailesBits = _007B2810_007D.decal1SelectedSailes;
		remotePlayerDynamicInfo.Decal2SelectedSailesBits = _007B2810_007D.decal2SelectedSailes;
		remotePlayerDynamicInfo._007B2813_007D = _007B2810_007D.PrecompuredBonusEffects;
		remotePlayerDynamicInfo.Flags = _007B2810_007D.WorldFlags;
		remotePlayerDynamicInfo.VisibleAccRank = _007B2810_007D.AccRank;
		remotePlayerDynamicInfo.AccountSID = _007B2810_007D.AccountSID;
		remotePlayerDynamicInfo.SelectedCaptainTitle = _007B2810_007D.TitleIcon;
		remotePlayerDynamicInfo.hpFactorCached = remotePlayerDynamicInfo.HpFactor;
		remotePlayerDynamicInfo.Reputations = _007B2810_007D.Reputations;
		remotePlayerDynamicInfo.FlagsTensityMode = _007B2810_007D.FlagsTensityMode;
		return remotePlayerDynamicInfo;
	}
}
