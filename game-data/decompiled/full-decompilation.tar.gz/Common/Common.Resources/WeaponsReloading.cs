using System;
using Common.Game;
using TheraEngine;

namespace Common.Resources;

public class WeaponsReloading
{
	private float[] _007B2319_007D = new float[5];

	private float[] _007B2320_007D = new float[5];

	public float RearMortarReloadingLeftSec => _007B2319_007D[0] / 1000f;

	public float BackMortarReloadingLeftSec => _007B2319_007D[1] / 1000f;

	public float FalkonetsReloadingLeftSec => _007B2319_007D[2] / 1000f;

	public float PowderKegsReloadingLeftSec => _007B2319_007D[3] / 1000f;

	public float BoardingHookReloadingLeftSec => _007B2319_007D[4] / 1000f;

	public float RearMortarReloadingMaxSec => _007B2320_007D[0] / 1000f;

	public float BackMortarReloadingMaxSec => _007B2320_007D[1] / 1000f;

	public float FalkonetsReloadingMaxSec => _007B2320_007D[2] / 1000f;

	public float PowderKegsReloadingMaxSec => _007B2320_007D[3] / 1000f;

	public float BoardingHookReloadingMaxSec => _007B2320_007D[4] / 1000f;

	public float RearMortarReloadingFactor => 1f - _007B2319_007D[0] / _007B2320_007D[0];

	public float BackMortarReloadingFactor => 1f - _007B2319_007D[1] / _007B2320_007D[1];

	public float FalkonetsReloadingFactor => 1f - _007B2319_007D[2] / _007B2320_007D[2];

	public float PowderKegsReloadingFactor => 1f - _007B2319_007D[3] / _007B2320_007D[3];

	public WeaponsReloading()
	{
		ResetAll();
	}

	public void Update(ref FrameTime _007B2304_007D, Player _007B2305_007D)
	{
		if (_007B2305_007D.DebugEnabled)
		{
			for (int i = 0; i < _007B2319_007D.Length; i++)
			{
				_007B2319_007D[i] = Math.Max(0f, _007B2319_007D[i] - _007B2304_007D.msElapsed * 20f);
			}
		}
		_007B2306_007D(ref _007B2304_007D, _007B2305_007D, 4);
		FrameTime _007B2307_007D = _007B2304_007D * _007B2305_007D.ReloadingFalkonetsSpeed;
		_007B2306_007D(ref _007B2307_007D, _007B2305_007D, 2);
		_007B2306_007D(ref _007B2307_007D, _007B2305_007D, 3);
		FrameTime _007B2307_007D2 = _007B2304_007D * _007B2305_007D.ReloadingWeaponsSpeed;
		_007B2306_007D(ref _007B2307_007D2, _007B2305_007D, 0);
		_007B2306_007D(ref _007B2307_007D2, _007B2305_007D, 1);
	}

	private void _007B2306_007D(ref FrameTime _007B2307_007D, Player _007B2308_007D, int _007B2309_007D)
	{
		if ((_007B2309_007D == 0 || _007B2309_007D == 1) && _007B2319_007D[_007B2309_007D] > 0f)
		{
			_007B2319_007D[_007B2309_007D] = Math.Max(0f, _007B2319_007D[_007B2309_007D] - _007B2307_007D.msElapsed * _007B2308_007D.UsedShip.Crew.Effectivity(_007B2308_007D.UsedShip));
		}
		else
		{
			_007B2307_007D.EvaluteTimerMs(ref _007B2319_007D[_007B2309_007D]);
		}
	}

	public void BeginReloadingRearMortar(Player _007B2310_007D, CannonBallInfo _007B2311_007D)
	{
		_007B2320_007D[0] = _007B2310_007D.UsedShip.GetMortarsAverageParameters(_007B2311_007D).cooldownMs * _007B2311_007D.ReloadFactor * (1f - _007B2310_007D.UsedShip.MortarReloadBonus);
		_007B2319_007D[0] = _007B2320_007D[0];
	}

	public void BeginReloadingBackMortar(Player _007B2312_007D, CannonBallInfo _007B2313_007D)
	{
		_007B2320_007D[1] = _007B2312_007D.UsedShip.GetMortarsAverageParameters(_007B2313_007D).cooldownMs * _007B2313_007D.ReloadFactor * (1f - _007B2312_007D.UsedShip.MortarReloadBonus);
		_007B2319_007D[1] = _007B2320_007D[1];
	}

	public void BeginReloadingFalkonets(Player _007B2314_007D)
	{
		_007B2320_007D[2] = 23000f * (1f - _007B2314_007D.UsedShip.FalkonetReloadBonus);
		_007B2319_007D[2] = _007B2320_007D[2];
	}

	public void BeginReloadingPowderKegs(Player _007B2315_007D, PowderKegInfo _007B2316_007D)
	{
		_007B2320_007D[3] = (float)(_007B2316_007D.ReloadSec * 1000) * (1f - _007B2315_007D.UsedShip.PowderKegReloadBoost);
		_007B2319_007D[3] = _007B2320_007D[3];
	}

	public void BeginReloadingBoardingHooks(Player _007B2317_007D)
	{
		_007B2320_007D[4] = 23000f * (1f - _007B2317_007D.UsedShip.BoardingHookReloadBonus);
		_007B2319_007D[4] = _007B2320_007D[4];
	}

	public void BeginReloadingWhaleHooks(Player _007B2318_007D)
	{
		_007B2320_007D[4] = 15000f;
		_007B2319_007D[4] = _007B2320_007D[4];
	}

	public void ResetAll()
	{
		_007B2320_007D[0] = Math.Max(_007B2320_007D[0], 15000f);
		_007B2320_007D[1] = Math.Max(_007B2320_007D[1], 15000f);
		_007B2320_007D[2] = 23000f;
		_007B2320_007D[3] = 20000f;
		for (int i = 0; i < _007B2319_007D.Length; i++)
		{
			_007B2319_007D[i] = _007B2320_007D[i];
		}
		_007B2319_007D[4] = 0f;
	}
}
