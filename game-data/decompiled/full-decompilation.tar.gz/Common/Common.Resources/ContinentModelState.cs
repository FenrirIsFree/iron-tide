using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using TheraEngine.Assets.Graphics;
using TheraEngine.Collections;
using TheraEngine.Graphics.Models;
using UWContentPipelineExtensionRuntime;

namespace Common.Resources;

public class ContinentModelState
{
	public UWModel TerrainModel;

	public UWModel TerrainModelLowpoly;

	public UWOpenModel SceneShape;

	public UWModel GreenSet;

	public UWModel WinterSet;

	public UWModel BigObjects;

	public UWModel SmallObjects;

	public Vector3[] PortEntryPoints;

	public Vector3[] FumePoints;

	public Vector3[] Lights;

	public ContinentModelState(InstancedMaterialDictionary _007B2216_007D, Model _007B2217_007D)
	{
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		TerrainModel = UWModel.Create(_007B2216_007D, _007B2217_007D, "fTerrain");
		TerrainModelLowpoly = UWModel.Create(_007B2216_007D, _007B2217_007D, "fLowTerrain");
		SceneShape = UWOpenModel.Create(_007B2216_007D, _007B2217_007D, "fSceneShape");
		GreenSet = UWModel.Create(_007B2216_007D, _007B2217_007D, "fGreenSet");
		WinterSet = UWModel.Create(_007B2216_007D, _007B2217_007D, "fWinterSet");
		BigObjects = UWModel.Create(_007B2216_007D, _007B2217_007D, "fBigObjects");
		SmallObjects = UWModel.Create(_007B2216_007D, _007B2217_007D, "fSmallObjects");
		ModelHardpoint[] array = UWModel.ExtractAllHardpoints(_007B2217_007D);
		Tlist<Vector3> tlist = new Tlist<Vector3>();
		Tlist<Vector3> tlist2 = new Tlist<Vector3>();
		Tlist<Vector3> tlist3 = new Tlist<Vector3>();
		foreach (ModelHardpoint modelHardpoint in array)
		{
			if (modelHardpoint.HardpointID == WorldOfSeaBattleHardpointID.HPIsleFume)
			{
				tlist2.Add(((Matrix)(ref modelHardpoint.Transform)).Translation);
			}
			if (modelHardpoint.HardpointID == WorldOfSeaBattleHardpointID.HPLightID1)
			{
				tlist3.Add(((Matrix)(ref modelHardpoint.Transform)).Translation);
			}
		}
		PortEntryPoints = tlist.ToArray();
		FumePoints = tlist2.ToArray();
		Lights = tlist3.ToArray();
	}
}
