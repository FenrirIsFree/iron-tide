namespace Common.Resources;

public enum PortLevelBonusType
{
	ResourceProduction,
	CrewLimit,
	BondmanTrade,
	CapitalRestoreDiscount,
	AllCraftTimeReduction,
	ShipCraftAndRepairTimeReduction,
	PortMissionsCraftTime,
	ShipCraftingInLowerRankPort,
	AllFractionShipsCraftNoPenalty,
	ShipDecraftEffectiveness,
	ShipCraftDiscount,
	PowerupItemsCraftDiscount,
	TargetForTravel,
	TradersCantOpenHq,
	EmpireCantAttack,
	FactoriesMiningSpeed,
	AllPortsAuction,
	AllPortsAuctionPirate,
	RecoveryTimeAfterSink,
	AuctionLotLimit,
	BribeNotConsumedInWaterArea,
	WeaponCraftDiscount
}
