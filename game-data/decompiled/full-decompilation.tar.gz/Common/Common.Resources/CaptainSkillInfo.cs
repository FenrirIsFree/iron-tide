using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using Common.Data;
using Common.Game;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using TheraEngine;
using TheraEngine.Core;

namespace Common.Resources;

public class CaptainSkillInfo : XmlAsset<CaptainSkillBonusInfoToken>
{
	private string _007B2846_007D;

	private string _007B2847_007D;

	public readonly int UiCategory;

	public readonly int CostPoints;

	public readonly GSI CostResources;

	public readonly RTI CostGold;

	public readonly PDynamicAccountBonus Effect;

	public readonly int EffectValue;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private CaptainSkillInfo _007B2848_007D;

	public readonly Vector2 UiPosition;

	public readonly Vector2 UiRadialPosition;

	public readonly AchievementEnum[] RequiredAchievements;

	public readonly PlayerShipInfo[] RequiredShips;

	public readonly int RequiredRank;

	public readonly bool IsRemoved;

	public readonly Texture2D IconTexture;

	public string Name => (_007B2846_007D == Local.removed) ? Local.removed : Local.Current(_007B2846_007D + "_name");

	public string Description => (_007B2846_007D == Local.removed) ? Local.removed : Local.Current(_007B2846_007D + "_desc");

	public CaptainSkillInfo DependsTo
	{
		[CompilerGenerated]
		get
		{
			return _007B2848_007D;
		}
		[CompilerGenerated]
		private set
		{
			_007B2848_007D = value;
		}
	}

	public bool NeedSyncInPort => Effect == PDynamicAccountBonus.BTradeQuestSmuggling || Effect == PDynamicAccountBonus.CQuestsLimit || Effect == PDynamicAccountBonus.PMoreResourcesForDestryingNpc;

	public static (PDynamicAccountBonus, int) ParseBonus(string _007B2842_007D)
	{
		if (_007B2842_007D == null)
		{
			return (PDynamicAccountBonus.PSightSpeed, 0);
		}
		string[] array = _007B2842_007D.Split(new char[2] { '+', ' ' }, StringSplitOptions.RemoveEmptyEntries);
		PDynamicAccountBonus item = ((array.Length == 0) ? PDynamicAccountBonus.PSightSpeed : ((PDynamicAccountBonus)Enum.Parse(typeof(PDynamicAccountBonus), array[0])));
		int item2 = ((array.Length != 0) ? ((int)array[1].ParseSafe()) : 0);
		return (item, item2);
	}

	public CaptainSkillInfo(ContentManager _007B2843_007D, CaptainSkillBonusInfoToken _007B2844_007D, int _007B2845_007D)
		: base(_007B2845_007D)
	{
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		_007B2846_007D = _007B2844_007D.Name;
		UiCategory = _007B2844_007D.UiCategory;
		CostPoints = _007B2844_007D.CostPoints;
		CostGold = 0;
		CostResources = new GSI();
		if (_007B2844_007D.Cost.Length > 0)
		{
			string[] array = _007B2844_007D.Cost.Split(' ');
			for (int i = 0; i < array.Length; i += 2)
			{
				if (array[i] == "gold")
				{
					CostGold = int.Parse(array[i + 1]);
				}
				else
				{
					CostResources.Exs(Gameplay.GetResIDByAnnotation(array[i]), int.Parse(array[i + 1]));
				}
			}
		}
		_007B2847_007D = _007B2844_007D.DependsTo;
		UiPosition = _007B2844_007D.UiPosition;
		UiRadialPosition = _007B2844_007D.UiRadialPosition;
		RequiredAchievements = ((_007B2844_007D.RequiredAchievements.Length == 0) ? new AchievementEnum[0] : (from _007B2849_007D in _007B2844_007D.RequiredAchievements.Split(' ')
			select (AchievementEnum)Enum.Parse(typeof(AchievementEnum), _007B2849_007D)).ToArray());
		(PDynamicAccountBonus, int) tuple = ParseBonus(_007B2844_007D.Effect);
		Effect = tuple.Item1;
		EffectValue = tuple.Item2;
		IsRemoved = _007B2844_007D.Name == Local.removed;
		RequiredShips = ((_007B2844_007D.RequiredShips.Length == 0) ? new PlayerShipInfo[0] : (from _007B2850_007D in _007B2844_007D.RequiredShips.Split(',')
			select Gameplay.PlayersInfo.First((PlayerShipInfo _007B2852_007D) => _007B2852_007D.ShipName == _007B2850_007D)).ToArray());
		if (RequiredShips.Any((PlayerShipInfo _007B2851_007D) => _007B2851_007D == null))
		{
			throw new InvalidOperationException(_007B2844_007D.RequiredShips);
		}
		int.TryParse(_007B2844_007D.RequiredRank, out RequiredRank);
		if (!CommonGlobal.IsServer)
		{
			IconTexture = _007B2843_007D.Load<Texture2D>("_lzcommon\\Items\\Skills\\" + _007B2844_007D.IconTextureName);
		}
	}

	internal void OnInit()
	{
		if (string.IsNullOrEmpty(_007B2847_007D))
		{
			return;
		}
		foreach (CaptainSkillInfo item in (IEnumerable<CaptainSkillInfo>)Gameplay.CaptainSkillsInfo)
		{
			if (item._007B2846_007D == _007B2847_007D)
			{
				DependsTo = item;
				return;
			}
		}
		throw new InvalidOperationException(_007B2847_007D + " not found");
	}
}
