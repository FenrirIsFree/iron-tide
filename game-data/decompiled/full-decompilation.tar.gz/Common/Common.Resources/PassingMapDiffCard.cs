namespace Common.Resources;

public enum PassingMapDiffCard
{
	None,
	StrongFog,
	ImprovedNpcSpeedAndMobility,
	ImprovedNpcStrength,
	ImprovedNpcCrewAndReload,
	ImprovedNpcsAmmo,
	ExtraRegularNpcs,
	ExtraWaveNpcs,
	PowderKegsEverywhere,
	PlayerCurse,
	FastWavesCooldown,
	PowefulBoss,
	StrongWind,
	Towers
}
