using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine;

namespace Common.Resources;

public struct ShipProperties : IMPSerializable
{
	public RTIf MaxHp;

	public float CapacityCg;

	public float Armor;

	public float MaxBasicSpeed;

	public ShipProperties Clone()
	{
		return new ShipProperties
		{
			MaxHp = MaxHp.Value,
			CapacityCg = CapacityCg,
			Armor = Armor,
			MaxBasicSpeed = MaxBasicSpeed
		};
	}

	public ShipProperties(float _007B2511_007D, float _007B2512_007D, float _007B2513_007D, float _007B2514_007D)
	{
		MaxHp = _007B2511_007D;
		CapacityCg = _007B2512_007D;
		Armor = _007B2513_007D;
		MaxBasicSpeed = _007B2514_007D;
	}

	public override bool Equals(object _007B2515_007D)
	{
		if (_007B2515_007D == null)
		{
			return false;
		}
		if (_007B2515_007D.GetType() != GetType())
		{
			return false;
		}
		ShipProperties shipProperties = (ShipProperties)_007B2515_007D;
		return shipProperties.MaxHp.Value == MaxHp.Value && shipProperties.Armor == Armor && shipProperties.CapacityCg == CapacityCg && shipProperties.MaxBasicSpeed == MaxBasicSpeed;
	}

	private void _007B2516_007D(WriterExtern _007B2517_007D)
	{
		_007B2517_007D.WriteStruct<float>(MaxHp.Value);
		_007B2517_007D.WriteStruct<float>(CapacityCg);
		_007B2517_007D.WriteStruct<float>(Armor);
		_007B2517_007D.WriteStruct<float>(MaxBasicSpeed);
	}

	private void _007B2518_007D(WriterExtern _007B2519_007D)
	{
		float num = default(float);
		_007B2519_007D.ReadStruct<float>(ref num);
		MaxHp = num;
		_007B2519_007D.ReadStruct<float>(ref CapacityCg);
		_007B2519_007D.ReadStruct<float>(ref Armor);
		_007B2519_007D.ReadStruct<float>(ref MaxBasicSpeed);
	}
}
