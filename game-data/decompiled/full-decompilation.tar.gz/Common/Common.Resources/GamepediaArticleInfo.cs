using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using Common.Account;
using Common.Data;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using TheraEngine.Collections;

namespace Common.Resources;

public class GamepediaArticleInfo : XmlAsset<GamepediaArticleInfoToken>
{
	[CompilerGenerated]
	private sealed class _003CGetTextParagraphs_003Ed__12 : IEnumerable<string>, IEnumerable, IEnumerator<string>, IEnumerator, IDisposable
	{
		private int _007B3434_007D;

		private string _007B3435_007D;

		private int _007B3436_007D;

		public GamepediaArticleInfo _003C_003E4__this;

		private int _007B3437_007D;

		private string _007B3438_007D;

		string IEnumerator<string>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B3435_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B3435_007D;
			}
		}

		[DebuggerHidden]
		public _003CGetTextParagraphs_003Ed__12(int _007B3429_007D)
		{
			_007B3434_007D = _007B3429_007D;
			_007B3436_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B3430_007D()
		{
			_007B3438_007D = null;
			_007B3434_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3430}
			this._007B3430_007D();
		}

		private bool _007B3431_007D()
		{
			switch (_007B3434_007D)
			{
			default:
				return false;
			case 0:
				_007B3434_007D = -1;
				if (!Local.ContainsKey(_003C_003E4__this._007B3423_007D + "_text1"))
				{
					_007B3435_007D = "there is #nothing";
					_007B3434_007D = 1;
					return true;
				}
				_007B3435_007D = Local.Current(_003C_003E4__this._007B3423_007D + "_text1");
				_007B3434_007D = 2;
				return true;
			case 1:
				_007B3434_007D = -1;
				return false;
			case 2:
				_007B3434_007D = -1;
				_007B3437_007D = 2;
				break;
			case 3:
				_007B3434_007D = -1;
				_007B3437_007D++;
				_007B3438_007D = null;
				break;
			}
			_007B3438_007D = _003C_003E4__this._007B3423_007D + "_text" + _007B3437_007D;
			if (Local.ContainsKey(_007B3438_007D))
			{
				_007B3435_007D = Local.Current(_007B3438_007D);
				_007B3434_007D = 3;
				return true;
			}
			return false;
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3431}
			return this._007B3431_007D();
		}

		[DebuggerHidden]
		private void _007B3432_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3432}
			this._007B3432_007D();
		}

		[DebuggerHidden]
		IEnumerator<string> IEnumerable<string>.GetEnumerator()
		{
			_003CGetTextParagraphs_003Ed__12 result;
			if (_007B3434_007D == -2 && _007B3436_007D == Environment.CurrentManagedThreadId)
			{
				_007B3434_007D = 0;
				result = this;
			}
			else
			{
				result = new _003CGetTextParagraphs_003Ed__12(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			return result;
		}

		[DebuggerHidden]
		private IEnumerator _007B3433_007D()
		{
			return ((IEnumerable<string>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3433}
			return this._007B3433_007D();
		}
	}

	public readonly EducationOnboarding? Condition;

	public readonly Rectangle TexturePath;

	public readonly Tlist<GamepediaArticleInfo> Subparagraphs;

	private readonly string _007B3423_007D;

	private readonly string[] _007B3424_007D;

	private GamepediaArticleInfo[] _007B3425_007D;

	public string Title => Local.Current(_007B3423_007D);

	public GamepediaArticleInfo[] References => _007B3425_007D ?? throw new InvalidOperationException("not loaded");

	public GamepediaArticleInfo(GamepediaArticleInfoToken _007B3421_007D, int _007B3422_007D)
		: base(_007B3422_007D)
	{
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		_007B3423_007D = _007B3421_007D.ID;
		_007B3424_007D = _007B3421_007D.References.Split(' ');
		Condition = (string.IsNullOrEmpty(_007B3421_007D.ConditionID) ? ((EducationOnboarding?)null) : new EducationOnboarding?((EducationOnboarding)Enum.Parse(typeof(EducationOnboarding), _007B3421_007D.ConditionID)));
		Subparagraphs = new Tlist<GamepediaArticleInfo>(_007B3421_007D.Subparagraphs.Select((GamepediaArticleInfoToken _007B3426_007D) => new GamepediaArticleInfo(_007B3426_007D, -1)));
		if (_007B3421_007D.TexturePath.Length > 0)
		{
			int[] array = (from _007B3427_007D in _007B3421_007D.TexturePath.Split(' ', ',')
				select int.Parse(_007B3427_007D)).ToArray();
			TexturePath = new Rectangle(array[0], array[1], array[2], array[3]);
		}
		if (Title.Length == 0 || GetTextParagraphs().Count() == 0)
		{
			throw new Exception();
		}
	}

	public void PostInit()
	{
	}

	[IteratorStateMachine(typeof(_003CGetTextParagraphs_003Ed__12))]
	public IEnumerable<string> GetTextParagraphs()
	{
		//yield-return decompiler failed: Method not found
		return new _003CGetTextParagraphs_003Ed__12(-2)
		{
			_003C_003E4__this = this
		};
	}
}
