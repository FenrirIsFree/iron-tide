namespace Common.Resources;

public enum CannonLocation
{
	LeftSide,
	RightSide,
	InFront,
	InBack
}
