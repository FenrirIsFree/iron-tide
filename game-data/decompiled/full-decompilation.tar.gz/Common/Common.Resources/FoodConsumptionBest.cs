using System;

namespace Common.Resources;

internal class FoodConsumptionBest
{
	private float _007B2896_007D = 0f;

	private float _007B2897_007D = 0f;

	private const int periodFoodConsumptionSec = 30;

	private const int timeToMaxLevelOfHungerSec = 45;

	public float LevelOfHunger => _007B2896_007D;

	public bool Update(int _007B2894_007D, float _007B2895_007D)
	{
		bool result = false;
		_007B2897_007D += _007B2895_007D;
		if (_007B2897_007D > 30f)
		{
			if (_007B2894_007D == 0)
			{
				_007B2896_007D = Math.Min(1f, _007B2896_007D + _007B2895_007D / 45f);
			}
			else
			{
				_007B2897_007D -= 30f;
				result = true;
			}
		}
		return result;
	}
}
