using System;
using System.Collections.Generic;
using System.IO;
using Common.Data;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using TheraEngine;
using TheraEngine.Assets.Graphics;
using TheraEngine.Assets.Models;
using TheraEngine.Collections;
using TheraEngine.Graphics.Models;
using UWPhysicsWOSLib;
using UWPhysicsWOSLib.Shapes;

namespace Common.Resources;

public class IsleModelInfo : InstancedModel
{
	internal Tlist<Vector2> ShallowPointsRaw;

	internal Tlist<(Vector2, float)> NpcFencesRaw;

	internal bool IsEmptyShapeModel;

	internal volatile bool IsFinalLoaded;

	public readonly string Path;

	public readonly bool DamageWhenPassing;

	public readonly bool IsUnderwaterDecoration;

	public readonly WorldBindingType Binding;

	public TriangleMeshShape MeshShape;

	public readonly Tlist<UWModel> DesturctionParts;

	public readonly Tlist<UWModel> Flags;

	public readonly Tlist<Vector3> VulcanoSpawns;

	public readonly Dictionary<string, UWModel> Connections;

	public readonly FloatingIsleType IsFloating;

	public readonly BoundingSphere ShapeModelBs;

	private Action _007B3292_007D;

	private object _007B3293_007D = new object();

	private bool _007B3294_007D;

	public IsleModelInfo(InstancedMaterialDictionary _007B3280_007D, Model _007B3281_007D, Model _007B3282_007D, UWOpenModel _007B3283_007D, UWOpenModel _007B3284_007D, string _007B3285_007D)
	{
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0304: Unknown result type (might be due to invalid IL or missing references)
		//IL_0309: Unknown result type (might be due to invalid IL or missing references)
		//IL_030e: Unknown result type (might be due to invalid IL or missing references)
		//IL_04aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_04af: Unknown result type (might be due to invalid IL or missing references)
		UWModel uWModel = UWModel.CreateWithout(_007B3280_007D, _007B3281_007D, "BuildingDestructions", "BuildingFlag", "VulcanoSpawns", "Connection");
		UWModel uWModel2 = UWModel.CreateWithout(_007B3280_007D, _007B3282_007D, "Connection", "VulcanoSpawns");
		UWOpenModel modelShape = _007B3283_007D ?? _007B3284_007D;
		Path = _007B3285_007D;
		Model = uWModel;
		ModelLod1 = uWModel2;
		DamageWhenPassing = Model.ModelName.Contains("damage");
		IsUnderwaterDecoration = Model.ModelName.Contains("reefunderwater");
		IsFloating = ((!_007B3285_007D.Contains("iceBig") && !_007B3285_007D.Contains("iceB1")) ? (_007B3285_007D.Contains("floatingdetails") ? FloatingIsleType.Floating : (_007B3285_007D.Contains("icbergs") ? FloatingIsleType.HalfFloating : FloatingIsleType.Impossible)) : FloatingIsleType.Impossible);
		IsEmptyShapeModel = _007B3283_007D == null && !_007B3285_007D.Contains("npcfence");
		if (Model.ModelName.Contains("rivermarker"))
		{
			Binding = WorldBindingType.RiverMarker;
		}
		else if (Model.ModelName.Contains("binding_fog"))
		{
			Binding = WorldBindingType.Fog;
		}
		else if (Model.ModelName.Contains("pb_resp_attack"))
		{
			Binding = WorldBindingType.PbAttackerRespawn;
		}
		else if (Model.ModelName.Contains("pb_resp_defend"))
		{
			Binding = WorldBindingType.PbDefenderRespawn;
		}
		else if (Model.ModelName.Contains("npcfence"))
		{
			Binding = WorldBindingType.NpcFence;
		}
		ShapeModelBs = modelShape.CommonSphere;
		if (_007B3281_007D != _007B3282_007D)
		{
			string fileName = System.IO.Path.GetFileName(_007B3285_007D);
			if ((float)ModelLod1.PrimitiveCount / 0.6f > (float)Model.PrimitiveCount)
			{
				GameLoader.Current.AddImportant("Model " + _007B3285_007D + " has not-efficient LOD model");
			}
			else if (Model.PrimitiveCount < 5000)
			{
				GameLoader.Current.AddImportant("Model " + _007B3285_007D + " should not have LOD model");
			}
		}
		if (_007B3281_007D == _007B3282_007D && Model.PrimitiveCount > 60000)
		{
			GameLoader.Current.AddImportant("Model " + _007B3285_007D + " big but doesn't have LOD");
		}
		MeshPartData[] meshParts = Model.MeshParts;
		foreach (MeshPartData meshPartData in meshParts)
		{
			if (meshPartData.LocalSpaceBoundingSphere.Radius + ((Vector3)(ref meshPartData.LocalSpaceBoundingSphere.Center)).Length() > 3000f)
			{
				Vector2 val = meshPartData.LocalSpaceBoundingSphere.Center.XY();
				if (((Vector2)(ref val)).Length() > 5000f)
				{
					GameLoader.Current.AddImportant("Model size-check failed " + _007B3285_007D);
				}
			}
		}
		GameLoader.RunWorker(delegate
		{
			int num = 20;
			float _007B246_007D = MathF.Pow((float)num + modelShape.CommonSphere.Radius, 1.1f) / ((float)modelShape.PrimitiveCount / 300f);
			MeshShape = new TriangleMeshShape(modelShape, _007B246_007D, num);
			_007B3286_007D(modelShape);
			lock (_007B3293_007D)
			{
				_007B3292_007D?.Invoke();
				_007B3294_007D = true;
			}
			IsFinalLoaded = true;
			modelShape = null;
		});
		Connections = new Dictionary<string, UWModel>();
		if (CommonGlobal.IsServer)
		{
			uWModel.DisposeWithSourceData();
			uWModel2.DisposeWithSourceData();
		}
		else
		{
			DesturctionParts = UWModel.Separate(_007B3280_007D, _007B3281_007D, "BuildingDestructions");
			Flags = UWModel.Separate(_007B3280_007D, _007B3281_007D, "BuildingFlag");
			VulcanoSpawns = new Tlist<Vector3>();
			Tlist<UWModel> tlist = UWModel.Separate(_007B3280_007D, _007B3281_007D, "VulcanoSpawns");
			foreach (UWModel item in (IEnumerable<UWModel>)tlist)
			{
				VulcanoSpawns.Add(in item.CommonSphere.Center);
			}
		}
		Tlist<UWModel> tlist2 = UWModel.Separate(_007B3280_007D, _007B3281_007D, "Connection");
		foreach (UWModel item2 in (IEnumerable<UWModel>)tlist2)
		{
			Connections.Add(item2.MeshName, item2);
		}
		NpcFencesRaw = new Tlist<(Vector2, float)>(10);
		foreach (KeyValuePair<string, UWModel> connection in Connections)
		{
			if (connection.Key.Contains("NpcFence"))
			{
				NpcFencesRaw.Add((connection.Value.CommonSphere.Center.XZ(), connection.Value.CommonSphere.Radius));
			}
		}
		NpcFencesRaw.Trim();
	}

	private void _007B3286_007D(UWOpenModel _007B3287_007D)
	{
		if (IsEmptyShapeModel)
		{
			return;
		}
		float num = 56.91057f;
		float distanceStepSq = num * num;
		ShallowPointsRaw = new Tlist<Vector2>(100);
		ShapeHelper.ClipPlane(MeshShape, 0.4f, delegate(Vector3 _007B3295_007D)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0034: Unknown result type (might be due to invalid IL or missing references)
			Vector2 item = _007B3295_007D.XZ();
			for (int num2 = ShallowPointsRaw.Size - 1; num2 >= 0; num2--)
			{
				if (Vector2.DistanceSquared(ShallowPointsRaw.Array[num2], item) < distanceStepSq)
				{
					return;
				}
			}
			ShallowPointsRaw.Add(in item);
		});
		ShallowPointsRaw.Trim();
		if (ShallowPointsRaw.Size == 0)
		{
			ShallowPointsRaw = null;
			if (_007B3287_007D.CommonSphere.Radius > 30f && !Model.ModelName.Contains("reef"))
			{
				GameLoader.Current.AddImportant("Model: " + Path + " hasn't points in shape for clipPlane");
			}
		}
	}

	internal void ApplyWithWorker(Action _007B3288_007D)
	{
		lock (_007B3293_007D)
		{
			if (_007B3294_007D)
			{
				_007B3288_007D();
			}
			else
			{
				_007B3292_007D = (Action)Delegate.Combine(_007B3292_007D, _007B3288_007D);
			}
		}
	}

	private static bool isLeft(Vector2 _007B3289_007D, Vector2 _007B3290_007D, Vector2 _007B3291_007D)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		return (_007B3290_007D.X - _007B3289_007D.X) * (_007B3291_007D.Y - _007B3289_007D.Y) - (_007B3290_007D.Y - _007B3289_007D.Y) * (_007B3291_007D.X - _007B3289_007D.X) > 0f;
	}
}
