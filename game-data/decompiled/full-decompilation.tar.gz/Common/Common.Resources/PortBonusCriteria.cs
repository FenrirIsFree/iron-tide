using System;

namespace Common.Resources;

[Flags]
public enum PortBonusCriteria
{
	None = 0,
	All = 1,
	NationOwner = 2,
	PirateOwner = 4,
	TraderOwnerAndTrusted = 8,
	AllWhenEmpire = 0x10,
	NationSupply = 0x20,
	PirateTrustedSupply = 0x40,
	NeutralNationReputation = 0x80,
	NeutralPirateReputation = 0x100,
	TradeHqInNation = 0x200,
	AllWhenPirateOwner = 0x400,
	AllNation = 0x800
}
