using Common.Data;
using Common.Game;
using CommonDataTypes;
using Microsoft.Xna.Framework.Graphics;
using TheraEngine;
using TheraEngine.Core;

namespace Common.Resources;

public class PowderKegInfo : XmlAsset<PowderKegInfoToken>, IStorageAsset
{
	internal string nameKey;

	private string _007B2876_007D;

	public readonly int Mass;

	public readonly RTI ShopCostGold;

	public readonly GSI ShopCostItems;

	public readonly int DamageL;

	public readonly float TriggerRadius;

	public readonly float DamageRadius;

	public readonly int KegsCount;

	public readonly Texture2D IconTexture;

	public readonly Texture2D IconTextureCircular;

	public readonly int ReloadSec;

	public readonly bool IsRare;

	public readonly int CrewUsage;

	public string Name => Local.Current(nameKey);

	public string Description => Local.Current(_007B2876_007D);

	public bool IsInvisibleMine => base.ID == 5 || base.ID == 6;

	public bool AdditionalCorpusCrit => base.ID == 5;

	public bool AdditionalShipSpeedReduce => base.ID == 3 || base.ID == 6;

	public float AdditionalFireZone => (base.ID == 2) ? FirePowderKegFireZone(_007B2872_007D: false) : 0f;

	public int? AvailableSinceRank => (base.ID == 7 || base.ID == 5) ? new int?(3) : ((base.ID > 3) ? new int?(4) : ((int?)null));

	public bool isFirebrand => base.ID == 7;

	float IStorageAsset.getStorageMass => Mass;

	string IStorageAsset.getName => Name;

	string IStorageAsset.getDescription => Description;

	Texture2D IStorageAsset.getIconTexture => IconTexture;

	StorageAssetEnum IStorageAsset.getType => StorageAssetEnum.PowderKeg;

	public static float FirePowderKegFireZone(bool _007B2872_007D)
	{
		return _007B2872_007D ? 14.5f : 12f;
	}

	public PowderKegInfo(ContentManager _007B2873_007D, PowderKegInfoToken _007B2874_007D, int _007B2875_007D)
		: base(_007B2875_007D)
	{
		nameKey = ((_007B2874_007D.ID == "removed") ? _007B2874_007D.ID : (_007B2874_007D.ID + "_name"));
		_007B2876_007D = ((_007B2874_007D.ID == "removed") ? _007B2874_007D.ID : (_007B2874_007D.ID + "_desc"));
		Mass = _007B2874_007D.Mass;
		ShopCostGold = _007B2874_007D.ShopGold;
		ShopCostItems = new GSI();
		if (_007B2874_007D.ShopVuduSkull != 0)
		{
			ShopCostItems.AddOrRemove(38, _007B2874_007D.ShopVuduSkull);
		}
		if (_007B2874_007D.ShopWarMarks != 0)
		{
			ShopCostItems.AddOrRemove(37, _007B2874_007D.ShopWarMarks);
		}
		IconTexture = _007B2873_007D.Load<Texture2D>("_lzcommon\\Items\\PowderKegs\\" + _007B2874_007D.IconTextureName);
		IconTextureCircular = _007B2873_007D.Load<Texture2D>("_lzcommon\\Items\\PowderKegs\\" + _007B2874_007D.IconTextureName + "_cir");
		DamageL = _007B2874_007D.Damage;
		TriggerRadius = _007B2874_007D.TriggerRadius;
		DamageRadius = _007B2874_007D.DamageRadius;
		KegsCount = _007B2874_007D.KegsCount;
		ReloadSec = _007B2874_007D.ReloadSec;
		IsRare = _007B2874_007D.IsRare;
		CrewUsage = _007B2874_007D.CrewUsage;
	}
}
