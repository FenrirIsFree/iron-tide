using System;
using System.Linq;
using Common.Data;
using Common.Game;
using CommonDataTypes;
using Microsoft.Xna.Framework.Graphics;
using TheraEngine;
using TheraEngine.Assets.Content;
using TheraEngine.Core;
using World_Of_Sea_Battle.Constants;

namespace Common.Resources;

public class UnitInfo : XmlAsset<UnitInfoToken>, IStorageAsset
{
	public int? Editor_Health = null;

	public float? Editor_SampleDamage = null;

	public int? Editor_Capacity = null;

	private string _007B3448_007D;

	private string _007B3449_007D;

	public readonly RTI CostGold;

	public readonly RTI CostMarks;

	public readonly Texture2D Icon;

	private readonly int _007B3450_007D;

	private readonly float _007B3451_007D;

	private readonly int _007B3452_007D;

	public readonly UnitType Type;

	public readonly SpecialUnitClass SpecialUnitClass;

	public readonly ShipBonus Bonus;

	public readonly ShipBonus BonusPerSailor;

	public readonly ShipBonus BonusPerBoardingUnit;

	public readonly bool IsNotAvailableInAllPorts;

	private readonly string _007B3453_007D;

	public readonly int InternalPrice;

	public string Name => Local.Current(_007B3448_007D);

	public string Text => Local.Current(_007B3449_007D);

	public int Health => Editor_Health ?? _007B3450_007D;

	public float SampleDamage => Editor_SampleDamage ?? _007B3451_007D;

	public int Capacity => Editor_Capacity ?? _007B3452_007D;

	public bool IsMusketeer => base.ID == 2;

	float IStorageAsset.getStorageMass => 1f;

	string IStorageAsset.getName => Name;

	Texture2D IStorageAsset.getIconTexture => Icon;

	StorageAssetEnum IStorageAsset.getType => StorageAssetEnum.Unit_DiplayOnly;

	short IStorageAsset.ID => base.ID;

	string IStorageAsset.getDescription => Text;

	public UnitInfo(ContentManager _007B3442_007D, UnitInfoToken _007B3443_007D, int _007B3444_007D)
		: base(_007B3444_007D)
	{
		_007B3448_007D = _007B3443_007D.ID + "_name";
		_007B3449_007D = _007B3443_007D.ID + "_text";
		Icon = _007B3442_007D.Load<Texture2D>("_lzcommon\\Items\\Units\\" + _007B3443_007D.IconName);
		Type = (UnitType)Enum.Parse(typeof(UnitType), _007B3443_007D.Type);
		if (Type == UnitType.Special)
		{
			string[] array = _007B3443_007D.Options.Split(' ');
			if (!array.Any())
			{
				throw new InvalidOperationException("Special should have class");
			}
			for (int i = 0; i < array.Length; i++)
			{
				if (Enum.TryParse<SpecialUnitClass>(array[i], ignoreCase: true, out var result))
				{
					SpecialUnitClass = result;
				}
			}
			_007B3453_007D = string.Empty;
		}
		else
		{
			IsNotAvailableInAllPorts = _007B3443_007D.Options.Length == 0;
			_007B3453_007D = _007B3443_007D.Options;
		}
		CostGold = _007B3443_007D.Cost;
		CostMarks = _007B3443_007D.CostMarks;
		_007B3450_007D = _007B3443_007D.DHealth;
		_007B3451_007D = _007B3443_007D.DDamage;
		_007B3452_007D = _007B3443_007D.DCapacity;
		bool flag = true;
		CostGold.Value = Math.Max(Math.Sign(CostGold.Value), CostGold.Value / 4);
		CostMarks.Value = Math.Max(Math.Sign(CostMarks.Value), CostMarks.Value / 4);
		if (!string.IsNullOrEmpty(_007B3443_007D.Effect))
		{
			Bonus = ShipUpgradeInfo.ParseHelper(_007B3443_007D.Effect)[0];
		}
		if (!string.IsNullOrEmpty(_007B3443_007D.EffectPerSailor))
		{
			BonusPerSailor = ShipUpgradeInfo.ParseHelper(_007B3443_007D.EffectPerSailor)[0];
		}
		if (!string.IsNullOrEmpty(_007B3443_007D.EffectPerBoardingUnit))
		{
			BonusPerBoardingUnit = ShipUpgradeInfo.ParseHelper(_007B3443_007D.EffectPerBoardingUnit)[0];
		}
		InternalPrice = CostGold.Value + CostMarks.Value * 100 + (IsNotAvailableInAllPorts ? 500 : 0);
	}

	public bool IsAvailableInPort(IslePortInfo _007B3445_007D)
	{
		if (IsNotAvailableInAllPorts)
		{
			return false;
		}
		if (_007B3453_007D.Contains("All"))
		{
			return true;
		}
		return _007B3445_007D.Flags.Contains(_007B3453_007D);
	}

	public string GetBonusDescription()
	{
		if (Bonus.Value != 0f)
		{
			return Bonus.ToString() ?? "";
		}
		if (BonusPerSailor.Value != 0f)
		{
			return Local.UnitBonus_2 + " " + BonusPerSailor;
		}
		if (BonusPerBoardingUnit.Value != 0f)
		{
			return Local.UnitBonus_3 + " " + BonusPerBoardingUnit;
		}
		return "";
	}

	public string GetBonusDescriptionShort(CustomSpriteFont _007B3446_007D, int _007B3447_007D)
	{
		string _007B286_007D = string.Empty;
		if (Bonus.Value != 0f)
		{
			_007B286_007D = Bonus.ToString();
		}
		if (BonusPerSailor.Value != 0f)
		{
			_007B286_007D = BonusPerSailor.ToString();
		}
		if (BonusPerBoardingUnit.Value != 0f)
		{
			_007B286_007D = BonusPerBoardingUnit.ToString();
		}
		return StringHelper.TrimByLength(_007B3446_007D, _007B286_007D, _007B3447_007D);
	}
}
