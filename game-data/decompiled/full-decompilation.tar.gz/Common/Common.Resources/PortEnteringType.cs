namespace Common.Resources;

public enum PortEnteringType
{
	None,
	Port,
	Miniport,
	PersonalIsle
}
