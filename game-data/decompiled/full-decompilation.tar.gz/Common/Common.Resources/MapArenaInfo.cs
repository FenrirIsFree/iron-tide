using System;
using System.Collections.Generic;
using System.Linq;
using Common.Data;
using Common.Game;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using TheraEngine.Collections;
using TheraEngine.Helpers;

namespace Common.Resources;

public class MapArenaInfo : WorldMapInfo
{
	private Vector2 _007B3322_007D;

	private Vector2 _007B3323_007D;

	private Vector2 _007B3324_007D;

	private Vector2 _007B3325_007D;

	internal Vector2 DiagonalMinus1;

	public Vector2 Side1FortPos;

	public Vector2 Side2FortPos;

	public Vector2[] side1_tower;

	public Vector2[] side2_tower;

	public Tlist<Vector2> CollectingModeFreePositions;

	public readonly ArenaMode[] GameplayMode;

	public readonly Tlist<Vector2> UpDropSpawnPositions;

	private const int countObjects = 8;

	private Vector2 _007B3315_007D(float _007B3316_007D, float _007B3317_007D)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		float num = 1f / 12f * MapSize.X;
		return new Vector2((12f - _007B3316_007D) * num - MapSize.X * 0.5f, _007B3317_007D * num - MapSize.X * 0.5f) * 0.8f;
	}

	public MapArenaInfo(MapArenaInfoToken _007B3318_007D, int _007B3319_007D)
		: base(2, _007B3318_007D.MapName, (WorldMapStyle)_007B3318_007D.Style, _007B3319_007D, new Vector2((float)_007B3318_007D.Size), _007B3318_007D.Objects)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0301: Unknown result type (might be due to invalid IL or missing references)
		ClonePresets();
		GameplayMode = (from _007B3327_007D in _007B3318_007D.GameplayMode.Split(',', StringSplitOptions.TrimEntries)
			where Enum.TryParse<ArenaMode>(_007B3327_007D, out var _)
			select Enum.Parse<ArenaMode>(_007B3327_007D)).ToArray();
		_007B3325_007D = _007B3315_007D(6f, 6f);
		DiagonalMinus1 = _007B3315_007D(9f, 9f);
		_007B3324_007D = _007B3315_007D(3f, 3f);
		_007B3322_007D = _007B3315_007D(1.75f, 10.25f);
		_007B3323_007D = _007B3315_007D(10.25f, 1.75f);
		Side1FortPos = _007B3315_007D(0.7f, 11.3f);
		Side2FortPos = _007B3315_007D(11.3f, 0.7f);
		Geometry.RotateVector2Fast(ref Side1FortPos, -0.3f, ref Side1FortPos);
		Geometry.RotateVector2Fast(ref Side2FortPos, -0.3f, ref Side2FortPos);
		side1_tower = (Vector2[])(object)new Vector2[3]
		{
			_007B3315_007D(7.5f, 11f),
			_007B3315_007D(3.5f, 8.5f),
			_007B3315_007D(1f, 4.5f)
		};
		side2_tower = (Vector2[])(object)new Vector2[3]
		{
			_007B3315_007D(11f, 7.5f),
			_007B3315_007D(8.5f, 3.5f),
			_007B3315_007D(4.5f, 1f)
		};
		UpDropSpawnPositions = new Tlist<Vector2>();
		foreach (IsleInstance item2 in (IEnumerable<IsleInstance>)Isles)
		{
			if (item2.ModelData.Model.ModelName.Contains("fl_dropspawn"))
			{
				UpDropSpawnPositions.Add(in item2.GlobalPosition);
			}
		}
		float num = 30f;
		FreePositionsSpace freePositionsSpace = FreePositionsSpace.BuildFreePositions(this, 75f, (int)(MapSize.X / num), 15f);
		CollectingModeFreePositions = new Tlist<Vector2>(100);
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector(0f, MapSize.Y / 2f);
		for (int num2 = 0; num2 < freePositionsSpace.Positions.Size; num2++)
		{
			Vector2 item = freePositionsSpace.Positions.Array[num2];
			if ((double)MathF.Abs(Geometry.RotateVector2(item, -(float)Math.PI / 4f).X) < (double)MapSize.X * 0.2 && CheckPosition(item) && ((Vector2)(ref item)).Length() < MapSize.X * 0.4f)
			{
				CollectingModeFreePositions.Add(in item);
			}
		}
		if (CollectingModeFreePositions.Size < 10)
		{
			GameLoader.Current.AddImportant($"Arena map ID {_007B3319_007D} doens't have enough free space ({CollectingModeFreePositions.Size} / 10) to put collecting mode position. Check it");
		}
	}

	private static float GetFortAxis(Vector2 _007B3320_007D)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		((Vector2)(ref _007B3320_007D)).Normalize();
		return 0f - MathF.Atan2(_007B3320_007D.Y, _007B3320_007D.X);
	}

	public (Vector2 team1Resp, Vector2 team2Resp) GetRespawns(ArenaMode _007B3321_007D)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return (team1Resp: _007B3322_007D, team2Resp: _007B3323_007D);
	}
}
