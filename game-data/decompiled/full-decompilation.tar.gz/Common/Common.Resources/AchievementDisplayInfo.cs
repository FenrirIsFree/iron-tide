using System;
using Common.Data;
using CommonDataTypes;
using Microsoft.Xna.Framework.Graphics;
using TheraEngine.Core;

namespace Common.Resources;

public class AchievementDisplayInfo : XmlAsset<AchievementDisplayInfoToken>
{
	private string _007B2836_007D;

	private string _007B2837_007D;

	public readonly AchievementEnum AchievementEnum;

	public readonly AchievementEnum[] ReferencesAsEnum;

	public readonly int CommonRatingWeight;

	public readonly bool IsSingleGive;

	public readonly Texture2D Icon;

	public readonly AchievementInterfaceCategory UiCategory;

	public string Name => Local.Current(_007B2836_007D);

	public string Description => _007B2835_007D();

	public AchievementDisplayInfo(ContentManager _007B2832_007D, AchievementDisplayInfoToken _007B2833_007D, int _007B2834_007D)
		: base(_007B2834_007D)
	{
		_007B2836_007D = _007B2833_007D.Name + "_name";
		_007B2837_007D = _007B2833_007D.Name + "_desc";
		AchievementEnum = _007B2833_007D.ID;
		ReferencesAsEnum = (string.IsNullOrEmpty(_007B2833_007D.ReferencesAsEnum) ? new AchievementEnum[0] : new AchievementEnum[1] { Enum.Parse<AchievementEnum>(_007B2833_007D.ReferencesAsEnum) });
		CommonRatingWeight = _007B2833_007D.CommonRatingWeight;
		IsSingleGive = _007B2833_007D.IsSingleGive;
		UiCategory = _007B2833_007D.UiCategory;
		Icon = _007B2832_007D.Load<Texture2D>("_lzcommon\\Items\\Achievements\\" + _007B2833_007D.ID);
	}

	private string _007B2835_007D()
	{
		if (AchievementEnum == AchievementEnum.LuckyOne)
		{
			return Local.Current(_007B2837_007D, 77);
		}
		return Local.Current(_007B2837_007D);
	}
}
