using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Microsoft.Xna.Framework;
using TheraEngine.Graphics.Models;
using UWPhysicsWOSLib.Shapes;

namespace Common.Resources;

public class SailHitbox : IShipHitbox
{
	[CompilerGenerated]
	private sealed class _003CEnumerateBaseShapes_003Ed__21 : IEnumerable<BoxShape>, IEnumerable, IEnumerator<BoxShape>, IEnumerator, IDisposable
	{
		private int _007B2503_007D;

		private BoxShape _007B2504_007D;

		private int _007B2505_007D;

		public SailHitbox _003C_003E4__this;

		private int _007B2506_007D;

		BoxShape IEnumerator<BoxShape>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B2504_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B2504_007D;
			}
		}

		[DebuggerHidden]
		public _003CEnumerateBaseShapes_003Ed__21(int _007B2498_007D)
		{
			_007B2503_007D = _007B2498_007D;
			_007B2505_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B2499_007D()
		{
			_007B2503_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2499}
			this._007B2499_007D();
		}

		private bool _007B2500_007D()
		{
			switch (_007B2503_007D)
			{
			default:
				return false;
			case 0:
				_007B2503_007D = -1;
				_007B2504_007D = _003C_003E4__this.CommonShape;
				_007B2503_007D = 1;
				return true;
			case 1:
				_007B2503_007D = -1;
				_007B2506_007D = 0;
				break;
			case 2:
				_007B2503_007D = -1;
				_007B2506_007D++;
				break;
			}
			if (_007B2506_007D < _003C_003E4__this.Shape.Length)
			{
				_007B2504_007D = _003C_003E4__this.Shape[_007B2506_007D];
				_007B2503_007D = 2;
				return true;
			}
			return false;
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2500}
			return this._007B2500_007D();
		}

		[DebuggerHidden]
		private void _007B2501_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2501}
			this._007B2501_007D();
		}

		[DebuggerHidden]
		IEnumerator<BoxShape> IEnumerable<BoxShape>.GetEnumerator()
		{
			_003CEnumerateBaseShapes_003Ed__21 result;
			if (_007B2503_007D == -2 && _007B2505_007D == Environment.CurrentManagedThreadId)
			{
				_007B2503_007D = 0;
				result = this;
			}
			else
			{
				result = new _003CEnumerateBaseShapes_003Ed__21(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			return result;
		}

		[DebuggerHidden]
		private IEnumerator _007B2502_007D()
		{
			return ((IEnumerable<BoxShape>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2502}
			return this._007B2502_007D();
		}
	}

	public const int levelsCount = 4;

	public UWModel Model;

	public UWModel ModelRolled;

	public byte CollisionNodeID;

	public BoxShape[] Shape;

	public BoxShape CommonShape;

	public float Weight;

	public float WeigthMul;

	public Vector2 ModelSpaceRotationPivot;

	public bool IsSailAnimated;

	public int SailStrengthIndex;

	public Vector3 VisualPosition => Model.CommonSphere.Center;

	public bool IsPerpendicular => CommonShape.length > CommonShape.width;

	public byte NodeID
	{
		get
		{
			return CollisionNodeID;
		}
		set
		{
			CollisionNodeID = value;
		}
	}

	public HitboxType Type => HitboxType.Sail;

	public SailHitbox(UWModel _007B2491_007D, UWModel _007B2492_007D, bool _007B2493_007D, BoxShape[] _007B2494_007D, BoxShape _007B2495_007D)
	{
		if (_007B2491_007D == null)
		{
			throw new ArgumentNullException();
		}
		Model = _007B2491_007D;
		ModelRolled = _007B2492_007D;
		IsSailAnimated = _007B2493_007D;
		Shape = _007B2494_007D;
		CommonShape = _007B2495_007D;
	}

	[IteratorStateMachine(typeof(_003CEnumerateBaseShapes_003Ed__21))]
	public IEnumerable<BoxShape> EnumerateBaseShapes()
	{
		//yield-return decompiler failed: Method not found
		return new _003CEnumerateBaseShapes_003Ed__21(-2)
		{
			_003C_003E4__this = this
		};
	}
}
