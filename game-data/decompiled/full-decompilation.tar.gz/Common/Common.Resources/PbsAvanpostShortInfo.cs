using System.Collections.Generic;
using Common.Game;
using Microsoft.Xna.Framework;
using TheraEngine.Collections;

namespace Common.Resources;

public class PbsAvanpostShortInfo
{
	public readonly Tlist<ShipPositionInfo> RespwanPositions;

	public readonly Vector2 Center;

	public readonly PbsBatlleSide BattleSide;

	public PbsAvanpostShortInfo(IEnumerable<ShipPositionInfo> _007B2984_007D, IsleInstance _007B2985_007D, PbsBatlleSide _007B2986_007D)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		RespwanPositions = new Tlist<ShipPositionInfo>(_007B2984_007D);
		Center = _007B2985_007D.GlobalPosition;
		BattleSide = _007B2986_007D;
	}
}
