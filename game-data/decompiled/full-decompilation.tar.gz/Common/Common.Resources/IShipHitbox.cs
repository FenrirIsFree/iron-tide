using System.Collections.Generic;
using UWPhysicsWOSLib.Shapes;

namespace Common.Resources;

public interface IShipHitbox
{
	byte NodeID { get; set; }

	HitboxType Type { get; }

	IEnumerable<BoxShape> EnumerateBaseShapes();
}
