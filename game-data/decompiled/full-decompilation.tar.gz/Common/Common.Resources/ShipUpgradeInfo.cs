using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using Common.Account;
using Common.Data;
using Common.Game;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using TheraEngine;
using TheraEngine.Core;

namespace Common.Resources;

public class ShipUpgradeInfo : XmlAsset<ShipUpgradeInfoTokenNew>
{
	[CompilerGenerated]
	private sealed class _003CGetEffects_003Ed__18 : IEnumerable<ShipBonus>, IEnumerable, IEnumerator<ShipBonus>, IEnumerator, IDisposable
	{
		private int _007B2650_007D;

		private ShipBonus _007B2651_007D;

		private int _007B2652_007D;

		private PlayerShipInfo _007B2653_007D;

		public PlayerShipInfo _003C_003E3__basedOn;

		public ShipUpgradeInfo _003C_003E4__this;

		private ShipBonus[] _007B2654_007D;

		private int _007B2655_007D;

		private int _007B2656_007D;

		private ShipBonus _007B2657_007D;

		private float _007B2658_007D;

		private int _007B2659_007D;

		private int _007B2660_007D;

		private float _007B2661_007D;

		ShipBonus IEnumerator<ShipBonus>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B2651_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B2651_007D;
			}
		}

		[DebuggerHidden]
		public _003CGetEffects_003Ed__18(int _007B2645_007D)
		{
			_007B2650_007D = _007B2645_007D;
			_007B2652_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B2646_007D()
		{
			_007B2654_007D = null;
			_007B2657_007D = default(ShipBonus);
			_007B2650_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2646}
			this._007B2646_007D();
		}

		private bool _007B2647_007D()
		{
			switch (_007B2650_007D)
			{
			default:
				return false;
			case 0:
				_007B2650_007D = -1;
				_007B2654_007D = _003C_003E4__this._007B2637_007D;
				_007B2655_007D = ((_007B2653_007D == null) ? 1 : _007B2653_007D.Rank);
				_007B2656_007D = 0;
				goto IL_0554;
			case 1:
				_007B2650_007D = -1;
				goto IL_0535;
			case 2:
				_007B2650_007D = -1;
				goto IL_0535;
			case 3:
				_007B2650_007D = -1;
				goto IL_0535;
			case 4:
				_007B2650_007D = -1;
				goto IL_0535;
			case 5:
				{
					_007B2650_007D = -1;
					goto IL_0535;
				}
				IL_0535:
				_007B2657_007D = default(ShipBonus);
				goto IL_0542;
				IL_0542:
				_007B2656_007D++;
				goto IL_0554;
				IL_0554:
				if (_007B2656_007D < _007B2654_007D.Length)
				{
					_007B2657_007D = _007B2654_007D[_007B2656_007D];
					if (_007B2654_007D[0].Type == ShipBonusEffect.BExtraMortars && _007B2653_007D != null)
					{
						if (_007B2657_007D.Type == ShipBonusEffect.PSpeed)
						{
							_007B2657_007D = new ShipBonus(_007B2657_007D.Type, (_007B2653_007D.Class == ShipClass.CargoShip) ? 5f : 0f);
						}
						else if (_007B2657_007D.Type == ShipBonusEffect.MMobilityBonus)
						{
							_007B2657_007D = new ShipBonus(_007B2657_007D.Type, (_007B2653_007D.Class == ShipClass.CargoShip) ? 10f : 15f);
						}
						else if (_007B2657_007D.Type == ShipBonusEffect.MHealth)
						{
							_007B2658_007D = ((_007B2653_007D.Class == ShipClass.CargoShip) ? (-7.5f) : (-10f)) / 100f * _007B2653_007D.PatHealth;
							_007B2658_007D = MathF.Round(_007B2658_007D / 10f) * 10f;
							_007B2657_007D = new ShipBonus(_007B2657_007D.Type, _007B2658_007D);
						}
						else if (_007B2657_007D.Type == ShipBonusEffect.MExtraPlaces)
						{
							_007B2659_007D = _007B2653_007D.PatPlacesUnits;
							_007B2657_007D = new ShipBonus(_007B2657_007D.Type, (_007B2653_007D.Class == ShipClass.CargoShip) ? ((int)((float)(-_007B2659_007D) * 0.25f)) : ((int)((float)(-_007B2659_007D) * 0.2f)));
						}
						else if (_007B2657_007D.Type == ShipBonusEffect.MPReduceCannonsQuantity)
						{
							_007B2657_007D = new ShipBonus(_007B2657_007D.Type, 30f);
						}
						else if (_007B2657_007D.Type == ShipBonusEffect.PCapacity)
						{
							_007B2657_007D = new ShipBonus(_007B2657_007D.Type, (_007B2653_007D.Class == ShipClass.CargoShip) ? (-20f) : 0f);
						}
						if (_007B2657_007D.Value == 0f)
						{
							goto IL_0542;
						}
					}
					if (_007B2657_007D.Type == ShipBonusEffect.MPReduceCannonsQuantity && _007B2653_007D != null)
					{
						_007B2651_007D = new ShipBonus(_007B2657_007D.Type, Math.Max(1, (int)Math.Round((float)_007B2653_007D.StaticInfo.LeftSidePorts.Length * _007B2657_007D.Value / 100f)));
						_007B2650_007D = 1;
						return true;
					}
					if (_007B2657_007D.Type == ShipBonusEffect.PFrontAndBackCannonsAddDamage && _007B2653_007D != null)
					{
						_007B2660_007D = Math.Max(_007B2653_007D.StaticInfo.FrontSidePorts.Length - 2, _007B2653_007D.StaticInfo.BackSidePorts.Length - 2);
						_007B2661_007D = ((_007B2655_007D >= 5) ? 6f : 10f);
						_007B2651_007D = _007B2657_007D.Scale(MathHelper.Lerp(1f, 0.35f, Math.Min(1f, (float)_007B2660_007D / _007B2661_007D)), _007B5049_007D: true);
						_007B2650_007D = 2;
						return true;
					}
					if (_007B2657_007D.Type == ShipBonusEffect.PCannonsReload && _007B2653_007D != null && _007B2653_007D.Class == ShipClass.Hardship)
					{
						_007B2651_007D = _007B2657_007D.Scale(1.5f, _007B5049_007D: true);
						_007B2650_007D = 3;
						return true;
					}
					if (_007B2657_007D.Type == ShipBonusEffect.BExtraMortars && _007B2653_007D != null)
					{
						_007B2651_007D = new ShipBonus(_007B2657_007D.Type, _007B2653_007D.StaticInfo.MortarPorts.Count((CannonLocationInfo _007B2638_007D) => _007B2638_007D.AvailableWithUpgrade));
						_007B2650_007D = 4;
						return true;
					}
					_007B2651_007D = new ShipBonus(_007B2657_007D.Type, _007B2657_007D.GetValueByRank(_007B2655_007D));
					_007B2650_007D = 5;
					return true;
				}
				return false;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2647}
			return this._007B2647_007D();
		}

		[DebuggerHidden]
		private void _007B2648_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2648}
			this._007B2648_007D();
		}

		[DebuggerHidden]
		IEnumerator<ShipBonus> IEnumerable<ShipBonus>.GetEnumerator()
		{
			_003CGetEffects_003Ed__18 _003CGetEffects_003Ed__;
			if (_007B2650_007D == -2 && _007B2652_007D == Environment.CurrentManagedThreadId)
			{
				_007B2650_007D = 0;
				_003CGetEffects_003Ed__ = this;
			}
			else
			{
				_003CGetEffects_003Ed__ = new _003CGetEffects_003Ed__18(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			_003CGetEffects_003Ed__._007B2653_007D = _003C_003E3__basedOn;
			return _003CGetEffects_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B2649_007D()
		{
			return ((IEnumerable<ShipBonus>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2649}
			return this._007B2649_007D();
		}
	}

	private string _007B2634_007D;

	private string _007B2635_007D;

	public readonly Texture2D IconTexture;

	public readonly ResourceInfo MainCraftResDsiplay;

	public readonly UpgradeStrengthWear WearType;

	public readonly RTI WearAmount;

	public readonly bool LowCost;

	public readonly bool DoesImprovmentTakeHoldSpace;

	public readonly ShipUpgradeCategory CategoryUi;

	private CraftingRecipe[] _007B2636_007D;

	private readonly ShipBonus[] _007B2637_007D;

	public readonly bool IsMortarUpgrade;

	public string Name => Local.Current(_007B2634_007D);

	public string ToolTipOrEmpty => (_007B2635_007D.Length == 0) ? _007B2635_007D : Local.Current(_007B2635_007D);

	public ShipUpgradeInfo(ContentManager _007B2604_007D, ShipUpgradeInfoTokenNew _007B2605_007D, int _007B2606_007D)
		: base(_007B2606_007D)
	{
		_007B2634_007D = _007B2605_007D.Name;
		_007B2635_007D = _007B2605_007D.Name.Replace("name", "tt");
		if (!Local.ContainsKey(_007B2635_007D))
		{
			_007B2635_007D = "";
		}
		_007B2637_007D = ParseHelper(_007B2605_007D.EffectsBoost);
		LowCost = _007B2605_007D.LowCost;
		if (!CommonGlobal.IsServer)
		{
			IconTexture = _007B2604_007D.Load<Texture2D>("_lzcommon\\Items\\ShipUpgrades\\" + _007B2605_007D.IconName);
		}
		DoesImprovmentTakeHoldSpace = !_007B2607_007D(ShipBonusEffect.MCapacity, ShipBonusEffect.PCapacity);
		CategoryUi = _007B2605_007D.Category;
		Gameplay.UpgradeCost(_007B2605_007D, ref _007B2636_007D, out MainCraftResDsiplay);
		WearType = _007B2605_007D.WearType;
		IsMortarUpgrade = WearType == UpgradeStrengthWear.MortarShotsCount && CategoryUi != ShipUpgradeCategory.Modification;
		if (CategoryUi == ShipUpgradeCategory.Modification)
		{
			WearType = UpgradeStrengthWear.None;
		}
		WearAmount = Gameplay.UpgradesStrength[WearType];
		if (_007B2605_007D.LowStrength)
		{
			WearAmount = WearAmount.Value / 2;
		}
		if (WearAmount.Value == 0)
		{
			WearAmount.Value = 1;
		}
	}

	private bool _007B2607_007D(params ShipBonusEffect[] _007B2608_007D)
	{
		for (int i = 0; i < _007B2637_007D.Length; i++)
		{
			foreach (ShipBonusEffect shipBonusEffect in _007B2608_007D)
			{
				if (_007B2637_007D[i].Type == shipBonusEffect && _007B2637_007D[i].Value > 0f)
				{
					return true;
				}
			}
		}
		return false;
	}

	[IteratorStateMachine(typeof(_003CGetEffects_003Ed__18))]
	public IEnumerable<ShipBonus> GetEffects(PlayerShipInfo? _007B2609_007D)
	{
		//yield-return decompiler failed: Method not found
		return new _003CGetEffects_003Ed__18(-2)
		{
			_003C_003E4__this = this,
			_003C_003E3__basedOn = _007B2609_007D
		};
	}

	public bool HasEffect(ShipBonusEffect _007B2610_007D)
	{
		for (int i = 0; i < _007B2637_007D.Length; i++)
		{
			if (_007B2637_007D[i].Type == _007B2610_007D)
			{
				return true;
			}
		}
		return false;
	}

	public bool IsUpgradeAvailableIn(PlayerShipDynamicInfo _007B2611_007D)
	{
		return IsUpgradeAvailableIn(_007B2611_007D.CraftFrom, _007B2611_007D.HasExtraMortarUpgrade);
	}

	public bool IsUpgradeAvailableIn(PlayerShipInfo _007B2612_007D, bool _007B2613_007D)
	{
		if (_007B2637_007D.Length == 0)
		{
			return false;
		}
		if (_007B2637_007D[0].Type == ShipBonusEffect.PDamageCannonIfStrengthBelow30P && _007B2612_007D.Class == ShipClass.Hardship)
		{
			return false;
		}
		if (IsMortarUpgrade && _007B2612_007D.StaticInfo.MortarPorts.Count((CannonLocationInfo _007B2643_007D) => !_007B2643_007D.AvailableWithUpgrade || _007B2613_007D) == 0)
		{
			return false;
		}
		if (_007B2637_007D[0].Type == ShipBonusEffect.PFrontAndBackCannonsAddDamage && _007B2612_007D.StaticInfo.BackSidePorts.Length == 0 && _007B2612_007D.StaticInfo.FrontSidePorts.Count((CannonLocationInfo _007B2639_007D) => _007B2639_007D.Mode == CannonLocationMode.Default) == 0)
		{
			return false;
		}
		if (IsUpgradeHidden(_007B2612_007D))
		{
			return false;
		}
		return true;
	}

	public bool IsUpgradeHidden(PlayerShipInfo _007B2614_007D)
	{
		if (_007B2637_007D.Length == 0 || (_007B2637_007D[0].Type == ShipBonusEffect.BExtraMortars && !_007B2614_007D.StaticInfo.MortarPorts.Any((CannonLocationInfo _007B2640_007D) => _007B2640_007D.AvailableWithUpgrade)))
		{
			return true;
		}
		return false;
	}

	private CraftingRecipe _007B2615_007D(PlayerShipInfo _007B2616_007D, PlayerAccount _007B2617_007D, bool _007B2618_007D)
	{
		int num = _007B2625_007D(_007B2616_007D, _007B2617_007D, _007B2618_007D);
		CraftingRecipe craftingRecipe = _007B2636_007D[num - 1];
		return new CraftingRecipe(craftingRecipe.InputItems, craftingRecipe.InputMoney.Value);
	}

	public CraftingRecipe GetCraft(PlayerShipInfo _007B2619_007D, PlayerAccount _007B2620_007D, bool _007B2621_007D)
	{
		return _007B2615_007D(_007B2619_007D, _007B2620_007D, _007B2621_007D);
	}

	public CraftingRecipe GetCraftForMarks(PlayerShipInfo _007B2622_007D, PlayerAccount _007B2623_007D, bool _007B2624_007D)
	{
		CraftingRecipe craft = GetCraft(_007B2622_007D, _007B2623_007D, _007B2624_007D);
		float num = (float)Cost(craft) / 500f * 2f;
		GSI gSI = new GSI();
		gSI.AddOrRemove(37, Math.Max((int)Math.Floor(num), 10));
		return new CraftingRecipe(gSI);
		static int Cost(CraftingRecipe _007B2633_007D)
		{
			int num2 = _007B2633_007D.InputMoney.Value;
			foreach (GSILocalPair item in (IEnumerable<GSILocalPair>)_007B2633_007D.InputItems)
			{
				ResourceInfo resourceInfo = Gameplay.ItemsInfo.FromID(item.ID);
				int num3 = num2;
				int count = item.Count;
				int iD = item.ID;
				if (1 == 0)
				{
				}
				int num4 = iD switch
				{
					37 => 500, 
					38 => 5000, 
					_ => resourceInfo.MediumCost.Value, 
				};
				if (1 == 0)
				{
				}
				num2 = num3 + count * num4;
			}
			return num2;
		}
	}

	private int _007B2625_007D(PlayerShipInfo _007B2626_007D, PlayerAccount _007B2627_007D, bool _007B2628_007D)
	{
		int num = _007B2626_007D.Rank;
		if (num >= 4 && _007B2627_007D != null && _007B2627_007D.Rang > 18 && _007B2628_007D)
		{
			num--;
		}
		return num;
	}

	public CraftingRecipe GetRepairCost(float _007B2629_007D, PlayerAccount _007B2630_007D, bool _007B2631_007D)
	{
		float num = (1f - _007B2629_007D / (float)WearAmount.Value) * 0.25f;
		GSI gSI = new GSI();
		CraftingRecipe craft = GetCraft(_007B2630_007D.Shipyard.CurrentRealShip.CraftFrom, _007B2630_007D, _007B2631_007D);
		foreach (GSILocalPair item in (IEnumerable<GSILocalPair>)craft.InputItems)
		{
			if (item.ID == 38 || item.ID == 37)
			{
				gSI.AddOrRemove(item.ID, (int)Math.Ceiling((float)item.Count * num * 0.6f));
			}
			else
			{
				gSI.AddOrRemove(item.ID, (int)Math.Ceiling((float)item.Count * num));
			}
		}
		return new CraftingRecipe(gSI, (int)Math.Ceiling((float)craft.InputMoney.Value * num));
	}

	public static ShipBonus[] ParseHelper(string _007B2632_007D)
	{
		List<string> list = (from _007B2641_007D in _007B2632_007D.Split(';')
			where !string.IsNullOrWhiteSpace(_007B2641_007D)
			select _007B2641_007D).ToList();
		ShipBonus[] array = new ShipBonus[list.Count];
		for (int num = 0; num < list.Count; num++)
		{
			string text = list[num].Trim();
			int num2 = text.IndexOf(' ');
			if (num2 < 0)
			{
				throw new FormatException("Invalid bonus format: " + text);
			}
			string value = text.Substring(0, num2).Trim();
			string text2 = text.Substring(num2 + 1).Trim();
			ShipBonusEffect shipBonusEffect = (ShipBonusEffect)Enum.Parse(typeof(ShipBonusEffect), value);
			float[] array2 = (from _007B2642_007D in text2.Split(',')
				select _007B2642_007D.ParseSafe()).ToArray();
			array[num] = ((array2.Length == 1) ? new ShipBonus(shipBonusEffect, array2[0]) : new ShipBonus(shipBonusEffect, array2[0], array2));
		}
		return array;
	}
}
