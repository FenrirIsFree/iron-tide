namespace Common.Resources;

public enum NpcVisualEffect
{
	Regular,
	MagmaShip,
	IceShip,
	ShadowShip,
	BloodShip,
	DirtShip,
	DestroyedShip
}
