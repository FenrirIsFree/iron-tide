using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using Common.Data;
using Common.Game;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using TheraEngine;
using TheraEngine.Assets.Graphics;
using TheraEngine.Core;
using TheraEngine.Graphics.Models;

namespace Common.Resources;

public class ShipDesignInfo : XmlAsset<ShipDesingElementInfoToken>
{
	public readonly string nameKey;

	public readonly bool InShop;

	public readonly RTI InShopByGold;

	public readonly RTI? CustomMonetsPrice;

	public readonly DesignElementCostTier CostTier;

	public readonly ShipDesignCategory Category;

	public Texture2D ApartIconTex;

	public Texture2D ApartIconTexAlt;

	public UWModel ApartModel;

	public readonly Rectangle IconTextPath;

	public readonly ShipBonus[] Bonus;

	public readonly (PDynamicAccountBonus, float) AccountBonus;

	public readonly string Texture;

	public readonly short ShipId;

	public readonly PlayerShipInfo AssociatedShip;

	public Dictionary<string, string> ShipFullDesignTable;

	public static Func<int, PublicDesignInfo> PublicDesignResolver;

	public static string ServerIdParam;

	public string Name => Local.Current(nameKey);

	public string NameShort
	{
		get
		{
			string text = Name;
			if (text.Contains('('))
			{
				text = text.Substring(0, text.IndexOf('('));
			}
			text = text.Replace(Local.key_design + " ", "");
			text = text.Replace(Local.key_flag + " ", "");
			text = text.Replace(Local.key_figure + " ", "");
			return text.Replace("\"", "");
		}
	}

	public bool WrapsPublicDesign => IsPublicDesign(id);

	public int PublicDesignID => id - 10000;

	public static bool IsPublicDesign(int _007B2392_007D)
	{
		return _007B2392_007D >= 10000;
	}

	public static ShipDesignInfo Resolve(int _007B2393_007D)
	{
		return Resolve(_007B2393_007D, _007B2395_007D: false);
	}

	public static ShipDesignInfo? Resolve(int _007B2394_007D, bool _007B2395_007D)
	{
		if (IsPublicDesign(_007B2394_007D))
		{
			int arg = _007B2394_007D - 10000;
			PublicDesignInfo publicDesignInfo = PublicDesignResolver?.Invoke(arg);
			return (publicDesignInfo != null) ? new ShipDesignInfo(publicDesignInfo) : (_007B2395_007D ? null : Gameplay.DesignsInfo[1]);
		}
		return Gameplay.DesignsInfo[_007B2394_007D];
	}

	public ShipDesignInfo(PublicDesignInfo _007B2396_007D)
		: base(10000 + _007B2396_007D.ID)
	{
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		nameKey = Local.GetKey((!string.IsNullOrEmpty(_007B2396_007D.OwnerGuildTag)) ? ((_007B2396_007D.Type == ShipDesignCategory.Flag) ? Local.design_private_guildflag : Local.design_private_guildsail) : ((_007B2396_007D.Type == ShipDesignCategory.Flag) ? Local.design_private_flag : Local.design_private_d));
		Category = _007B2396_007D.Type;
		Bonus = Array.Empty<ShipBonus>();
		AccountBonus = default((PDynamicAccountBonus, float));
		Texture = CommonGameConfig.CurrentSettings.PublicDesignsCdnAddress + _007B2396_007D.GetFileName();
		IconTextPath = Rectangle.Empty;
		InShop = false;
	}

	public ShipDesignInfo(InstancedMaterialDictionary _007B2397_007D, ContentManager _007B2398_007D, ShipDesingElementInfoToken _007B2399_007D, int _007B2400_007D)
		: base(_007B2400_007D)
	{
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		nameKey = _007B2399_007D.Name;
		Category = _007B2399_007D.Category;
		Bonus = ShipBonus.ParseStrings(_007B2399_007D.BonusEffectType, _007B2399_007D.BonusEffectValue);
		(PDynamicAccountBonus, int) tuple = CaptainSkillInfo.ParseBonus(_007B2399_007D.EnvDesingBonus);
		AccountBonus = (tuple.Item1, tuple.Item2);
		Texture = _007B2399_007D.Texture;
		ShipId = (short)_007B2399_007D.ShipId;
		if (_007B2399_007D.IconName.Length == 0)
		{
			IconTextPath = Rectangle.Empty;
		}
		else if (_007B2399_007D.IconName.Contains("Icons"))
		{
			string[] array = _007B2399_007D.IconName.Split(' ');
			int num = ((base.ID >= 420) ? 1 : 2);
			IconTextPath = new Rectangle(int.Parse(array[1]) * num, int.Parse(array[2]) * num, int.Parse(array[3]) * num, int.Parse(array[4]) * num);
		}
		else
		{
			string text = (_007B2399_007D.IconName.StartsWith("env_") ? "EnvDecor" : "DesingElements");
			ApartIconTex = _007B2398_007D.Load<Texture2D>(string.Concat("_lzcommon\\Items\\" + text + "\\", _007B2399_007D.IconName));
			ApartIconTexAlt = _007B2398_007D.TryLoadOrNull<Texture2D>(string.Concat("_lzcommon\\Items\\" + text + "\\", _007B2399_007D.IconName, "_alt"));
		}
		InShopByGold = 0;
		if (_007B2399_007D.InShop.Contains("ByGold"))
		{
			InShop = true;
			InShopByGold = int.Parse(_007B2399_007D.InShop.Split(' ')[1]);
		}
		else if (_007B2399_007D.InShop.Contains("ByMonets"))
		{
			InShop = true;
			CustomMonetsPrice = int.Parse(_007B2399_007D.InShop.Split(' ')[1]);
		}
		else
		{
			InShop = _007B2399_007D.InShop.Contains("true");
		}
		if (_007B2399_007D.InShop != "true" && _007B2399_007D.InShop != "false" && _007B2399_007D.InShop.Length > 0)
		{
			CostTier = Enum.Parse<DesignElementCostTier>(_007B2399_007D.InShop.Contains(' ') ? _007B2399_007D.InShop.Split(' ')[1] : _007B2399_007D.InShop);
		}
		else
		{
			CostTier = DesignElementCostTier.Tier1;
		}
		if (Category == ShipDesignCategory.ShipFullDesign)
		{
			string[] array2 = new string(_007B2399_007D.Texture.Where((char _007B2405_007D) => !"\t\n ".Contains(_007B2405_007D)).ToArray()).Split(new char[1] { ';' }, StringSplitOptions.RemoveEmptyEntries);
			ShipFullDesignTable = new Dictionary<string, string>();
			string[] array3 = array2;
			foreach (string text2 in array3)
			{
				string[] array4 = text2.Split(':');
				ShipFullDesignTable.Add(array4[0], array4[1]);
			}
			AssociatedShip = Gameplay.PlayersInfo.FirstOrDefault((PlayerShipInfo _007B2404_007D) => _007B2404_007D.ID == ShipId);
			if (AssociatedShip == null && Name != Local.design_private_d && Name != "removed")
			{
				GameLoader.Current.ImportantMessages.Add("Design " + Name + " doesn't fit any ship");
			}
		}
	}

	public string GetAnnotation()
	{
		return (Category == ShipDesignCategory.SailTexture) ? Local.PortRealShopPage_53b : ((Category == ShipDesignCategory.Satellite) ? Local.PortRealShopPage_51 : ((Category == ShipDesignCategory.Decal1 || Category == ShipDesignCategory.Decal2) ? Local.PortRealShopPage_53 : ((Category != ShipDesignCategory.BowFigure) ? string.Empty : ((InShopByGold.Value > 0) ? Local.PortRealShop_bowFigureTt_gold : Local.PortRealShop_bowFigureTt_real))));
	}

	public static bool AliasEquals(ShipDesignCategory _007B2401_007D, ShipDesignCategory _007B2402_007D)
	{
		return _007B2401_007D == _007B2402_007D || (_007B2401_007D == ShipDesignCategory.Decal1 && _007B2402_007D == ShipDesignCategory.Decal2) || (_007B2401_007D == ShipDesignCategory.Decal2 && _007B2402_007D == ShipDesignCategory.Decal1) || (_007B2401_007D == ShipDesignCategory.Flag && _007B2402_007D == ShipDesignCategory.Flag2) || (_007B2401_007D == ShipDesignCategory.Flag2 && _007B2402_007D == ShipDesignCategory.Flag);
	}

	[CompilerGenerated]
	private bool _007B2403_007D(PlayerShipInfo _007B2404_007D)
	{
		return _007B2404_007D.ID == ShipId;
	}
}
