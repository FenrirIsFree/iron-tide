using Common.Game;
using Microsoft.Xna.Framework;
using TheraEngine.Collections;

namespace Common.Resources;

public class IslePortPharosInfo
{
	public Vector2 MapGlobalPosition;

	public Tlist<ShipPositionInfo> Exits;

	public IsleInstance Isle;

	public IslePortPharosInfo(IsleInstance _007B2978_007D)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		Isle = _007B2978_007D;
		Exits = null;
		MapGlobalPosition = _007B2978_007D.GlobalPosition;
	}

	public IslePortPharosInfo(Vector2 _007B2979_007D, Tlist<ShipPositionInfo> _007B2980_007D)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		MapGlobalPosition = _007B2979_007D;
		Exits = _007B2980_007D;
		Isle = null;
	}
}
