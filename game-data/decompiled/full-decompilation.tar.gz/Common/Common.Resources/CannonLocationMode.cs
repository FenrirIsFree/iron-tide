namespace Common.Resources;

public enum CannonLocationMode
{
	Default,
	Special,
	Mortar
}
