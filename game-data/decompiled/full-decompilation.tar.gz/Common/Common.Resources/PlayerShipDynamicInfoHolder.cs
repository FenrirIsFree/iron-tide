using System;
using System.Runtime.CompilerServices;
using System.Text;
using Common.Data.Migrations;
using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;
using TheraEngine.Collections;

namespace Common.Resources;

internal class PlayerShipDynamicInfoHolder : IMPSerializable, ITKSerializable
{
	public Vector2 DesignBigLampPosition;

	public Vector3 DesignBowFigurePosition;

	public SlottedMap<ShipDesignInfo> DesignElementsNew;

	public int decal1SelectedSailes;

	public int decal2SelectedSailes;

	public PlayerShipInfo CraftFrom;

	public ShipFirstHp FirstHP;

	public byte[] FirstSailHP;

	public GSI BallsOfHold;

	public CannonCollection Cannons;

	public Map<CannonGameInstance> Mortars;

	public UnitCollection Crew;

	public UpgradesCollection Upgrades;

	public GSI ResourcesOfHold;

	public GSI PowderKegsOfHold;

	public string CustomName;

	public byte Integrity;

	public PowerupItemsSlots PowerupItemSlots;

	public float ClientTimeToRestoreIntegrity;

	public Tlist<byte> Deprecated_StoredUpgrades;

	public GSI CannonsShouldMoveToStorage;

	public bool TrophyShip;

	public PlayerShipDynamicInfoHolder()
	{
	}

	public PlayerShipDynamicInfoHolder(PlayerShipDynamicInfo _007B2779_007D)
	{
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		FirstHP = _007B2779_007D.firstHP;
		FirstSailHP = new byte[_007B2779_007D.HitboxSailsStrength.Length];
		for (int i = 0; i < _007B2779_007D.HitboxSailsStrength.Length; i++)
		{
			FirstSailHP[i] = (byte)Math.Max(0, Math.Min(255, (int)(_007B2779_007D.HitboxSailsStrength[i] * 255f)));
			_007B2779_007D.HitboxSailsStrength[i] = (float)(int)FirstSailHP[i] / 255f;
		}
		_007B2779_007D.HitboxSailsStrengthCacheUpdate();
		CraftFrom = _007B2779_007D.CraftFrom;
		BallsOfHold = _007B2779_007D.BallsOfHold;
		Cannons = _007B2779_007D.Cannons;
		Mortars = _007B2779_007D.Mortars;
		Crew = _007B2779_007D.Crew;
		DesignElementsNew = _007B2779_007D.designEmenents;
		decal1SelectedSailes = _007B2779_007D.Decal1SelectedSailesBits.Value;
		decal2SelectedSailes = _007B2779_007D.Decal2SelectedSailesBits.Value;
		Upgrades = _007B2779_007D.Upgrades;
		ResourcesOfHold = _007B2779_007D.PrivateResourcesOfHold;
		PowderKegsOfHold = _007B2779_007D.PowderKegsOfHold;
		DesignBigLampPosition = _007B2779_007D.BigLampPosition;
		DesignBowFigurePosition = _007B2779_007D.BowFigurePosition;
		CustomName = _007B2779_007D.CustomName;
		Integrity = (byte)_007B2779_007D.Integrity;
		PowerupItemSlots = _007B2779_007D.PowerupItemSlots;
		ClientTimeToRestoreIntegrity = _007B2779_007D.ClientTimeToRestoreIntegrity;
		CannonsShouldMoveToStorage = _007B2779_007D.CannonsShouldMoveToStorage;
		TrophyShip = _007B2779_007D.TrophyShipNotification;
	}

	private void _007B2780_007D(WriterExtern _007B2781_007D)
	{
		_007B2781_007D.WriteNoNull<ShipFirstHp>(FirstHP);
		_007B2781_007D.WriteBytes8bitSize(FirstSailHP);
		_007B2781_007D.WriteStruct<short>(CraftFrom.ID);
		_007B2781_007D.WriteNoNull<GSI>(BallsOfHold);
		Cannons.Boxing(_007B2781_007D, CraftFrom.StaticInfo);
		_007B2781_007D.WriteNoNull<UnitCollection>(Crew);
		_007B2781_007D.Write<SlottedMap<ShipDesignInfo>>(DesignElementsNew);
		if (DesignElementsNew[1] != null || DesignElementsNew[3] != null)
		{
			_007B2781_007D.WriteStruct<int>(ref decal1SelectedSailes);
			_007B2781_007D.WriteStruct<int>(ref decal2SelectedSailes);
		}
		_007B2781_007D.WriteStruct<Vector2>(ref DesignBigLampPosition);
		_007B2781_007D.WriteStruct<Vector3>(ref DesignBowFigurePosition);
		_007B2781_007D.WriteNoNull<UpgradesCollection>(Upgrades);
		_007B2781_007D.WriteNoNull<GSI>(ResourcesOfHold);
		_007B2781_007D.WriteNoNull<GSI>(PowderKegsOfHold);
		_007B2781_007D.Write(CustomName, (Encoding)null);
		_007B2781_007D.WriteByte(Integrity);
		_007B2781_007D.WriteNoNull<PowerupItemsSlots>(PowerupItemSlots);
		_007B2781_007D.WriteStruct<float>(ClientTimeToRestoreIntegrity);
		_007B2781_007D.Write<GSI>(CannonsShouldMoveToStorage);
		_007B2781_007D.WriteMap(Mortars);
		_007B2781_007D.Write(TrophyShip);
	}

	private void _007B2782_007D(WriterExtern _007B2783_007D)
	{
		_007B2783_007D.ReadIMPSNoNull<ShipFirstHp>(ref FirstHP);
		_007B2783_007D.ReadBytes8bitSize(ref FirstSailHP);
		short _007B3506_007D = default(short);
		_007B2783_007D.ReadStruct<short>(ref _007B3506_007D);
		CraftFrom = Gameplay.PlayersInfo.FromID(_007B3506_007D);
		_007B2783_007D.ReadIMPSNoNull<GSI>(ref BallsOfHold);
		Cannons = new CannonCollection();
		Cannons.Unboxing(_007B2783_007D, this, CraftFrom.StaticInfo);
		_007B2783_007D.ReadIMPSNoNull<UnitCollection>(ref Crew);
		_007B2783_007D.ReadIMPS<SlottedMap<ShipDesignInfo>>(ref DesignElementsNew);
		if (DesignElementsNew[1] != null || DesignElementsNew[3] != null)
		{
			_007B2783_007D.ReadStruct<int>(ref decal1SelectedSailes);
			_007B2783_007D.ReadStruct<int>(ref decal2SelectedSailes);
		}
		else
		{
			decal1SelectedSailes = int.MaxValue;
			decal2SelectedSailes = int.MaxValue;
		}
		_007B2783_007D.ReadStruct<Vector2>(ref DesignBigLampPosition);
		_007B2783_007D.ReadStruct<Vector3>(ref DesignBowFigurePosition);
		_007B2783_007D.ReadIMPSNoNull<UpgradesCollection>(ref Upgrades);
		Upgrades.SerializerInitialize(CraftFrom);
		_007B2783_007D.ReadIMPSNoNull<GSI>(ref ResourcesOfHold);
		_007B2783_007D.ReadIMPSNoNull<GSI>(ref PowderKegsOfHold);
		_007B2783_007D.ReadString(ref CustomName, (Encoding)null);
		Integrity = _007B2783_007D.ReadByte();
		_007B2783_007D.ReadIMPSNoNull<PowerupItemsSlots>(ref PowerupItemSlots);
		_007B2783_007D.ReadStruct<float>(ref ClientTimeToRestoreIntegrity);
		_007B2783_007D.ReadIMPS<GSI>(ref CannonsShouldMoveToStorage);
		_007B2783_007D.ReadMap(out Mortars);
		_007B2783_007D.ReadBoolean(ref TrophyShip);
	}

	private void _007B2784_007D()
	{
		decal1SelectedSailes = int.MaxValue;
		decal2SelectedSailes = int.MaxValue;
	}

	private void _007B2785_007D()
	{
		if (FirstHP == null)
		{
			FirstHP = new ShipFirstHp(1f);
		}
		if (ResourcesOfHold == null)
		{
			ResourcesOfHold = new GSI();
		}
		if (Crew == null)
		{
			Crew = new UnitCollection();
		}
		if (PowderKegsOfHold == null)
		{
			PowderKegsOfHold = new GSI();
		}
		if (BallsOfHold == null)
		{
			BallsOfHold = new GSI();
		}
		if (PowerupItemSlots == null)
		{
			PowerupItemSlots = new PowerupItemsSlots();
		}
		if (Mortars == null)
		{
			Mortars = new Map<CannonGameInstance>();
		}
		if (Cannons == null)
		{
			Cannons = new CannonCollection();
		}
	}

	private void _007B2786_007D(TKWriterExtern _007B2787_007D)
	{
		short iD = CraftFrom.ID;
		((TKWriterExtern)(ref _007B2787_007D)).WriteStruct<short>((short)4, ref iD);
		((TKWriterExtern)(ref _007B2787_007D)).WriteIMP<GSI>((short)35, BallsOfHold);
		((TKWriterExtern)(ref _007B2787_007D)).WriteIMP<GSI>((short)34, PowderKegsOfHold);
		((TKWriterExtern)(ref _007B2787_007D)).WriteIMP<UpgradesCollection>((short)68, Upgrades);
		((TKWriterExtern)(ref _007B2787_007D)).WriteIMP<GSI>((short)20, ResourcesOfHold);
		((TKWriterExtern)(ref _007B2787_007D)).WriteByte32bitSize((short)21, FirstSailHP);
		if (DesignBigLampPosition.X != 0f || DesignBigLampPosition.Y != 0f)
		{
			((TKWriterExtern)(ref _007B2787_007D)).WriteStruct<Vector2>((short)23, ref DesignBigLampPosition);
		}
		if (DesignBowFigurePosition.X != 0f || DesignBowFigurePosition.Y != 0f)
		{
			((TKWriterExtern)(ref _007B2787_007D)).WriteStruct<Vector3>((short)50, ref DesignBowFigurePosition);
		}
		((TKWriterExtern)(ref _007B2787_007D)).WriteIMP<UnitCollection>((short)55, Crew);
		((TKWriterExtern)(ref _007B2787_007D)).WriteContent((short)37, (Action<WriterExtern>)delegate(WriterExtern _007B2795_007D)
		{
			_007B2795_007D.WriteNoNull<ShipFirstHp>(FirstHP);
		});
		((TKWriterExtern)(ref _007B2787_007D)).WriteContent((short)41, (Action<WriterExtern>)delegate(WriterExtern _007B2797_007D)
		{
			_007B2797_007D.WriteStruct<int>(decal1SelectedSailes);
		});
		((TKWriterExtern)(ref _007B2787_007D)).WriteContent((short)42, (Action<WriterExtern>)delegate(WriterExtern _007B2799_007D)
		{
			_007B2799_007D.WriteStruct<int>(decal2SelectedSailes);
		});
		((TKWriterExtern)(ref _007B2787_007D)).Write((short)43, CustomName);
		((TKWriterExtern)(ref _007B2787_007D)).WriteByte((short)45, Integrity);
		((TKWriterExtern)(ref _007B2787_007D)).WriteIMP<PowerupItemsSlots>((short)56, PowerupItemSlots);
		((TKWriterExtern)(ref _007B2787_007D)).WriteIMP<SlottedMap<ShipDesignInfo>>((short)59, DesignElementsNew);
		((TKWriterExtern)(ref _007B2787_007D)).WriteStruct<float>((short)60, ref ClientTimeToRestoreIntegrity);
		((TKWriterExtern)(ref _007B2787_007D)).WriteContent((short)62, (Action<WriterExtern>)delegate(WriterExtern _007B2801_007D)
		{
			Cannons.Boxing(_007B2801_007D, CraftFrom.StaticInfo);
		});
		((TKWriterExtern)(ref _007B2787_007D)).WriteContent((short)63, (Action<WriterExtern>)delegate(WriterExtern _007B2803_007D)
		{
			_007B2803_007D.WriteMap(Mortars);
		});
		((TKWriterExtern)(ref _007B2787_007D)).Write((short)64, TrophyShip);
	}

	private void _007B2788_007D(short _007B2789_007D, WriterExtern _007B2790_007D, out bool _007B2791_007D)
	{
		_007B2791_007D = true;
		switch (_007B2789_007D)
		{
		case 4:
		{
			short _007B3506_007D = default(short);
			_007B2790_007D.ReadStruct<short>(ref _007B3506_007D);
			CraftFrom = Gameplay.PlayersInfo.FromID(_007B3506_007D);
			if (CraftFrom.MaxIntegrity == -1)
			{
				Integrity = 1;
			}
			else
			{
				Integrity = (byte)CraftFrom.MaxIntegrity;
			}
			break;
		}
		case 20:
			_007B2790_007D.ReadIMPS<GSI>(ref ResourcesOfHold);
			break;
		case 21:
			_007B2790_007D.ReadBytes32bitSize(ref FirstSailHP);
			break;
		case 23:
			_007B2790_007D.ReadStruct<Vector2>(ref DesignBigLampPosition);
			break;
		case 24:
		{
			int num = _007B2790_007D.ReadByte();
			Deprecated_StoredUpgrades = new Tlist<byte>(num);
			_007B2790_007D.ReadByte(ref Deprecated_StoredUpgrades.Array, num);
			Deprecated_StoredUpgrades.Size = num;
			if (Upgrades == null)
			{
				Upgrades = new UpgradesCollection();
			}
			break;
		}
		case 55:
			_007B2790_007D.ReadIMPS<UnitCollection>(ref Crew);
			break;
		case 37:
			_007B2790_007D.ReadIMPSNoNull<ShipFirstHp>(ref FirstHP);
			break;
		case 34:
			_007B2790_007D.ReadIMPS<GSI>(ref PowderKegsOfHold);
			PowderKegsOfHold.CleanRemovedPowderKegs();
			break;
		case 35:
			_007B2790_007D.ReadIMPS<GSI>(ref BallsOfHold);
			BallsOfHold.CleanRemovedCannonBalls();
			break;
		case 40:
			if (CraftFrom.ID == 1)
			{
				_007B2791_007D = false;
				break;
			}
			Cannons = CannonCollection.ReadFromStreamNew2(_007B2790_007D, CraftFrom.StaticInfo);
			_007B2792_007D(Cannons);
			break;
		case 41:
			_007B2790_007D.ReadStruct<int>(ref decal1SelectedSailes);
			break;
		case 42:
			_007B2790_007D.ReadStruct<int>(ref decal2SelectedSailes);
			break;
		case 43:
			_007B2790_007D.ReadString(ref CustomName, (Encoding)null);
			break;
		case 44:
		{
			byte[] array = default(byte[]);
			_007B2790_007D.ReadBytes8bitSize(ref array);
			DesignElementsNew = new SlottedMap<ShipDesignInfo>();
			for (int i = 0; i < array.Length; i++)
			{
				if (array[i] != 0)
				{
					DesignElementsNew[i] = Gameplay.DesignsInfo.FromID(array[i]);
				}
			}
			break;
		}
		case 59:
			_007B2790_007D.ReadIMPS<SlottedMap<ShipDesignInfo>>(ref DesignElementsNew);
			break;
		case 45:
			Integrity = _007B2790_007D.ReadByte();
			break;
		case 46:
			Cannons = CannonCollection.ReadFromStreamNew3(_007B2790_007D, CraftFrom.StaticInfo);
			_007B2792_007D(Cannons);
			break;
		case 56:
			_007B2790_007D.ReadIMPS<PowerupItemsSlots>(ref PowerupItemSlots);
			break;
		case 50:
			_007B2790_007D.ReadStruct<Vector3>(ref DesignBowFigurePosition);
			break;
		case 57:
			try
			{
				_007B2790_007D.ReadIMPS<UpgradesCollection>(ref Upgrades);
			}
			catch (OverflowException)
			{
				Upgrades = new UpgradesCollection();
			}
			catch (IndexOutOfRangeException)
			{
				Upgrades = new UpgradesCollection();
			}
			_007B2791_007D = false;
			Upgrades.SerializerInitialize(CraftFrom);
			break;
		case 68:
			_007B2790_007D.ReadIMPS<UpgradesCollection>(ref Upgrades);
			Upgrades.SerializerInitialize(CraftFrom);
			break;
		case 58:
			Cannons = new CannonCollection();
			Cannons.Unboxing(_007B2790_007D, this, CraftFrom.StaticInfo);
			_007B2792_007D(Cannons);
			break;
		case 60:
			_007B2790_007D.ReadStruct<float>(ref ClientTimeToRestoreIntegrity);
			break;
		case 61:
			_007B2790_007D.ReadMap(out Mortars);
			{
				foreach (CannonGameInstance mortar in Mortars)
				{
					if (CannonsChangeToNCS.LookupNumeric.TryGetValue((byte)mortar.Info.ID, out var value))
					{
						mortar.InfoID = value;
						mortar.Info = Gameplay.CannonsGameInfo.FromID(value);
					}
				}
				break;
			}
		case 62:
			Cannons = new CannonCollection();
			Cannons.Unboxing(_007B2790_007D, this, CraftFrom.StaticInfo);
			break;
		case 63:
			_007B2790_007D.ReadMap(out Mortars);
			break;
		case 64:
			_007B2790_007D.ReadBoolean(ref TrophyShip);
			break;
		default:
			_007B2791_007D = false;
			break;
		}
	}

	private void _007B2792_007D(CannonCollection _007B2793_007D)
	{
		for (int i = 0; i < Cannons.Items.Size; i++)
		{
			short iD = Cannons.Items[i].GameInfo.ID;
			if (CannonsChangeToNCS.LookupNumeric.TryGetValue((byte)iD, out var value))
			{
				CannonGameInfo _007B4582_007D = Gameplay.CannonsGameInfo.FromID(value);
				Cannons.Items[i] = new CannonCommon(Cannons.Items[i].Location, _007B4582_007D);
			}
		}
	}

	[CompilerGenerated]
	private void _007B2794_007D(WriterExtern _007B2795_007D)
	{
		_007B2795_007D.WriteNoNull<ShipFirstHp>(FirstHP);
	}

	[CompilerGenerated]
	private void _007B2796_007D(WriterExtern _007B2797_007D)
	{
		_007B2797_007D.WriteStruct<int>(decal1SelectedSailes);
	}

	[CompilerGenerated]
	private void _007B2798_007D(WriterExtern _007B2799_007D)
	{
		_007B2799_007D.WriteStruct<int>(decal2SelectedSailes);
	}

	[CompilerGenerated]
	private void _007B2800_007D(WriterExtern _007B2801_007D)
	{
		Cannons.Boxing(_007B2801_007D, CraftFrom.StaticInfo);
	}

	[CompilerGenerated]
	private void _007B2802_007D(WriterExtern _007B2803_007D)
	{
		_007B2803_007D.WriteMap(Mortars);
	}
}
