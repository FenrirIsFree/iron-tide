using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Account;
using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Helpers;

namespace Common.Resources;

public class PowerupItemsSlots : IMPSerializable
{
	[CompilerGenerated]
	private sealed class _003CEnumerateInstalledItems_003Ed__13 : IEnumerable<PowerupItemInfo>, IEnumerable, IEnumerator<PowerupItemInfo>, IEnumerator, IDisposable
	{
		private int _007B3377_007D;

		private PowerupItemInfo _007B3378_007D;

		private int _007B3379_007D;

		public PowerupItemsSlots _003C_003E4__this;

		private int _007B3380_007D;

		PowerupItemInfo IEnumerator<PowerupItemInfo>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B3378_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B3378_007D;
			}
		}

		[DebuggerHidden]
		public _003CEnumerateInstalledItems_003Ed__13(int _007B3372_007D)
		{
			_007B3377_007D = _007B3372_007D;
			_007B3379_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B3373_007D()
		{
			_007B3377_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3373}
			this._007B3373_007D();
		}

		private bool _007B3374_007D()
		{
			int num = _007B3377_007D;
			if (num != 0)
			{
				if (num != 1)
				{
					return false;
				}
				_007B3377_007D = -1;
				goto IL_007c;
			}
			_007B3377_007D = -1;
			_007B3380_007D = 0;
			goto IL_008c;
			IL_007c:
			_007B3380_007D++;
			goto IL_008c;
			IL_008c:
			if (_007B3380_007D < 3)
			{
				if (_003C_003E4__this._007B3370_007D[_007B3380_007D] != 254)
				{
					_007B3378_007D = Gameplay.PowerupItems.Array[_003C_003E4__this._007B3370_007D[_007B3380_007D]];
					_007B3377_007D = 1;
					return true;
				}
				goto IL_007c;
			}
			return false;
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3374}
			return this._007B3374_007D();
		}

		[DebuggerHidden]
		private void _007B3375_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3375}
			this._007B3375_007D();
		}

		[DebuggerHidden]
		IEnumerator<PowerupItemInfo> IEnumerable<PowerupItemInfo>.GetEnumerator()
		{
			_003CEnumerateInstalledItems_003Ed__13 result;
			if (_007B3377_007D == -2 && _007B3379_007D == Environment.CurrentManagedThreadId)
			{
				_007B3377_007D = 0;
				result = this;
			}
			else
			{
				result = new _003CEnumerateInstalledItems_003Ed__13(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			return result;
		}

		[DebuggerHidden]
		private IEnumerator _007B3376_007D()
		{
			return ((IEnumerable<PowerupItemInfo>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3376}
			return this._007B3376_007D();
		}
	}

	public const int count = 3;

	private const byte identity = 254;

	private byte[] _007B3370_007D;

	public readonly StaticEffectsCalculator EffectsFromInstalled = new StaticEffectsCalculator();

	public PowerupItemInfo this[int _007B3359_007D]
	{
		get
		{
			return (_007B3370_007D[_007B3359_007D] == 254) ? null : Gameplay.PowerupItems.Array[_007B3370_007D[_007B3359_007D]];
		}
		set
		{
			_007B3370_007D[_007B3360_007D] = (byte)((value == null) ? 254 : ((byte)value.Index));
			_007B3365_007D();
		}
	}

	public PowerupItemsSlots()
	{
		_007B3370_007D = new byte[3];
		for (int i = 0; i < 3; i++)
		{
			_007B3370_007D[i] = 254;
		}
	}

	public void TakeOffAll()
	{
		for (int i = 0; i < 3; i++)
		{
			_007B3370_007D[i] = 254;
		}
		_007B3365_007D();
	}

	public int GetSlotIndex(PowerupItemInfo _007B3362_007D)
	{
		for (int i = 0; i < 3; i++)
		{
			if (_007B3370_007D[i] == (byte)_007B3362_007D.Index)
			{
				return i;
			}
		}
		return -1;
	}

	public bool Contains(PowerupItemInfo _007B3363_007D)
	{
		for (int i = 0; i < 3; i++)
		{
			if (_007B3370_007D[i] == (byte)_007B3363_007D.Index)
			{
				return true;
			}
		}
		return false;
	}

	public int GetRandomPowerupItemIndex(PlayerAccount _007B3364_007D)
	{
		int num = Rand.RangeInt(0, 3);
		for (int i = 0; i < 3; i++)
		{
			int num2 = (i + num) % 3;
			if (_007B3370_007D[num2] != 254 && _007B3364_007D.PowerupItemsAtStorage[_007B3370_007D[num2]] > 0)
			{
				return _007B3370_007D[num2];
			}
		}
		return -1;
	}

	private void _007B3365_007D()
	{
		EffectsFromInstalled.Clear();
		for (int i = 0; i < 3; i++)
		{
			if (_007B3370_007D[i] == 254)
			{
				continue;
			}
			PowerupItemInfo powerupItemInfo = Gameplay.PowerupItems.Array[_007B3370_007D[i]];
			foreach (ShipBonus item in (IEnumerable<ShipBonus>)powerupItemInfo.EffectsWhenInstalled)
			{
				ShipBonus _007B5225_007D = item;
				EffectsFromInstalled.Add(in _007B5225_007D);
			}
		}
	}

	[IteratorStateMachine(typeof(_003CEnumerateInstalledItems_003Ed__13))]
	public IEnumerable<PowerupItemInfo> EnumerateInstalledItems()
	{
		//yield-return decompiler failed: Method not found
		return new _003CEnumerateInstalledItems_003Ed__13(-2)
		{
			_003C_003E4__this = this
		};
	}

	private void _007B3366_007D(WriterExtern _007B3367_007D)
	{
		_007B3367_007D.WriteByte(byte.MaxValue);
		_007B3367_007D.WriteBytes8bitSize(_007B3370_007D);
	}

	private void _007B3368_007D(WriterExtern _007B3369_007D)
	{
		if (_007B3369_007D.PeekByte() == byte.MaxValue)
		{
			_007B3369_007D.ReadByte();
			_007B3369_007D.ReadBytes8bitSize(ref _007B3370_007D);
		}
		else
		{
			_007B3369_007D.ReadByte(ref _007B3370_007D, 3);
			Array.Resize(ref _007B3370_007D, 3);
		}
		for (int i = 0; i < 3; i++)
		{
			if (_007B3370_007D[i] != 254 && (_007B3370_007D[i] >= Gameplay.PowerupItems.Size || Gameplay.PowerupItems.Array[_007B3370_007D[i]].nameKey[0] == 'r'))
			{
				_007B3370_007D[i] = 254;
			}
		}
		_007B3365_007D();
	}
}
