using Microsoft.Xna.Framework;

namespace Common.Resources;

public class PivotInfo
{
	public readonly Vector3 Lower;

	public readonly Vector3 Upper;

	public readonly Vector3 Fixed;

	public readonly Vector3 Normal;

	public Vector3 SailNormal;

	public Vector3 SailRollPosition;

	public float SailCurvatureRoll;

	public bool IsFixed => Fixed.Y != 0f;

	public Vector3 Average => Vector3.Lerp(Lower, Upper, 0.5f);

	public PivotInfo(Vector3 _007B2413_007D)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		Lower = (Upper = _007B2413_007D);
		Normal = Vector3.Up;
	}

	public PivotInfo(Vector3 _007B2414_007D, Vector3 _007B2415_007D)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		Lower = ((_007B2414_007D.Y > _007B2415_007D.Y) ? _007B2415_007D : _007B2414_007D);
		Upper = ((_007B2414_007D.Y > _007B2415_007D.Y) ? _007B2414_007D : _007B2415_007D);
		Normal = Upper - Lower;
		Fixed = Vector3.Zero;
	}
}
