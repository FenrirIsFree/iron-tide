using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using TheraEngine;
using TheraEngine.Assets.Graphics;
using TheraEngine.Collections;
using TheraEngine.Graphics;
using TheraEngine.Graphics.Models;

namespace Common.Resources;

public class ShipModelContent
{
	public UWModel corpus;

	public UWModel stuff;

	public UWModel corpusLow;

	public UWModel shipMin;

	public Tlist<UWModel> arris;

	public Tlist<UWModel> sailesStatic;

	public Tlist<UWModel> sailesAnimated;

	public Tlist<UWModel> sailesRolledAll;

	public UWModel masts;

	public Tlist<UWModel> mastsApart;

	public Tlist<UWModel> mastRotateFrames;

	public UWModel unallocatdRoops;

	public Tlist<UWModel> flagpolls;

	public Tlist<ShipModelMainFlag> mainFlags;

	public BoundingSphere DefaultElementsBS;

	internal UWOpenModel hitboxModel;

	public UWModel deckCoverModel;

	public UWModel paddleModel;

	public UWModel wheelSteamShip;

	public UWModel steamWheelCenterPoint;

	public UWModel pipeOut;

	public bool HasPerpendicularBackSail;

	internal Tlist<int>[] SailOpenPriority;

	internal int SailOpenPriorityForZeroSpeedManuer;

	public Tlist<Vector3> MastControls;

	public Tlist<Vector3> ArrisControls;

	public Vector2 MastControlsMinMaxX;

	public unsafe ShipModelContent(InstancedMaterialDictionary _007B2433_007D, Model _007B2434_007D, Model _007B2435_007D)
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0305: Unknown result type (might be due to invalid IL or missing references)
		//IL_0317: Unknown result type (might be due to invalid IL or missing references)
		//IL_031c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0321: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Unknown result type (might be due to invalid IL or missing references)
		//IL_0358: Unknown result type (might be due to invalid IL or missing references)
		//IL_035d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0362: Unknown result type (might be due to invalid IL or missing references)
		//IL_0384: Unknown result type (might be due to invalid IL or missing references)
		//IL_038f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0394: Unknown result type (might be due to invalid IL or missing references)
		//IL_0399: Unknown result type (might be due to invalid IL or missing references)
		corpus = UWModel.Create(_007B2433_007D, _007B2434_007D, "ShipCorpus");
		Enumerator enumerator = _007B2434_007D.Meshes.GetEnumerator();
		try
		{
			while (((Enumerator)(ref enumerator)).MoveNext())
			{
				ModelMesh current = ((Enumerator)(ref enumerator)).Current;
				if (current.Name.Contains("staff") || current.Name.Contains("Staff"))
				{
					throw new Exception("staff " + corpus.ModelName);
				}
			}
		}
		finally
		{
			((IDisposable)(*(Enumerator*)(&enumerator))/*cast due to .constrained prefix*/).Dispose();
		}
		stuff = UWModel.TryCreate(_007B2433_007D, _007B2434_007D, "DeckStuff", 100);
		deckCoverModel = UWModel.TryCreate(_007B2433_007D, _007B2434_007D, "DeckCoverModel");
		paddleModel = UWModel.TryCreate(_007B2433_007D, _007B2434_007D, "PaddleModel");
		wheelSteamShip = UWModel.TryCreate(_007B2433_007D, _007B2434_007D, "RotateCyrcle");
		steamWheelCenterPoint = UWModel.TryCreate(_007B2433_007D, _007B2434_007D, "WheelCenterPivot");
		pipeOut = UWModel.TryCreate(_007B2433_007D, _007B2434_007D, "HPShipSmoke");
		shipMin = UWModel.Create(_007B2433_007D, _007B2434_007D, "ShipMin");
		corpusLow = UWModel.Create(_007B2433_007D, _007B2434_007D, "ShipLowCorpus");
		arris = UWModel.Separate(_007B2433_007D, _007B2434_007D, "ArrisItem");
		sailesStatic = UWModel.Separate(_007B2433_007D, _007B2434_007D, "SailStatic");
		sailesStatic.SortTop((UWModel _007B2443_007D) => -tryGetFirstNumberFromName(_007B2443_007D.MeshName));
		sailesAnimated = UWModel.Separate(_007B2433_007D, _007B2434_007D, "SailAnimated");
		sailesAnimated.SortTop((UWModel _007B2444_007D) => -tryGetFirstNumberFromName(_007B2444_007D.MeshName));
		sailesRolledAll = UWModel.Separate(_007B2433_007D, _007B2434_007D, "SailRolledup");
		mastRotateFrames = UWModel.Separate(_007B2433_007D, _007B2434_007D, "RotateFrame");
		masts = UWModel.Create(_007B2433_007D, _007B2434_007D, "MastFrame", _007B15187_007D: true);
		mastsApart = UWModel.Separate(_007B2433_007D, _007B2434_007D, "MastFrame");
		unallocatdRoops = UWModel.Create(_007B2433_007D, _007B2434_007D, "UnallocatedFrame", _007B15187_007D: true);
		flagpolls = UWModel.Separate(_007B2433_007D, _007B2434_007D, "SPAWN_FLAGPOLL");
		mainFlags = new Tlist<ShipModelMainFlag>(from _007B2445_007D in UWModel.Separate(_007B2433_007D, _007B2434_007D, "ShipMainFlag")
			select new ShipModelMainFlag(_007B2445_007D, _007B2445_007D.MeshName.Contains("_FixToFrame")));
		hitboxModel = UWOpenModel.Create(_007B2433_007D, _007B2435_007D ?? _007B2434_007D, "Hitbox");
		MastControls = new Tlist<Vector3>(from _007B2446_007D in UWModel.Separate(_007B2433_007D, _007B2434_007D, "ConnectionMastControl")
			select _007B2446_007D.CommonSphere.Center);
		ArrisControls = new Tlist<Vector3>(from _007B2447_007D in UWModel.Separate(_007B2433_007D, _007B2434_007D, "ConnectionArrisControl")
			select _007B2447_007D.CommonSphere.Center);
		DefaultElementsBS = corpus.CommonSphere;
		for (int num = 0; num < sailesStatic.Size; num++)
		{
			DefaultElementsBS = BoundingSphere.CreateMerged(DefaultElementsBS, sailesStatic.Array[num].CommonSphere);
		}
		for (int num2 = 0; num2 < sailesAnimated.Size; num2++)
		{
			DefaultElementsBS = BoundingSphere.CreateMerged(DefaultElementsBS, sailesAnimated.Array[num2].CommonSphere);
		}
		DefaultElementsBS = BoundingSphere.CreateMerged(DefaultElementsBS, masts.CommonSphere);
		UpdateRollData();
		SailOpenPriority = new Tlist<int>[2];
		for (int num3 = 0; num3 < 2; num3++)
		{
			SailOpenPriority[num3] = new Tlist<int>();
		}
		if (sailesStatic.Size + sailesAnimated.Size <= 2)
		{
			SailOpenPriority[0].Add(0);
			for (int item = 0; item < sailesStatic.Size + sailesAnimated.Size; item++)
			{
				SailOpenPriority[1].Add(in item);
			}
		}
		else
		{
			int num4 = ((sailesStatic.Size != 0) ? Math.Max(1, sailesStatic.Size / 2) : 0);
			for (int item2 = 0; item2 < num4; item2++)
			{
				SailOpenPriority[0].Add(in item2);
			}
			num4 = ((sailesAnimated.Size != 0) ? Math.Max(1, sailesAnimated.Size / 3) : 0);
			for (int num5 = 0; num5 < num4; num5++)
			{
				SailOpenPriority[0].Add(sailesStatic.Size + num5);
			}
			for (int item3 = 0; item3 < sailesStatic.Size; item3++)
			{
				SailOpenPriority[1].Add(in item3);
			}
			num4 = ((sailesAnimated.Size != 0) ? Math.Max(1, sailesAnimated.Size * 2 / 3) : 0);
			for (int num6 = 0; num6 < num4; num6++)
			{
				SailOpenPriority[1].Add(sailesStatic.Size + num6);
			}
		}
		SailOpenPriorityForZeroSpeedManuer = ((sailesStatic.Size > 0) ? sailesStatic.IndexOf(sailesStatic.MaxItem((UWModel _007B2448_007D) => _007B2448_007D.CommonSphere.Center.X)) : (sailesStatic.Size + sailesAnimated.IndexOf(sailesAnimated.MaxItem((UWModel _007B2449_007D) => _007B2449_007D.CommonSphere.Center.X))));
		if (sailesAnimated.Size > 0)
		{
			MeshPartData meshPartData = sailesAnimated.MaxItem((UWModel _007B2450_007D) => 0f - _007B2450_007D.CommonSphere.Center.X).MeshParts.First();
			HasPerpendicularBackSail = meshPartData.LocalSpaceBoundingBox.Max.X - meshPartData.LocalSpaceBoundingBox.Min.X > meshPartData.LocalSpaceBoundingBox.Max.Z - meshPartData.LocalSpaceBoundingBox.Min.Z;
		}
		UpdatePivots();
		static int tryGetFirstNumberFromName(string _007B2442_007D)
		{
			int result;
			return (_007B2442_007D.Contains('_') && int.TryParse(_007B2442_007D.Substring(0, _007B2442_007D.LastIndexOf('_')), out result)) ? result : (-1);
		}
	}

	public void UpdateRollData()
	{
		ComputeRollData(sailesStatic);
		ComputeRollData(sailesAnimated);
	}

	public void UpdatePivots()
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		//IL_0267: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_0274: Unknown result type (might be due to invalid IL or missing references)
		if (MastControls.Size == 0 && mastRotateFrames.Size > 0)
		{
			if (!corpus.ModelName.Contains("Small"))
			{
				throw new InvalidOperationException("Ship " + corpus.ModelName + " has masts but hasn't ConnectionMastControl");
			}
			MastControls.Add(default(Vector3));
		}
		if (ArrisControls.Size == 0 && arris.Size > 0)
		{
			if (!corpus.ModelName.Contains("Small"))
			{
				throw new InvalidOperationException("Ship " + corpus.ModelName + " has arris but hasn't ConnectionArrisControl");
			}
			ArrisControls.Add(default(Vector3));
		}
		if (MastControls.Size > 0)
		{
			MastControlsMinMaxX.Y = MastControls.Max((Vector3 _007B2451_007D) => _007B2451_007D.X);
			MastControlsMinMaxX.X = MastControls.Min((Vector3 _007B2452_007D) => _007B2452_007D.X);
		}
		foreach (UWModel item in (IEnumerable<UWModel>)arris)
		{
			var (_007B2414_007D, _007B2415_007D) = FindPivotArris(in item.CommonSphere.Center);
			AnimatedModelTag.Append(item, new PivotInfo(_007B2414_007D, _007B2415_007D));
		}
		foreach (UWModel item2 in (IEnumerable<UWModel>)mastRotateFrames)
		{
			var (_007B2414_007D2, _007B2415_007D2) = FindPivot(in item2.CommonSphere.Center);
			AnimatedModelTag.Append(item2, new PivotInfo(_007B2414_007D2, _007B2415_007D2));
		}
		foreach (UWModel item3 in (IEnumerable<UWModel>)sailesAnimated)
		{
			var (_007B2414_007D3, _007B2415_007D3) = FindPivot(in item3.CommonSphere.Center);
			AnimatedModelTag.Append(item3, new PivotInfo(_007B2414_007D3, _007B2415_007D3));
		}
	}

	private (Vector3, Vector3) FindPivot(in Vector3 _007B2436_007D)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		Vector2 elementPos2 = _007B2436_007D.XZ() + new Vector2(1f, 0f);
		MastControls.SortTop((Vector3 _007B2453_007D) => 0f - Vector2.DistanceSquared(_007B2453_007D.XZ(), elementPos2));
		return (MastControls[0], MastControls[1]);
	}

	private (Vector3, Vector3) FindPivotArris(in Vector3 _007B2437_007D)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		Vector2 elementPos2 = _007B2437_007D.XZ() + new Vector2(1f, 0f);
		ArrisControls.SortTop((Vector3 _007B2454_007D) => 0f - Vector2.DistanceSquared(_007B2454_007D.XZ(), elementPos2));
		return (ArrisControls[0], ArrisControls[1]);
	}

	internal static void ComputeRollData(Tlist<UWModel> _007B2438_007D)
	{
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_0236: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_020b: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0293: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_0297: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_029e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_0244: Unknown result type (might be due to invalid IL or missing references)
		//IL_0246: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0251: Unknown result type (might be due to invalid IL or missing references)
		//IL_0268: Unknown result type (might be due to invalid IL or missing references)
		//IL_026a: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0278: Unknown result type (might be due to invalid IL or missing references)
		//IL_027d: Unknown result type (might be due to invalid IL or missing references)
		//IL_027f: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < _007B2438_007D.Size; i++)
		{
			MeshPartData meshPartData = _007B2438_007D.Array[i].MeshParts[0];
			VertexPositionNormal[] _007B2439_007D = meshPartData.BuildVertexBufferSlim();
			bool flag = meshPartData.LocalSpaceBoundingBox.Max.X - meshPartData.LocalSpaceBoundingBox.Min.X < meshPartData.LocalSpaceBoundingBox.Max.Z - meshPartData.LocalSpaceBoundingBox.Min.Z;
			Vector3 val = (meshPartData.LocalSpaceBoundingBox.Min + meshPartData.LocalSpaceBoundingBox.Max) * 0.5f;
			if (flag)
			{
				Vector3 val2 = SearchSimplexGradient(_007B2439_007D, val, new Vector3(0f, 1f, 1f));
				Vector3 val3 = SearchSimplexGradient(_007B2439_007D, val, new Vector3(0f, 1f, -1f));
				Vector3 val4 = SearchSimplexGradient(_007B2439_007D, val, new Vector3(0f, -1f, 1f));
				Vector3 val5 = SearchSimplexGradient(_007B2439_007D, val, new Vector3(0f, -1f, -1f));
				AnimatedModelTag.Append(_007B2438_007D.Array[i], new SailRollData(1f, new Vector3(0.2f, 0f, Math.Min(1f, (val2.Z - val3.Z) / (val4.Z - val5.Z))), (val2 + val3) * 0.5f));
				continue;
			}
			Vector3 val6 = SearchSimplexGradient(_007B2439_007D, val, new Vector3(1f, -1f, 0f));
			Vector3 val7 = SearchSimplexGradient(_007B2439_007D, val, new Vector3(1f, 1f, 0f));
			Vector3 val8 = SearchSimplexGradient(_007B2439_007D, val, new Vector3(-1f, 1f, 0f));
			if (val6 == val7)
			{
				Vector3 val9 = val8 - val6;
				Vector3 _007B2420_007D = val9;
				((Vector3)(ref _007B2420_007D)).Normalize();
				AnimatedModelTag.Append(_007B2438_007D.Array[i], new SailRollData(0f, _007B2420_007D, (val8 + val6) * 0.5f + val));
			}
			else if (val8 == val7)
			{
				Vector3 val10 = val7 - val6;
				Vector3 _007B2420_007D2 = val10;
				((Vector3)(ref _007B2420_007D2)).Normalize();
				AnimatedModelTag.Append(_007B2438_007D.Array[i], new SailRollData(0f, _007B2420_007D2, (val7 + val6) * 0.5f + val));
			}
			else
			{
				Vector3 val11 = val8 - val7;
				Vector3 _007B2420_007D3 = val11;
				((Vector3)(ref _007B2420_007D3)).Normalize();
				AnimatedModelTag.Append(_007B2438_007D.Array[i], new SailRollData(0.7f, _007B2420_007D3, (val8 + val7) * 0.5f + val));
			}
		}
	}

	private static Vector3 SearchSimplexGradient(VertexPositionNormal[] _007B2439_007D, Vector3 _007B2440_007D, Vector3 _007B2441_007D)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		float num = float.MinValue;
		Vector3 result = Vector3.Zero;
		for (int i = 0; i < _007B2439_007D.Length; i++)
		{
			VertexPositionNormal vertexPositionNormal = _007B2439_007D[i];
			vertexPositionNormal.Position -= _007B2440_007D;
			float num2 = (_007B2441_007D.X * vertexPositionNormal.Position.X + _007B2441_007D.Y * vertexPositionNormal.Position.Y + _007B2441_007D.Z * vertexPositionNormal.Position.Z) / (_007B2441_007D.X * _007B2441_007D.X + _007B2441_007D.Y * _007B2441_007D.Y + _007B2441_007D.Z * _007B2441_007D.Z);
			if (num2 > num)
			{
				num = num2;
				result = vertexPositionNormal.Position;
			}
		}
		return result;
	}
}
