namespace Common.Resources;

public enum WorldMapStyle
{
	Default = 1,
	Snow,
	Dark,
	DarkMountains
}
