namespace Common.Resources;

public static class PortLevelBonusTypeExtension
{
	public static bool IsPercent(this PortLevelBonusType _007B3413_007D)
	{
		switch (_007B3413_007D)
		{
		case PortLevelBonusType.ResourceProduction:
		case PortLevelBonusType.CapitalRestoreDiscount:
		case PortLevelBonusType.AllCraftTimeReduction:
		case PortLevelBonusType.ShipCraftAndRepairTimeReduction:
		case PortLevelBonusType.ShipDecraftEffectiveness:
		case PortLevelBonusType.ShipCraftDiscount:
		case PortLevelBonusType.PowerupItemsCraftDiscount:
		case PortLevelBonusType.FactoriesMiningSpeed:
		case PortLevelBonusType.RecoveryTimeAfterSink:
		case PortLevelBonusType.WeaponCraftDiscount:
			return true;
		default:
			return false;
		}
	}

	public static bool IsBoolean(this PortLevelBonusType _007B3414_007D)
	{
		switch (_007B3414_007D)
		{
		case PortLevelBonusType.BondmanTrade:
		case PortLevelBonusType.ShipCraftingInLowerRankPort:
		case PortLevelBonusType.AllFractionShipsCraftNoPenalty:
		case PortLevelBonusType.TargetForTravel:
		case PortLevelBonusType.TradersCantOpenHq:
		case PortLevelBonusType.EmpireCantAttack:
		case PortLevelBonusType.AllPortsAuction:
		case PortLevelBonusType.AllPortsAuctionPirate:
		case PortLevelBonusType.BribeNotConsumedInWaterArea:
			return true;
		default:
			return false;
		}
	}
}
