using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Microsoft.Xna.Framework;
using TheraEngine.Graphics.Models;
using UWPhysicsWOSLib.Shapes;

namespace Common.Resources;

public class MastHitbox : IShipHitbox
{
	[CompilerGenerated]
	private sealed class _003CEnumerateBaseShapes_003Ed__10 : IEnumerable<BoxShape>, IEnumerable, IEnumerator<BoxShape>, IEnumerator, IDisposable
	{
		private int _007B2483_007D;

		private BoxShape _007B2484_007D;

		private int _007B2485_007D;

		public MastHitbox _003C_003E4__this;

		BoxShape IEnumerator<BoxShape>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B2484_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B2484_007D;
			}
		}

		[DebuggerHidden]
		public _003CEnumerateBaseShapes_003Ed__10(int _007B2478_007D)
		{
			_007B2483_007D = _007B2478_007D;
			_007B2485_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B2479_007D()
		{
			_007B2483_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2479}
			this._007B2479_007D();
		}

		private bool _007B2480_007D()
		{
			switch (_007B2483_007D)
			{
			default:
				return false;
			case 0:
				_007B2483_007D = -1;
				_007B2484_007D = _003C_003E4__this.Shape;
				_007B2483_007D = 1;
				return true;
			case 1:
				_007B2483_007D = -1;
				return false;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2480}
			return this._007B2480_007D();
		}

		[DebuggerHidden]
		private void _007B2481_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2481}
			this._007B2481_007D();
		}

		[DebuggerHidden]
		IEnumerator<BoxShape> IEnumerable<BoxShape>.GetEnumerator()
		{
			_003CEnumerateBaseShapes_003Ed__10 result;
			if (_007B2483_007D == -2 && _007B2485_007D == Environment.CurrentManagedThreadId)
			{
				_007B2483_007D = 0;
				result = this;
			}
			else
			{
				result = new _003CEnumerateBaseShapes_003Ed__10(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			return result;
		}

		[DebuggerHidden]
		private IEnumerator _007B2482_007D()
		{
			return ((IEnumerable<BoxShape>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2482}
			return this._007B2482_007D();
		}
	}

	public UWModel Model;

	public byte CollisionNodeID;

	public BoxShape Shape;

	public SailHitbox[] SailesLinks;

	public byte NodeID
	{
		get
		{
			return CollisionNodeID;
		}
		set
		{
			CollisionNodeID = value;
		}
	}

	public HitboxType Type => HitboxType.Mast;

	public MastHitbox(UWModel _007B2473_007D, BoundingBox _007B2474_007D, SailHitbox[] _007B2475_007D)
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		Model = _007B2473_007D;
		SailesLinks = _007B2475_007D;
		float num = 1.3f;
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector(_007B2474_007D.Max.X * 0.8f + _007B2474_007D.Min.X * 0.2f, 0f);
		_007B2474_007D.Min.X = val.X - num * 1.6f;
		_007B2474_007D.Max.X = val.X + num * 0.2f;
		_007B2474_007D.Min.Z = val.Y - num * 0.8f;
		_007B2474_007D.Max.Z = val.Y + num * 0.8f;
		_007B2474_007D.Max.Y *= 0.8f;
		Shape = new BoxShape(_007B2474_007D);
	}

	[IteratorStateMachine(typeof(_003CEnumerateBaseShapes_003Ed__10))]
	public IEnumerable<BoxShape> EnumerateBaseShapes()
	{
		//yield-return decompiler failed: Method not found
		return new _003CEnumerateBaseShapes_003Ed__10(-2)
		{
			_003C_003E4__this = this
		};
	}
}
