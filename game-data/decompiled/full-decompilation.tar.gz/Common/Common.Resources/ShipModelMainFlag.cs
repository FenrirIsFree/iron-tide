using TheraEngine.Graphics.Models;

namespace Common.Resources;

public struct ShipModelMainFlag
{
	public UWModel SrcModel;

	public bool FixedToBackFrame;

	public ShipModelMainFlag(UWModel _007B2408_007D, bool _007B2409_007D)
	{
		SrcModel = _007B2408_007D;
		FixedToBackFrame = _007B2409_007D;
	}
}
