namespace Common.Resources;

public enum NpcEducationMap
{
	None,
	FirstShip,
	BattleAllies,
	BattleEnemies
}
