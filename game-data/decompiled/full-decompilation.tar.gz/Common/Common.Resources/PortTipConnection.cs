namespace Common.Resources;

public enum PortTipConnection
{
	Verfy,
	Trade,
	RealShop,
	Workshop,
	ExitWorld,
	ExitWorldLighthouse,
	OverseasTrader,
	PirateTrader,
	Taverna,
	Hq,
	QuestUnit
}
