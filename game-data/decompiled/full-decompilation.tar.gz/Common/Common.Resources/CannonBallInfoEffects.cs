namespace Common.Resources;

public enum CannonBallInfoEffects
{
	AdditionalDispersion,
	ImprovedDamageBuildings,
	Bombershell,
	Overpenetration,
	CanMakeCannonsDamage,
	CanMakeAnyBurnings,
	FireArea,
	ExtraMicroburning,
	LessScatter,
	IgnoreSailes
}
