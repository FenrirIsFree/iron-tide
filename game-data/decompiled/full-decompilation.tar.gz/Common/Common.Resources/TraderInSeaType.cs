namespace Common.Resources;

public enum TraderInSeaType
{
	TraderInSea,
	SmallVilage,
	Town,
	Altar,
	ResearchPoint
}
