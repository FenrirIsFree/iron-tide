namespace Common.Resources;

public enum CannonAmmoType
{
	CannonBall,
	MortarBall,
	FalkonetBall
}
