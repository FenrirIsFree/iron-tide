using Common.Game;
using Microsoft.Xna.Framework;
using TheraEngine;

namespace Common.Resources;

public readonly struct NpcLocation
{
	public readonly object Data;

	private static readonly object seamlessSeaToken = new object();

	public WorldMapRegionInfo AsWorldRegion => Data as WorldMapRegionInfo;

	public Vector3? AsWorldZone => (Data is Vector3 value) ? new Vector3?(value) : ((Vector3?)null);

	public bool IsSeamlessSea => Data == seamlessSeaToken;

	public bool IsNull => Data == null;

	public int HzLevel => (AsWorldRegion != null) ? AsWorldRegion.LevelInt : (AsWorldZone.HasValue ? Gameplay.GetNearWorldRegion(AsWorldZone.Value.XY()).LevelInt : (IsSeamlessSea ? Gameplay.WorldMap.RegionsInfo.Last().LevelInt : (-1)));

	public NpcLocation(WorldMapRegionInfo _007B2328_007D)
	{
		Data = _007B2328_007D;
	}

	public NpcLocation(Vector3 _007B2329_007D)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		Data = _007B2329_007D;
	}

	public NpcLocation(bool _007B2330_007D)
	{
		Data = seamlessSeaToken;
	}

	public override string ToString()
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		object result;
		if (!IsNull)
		{
			if (!AsWorldZone.HasValue)
			{
				result = "World:" + HzLevel;
			}
			else
			{
				WorldMapInfo worldMap = Gameplay.WorldMap;
				Vector3 value = AsWorldZone.Value;
				result = "Zone near " + worldMap.GetNearPort(((Vector3)(ref value)).XY).PortName;
			}
		}
		else
		{
			result = "null";
		}
		return (string)result;
	}
}
