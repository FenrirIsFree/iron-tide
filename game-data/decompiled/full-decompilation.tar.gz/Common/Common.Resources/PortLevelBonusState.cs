namespace Common.Resources;

public readonly struct PortLevelBonusState
{
	public readonly PortLevelBonusType Type;

	public readonly int Value;

	public PortLevelBonusState(PortLevelBonusType _007B3417_007D, int _007B3418_007D)
	{
		Type = _007B3417_007D;
		Value = _007B3418_007D;
	}
}
