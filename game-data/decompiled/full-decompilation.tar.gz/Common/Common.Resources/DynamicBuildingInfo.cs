using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Data;
using Common.Game;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Graphics.Models;
using TheraEngine.Helpers;
using UWContentPipelineExtensionRuntime;

namespace Common.Resources;

public class DynamicBuildingInfo
{
	[CompilerGenerated]
	private sealed class _003CVisualHelperMortars_003Ed__13 : IEnumerable<float>, IEnumerable, IEnumerator<float>, IEnumerator, IDisposable
	{
		private int _007B2934_007D;

		private float _007B2935_007D;

		private int _007B2936_007D;

		private Matrix _007B2937_007D;

		public Matrix _003C_003E3__world;

		private IEnumerable<Player> _007B2938_007D;

		public IEnumerable<Player> _003C_003E3__players;

		private Func<Player, bool> _007B2939_007D;

		public Func<Player, bool> _003C_003E3__enemyTest;

		private float _007B2940_007D;

		public float _003C_003E3__deadZone;

		private float _007B2941_007D;

		public float _003C_003E3__maxDistance;

		public DynamicBuildingInfo _003C_003E4__this;

		private IEnumerator<Vector3> _007B2942_007D;

		private Vector3 _007B2943_007D;

		private Vector3 _007B2944_007D;

		private Vector3 _007B2945_007D;

		private Player _007B2946_007D;

		private float _007B2947_007D;

		private IEnumerator<Player> _007B2948_007D;

		private Player _007B2949_007D;

		private float _007B2950_007D;

		private Vector3 _007B2951_007D;

		float IEnumerator<float>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B2935_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B2935_007D;
			}
		}

		[DebuggerHidden]
		public _003CVisualHelperMortars_003Ed__13(int _007B2928_007D)
		{
			_007B2934_007D = _007B2928_007D;
			_007B2936_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B2929_007D()
		{
			int num = _007B2934_007D;
			if (num == -3 || num == 1)
			{
				try
				{
				}
				finally
				{
					_007B2931_007D();
				}
			}
			_007B2942_007D = null;
			_007B2946_007D = null;
			_007B2948_007D = null;
			_007B2949_007D = null;
			_007B2934_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2929}
			this._007B2929_007D();
		}

		private bool _007B2930_007D()
		{
			//IL_0053: Unknown result type (might be due to invalid IL or missing references)
			//IL_0058: Unknown result type (might be due to invalid IL or missing references)
			//IL_0060: Unknown result type (might be due to invalid IL or missing references)
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
			//IL_019a: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
			//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
			try
			{
				int num = _007B2934_007D;
				if (num != 0)
				{
					if (num != 1)
					{
						return false;
					}
					_007B2934_007D = -3;
					goto IL_01e4;
				}
				_007B2934_007D = -1;
				_007B2942_007D = ((IEnumerable<Vector3>)_003C_003E4__this.MortarsPositions).GetEnumerator();
				_007B2934_007D = -3;
				goto IL_01ec;
				IL_01e4:
				_007B2946_007D = null;
				goto IL_01ec;
				IL_01ec:
				if (_007B2942_007D.MoveNext())
				{
					_007B2943_007D = _007B2942_007D.Current;
					_007B2944_007D = _007B2943_007D;
					Vector3.Transform(ref _007B2944_007D, ref _007B2937_007D, ref _007B2945_007D);
					_007B2946_007D = null;
					_007B2947_007D = float.MaxValue;
					_007B2948_007D = _007B2938_007D.GetEnumerator();
					try
					{
						while (_007B2948_007D.MoveNext())
						{
							_007B2949_007D = _007B2948_007D.Current;
							_007B2950_007D = Vector2.DistanceSquared(_007B2949_007D.Position, _007B2945_007D.XZ());
							if (_007B2950_007D < _007B2947_007D && _007B2950_007D < _007B2941_007D * _007B2941_007D && _007B2950_007D > _007B2940_007D * _007B2940_007D && _007B2939_007D(_007B2949_007D))
							{
								_007B2946_007D = _007B2949_007D;
								_007B2947_007D = _007B2950_007D;
							}
							_007B2949_007D = null;
						}
					}
					finally
					{
						if (_007B2948_007D != null)
						{
							_007B2948_007D.Dispose();
						}
					}
					_007B2948_007D = null;
					if (_007B2947_007D != float.MaxValue)
					{
						_007B2951_007D = _007B2946_007D.Position3D - _007B2945_007D;
						_007B2935_007D = MathF.Atan2(_007B2951_007D.Z, _007B2951_007D.X);
						_007B2934_007D = 1;
						return true;
					}
					goto IL_01e4;
				}
				_007B2931_007D();
				_007B2942_007D = null;
				return false;
			}
			catch
			{
				//try-fault
				_007B2929_007D();
				throw;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2930}
			return this._007B2930_007D();
		}

		private void _007B2931_007D()
		{
			_007B2934_007D = -1;
			if (_007B2942_007D != null)
			{
				_007B2942_007D.Dispose();
			}
		}

		[DebuggerHidden]
		private void _007B2932_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2932}
			this._007B2932_007D();
		}

		[DebuggerHidden]
		IEnumerator<float> IEnumerable<float>.GetEnumerator()
		{
			//IL_0037: Unknown result type (might be due to invalid IL or missing references)
			//IL_003c: Unknown result type (might be due to invalid IL or missing references)
			_003CVisualHelperMortars_003Ed__13 _003CVisualHelperMortars_003Ed__;
			if (_007B2934_007D == -2 && _007B2936_007D == Environment.CurrentManagedThreadId)
			{
				_007B2934_007D = 0;
				_003CVisualHelperMortars_003Ed__ = this;
			}
			else
			{
				_003CVisualHelperMortars_003Ed__ = new _003CVisualHelperMortars_003Ed__13(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			_003CVisualHelperMortars_003Ed__._007B2937_007D = _003C_003E3__world;
			_003CVisualHelperMortars_003Ed__._007B2938_007D = _003C_003E3__players;
			_003CVisualHelperMortars_003Ed__._007B2939_007D = _003C_003E3__enemyTest;
			_003CVisualHelperMortars_003Ed__._007B2940_007D = _003C_003E3__deadZone;
			_003CVisualHelperMortars_003Ed__._007B2941_007D = _003C_003E3__maxDistance;
			return _003CVisualHelperMortars_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B2933_007D()
		{
			return ((IEnumerable<float>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {2933}
			return this._007B2933_007D();
		}
	}

	public readonly IsleModelInfo Model;

	public readonly Tlist<(Vector3 gunPos, Vector3 direction)> CannonsPositions;

	public readonly Tlist<Vector3> MortarsPositions;

	public readonly Tlist<UWModel> MortarsRotatedParts;

	public readonly InitialDynamicBuildingId InitialID;

	public readonly Vector3 CannonsMiddlePosition;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private int _007B2925_007D;

	public int TableID
	{
		[CompilerGenerated]
		get
		{
			return _007B2925_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B2925_007D = value;
		}
	}

	public DynamicBuildingInfo(InitialDynamicBuildingId _007B2902_007D, Vector3 _007B2903_007D, IsleModelInfo _007B2904_007D)
	{
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		Model = _007B2904_007D;
		InitialID = _007B2902_007D;
		CannonsPositions = new Tlist<(Vector3, Vector3)>();
		ModelHardpoint[] externalHardpoints = Model.Model.ExternalHardpoints;
		foreach (ModelHardpoint modelHardpoint in externalHardpoints)
		{
			if (modelHardpoint.HardpointID == WorldOfSeaBattleHardpointID.BuildingWeapon || true)
			{
				CannonsPositions.Add((((Matrix)(ref modelHardpoint.Transform)).Translation + ((Matrix)(ref modelHardpoint.Transform)).Forward * _007B2903_007D, ((Matrix)(ref modelHardpoint.Transform)).Forward));
				CannonsMiddlePosition += ((Matrix)(ref modelHardpoint.Transform)).Translation;
			}
		}
		if (CannonsPositions.Size > 0)
		{
			CannonsMiddlePosition /= (float)CannonsPositions.Size;
		}
		CannonsPositions.SortTop(((Vector3 gunPos, Vector3 direction) _007B2926_007D) => ((Vector3)(ref _007B2926_007D.gunPos)).Length());
		MortarsPositions = new Tlist<Vector3>();
		MortarsRotatedParts = new Tlist<UWModel>();
		foreach (KeyValuePair<string, UWModel> connection in _007B2904_007D.Connections)
		{
			if (connection.Key.Contains("ConnectionBuildingMort"))
			{
				MortarsRotatedParts.Add(connection.Value);
				MortarsPositions.Add(in connection.Value.CommonSphere.Center);
			}
		}
		if (_007B2902_007D == InitialDynamicBuildingId.FortMain && CannonsPositions.Size <= 1)
		{
			throw new InvalidOperationException("Fort CannonsPositions problem");
		}
		if ((_007B2902_007D == InitialDynamicBuildingId.FortTowerMortar || _007B2902_007D == InitialDynamicBuildingId.FortTowerFire || _007B2902_007D == InitialDynamicBuildingId.FortTowerCannons) && !CommonGlobal.IsServer && _007B2904_007D.DesturctionParts.Size == 0)
		{
			throw new InvalidOperationException("Tower DesturctionParts not found");
		}
	}

	public void AttackHelperCannons(bool _007B2905_007D, Matrix _007B2906_007D, float _007B2907_007D, Tlist<(Vector3, Player, int)> _007B2908_007D, int _007B2909_007D, Tlist<Player> _007B2910_007D, float _007B2911_007D, float _007B2912_007D, float _007B2913_007D)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		(Vector3 gunPos, Vector3 direction) tuple = CannonsPositions.Array[_007B2909_007D];
		Vector3 item = tuple.gunPos;
		Vector3 item2 = tuple.direction;
		Vector2 val = Geometry.RotateVector2(item2.XZ(), _007B2907_007D);
		Vector3 val3 = default(Vector3);
		foreach (Player item3 in (IEnumerable<Player>)_007B2910_007D)
		{
			Vector3 val2 = item;
			Vector3.Transform(ref val2, ref _007B2906_007D, ref val3);
			Vector3 val4 = item3.Position3D - val3;
			float num = ((Vector3)(ref val4)).LengthSquared();
			if (num > _007B2912_007D * _007B2912_007D && num < _007B2913_007D * _007B2913_007D)
			{
				Vector2 val5 = (_007B2905_007D ? item.XZ().Normal() : val);
				float num2 = MathF.Atan2(val5.Y, val5.X);
				float num3 = MathF.Atan2(val4.Z, val4.X);
				if (Geometry.AxisDistance(num2, num3) < _007B2911_007D)
				{
					_007B2908_007D.Add((val3, item3, _007B2909_007D));
				}
			}
		}
	}

	public void AttackHelperMortars(Matrix _007B2914_007D, Tlist<(Vector3 from, Player to, int zero)> _007B2915_007D, Tlist<Player> _007B2916_007D, float _007B2917_007D, float _007B2918_007D, int _007B2919_007D)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = MortarsPositions.Array[_007B2919_007D];
		Vector3 val2 = val;
		Vector3 val3 = default(Vector3);
		Vector3.Transform(ref val2, ref _007B2914_007D, ref val3);
		Player item = null;
		float num = float.MaxValue;
		foreach (Player item2 in (IEnumerable<Player>)_007B2916_007D)
		{
			float num2 = Vector2.DistanceSquared(item2.Position, val3.XZ());
			if (num2 < num && num2 < _007B2918_007D * _007B2918_007D && num2 > _007B2917_007D * _007B2917_007D)
			{
				item = item2;
				num = num2;
			}
		}
		if (num != float.MaxValue)
		{
			_007B2915_007D.Add((val3, item, -1));
		}
	}

	[IteratorStateMachine(typeof(_003CVisualHelperMortars_003Ed__13))]
	public IEnumerable<float> VisualHelperMortars(Matrix _007B2920_007D, IEnumerable<Player> _007B2921_007D, Func<Player, bool> _007B2922_007D, float _007B2923_007D, float _007B2924_007D)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//yield-return decompiler failed: Method not found
		return new _003CVisualHelperMortars_003Ed__13(-2)
		{
			_003C_003E4__this = this,
			_003C_003E3__world = _007B2920_007D,
			_003C_003E3__players = _007B2921_007D,
			_003C_003E3__enemyTest = _007B2922_007D,
			_003C_003E3__deadZone = _007B2923_007D,
			_003C_003E3__maxDistance = _007B2924_007D
		};
	}
}
