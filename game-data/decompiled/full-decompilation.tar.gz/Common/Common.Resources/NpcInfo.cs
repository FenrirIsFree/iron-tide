using System;
using System.Linq;
using System.Runtime.CompilerServices;
using Common.Account;
using Common.Data;
using Common.Game;
using CommonDataTypes;

namespace Common.Resources;

public class NpcInfo : XmlAsset<NpcGenerator>
{
	public ShipStaticInfo Ship;

	public PlayerShipInfo BasedOn;

	public NpcType Descritpion;

	public string NpcName;

	public NpcLocation Location;

	public float DamagePerShot;

	public float MaxCannonAngle;

	public int? OverrideCannonBalls;

	public float ReloadCannonTime;

	public float AttackDistance;

	public NpcVisualEffect SpecialEffect;

	public int Generation;

	public float SpecialSpawnIntervalMin;

	public ShipProperties ShipProperties;

	public int DefaultCrewAmount;

	public float Mobility;

	public Bonus RewardAmount;

	public int CountAmmoWillFound;

	public (NpcInfo, int)[] DefenceWaves;

	public int FleetSize;

	public object Tag;

	public bool IsDefenderOrPrivateer;

	public bool NpcInfoIDPassingMap;

	public float? OverrideMortarDamage;

	public NpcEducationMap EducationMapScenario;

	internal CannonGameInfo CannonInfo;

	private (NpcGenerator, int)[] _007B2346_007D;

	public NpcClassDecorator Extras => new NpcClassDecorator(Descritpion);

	public bool MortarShipModification => Ship.MortarPorts.Any((CannonLocationInfo _007B2347_007D) => !_007B2347_007D.AvailableWithUpgrade);

	public bool UseTradingRoute => Descritpion == NpcType.Trader_Regular && !IsDefenderOrPrivateer;

	public bool MakeNearSameNpcAgreessiveWhenAttackeed => UseTradingRoute;

	public float MaxAgressionDistance(NpcAgression _007B2335_007D)
	{
		return _007B2335_007D switch
		{
			NpcAgression.Distance => Math.Min(145f, AttackDistance) * 0.8f, 
			NpcAgression.No => 0f, 
			_ => AttackDistance * 0.5f, 
		};
	}

	public float MaxAgressionDistance(NpcAgression _007B2336_007D, PlayerAccount _007B2337_007D, float _007B2338_007D)
	{
		return MaxAgressionDistance(_007B2336_007D) * (1f - (float)_007B2337_007D.CaptainSkills[PDynamicAccountBonus.PReduceNpcAgressionDistance] / 100f) * (0.75f + 0.25f * _007B2338_007D);
	}

	internal NpcInfo Clone(int _007B2339_007D)
	{
		NpcInfo npcInfo = new NpcInfo((short)_007B2339_007D);
		npcInfo.Descritpion = Descritpion;
		npcInfo.Ship = Ship;
		npcInfo.BasedOn = BasedOn;
		npcInfo.NpcName = NpcName;
		npcInfo.Location = Location;
		npcInfo.DamagePerShot = DamagePerShot;
		npcInfo.MaxCannonAngle = MaxCannonAngle;
		npcInfo.OverrideCannonBalls = OverrideCannonBalls;
		npcInfo.ReloadCannonTime = ReloadCannonTime;
		npcInfo.AttackDistance = AttackDistance;
		npcInfo.SpecialEffect = SpecialEffect;
		npcInfo.Generation = Generation;
		npcInfo.SpecialSpawnIntervalMin = SpecialSpawnIntervalMin;
		npcInfo.ShipProperties = ShipProperties.Clone();
		npcInfo.Mobility = Mobility;
		npcInfo.RewardAmount = RewardAmount;
		npcInfo.CountAmmoWillFound = CountAmmoWillFound;
		npcInfo.DefenceWaves = DefenceWaves;
		npcInfo.FleetSize = FleetSize;
		npcInfo.DefaultCrewAmount = DefaultCrewAmount;
		npcInfo.OverrideMortarDamage = OverrideMortarDamage;
		npcInfo.EducationMapScenario = EducationMapScenario;
		npcInfo.Tag = Tag;
		return npcInfo;
	}

	private NpcInfo(int _007B2340_007D = 1)
		: base(_007B2340_007D)
	{
	}

	public NpcInfo(int _007B2341_007D, NpcGenerator _007B2342_007D, bool _007B2343_007D)
		: base(_007B2341_007D)
	{
		if (_007B2342_007D.Armor < 0.5f || _007B2342_007D.Hp < 1f || _007B2342_007D.Mobility < 10f || _007B2342_007D.AttackDistance < 1f || _007B2342_007D.DamagePerShot < 1f || _007B2342_007D.ReloadCannonTime < 1f || _007B2342_007D.Speed < 1f || _007B2342_007D.FleetSize < 1)
		{
			throw new Exception();
		}
		Ship = Gameplay.ShipsStaticInfo.FromID(_007B2342_007D.Ship);
		if (_007B2342_007D.ReloadCannonTime < 4500f && !Ship.IsBalloon)
		{
			throw new Exception();
		}
		IsDefenderOrPrivateer = _007B2343_007D;
		BasedOn = Gameplay.PlayersInfo.First((PlayerShipInfo _007B2345_007D) => _007B2345_007D.StaticInfo.ID == Ship.ID);
		Descritpion = _007B2342_007D.Class;
		NpcName = _007B2342_007D.Name;
		Generation = _007B2342_007D.Generation;
		SpecialSpawnIntervalMin = _007B2342_007D.SpecialSpawnIntervalMin;
		Location = _007B2342_007D.Location;
		ShipProperties.MaxHp = (int)_007B2342_007D.Hp;
		ShipProperties.Armor = _007B2342_007D.Armor;
		AttackDistance = _007B2342_007D.AttackDistance;
		OverrideCannonBalls = ((_007B2342_007D.AttackID == -1) ? ((int?)null) : new int?(_007B2342_007D.AttackID));
		DamagePerShot = _007B2342_007D.DamagePerShot;
		MaxCannonAngle = NpcShipHelper.GetNpcCannonAngle(_007B2342_007D.AttackDistance, _007B2341_007D, _007B2342_007D.Class);
		ReloadCannonTime = _007B2342_007D.ReloadCannonTime;
		ShipProperties.MaxBasicSpeed = _007B2342_007D.Speed - 1f;
		ShipProperties.CapacityCg = 1000000f;
		SpecialEffect = _007B2342_007D.Visual;
		Mobility = _007B2342_007D.Mobility;
		FleetSize = _007B2342_007D.FleetSize;
		(int, int, int) tuple = WosbNpcs.MatchBasicReward(this, _007B2343_007D);
		RewardAmount = new Bonus(tuple.Item2, tuple.Item1);
		CountAmmoWillFound = tuple.Item3;
		DefaultCrewAmount = _007B2342_007D.OverrideCrewCount ?? NpcShipHelper.GetMaxCrewCount(_007B2342_007D.Hp, _007B2341_007D, Descritpion);
		EducationMapScenario = _007B2342_007D.EducationMapScenario;
		Tag = _007B2342_007D.Tag;
		DefenceWaves = new(NpcInfo, int)[(_007B2342_007D.DefenceWaves != null) ? _007B2342_007D.DefenceWaves.Length : 0];
		_007B2346_007D = _007B2342_007D.DefenceWaves;
		if (Descritpion == NpcType.SpecialNoReward && RewardAmount.XpBonus > 0)
		{
			throw new InvalidCastException();
		}
	}

	internal void IntializeDefenceWaves()
	{
		for (int i = 0; i < DefenceWaves.Length; i++)
		{
			(NpcGenerator, int) tuple = _007B2346_007D[i];
			tuple.Item1.Class = ((base.ID == 0) ? NpcType.BonusMap : (Extras.IsEmpire ? NpcType.Empire_Regular : ((Extras.Flags != OpenWorldFlag.Trader) ? NpcType.PirateFraction1_Regular : NpcType.Trader_Regular)));
			tuple.Item1.Generation = 0;
			tuple.Item1.AttackDistance = AttackDistance;
			tuple.Item1.Speed -= 1f;
			if (tuple.Item1.ReloadCannonTime < 9000f)
			{
				tuple.Item1.ReloadCannonTime *= 1.5f;
				tuple.Item1.DamagePerShot *= 1.45f;
			}
			tuple.Item1.DamagePerShot *= 1.15f;
			short iD = Gameplay.NpcsInfo.Last().ID;
			NpcInfo item = new NpcInfo(iD + 1, tuple.Item1, _007B2343_007D: true);
			Gameplay.NpcsInfo.Add(in item);
			DefenceWaves[i] = (item, tuple.Item2);
		}
		_007B2346_007D = null;
	}

	[CompilerGenerated]
	private bool _007B2344_007D(PlayerShipInfo _007B2345_007D)
	{
		return _007B2345_007D.StaticInfo.ID == Ship.ID;
	}
}
