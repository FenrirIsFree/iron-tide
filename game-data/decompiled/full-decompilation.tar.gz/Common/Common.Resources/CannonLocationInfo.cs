using System;
using Common.Game;
using Microsoft.Xna.Framework;

namespace Common.Resources;

public class CannonLocationInfo
{
	public readonly short SectionID;

	public readonly Vector3 Position;

	internal Vector3 PositionI;

	public readonly Vector2 CurrentDirection;

	public readonly Vector3 Normal;

	public readonly CannonLocation Side;

	public readonly bool IsLafetVisible;

	public readonly Matrix WorldLocal;

	public readonly Matrix WorldLocalIT;

	public readonly CannonLocationMode Mode;

	internal readonly float FocusingOffsetMultiplier;

	public readonly bool AvailableWithUpgrade;

	public int ReduceCannonsOrder;

	public int DeckIndex = -1;

	public bool IsStatic = false;

	public bool Hidden = false;

	internal CannonLocationInfo(int _007B2267_007D, int _007B2268_007D, float _007B2269_007D, Vector3 _007B2270_007D, Vector2 _007B2271_007D, CannonLocation _007B2272_007D, ShipStaticInfo _007B2273_007D, bool _007B2274_007D, CannonLocationMode _007B2275_007D, bool _007B2276_007D = false)
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		SectionID = (short)_007B2267_007D;
		CurrentDirection = _007B2271_007D;
		Side = _007B2272_007D;
		Position = _007B2270_007D;
		PositionI = _007B2270_007D;
		AvailableWithUpgrade = _007B2276_007D;
		ReduceCannonsOrder = _007B2268_007D;
		IsStatic = _007B2275_007D == CannonLocationMode.Special && _007B2273_007D.ID == 63;
		Hidden = _007B2275_007D == CannonLocationMode.Special && (_007B2273_007D.ID == 63 || _007B2273_007D.ID == 27 || _007B2273_007D.ID == 25 || _007B2273_007D.ID == 34);
		if (1 == 0)
		{
		}
		Vector3 normal = (Vector3)(_007B2272_007D switch
		{
			CannonLocation.LeftSide => new Vector3(0f, 0f, 1f), 
			CannonLocation.RightSide => new Vector3(0f, 0f, -1f), 
			CannonLocation.InBack => new Vector3(-1f, 0f, 0f), 
			CannonLocation.InFront => new Vector3(1f, 0f, 0f), 
			_ => throw new NotSupportedException(), 
		});
		if (1 == 0)
		{
		}
		Normal = normal;
		IsLafetVisible = _007B2274_007D;
		_007B2269_007D = ((_007B2275_007D != CannonLocationMode.Special) ? (_007B2269_007D * 1.05f) : (_007B2269_007D * 1.3f));
		WorldLocal = Matrix.CreateScale(_007B2269_007D) * Matrix.CreateRotationY(CurrentDirection.Y + ((_007B2272_007D == CannonLocation.RightSide || _007B2272_007D == CannonLocation.LeftSide) ? ((float)Math.PI) : 0f)) * Matrix.CreateTranslation(Position);
		Matrix.Invert(ref WorldLocal, ref WorldLocalIT);
		Matrix.Transpose(ref WorldLocalIT, ref WorldLocalIT);
		Mode = _007B2275_007D;
		if (Side == CannonLocation.InBack || Side == CannonLocation.InFront)
		{
			FocusingOffsetMultiplier = MathF.Sqrt(Math.Abs(Position.Z)) * (float)Math.Sign(Position.Z) * (float)Math.Sign(0f - Position.X) / 3.5f;
		}
		else
		{
			FocusingOffsetMultiplier = MathF.Sqrt(Math.Abs(Position.X)) * (float)Math.Sign(Position.X) * (float)Math.Sign(0f - Position.Z) / 1.5f;
		}
	}

	public Vector3 GetPosition(Ship _007B2277_007D)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		return _007B2277_007D.transform.Transform3X3(Position);
	}

	public bool IsBlocked(ShipDynamicInfo _007B2278_007D)
	{
		if (Mode == CannonLocationMode.Mortar)
		{
			return AvailableWithUpgrade && !_007B2278_007D.HasExtraMortarUpgrade;
		}
		return (Side == CannonLocation.LeftSide || Side == CannonLocation.RightSide) && ReduceCannonsOrder < _007B2278_007D.ReduceBoardCannonsQuantity;
	}
}
