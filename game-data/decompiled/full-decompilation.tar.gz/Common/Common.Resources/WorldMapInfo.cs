using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using Common.Account;
using Common.Data;
using Common.Game;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Graphics.Models;
using TheraEngine.Helpers;

namespace Common.Resources;

public class WorldMapInfo : XmlAsset<MapInfoToken>
{
	[CompilerGenerated]
	private sealed class _003CGetAvailableRespawnsInSea_003Ed__62 : IEnumerable<IslePortPharosInfo>, IEnumerable, IEnumerator<IslePortPharosInfo>, IEnumerator, IDisposable
	{
		private int _007B3155_007D;

		private IslePortPharosInfo _007B3156_007D;

		private int _007B3157_007D;

		private Vector2 _007B3158_007D;

		public Vector2 _003C_003E3__p;

		private float _007B3159_007D;

		public float _003C_003E3__maxDistance;

		private bool _007B3160_007D;

		public bool _003C_003E3__manyPvpShipsAroundPort;

		private PlayerAccount _007B3161_007D;

		public PlayerAccount _003C_003E3__account;

		public WorldMapInfo _003C_003E4__this;

		private int _007B3162_007D;

		private int _007B3163_007D;

		private int _007B3164_007D;

		private IslePortInfo _007B3165_007D;

		private IEnumerator<IslePortPharosInfo> _007B3166_007D;

		private IslePortPharosInfo _007B3167_007D;

		private float _007B3168_007D;

		IslePortPharosInfo IEnumerator<IslePortPharosInfo>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B3156_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B3156_007D;
			}
		}

		[DebuggerHidden]
		public _003CGetAvailableRespawnsInSea_003Ed__62(int _007B3149_007D)
		{
			_007B3155_007D = _007B3149_007D;
			_007B3157_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B3150_007D()
		{
			int num = _007B3155_007D;
			if (num == -3 || num == 1)
			{
				try
				{
				}
				finally
				{
					_007B3152_007D();
				}
			}
			_007B3165_007D = null;
			_007B3166_007D = null;
			_007B3167_007D = null;
			_007B3155_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3150}
			this._007B3150_007D();
		}

		private bool _007B3151_007D()
		{
			//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
			//IL_0122: Unknown result type (might be due to invalid IL or missing references)
			//IL_012d: Unknown result type (might be due to invalid IL or missing references)
			try
			{
				int num = _007B3155_007D;
				if (num != 0)
				{
					if (num != 1)
					{
						return false;
					}
					_007B3155_007D = -3;
					goto IL_0197;
				}
				_007B3155_007D = -1;
				_007B3162_007D = _007B3161_007D.Shipyard.CurrentRealShip.CraftFrom.Rank;
				_007B3163_007D = 108900;
				_007B3164_007D = (_007B3160_007D ? 600 : 0);
				_007B3165_007D = _003C_003E4__this.GetNearPort(in _007B3158_007D);
				_007B3166_007D = ((IEnumerable<IslePortPharosInfo>)_003C_003E4__this.RespawnInSeaPositions).GetEnumerator();
				_007B3155_007D = -3;
				goto IL_019f;
				IL_0197:
				_007B3167_007D = null;
				goto IL_019f;
				IL_019f:
				if (_007B3166_007D.MoveNext())
				{
					_007B3167_007D = _007B3166_007D.Current;
					_007B3168_007D = Vector2.DistanceSquared(_007B3167_007D.MapGlobalPosition, _007B3158_007D);
					if (_007B3168_007D < _007B3159_007D * _007B3159_007D && _007B3168_007D > (float)_007B3163_007D && _007B3162_007D >= _003C_003E4__this.Shallows.Get(in _007B3167_007D.MapGlobalPosition) && Vector2.DistanceSquared(_007B3165_007D.EntryPos, _007B3167_007D.MapGlobalPosition) > (float)(_007B3164_007D * _007B3164_007D) && (!_007B3161_007D.DisallowEnteringHazardWaters || !Gameplay.IsInHazardZone(in _007B3167_007D.MapGlobalPosition)))
					{
						_007B3156_007D = _007B3167_007D;
						_007B3155_007D = 1;
						return true;
					}
					goto IL_0197;
				}
				_007B3152_007D();
				_007B3166_007D = null;
				return false;
			}
			catch
			{
				//try-fault
				_007B3150_007D();
				throw;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3151}
			return this._007B3151_007D();
		}

		private void _007B3152_007D()
		{
			_007B3155_007D = -1;
			if (_007B3166_007D != null)
			{
				_007B3166_007D.Dispose();
			}
		}

		[DebuggerHidden]
		private void _007B3153_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3153}
			this._007B3153_007D();
		}

		[DebuggerHidden]
		IEnumerator<IslePortPharosInfo> IEnumerable<IslePortPharosInfo>.GetEnumerator()
		{
			//IL_0037: Unknown result type (might be due to invalid IL or missing references)
			//IL_003c: Unknown result type (might be due to invalid IL or missing references)
			_003CGetAvailableRespawnsInSea_003Ed__62 _003CGetAvailableRespawnsInSea_003Ed__;
			if (_007B3155_007D == -2 && _007B3157_007D == Environment.CurrentManagedThreadId)
			{
				_007B3155_007D = 0;
				_003CGetAvailableRespawnsInSea_003Ed__ = this;
			}
			else
			{
				_003CGetAvailableRespawnsInSea_003Ed__ = new _003CGetAvailableRespawnsInSea_003Ed__62(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			_003CGetAvailableRespawnsInSea_003Ed__._007B3158_007D = _003C_003E3__p;
			_003CGetAvailableRespawnsInSea_003Ed__._007B3159_007D = _003C_003E3__maxDistance;
			_003CGetAvailableRespawnsInSea_003Ed__._007B3160_007D = _003C_003E3__manyPvpShipsAroundPort;
			_003CGetAvailableRespawnsInSea_003Ed__._007B3161_007D = _003C_003E3__account;
			return _003CGetAvailableRespawnsInSea_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B3154_007D()
		{
			return ((IEnumerable<IslePortPharosInfo>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3154}
			return this._007B3154_007D();
		}
	}

	[CompilerGenerated]
	private sealed class _003CLoadRespawnConnections_003Ed__44 : IEnumerable<ShipPositionInfo>, IEnumerable, IEnumerator<ShipPositionInfo>, IEnumerator, IDisposable
	{
		private int _007B3176_007D;

		private ShipPositionInfo _007B3177_007D;

		private int _007B3178_007D;

		private IsleInstance _007B3179_007D;

		public IsleInstance _003C_003E3__isle;

		private Tlist<Vector2> _007B3180_007D;

		private Dictionary<string, UWModel>.Enumerator _007B3181_007D;

		private KeyValuePair<string, UWModel> _007B3182_007D;

		private Vector2 _007B3183_007D;

		ShipPositionInfo IEnumerator<ShipPositionInfo>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B3177_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B3177_007D;
			}
		}

		[DebuggerHidden]
		public _003CLoadRespawnConnections_003Ed__44(int _007B3170_007D)
		{
			_007B3176_007D = _007B3170_007D;
			_007B3178_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B3171_007D()
		{
			int num = _007B3176_007D;
			if (num == -3 || num == 1)
			{
				try
				{
				}
				finally
				{
					_007B3173_007D();
				}
			}
			_007B3180_007D = null;
			_007B3181_007D = default(Dictionary<string, UWModel>.Enumerator);
			_007B3182_007D = default(KeyValuePair<string, UWModel>);
			_007B3176_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3171}
			this._007B3171_007D();
		}

		private bool _007B3172_007D()
		{
			//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
			try
			{
				int num = _007B3176_007D;
				if (num != 0)
				{
					if (num != 1)
					{
						return false;
					}
					_007B3176_007D = -3;
					goto IL_011d;
				}
				_007B3176_007D = -1;
				_007B3180_007D = new Tlist<Vector2>();
				_007B3181_007D = _007B3179_007D.ModelData.Connections.GetEnumerator();
				_007B3176_007D = -3;
				goto IL_012a;
				IL_011d:
				_007B3182_007D = default(KeyValuePair<string, UWModel>);
				goto IL_012a;
				IL_012a:
				if (_007B3181_007D.MoveNext())
				{
					_007B3182_007D = _007B3181_007D.Current;
					if (_007B3182_007D.Key.Contains("Respawn"))
					{
						_007B3183_007D = _007B3179_007D.GlobalTransform.Transform3X3(_007B3182_007D.Value.CommonSphere.Center).XZ();
						_007B3177_007D = new ShipPositionInfo(_007B3183_007D, MathF.Atan2(_007B3183_007D.Y - _007B3179_007D.ModelGlobalBSxz.Y, _007B3183_007D.X - _007B3179_007D.ModelGlobalBSxz.X));
						_007B3176_007D = 1;
						return true;
					}
					goto IL_011d;
				}
				_007B3173_007D();
				_007B3181_007D = default(Dictionary<string, UWModel>.Enumerator);
				return false;
			}
			catch
			{
				//try-fault
				_007B3171_007D();
				throw;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3172}
			return this._007B3172_007D();
		}

		private void _007B3173_007D()
		{
			_007B3176_007D = -1;
			((IDisposable)_007B3181_007D/*cast due to .constrained prefix*/).Dispose();
		}

		[DebuggerHidden]
		private void _007B3174_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3174}
			this._007B3174_007D();
		}

		[DebuggerHidden]
		IEnumerator<ShipPositionInfo> IEnumerable<ShipPositionInfo>.GetEnumerator()
		{
			_003CLoadRespawnConnections_003Ed__44 _003CLoadRespawnConnections_003Ed__;
			if (_007B3176_007D == -2 && _007B3178_007D == Environment.CurrentManagedThreadId)
			{
				_007B3176_007D = 0;
				_003CLoadRespawnConnections_003Ed__ = this;
			}
			else
			{
				_003CLoadRespawnConnections_003Ed__ = new _003CLoadRespawnConnections_003Ed__44(0);
			}
			_003CLoadRespawnConnections_003Ed__._007B3179_007D = _003C_003E3__isle;
			return _003CLoadRespawnConnections_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B3175_007D()
		{
			return ((IEnumerable<ShipPositionInfo>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3175}
			return this._007B3175_007D();
		}
	}

	private readonly string _007B3115_007D;

	public readonly Vector4 EndCoordinates;

	public readonly Vector2 MapSize;

	public readonly WorldMapStyle Style;

	public readonly WeatherEngine Weather;

	public readonly Tlist<IsleInstance> Isles;

	public readonly Tlist<IslePortInfo> Ports;

	public readonly Tlist<IslePortInfo> StartPorts;

	public readonly Tlist<ShipPositionInfo> WorldForts;

	public readonly Tlist<IsleInstance> CollisableObjects;

	public readonly Tlist<FactoryPlaceIsleInfo> Factories;

	public readonly Tlist<TraderInSeaPlaceInfo> TradersInSea;

	public readonly Tlist<IslePortPharosInfo> RespawnInSeaPositions;

	public readonly WorldBitmap Shallows;

	public readonly WorldBitmap Regions;

	public readonly Tlist<WorldMapRegionInfo> RegionsInfo = new Tlist<WorldMapRegionInfo>();

	public Texture2D RegionsTex;

	public Texture2D RegionsTexBlurred;

	internal readonly Tlist<Vector2> PoolQuestPositionsIsles = new Tlist<Vector2>();

	public readonly Tlist<Vector2> PositionsForDropInIsle;

	public readonly Tlist<Vector2> PositionsForDropInIsleOutsideSeam;

	public readonly Tlist<Vector2> PositionsOfLivings;

	private readonly Dictionary<Index2D, WorldHashingSector> _007B3116_007D = new Dictionary<Index2D, WorldHashingSector>(10000);

	private Index2D _007B3117_007D;

	private Index2D _007B3118_007D;

	private float _007B3119_007D;

	private const float deepWaterDistancingLimit = 1700f;

	private bool _007B3120_007D;

	public bool IsWorldmap;

	public bool IsCircularShape;

	public bool IsBoardingEnable;

	public bool IsEnableArenaUi;

	public bool IsEducationMap;

	public bool IsEvaluteQuestsTime;

	public bool IsPassingUi;

	public float DefaultMendingSpeed;

	public bool IsReducedFarDistView;

	public string Name => Local.Current(_007B3115_007D);

	public bool WindEnable => _007B3120_007D && !ShipPhysics.DisableWind;

	internal void InitMaptype(int _007B3019_007D)
	{
		IsWorldmap = _007B3019_007D == 0;
		IsCircularShape = _007B3019_007D == 2 || _007B3019_007D == 3 || _007B3019_007D == 5;
		IsBoardingEnable = _007B3019_007D == 0 || _007B3019_007D == 2 || _007B3019_007D == 3;
		IsEnableArenaUi = _007B3019_007D == 2;
		IsEducationMap = _007B3019_007D == 5;
		IsEvaluteQuestsTime = IsWorldmap;
		IsPassingUi = _007B3019_007D == 3;
		DefaultMendingSpeed = ((_007B3019_007D != 3) ? 1 : 2);
		IsReducedFarDistView = _007B3019_007D == 2;
		_007B3120_007D = _007B3019_007D == 0 || _007B3019_007D == 5;
		_007B3119_007D = (IsWorldmap ? 160 : 300);
	}

	private void _007B3020_007D()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0591: Unknown result type (might be due to invalid IL or missing references)
		//IL_0598: Unknown result type (might be due to invalid IL or missing references)
		//IL_055e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0565: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_0314: Unknown result type (might be due to invalid IL or missing references)
		//IL_0319: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0401: Unknown result type (might be due to invalid IL or missing references)
		//IL_0406: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = (IsWorldmap ? Gameplay.WorldMaxMapSizeXY : MapSize);
		float num = 600f + _007B3119_007D;
		Tlist<IsleInstance> tlist = new Tlist<IsleInstance>();
		Tlist<IsleInstance> tlist2 = new Tlist<IsleInstance>();
		Tlist<PbsBuildingPlaceInfo> tlist3 = new Tlist<PbsBuildingPlaceInfo>();
		Tlist<FenceSphereStruct> tlist4 = new Tlist<FenceSphereStruct>();
		Tlist<FenceSphereStruct> tlist5 = new Tlist<FenceSphereStruct>();
		Tlist<FenceSphereStruct> tlist6 = new Tlist<FenceSphereStruct>();
		IsleInstance[] array = Isles.Where((IsleInstance _007B3121_007D) => _007B3121_007D.ModelData.Binding == WorldBindingType.RiverMarker).ToArray();
		_007B3117_007D = new Index2D(0, 0);
		_007B3118_007D = new Index2D(0, 0);
		Vector2 val2 = default(Vector2);
		val2.X = 0f - _007B3119_007D;
		while (val2.X <= val.X + _007B3119_007D)
		{
			val2.Y = 0f - _007B3119_007D;
			while (val2.Y <= val.Y + _007B3119_007D)
			{
				Vector2 _007B3069_007D = val2 - val * 0.5f;
				Index2D key = new Index2D(_007B3069_007D, _007B3119_007D);
				_007B3117_007D.X = Math.Min(_007B3117_007D.X, key.X);
				_007B3117_007D.Y = Math.Min(_007B3117_007D.Y, key.Y);
				_007B3118_007D.X = Math.Max(_007B3118_007D.X, key.X);
				_007B3118_007D.Y = Math.Max(_007B3118_007D.Y, key.Y);
				for (int num2 = 0; num2 < CollisableObjects.Size; num2++)
				{
					IsleInstance item = CollisableObjects.Array[num2];
					float num3 = Vector2.DistanceSquared(item.ModelGlobalBSxz, _007B3069_007D);
					if (num3 < (num + item.ModelGlobalBS.Radius) * (num + item.ModelGlobalBS.Radius))
					{
						tlist.Add(in item);
						if (item.GroupID == WorldObjectID.WPort || num3 < (90f + _007B3119_007D + 1.1f * item.ModelGlobalBS.Radius) * (90f + _007B3119_007D + 1.1f * item.ModelGlobalBS.Radius))
						{
							tlist2.Add(in item);
						}
					}
					float num4 = 1700f + _007B3119_007D + item.ModelGlobalBS.Radius;
					if (num3 < num4 * num4)
					{
						if (item.ModelGlobalBS.Radius > 230f)
						{
							tlist4.Add(new FenceSphereStruct(in item.ModelGlobalBSxz, item.ModelGlobalBS.Radius * 0.7f));
						}
						else if (item.ModelGlobalBS.Radius > 130f || item.GroupID == WorldObjectID.WPort)
						{
							tlist5.Add(new FenceSphereStruct(in item.ModelGlobalBSxz, item.ModelGlobalBS.Radius * 0.7f));
						}
					}
				}
				foreach (IsleInstance isleInstance in array)
				{
					if (Vector2.DistanceSquared(isleInstance.ModelGlobalBSxz, _007B3069_007D) < (isleInstance.ModelGlobalBS.Radius + 30f + _007B3119_007D) * (isleInstance.ModelGlobalBS.Radius + 30f + _007B3119_007D))
					{
						tlist6.Add(new FenceSphereStruct(in isleInstance.ModelGlobalBSxz, isleInstance.ModelGlobalBS.Radius));
					}
				}
				IslePortInfo _007B3207_007D = null;
				float num6 = float.MaxValue;
				for (int num7 = 0; num7 < Ports.Size; num7++)
				{
					IslePortInfo islePortInfo = Ports.Array[num7];
					float num8 = Vector2.DistanceSquared(islePortInfo.EntryPos, _007B3069_007D);
					if (num8 < num6)
					{
						num6 = num8;
						_007B3207_007D = islePortInfo;
					}
					foreach (KeyValuePair<int, PbsBuildingPlaceInfo> item2 in islePortInfo.PbSystem)
					{
						if (Vector2.DistanceSquared(item2.Value.Position, _007B3069_007D) < (num + item2.Value.MaximalRadius) * (num + item2.Value.MaximalRadius))
						{
							tlist3.Add(item2.Value);
						}
					}
				}
				TraderInSeaPlaceInfo _007B3211_007D = null;
				num6 = float.MaxValue;
				for (int num9 = 0; num9 < TradersInSea.Size; num9++)
				{
					TraderInSeaPlaceInfo traderInSeaPlaceInfo = TradersInSea.Array[num9];
					float num10 = Vector2.DistanceSquared(traderInSeaPlaceInfo.Position, _007B3069_007D);
					if (num10 < num6)
					{
						num6 = num10;
						_007B3211_007D = traderInSeaPlaceInfo;
					}
				}
				_007B3116_007D.Add(key, new WorldHashingSector(_007B3207_007D, tlist.CloneOrEmptyReadonly(), tlist2.CloneOrEmptyReadonly(), tlist3.CloneOrEmptyReadonly(), _007B3211_007D, tlist6.CloneOrEmptyReadonly(), MatchDeepnessLevel(ref _007B3069_007D, tlist4, tlist5)));
				tlist.Size = 0;
				tlist2.Size = 0;
				tlist3.Size = 0;
				tlist4.Size = 0;
				tlist5.Size = 0;
				tlist6.Size = 0;
				val2.Y += _007B3119_007D;
			}
			val2.X += _007B3119_007D;
		}
		if (IsWorldmap)
		{
			PoolQuestPositionsIsles.Add(PositionsOfLivings);
			CutoffPositionsWithEntryZones(PoolQuestPositionsIsles, 10f, 0f);
		}
	}

	protected static void LoadIsleds(IsleInfoToken[] _007B3021_007D, WorldMapInfo _007B3022_007D, Tlist<IslePortInfoToken> _007B3023_007D, Tlist<IsleInstance> _007B3024_007D, Tlist<IslePortInfo> _007B3025_007D, Tlist<FactoryPlaceIsleInfo> _007B3026_007D, Tlist<IsleInstance> _007B3027_007D, Tlist<TraderInSeaPlaceInfo> _007B3028_007D, out Tlist<IsleInstance> _007B3029_007D)
	{
		//IL_03df: Unknown result type (might be due to invalid IL or missing references)
		_007B3029_007D = new Tlist<IsleInstance>();
		Tlist<IsleInstance> tlist = new Tlist<IsleInstance>();
		int num = 0;
		int num2 = 0;
		foreach (IsleInfoToken isleInfoToken in _007B3021_007D)
		{
			string[] array = isleInfoToken.Parameters.Split(",");
			string portName = string.Empty;
			string preset = string.Empty;
			string[] array2 = array;
			foreach (string text in array2)
			{
				if (text.Contains("port"))
				{
					portName = text;
				}
				if (text.StartsWith("preset__"))
				{
					string text2 = text;
					preset = text2.Substring(8, text2.Length - 8);
				}
			}
			string text3 = null;
			if (CalendarEvents.IsNewYear && isleInfoToken.Path.EndsWith("altar"))
			{
				text3 = isleInfoToken.Path.Replace("altar", "altar_newyear");
			}
			IsleModelInfo modelOrLoad = GameLoader.Current.GetModelOrLoad(text3 ?? isleInfoToken.Path);
			IsleInstance item = null;
			Tlist<FactoryType> _007B8437_007D;
			if (isleInfoToken.Path.Contains("editor"))
			{
				IsleInstance item2 = new IsleInstance(WorldObjectID.WSomeObject, isleInfoToken, _007B3022_007D, modelOrLoad, isleInfoToken.Terrain, isleInfoToken);
				_007B3027_007D.Add(in item2);
				item = item2;
			}
			else if (!string.IsNullOrEmpty(portName))
			{
				IslePortInfoToken islePortInfoToken = _007B3023_007D.FirstOrDefault((IslePortInfoToken _007B3141_007D) => _007B3141_007D.PortName == portName);
				if (islePortInfoToken != null)
				{
					IslePortInfo item3 = new IslePortInfo(isleInfoToken, islePortInfoToken, _007B3022_007D, modelOrLoad, num2++);
					item = item3;
					_007B3025_007D.Add(in item3);
				}
			}
			else if (FactoryPlaceIsleInfo.ParsePath(isleInfoToken.Path, out _007B8437_007D))
			{
				FactoryPlaceIsleInfo item4 = new FactoryPlaceIsleInfo(num++, isleInfoToken, modelOrLoad, _007B3022_007D, _007B8437_007D);
				_007B3026_007D.Add(in item4);
				item = item4;
			}
			else
			{
				item = new IsleInstance(WorldObjectID.WSomeObject, isleInfoToken, _007B3022_007D, modelOrLoad, isleInfoToken.Terrain, isleInfoToken);
				if (isleInfoToken.Path.Contains("ports\\pharos_"))
				{
					tlist.Add(in item);
				}
				else if (isleInfoToken.Path.Contains("trader_fishingvil"))
				{
					_007B3028_007D.Add(new TraderInSeaPlaceInfo(_007B3022_007D, null, item, TraderInSeaType.TraderInSea, null));
				}
				else if (isleInfoToken.Path.Contains("trader_village"))
				{
					_007B3028_007D.Add(new TraderInSeaPlaceInfo(_007B3022_007D, null, item, TraderInSeaType.SmallVilage, null));
				}
				else if (isleInfoToken.Path.Contains("trader_town"))
				{
					_007B3028_007D.Add(new TraderInSeaPlaceInfo(_007B3022_007D, null, item, TraderInSeaType.Town, null));
				}
				else if (isleInfoToken.Path.Contains("altar"))
				{
					_007B3028_007D.Add(new TraderInSeaPlaceInfo(_007B3022_007D, null, item, TraderInSeaType.Altar, null));
				}
				else if (isleInfoToken.Path.Contains("isles_y") || isleInfoToken.Path.Contains("mountain_") || isleInfoToken.Path.Contains("cont_") || isleInfoToken.Path.Contains("piratehouses") || isleInfoToken.Path.Contains("crag_whouses"))
				{
					_007B3029_007D.Add(in item);
				}
			}
			if (item != null)
			{
				item.Preset = preset;
				_007B3024_007D.Add(in item);
			}
		}
		if (_007B3025_007D.Size > 0)
		{
			foreach (IsleInstance item5 in (IEnumerable<IsleInstance>)tlist)
			{
				_007B3025_007D.FindNear(item5.GlobalPosition, (IslePortInfo _007B3122_007D) => _007B3122_007D.EntryPos).ReferencedPharosesTransformed.Add(new IslePortPharosInfo(item5));
			}
		}
		foreach (IslePortInfo item6 in (IEnumerable<IslePortInfo>)_007B3025_007D)
		{
			Tlist<(float, Tlist<Vector2>)> tlist2 = new Tlist<(float, Tlist<Vector2>)>();
			foreach (IslePortPharosInfo item7 in (IEnumerable<IslePortPharosInfo>)item6.ReferencedPharosesTransformed)
			{
				item7.Exits = new Tlist<ShipPositionInfo>(LoadRespawnConnections(item7.Isle));
			}
		}
	}

	[IteratorStateMachine(typeof(_003CLoadRespawnConnections_003Ed__44))]
	private static IEnumerable<ShipPositionInfo> LoadRespawnConnections(IsleInstance _007B3030_007D)
	{
		//yield-return decompiler failed: Method not found
		return new _003CLoadRespawnConnections_003Ed__44(-2)
		{
			_003C_003E3__isle = _007B3030_007D
		};
	}

	protected WorldMapInfo(int _007B3031_007D, string _007B3032_007D, WorldMapStyle _007B3033_007D, int _007B3034_007D, Vector2 _007B3035_007D, IsleInfoToken[] _007B3036_007D = null)
		: base(_007B3034_007D)
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		_007B3115_007D = _007B3032_007D;
		InitMaptype(_007B3031_007D);
		MapSize = _007B3035_007D;
		EndCoordinates = new Vector4((0f - MapSize.X) / 2f, (0f - MapSize.Y) / 2f, MapSize.X / 2f, MapSize.Y / 2f);
		Style = _007B3033_007D;
		Shallows = new WorldBitmap(1, Vector2.One);
		Regions = new WorldBitmap(1, Vector2.One);
		Ports = new Tlist<IslePortInfo>();
		Factories = new Tlist<FactoryPlaceIsleInfo>();
		Isles = new Tlist<IsleInstance>();
		Tlist<IsleInstance> _007B3027_007D = new Tlist<IsleInstance>();
		TradersInSea = new Tlist<TraderInSeaPlaceInfo>(20);
		if (_007B3036_007D != null)
		{
			LoadIsleds(_007B3036_007D, this, new Tlist<IslePortInfoToken>(), Isles, Ports, Factories, _007B3027_007D, TradersInSea, out Tlist<IsleInstance> _);
			Factories.Clear();
		}
		CollisableObjects = new Tlist<IsleInstance>();
		CollisableObjects.Add(from _007B3124_007D in Isles
			where !_007B3124_007D.ModelData.IsEmptyShapeModel
			select (_007B3124_007D));
		StartPorts = new Tlist<IslePortInfo>();
		RespawnInSeaPositions = new Tlist<IslePortPharosInfo>();
		TradersInSea.Clear();
		foreach (IsleInstance item in (IEnumerable<IsleInstance>)Isles)
		{
			if (item.ModelData.Path.Contains("trader_fishingvil") || item.ModelData.Path.Contains("trader_village"))
			{
				TradersInSea.Add(new TraderInSeaPlaceInfo(this, item.GlobalPosition, item, TraderInSeaType.TraderInSea, null));
			}
		}
		_007B3020_007D();
		Weather = (IsEnableArenaUi ? CommonGlobal.ArenaWeather : CommonGlobal.PassingMapsWeather);
		foreach (IslePortInfo item2 in (IEnumerable<IslePortInfo>)Ports)
		{
			item2.Initialize(this);
		}
	}

	protected void ClonePresets()
	{
		Sequence sequence = new Sequence(base.ID);
		foreach (IsleInstance item in (IEnumerable<IsleInstance>)Isles)
		{
			string name = item.ModelData.Model.ModelName;
			if (item.Preset.Length == 0)
			{
				IsleInstance[] array = Gameplay.WorldMap.Isles.Where((IsleInstance _007B3142_007D) => _007B3142_007D.ModelData.Model.ModelName.Contains(name) && Gameplay.GetNearWorldRegion(in _007B3142_007D.GlobalPosition).Feature == WorldMapRegionInfo.FeatureType.NorthRegion == (Style == WorldMapStyle.Snow)).ToArray();
				if (array.Length != 0)
				{
					IsleInstance isleInstance = sequence.Pick(array);
					item.Preset = isleInstance.Preset;
				}
			}
		}
	}

	public unsafe WorldMapInfo(MapInfoToken _007B3037_007D, int _007B3038_007D)
		: base(_007B3038_007D)
	{
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_021b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		//IL_0273: Unknown result type (might be due to invalid IL or missing references)
		//IL_0290: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0320: Unknown result type (might be due to invalid IL or missing references)
		//IL_0340: Unknown result type (might be due to invalid IL or missing references)
		//IL_035c: Unknown result type (might be due to invalid IL or missing references)
		//IL_037c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0397: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0509: Unknown result type (might be due to invalid IL or missing references)
		//IL_0557: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a28: Unknown result type (might be due to invalid IL or missing references)
		//IL_098e: Unknown result type (might be due to invalid IL or missing references)
		//IL_09c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_09fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c44: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c72: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ca3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0caa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ccd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cd4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d10: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d44: Unknown result type (might be due to invalid IL or missing references)
		//IL_10eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_10f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_111e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1123: Unknown result type (might be due to invalid IL or missing references)
		//IL_11a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_11ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_11ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_11af: Unknown result type (might be due to invalid IL or missing references)
		//IL_11b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_11b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_11bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_11c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_11cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_11d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_1167: Unknown result type (might be due to invalid IL or missing references)
		//IL_116c: Unknown result type (might be due to invalid IL or missing references)
		//IL_121e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1222: Unknown result type (might be due to invalid IL or missing references)
		if (_007B3038_007D > 255)
		{
			throw new InvalidOperationException();
		}
		InitMaptype((_007B3038_007D == 0) ? 5 : 0);
		if (IsWorldmap)
		{
			Gameplay.WorldMap = this;
		}
		MapSize = (Vector2)((_007B3038_007D == 0) ? new Vector2(1150f) : Gameplay.WorldMapSizeXY);
		EndCoordinates = new Vector4((0f - MapSize.X) / 2f, (0f - MapSize.Y) / 2f, MapSize.X / 2f, MapSize.Y / 2f);
		Style = (WorldMapStyle)_007B3037_007D.Style;
		_007B3115_007D = _007B3037_007D.MapName;
		Weather = (IsEducationMap ? CommonGlobal.EducationMapWeather : CommonGlobal.WorldWeather);
		if (_007B3038_007D == 1)
		{
			Texture2D val = GameLoader.Current.InternalContentManager.Load<Texture2D>("_lzcommon/WorldMapShallow");
			Shallows = new WorldBitmap(val.Width, MapSize);
			Shallows.ParseFrom2(val, (Color.Red, 2), (Color.Orange, 3), (Color.Yellow, 4), (Color.Lime, 5), (Color.Blue, 6), (Color.White, 10), (Color.Black, 0));
			RegionsTex = GameLoader.Current.InternalContentManager.Load<Texture2D>("_lzcommon/WorldMapRegions");
			RegionsTexBlurred = GameLoader.Current.InternalContentManager.Load<Texture2D>("_lzcommon/WorldMapRegionsBlurred");
			(Color, byte)[] array = new(Color, byte)[15]
			{
				(new Color(158, 255, 147), 0),
				(new Color(0, 255, 0), 1),
				(new Color(170, 173, 255), 2),
				(new Color(100, 140, 255), 3),
				(new Color(0, 255, 255), 4),
				(new Color(0, 0, 255), 5),
				(new Color(255, 255, 0), 6),
				(new Color(255, 180, 100), 7),
				(new Color(255, 127, 0), 8),
				(new Color(255, 163, 163), 9),
				(new Color(180, 110, 255), 10),
				(new Color(255, 0, 102), 11),
				(new Color(255, 110, 140), 12),
				(new Color(255, 0, 0), 13),
				(new Color(255, 0, 255), 14)
			};
			byte[] array2 = new byte[15]
			{
				0, 0, 1, 1, 2, 2, 2, 3, 3, 3,
				4, 4, 5, 5, 6
			};
			Regions = new WorldBitmap(RegionsTex.Width, MapSize);
			Regions.ParseFrom2(RegionsTex, array);
			ScoreDictionary<byte> scoreDictionary = Regions.MacthArea(array);
			Dictionary<byte, Vector2> dictionary = Regions.MacthCentersApproximate(array);
			foreach (KeyValuePair<byte, float> item4 in scoreDictionary.BaseDictionary.OrderBy((KeyValuePair<byte, float> _007B3125_007D) => _007B3125_007D.Key))
			{
				bool flag = item4.Key == 5 || item4.Key == 9 || item4.Key == 10 || item4.Key == 13;
				bool flag2 = item4.Key == 7 || item4.Key == 4 || item4.Key == 2 || item4.Key == 1;
				bool flag3 = item4.Key == 11 || item4.Key == 12;
				bool flag4 = item4.Key == 14;
				RegionsInfo.Add(new WorldMapRegionInfo(item4.Key, dictionary[item4.Key], scoreDictionary[item4.Key] / scoreDictionary[5], "region" + item4.Key, array2[item4.Key], array[item4.Key].Item1, flag3 ? EconomyRegion.Arab : (flag2 ? EconomyRegion.South : (flag ? EconomyRegion.North : (flag4 ? EconomyRegion.Center : EconomyRegion.None))), flag ? WorldMapRegionInfo.FeatureType.NorthRegion : WorldMapRegionInfo.FeatureType.None));
			}
		}
		else
		{
			Shallows = new WorldBitmap(1, Vector2.One);
			Regions = new WorldBitmap(1, Vector2.One);
		}
		Ports = new Tlist<IslePortInfo>();
		Factories = new Tlist<FactoryPlaceIsleInfo>();
		Isles = new Tlist<IsleInstance>();
		WorldForts = new Tlist<ShipPositionInfo>();
		TradersInSea = new Tlist<TraderInSeaPlaceInfo>(100);
		Tlist<IsleInstance> tlist = new Tlist<IsleInstance>();
		if (IsWorldmap)
		{
			_007B3037_007D.Ports = GameplayAssist.worldMapPorts.ToArray();
		}
		LoadIsleds(_007B3037_007D.Isles, this, new Tlist<IslePortInfoToken>(_007B3037_007D.Ports), Isles, Ports, Factories, tlist, TradersInSea, out Tlist<IsleInstance> _007B3029_007D);
		IslePortInfoToken[] ports = _007B3037_007D.Ports;
		foreach (IslePortInfoToken port in ports)
		{
			if (!Ports.Any((IslePortInfo _007B3143_007D) => _007B3143_007D.portNameKey == port.PortName))
			{
				GameLoader.Current.AddImportant("There's no connection for " + port.PortName);
			}
		}
		foreach (IslePortInfo item5 in (IEnumerable<IslePortInfo>)Ports)
		{
			item5.Initialize(this);
		}
		StartPorts = new Tlist<IslePortInfo>(Ports.Where((IslePortInfo _007B3126_007D) => _007B3126_007D.IsStartPort));
		if (StartPorts.Size == 0 && IsWorldmap)
		{
			GameLoader.Current.AddImportant("There are no start ports");
		}
		foreach (TraderInSeaPlaceInfo item in (IEnumerable<TraderInSeaPlaceInfo>)TradersInSea)
		{
			item.NearPort = Ports.MaxItem((IslePortInfo _007B3144_007D) => 0f - Vector2.DistanceSquared(_007B3144_007D.EntryPos, item.Position));
		}
		RespawnInSeaPositions = new Tlist<IslePortPharosInfo>(from _007B3128_007D in TradersInSea
			where _007B3128_007D.Type == TraderInSeaType.SmallVilage || _007B3128_007D.Type == TraderInSeaType.TraderInSea
			select new IslePortPharosInfo(_007B3128_007D.Position, _007B3128_007D.RespawnPositions));
		bool flag5 = true;
		foreach (IslePortInfo item6 in (IEnumerable<IslePortInfo>)Ports)
		{
			foreach (IslePortPharosInfo item7 in (IEnumerable<IslePortPharosInfo>)item6.ReferencedPharosesTransformed)
			{
				IslePortPharosInfo item2 = item7;
				RespawnInSeaPositions.Add(in item2);
			}
		}
		for (int num2 = 0; num2 < Isles.Size; num2++)
		{
			IsleInstance isleInstance = Isles.Array[num2];
			bool flag6 = isleInstance.ModelData.Path.Contains("t_cannonsstr") || isleInstance.ModelData.Path.Contains("t_mortar");
			bool flag7 = isleInstance.ModelData.Path.Contains("guildfort");
			bool flag8 = isleInstance.ModelData.Path.Contains("worldfort");
			if (flag6 || flag7)
			{
				IslePortInfo nearAvailablePort = GetNearAvailablePort(in isleInstance.GlobalPosition, (IslePortInfo _007B3129_007D) => _007B3129_007D.AllowCapture);
				Isles.FastRemoveAt(num2);
				num2--;
				int num3 = nearAvailablePort.PbSystem.Count + 100;
				if (flag6)
				{
					PbsBuildingPlaceInfo value = new PbsBuildingPlaceInfo(num3, nearAvailablePort, isleInstance.GlobalPosition, 0f, WorldObjectID.WGuildFortTower, -1);
					nearAvailablePort.PbSystem.Add(num3, value);
				}
				if (flag7)
				{
					PbsBuildingPlaceInfo value2 = new PbsBuildingPlaceInfo(num3, nearAvailablePort, isleInstance.GlobalPosition, isleInstance.GlobalTransform.Yaw, WorldObjectID.WGuildFort, isleInstance.ReplacebleXfxID);
					nearAvailablePort.PbSystem.Add(num3, value2);
					nearAvailablePort.FortPosition = isleInstance.GlobalPosition;
				}
			}
			if (flag8)
			{
				Isles.FastRemoveAt(num2);
				num2--;
				WorldForts.Add(new ShipPositionInfo(isleInstance.GlobalPosition, isleInstance.GlobalTransform.Yaw));
			}
		}
		if (IsWorldmap)
		{
			foreach (IslePortInfo item8 in (IEnumerable<IslePortInfo>)Ports)
			{
				if (item8.AllowCapture)
				{
					int num4 = item8.PbSystem.Count<KeyValuePair<int, PbsBuildingPlaceInfo>>((KeyValuePair<int, PbsBuildingPlaceInfo> _007B3130_007D) => _007B3130_007D.Value.GroupID == WorldObjectID.WGuildFort);
					if (num4 != 1)
					{
						GameLoader.Current.AddImportant(item8.PortName + " wrong num of forts: " + num4 + ", positions: " + item8.PbSystem.Where<KeyValuePair<int, PbsBuildingPlaceInfo>>((KeyValuePair<int, PbsBuildingPlaceInfo> _007B3131_007D) => _007B3131_007D.Value.GroupID == WorldObjectID.WGuildFort).Aggregate("", delegate(string _007B3132_007D, KeyValuePair<int, PbsBuildingPlaceInfo> _007B3133_007D)
						{
							//IL_000d: Unknown result type (might be due to invalid IL or missing references)
							//IL_0012: Unknown result type (might be due to invalid IL or missing references)
							Vector2 position = _007B3133_007D.Value.Position;
							return _007B3132_007D + ", " + ((object)(*(Vector2*)(&position))/*cast due to .constrained prefix*/).ToString();
						}));
					}
					else
					{
						int num5 = item8.PbSystem.Count<KeyValuePair<int, PbsBuildingPlaceInfo>>((KeyValuePair<int, PbsBuildingPlaceInfo> _007B3134_007D) => _007B3134_007D.Value.GroupID == WorldObjectID.WGuildFortTower);
					}
				}
				else if (item8.PbSystem.Count != 0)
				{
					GameLoader.Current.AddImportant(item8.PortName + " has unrequired PB elements");
				}
			}
		}
		foreach (IslePortInfo item9 in (IEnumerable<IslePortInfo>)Ports)
		{
			if (!item9.AllowCapture || item9.ReferencedPharosesTransformed.Size == 0 || IsEducationMap)
			{
				continue;
			}
			IsleInstance isleInstance2 = tlist.FindNear(item9.EntryPos, (IsleInstance _007B3135_007D) => (Vector2)((_007B3135_007D.ModelData.Binding == WorldBindingType.PbAttackerRespawn) ? _007B3135_007D.GlobalPosition : new Vector2(1000000f, 0f)));
			IsleInstance isleInstance3 = tlist.FindNear(item9.EntryPos, (IsleInstance _007B3136_007D) => (Vector2)((_007B3136_007D.ModelData.Binding == WorldBindingType.PbDefenderRespawn) ? _007B3136_007D.GlobalPosition : new Vector2(1000000f, 0f)));
			if (isleInstance2 != null && Vector2.Distance(isleInstance2.GlobalPosition, item9.EntryPos) > 1000f)
			{
				isleInstance2 = null;
			}
			if (isleInstance3 != null && Vector2.Distance(isleInstance3.GlobalPosition, item9.EntryPos) > 1000f)
			{
				isleInstance3 = null;
			}
			if (isleInstance3 != null && isleInstance2 != null)
			{
				IslePortPharosInfo islePortPharosInfo = item9.ReferencedPharosesTransformed.FindNear(isleInstance2.GlobalPosition, (IslePortPharosInfo _007B3137_007D) => _007B3137_007D.MapGlobalPosition);
				IslePortPharosInfo islePortPharosInfo2 = item9.ReferencedPharosesTransformed.FindNear(isleInstance3.GlobalPosition, (IslePortPharosInfo _007B3138_007D) => _007B3138_007D.MapGlobalPosition);
				item9.PbRespawn.Add(PbsBatlleSide.Attacker, new PbsAvanpostShortInfo(islePortPharosInfo.Exits, islePortPharosInfo.Isle, PbsBatlleSide.Attacker));
				item9.PbRespawn.Add(PbsBatlleSide.Defender, new PbsAvanpostShortInfo(islePortPharosInfo2.Exits, islePortPharosInfo2.Isle, PbsBatlleSide.Defender));
			}
			else
			{
				IslePortPharosInfo islePortPharosInfo3 = item9.ReferencedPharosesTransformed.Array[0];
				IslePortPharosInfo islePortPharosInfo4 = item9.ReferencedPharosesTransformed.Array[1];
				item9.PbRespawn.Add(PbsBatlleSide.Attacker, new PbsAvanpostShortInfo(islePortPharosInfo3.Exits, islePortPharosInfo3.Isle, PbsBatlleSide.Attacker));
				item9.PbRespawn.Add(PbsBatlleSide.Defender, new PbsAvanpostShortInfo(islePortPharosInfo4.Exits, islePortPharosInfo4.Isle, PbsBatlleSide.Defender));
				GameLoader.Current.AddImportant(item9.PortName + " hasn't PB avanposts");
			}
		}
		PositionsOfLivings = new Tlist<Vector2>();
		foreach (IsleInstance item10 in (IEnumerable<IsleInstance>)Isles)
		{
			if ((item10.ModelData.Path.Contains("dec_asia") || item10.ModelData.Path.Contains("dec_nord") || item10.ModelData.Path.Contains("dec_misc") || item10.ModelData.Path.Contains("dec_pirate") || item10.ModelData.Path.Contains("dec_spain") || item10.ModelData.Path.Contains("dec_tudor") || item10.ModelData.Path.Contains("dec_arab")) && Math.Abs(item10.GlobalTransform.Translation.Y) < 1f)
			{
				PositionsOfLivings.Add(in item10.GlobalPosition);
			}
		}
		PositionsOfLivings.Trim();
		CollisableObjects = new Tlist<IsleInstance>(Isles.Size);
		CollisableObjects.Add(from _007B3140_007D in Isles
			where !_007B3140_007D.ModelData.IsEmptyShapeModel
			select (_007B3140_007D));
		_007B3020_007D();
		PositionsForDropInIsle = new Tlist<Vector2>(100);
		PositionsForDropInIsleOutsideSeam = new Tlist<Vector2>();
		Tlist<Vector2> tlist2 = new Tlist<Vector2>();
		foreach (IsleInstance item11 in (IEnumerable<IsleInstance>)_007B3029_007D)
		{
			while (!item11.ModelData.IsFinalLoaded)
			{
				Thread.Sleep(10);
			}
			if (item11.TransformedShallowsPoints == null || item11.TransformedShallowsPoints.Size <= 1)
			{
				continue;
			}
			int num6 = 1 + (int)Math.Floor(item11.ModelGlobalBS.Radius / 80f);
			int num7 = num6 * 2;
			float minDistance = 25f + item11.ModelGlobalBS.Radius / 3f;
			tlist2.Clear();
			int num8 = 0;
			for (int num9 = 0; num9 < num7; num9++)
			{
				Vector2 item3 = item11.TransformedShallowsPoints.Array[0];
				float num10 = 0f;
				foreach (Vector2 item12 in (IEnumerable<Vector2>)item11.TransformedShallowsPoints)
				{
					Vector2 xx = item12;
					float num11 = ((Vector2)(ref xx)).LengthSquared();
					if (num11 >= num10 && (tlist2.Size == 0 || tlist2.All((Vector2 _007B3145_007D) => Vector2.DistanceSquared(xx, _007B3145_007D) > minDistance * minDistance)))
					{
						item3 = xx;
						num10 = num11;
					}
				}
				if (num10 == 0f)
				{
					break;
				}
				tlist2.Add(in item3);
				Vector2 val2 = item3;
				val2 += (val2 - item11.GlobalPosition).Normal() * 4f;
				bool flag9 = false;
				Tlist<IsleInstance> containedIsles = GetContainedIsles(in val2);
				foreach (IsleInstance item13 in (IEnumerable<IsleInstance>)containedIsles)
				{
					if (item13 == item11)
					{
						continue;
					}
					foreach (FenceSphere item14 in (IEnumerable<FenceSphere>)item13.TransformedFenceSpheres)
					{
						if (Vector2.DistanceSquared(val2, item14.C) < item14.Rpow2)
						{
							flag9 = true;
							break;
						}
					}
					if (!flag9)
					{
						continue;
					}
					break;
				}
				if (!flag9)
				{
					if (IsInsideMap(in val2))
					{
						PositionsForDropInIsle.Add(in val2);
					}
					else if (CheckPositionBorder(in val2, -1000f))
					{
						PositionsForDropInIsleOutsideSeam.Add(in val2);
					}
					num8++;
					if (num8 >= num6)
					{
						break;
					}
				}
			}
		}
		CutoffPositionsWithEntryZones(PositionsForDropInIsle, 200f, 0f);
		PositionsForDropInIsle.Trim();
		PositionsForDropInIsleOutsideSeam.Trim();
		foreach (IslePortInfo item15 in (IEnumerable<IslePortInfo>)Ports)
		{
			if ((item15.MustHavePharoses ? (item15.ReferencedPharosesTransformed.Size != 3) : ((byte)item15.ReferencedPharosesTransformed.Size != 0)) && !IsEducationMap)
			{
				GameLoader.Current.AddImportant(item15.PortName + " pharoses: " + item15.ReferencedPharosesTransformed.Size + Environment.NewLine);
			}
		}
		foreach (IslePortInfo item16 in (IEnumerable<IslePortInfo>)Ports)
		{
			item16.Initialize2(this);
		}
		if (IsEducationMap)
		{
			ClonePresets();
		}
	}

	private void CutoffPositionsWithEntryZones(Tlist<Vector2> _007B3039_007D, float _007B3040_007D, float _007B3041_007D)
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0275: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		foreach (IslePortInfo item in (IEnumerable<IslePortInfo>)Ports)
		{
			float num = (item.GlobalEntryRadius + _007B3040_007D) * (item.GlobalEntryRadius + _007B3040_007D);
			for (int i = 0; i < _007B3039_007D.Size; i++)
			{
				if (Vector2.DistanceSquared(_007B3039_007D.Array[i], item.EntryPos) < num)
				{
					_007B3039_007D.FastRemoveAt(i);
					i--;
				}
			}
			foreach (IslePortPharosInfo item2 in (IEnumerable<IslePortPharosInfo>)item.ReferencedPharosesTransformed)
			{
				for (int j = 0; j < _007B3039_007D.Size; j++)
				{
					if (Vector2.DistanceSquared(_007B3039_007D.Array[j], item2.MapGlobalPosition) < 14400f)
					{
						_007B3039_007D.FastRemoveAt(j);
						j--;
					}
				}
			}
			foreach (KeyValuePair<int, PbsBuildingPlaceInfo> item3 in item.PbSystem)
			{
				for (int k = 0; k < _007B3039_007D.Size; k++)
				{
					if (Vector2.DistanceSquared(_007B3039_007D.Array[k], item3.Value.Position) < item3.Value.MaximalRadiusP2)
					{
						_007B3039_007D.FastRemoveAt(k);
						k--;
					}
				}
			}
		}
		foreach (FactoryPlaceIsleInfo item4 in (IEnumerable<FactoryPlaceIsleInfo>)Factories)
		{
			float num2 = (80f + _007B3041_007D) * (80f + _007B3041_007D);
			for (int l = 0; l < _007B3039_007D.Size; l++)
			{
				if (Vector2.DistanceSquared(_007B3039_007D.Array[l], item4.GlobalPosition) < num2)
				{
					_007B3039_007D.FastRemoveAt(l);
					l--;
				}
			}
		}
		foreach (TraderInSeaPlaceInfo item5 in (IEnumerable<TraderInSeaPlaceInfo>)TradersInSea)
		{
			float num3 = (80f + _007B3041_007D) * (80f + _007B3041_007D);
			for (int m = 0; m < _007B3039_007D.Size; m++)
			{
				if (Vector2.DistanceSquared(_007B3039_007D.Array[m], item5.Position) < num3)
				{
					_007B3039_007D.FastRemoveAt(m);
					m--;
				}
			}
		}
	}

	public bool IsInsideMap(in Vector2 _007B3042_007D, bool _007B3043_007D = true)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		if (IsCircularShape && _007B3043_007D)
		{
			Vector2 val = _007B3042_007D;
			return ((Vector2)(ref val)).LengthSquared() < MapSize.X / 2f * (MapSize.X / 2f);
		}
		return _007B3042_007D.X > EndCoordinates.X && _007B3042_007D.Y > EndCoordinates.Y && _007B3042_007D.X < EndCoordinates.Z && _007B3042_007D.Y < EndCoordinates.W;
	}

	public bool CheckPositionBorder(in Vector2 _007B3044_007D, float _007B3045_007D, bool _007B3046_007D = true)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		if (IsCircularShape && _007B3046_007D)
		{
			Vector2 val = _007B3044_007D;
			return ((Vector2)(ref val)).LengthSquared() < (MapSize.X / 2f - _007B3045_007D) * (MapSize.X / 2f - _007B3045_007D);
		}
		return _007B3044_007D.X > EndCoordinates.X + _007B3045_007D && _007B3044_007D.Y > EndCoordinates.Y + _007B3045_007D && _007B3044_007D.X < EndCoordinates.Z - _007B3045_007D && _007B3044_007D.Y < EndCoordinates.W - _007B3045_007D;
	}

	public void ClampToMap(ref Vector2 _007B3047_007D, bool _007B3048_007D = true)
	{
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		if (IsCircularShape && _007B3048_007D)
		{
			float num = ((Vector2)(ref _007B3047_007D)).LengthSquared();
			if (num > MapSize.X * MapSize.X * 0.5f * 0.5f)
			{
				_007B3047_007D = Geometry.SubstructRotate(MathF.Atan2(_007B3047_007D.Y, _007B3047_007D.X), MapSize.X / 2f);
			}
		}
		else
		{
			_007B3047_007D.X = Math.Max(EndCoordinates.X, _007B3047_007D.X);
			_007B3047_007D.X = Math.Min(EndCoordinates.Z, _007B3047_007D.X);
			_007B3047_007D.Y = Math.Max(EndCoordinates.Y, _007B3047_007D.Y);
			_007B3047_007D.Y = Math.Min(EndCoordinates.W, _007B3047_007D.Y);
		}
	}

	public Vector2 ClampToMap(Vector2 _007B3049_007D, bool _007B3050_007D)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		ClampToMap(ref _007B3049_007D, _007B3050_007D);
		return _007B3049_007D;
	}

	public IslePortInfo GetNearPort(in Vector2 _007B3051_007D)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		if (Ports.Size == 0)
		{
			throw new InvalidOperationException();
		}
		return _007B3116_007D[new Index2D(_007B3051_007D, _007B3119_007D).Clamp(in _007B3117_007D, in _007B3118_007D)].NearPort;
	}

	public IslePortInfo? GetNearAquatoria(in Vector2 _007B3052_007D)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		IslePortInfo nearPort = Gameplay.WorldMap.GetNearPort(in _007B3052_007D);
		float portAquatoriaSize = Gameplay.PortAquatoriaSize;
		if (Vector2.DistanceSquared(nearPort.EntryPos, _007B3052_007D) > portAquatoriaSize * portAquatoriaSize)
		{
			return null;
		}
		return nearPort;
	}

	internal TraderInSeaPlaceInfo GetNearTraderInSea(in Vector2 _007B3053_007D)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		if (Ports.Size == 0)
		{
			throw new InvalidOperationException();
		}
		return _007B3116_007D[new Index2D(_007B3053_007D, _007B3119_007D).Clamp(in _007B3117_007D, in _007B3118_007D)].NearTraderInSea;
	}

	public FactoryPlaceIsleInfo GetNearFactory(Vector2 _007B3054_007D)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return Factories.MinBy((FactoryPlaceIsleInfo _007B3146_007D) => Vector2.DistanceSquared(_007B3146_007D.GlobalPosition, _007B3054_007D)) ?? throw new InvalidOperationException();
	}

	private WorldHashingSector _007B3055_007D(in Vector2 _007B3056_007D)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return _007B3116_007D[new Index2D(_007B3056_007D, _007B3119_007D).Clamp(in _007B3117_007D, in _007B3118_007D)];
	}

	public Tlist<IsleInstance> GetVisibleIsles(in Vector2 _007B3057_007D)
	{
		return _007B3055_007D(in _007B3057_007D).VisibleCollisableObjects;
	}

	public Tlist<IsleInstance> GetContainedIsles(in Vector2 _007B3058_007D)
	{
		return _007B3055_007D(in _007B3058_007D).ContainsCollisableObjects;
	}

	public IslePortInfo? FindNearPortBy(in Vector2 _007B3059_007D, Func<IslePortInfo, bool> _007B3060_007D)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		float num = float.MaxValue;
		IslePortInfo result = null;
		for (int i = 0; i < Ports.Size; i++)
		{
			IslePortInfo islePortInfo = Ports.Array[i];
			float num2 = Vector2.DistanceSquared(islePortInfo.EntryPos, _007B3059_007D);
			if (num2 < num && _007B3060_007D(islePortInfo))
			{
				num = num2;
				result = islePortInfo;
			}
		}
		return result;
	}

	public IslePortPharosInfo GetNearAvailableRespawnInSea(Vector2 _007B3061_007D, bool _007B3062_007D, PlayerAccount _007B3063_007D)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		float num = float.MaxValue;
		IslePortPharosInfo result = null;
		foreach (IslePortPharosInfo item in GetAvailableRespawnsInSea(_007B3061_007D, num, _007B3062_007D, _007B3063_007D))
		{
			float num2 = Vector2.DistanceSquared(item.MapGlobalPosition, _007B3061_007D);
			if (num2 < num)
			{
				num = num2;
				result = item;
			}
		}
		return result;
	}

	[IteratorStateMachine(typeof(_003CGetAvailableRespawnsInSea_003Ed__62))]
	public IEnumerable<IslePortPharosInfo> GetAvailableRespawnsInSea(Vector2 _007B3064_007D, float _007B3065_007D, bool _007B3066_007D, PlayerAccount _007B3067_007D)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//yield-return decompiler failed: Method not found
		return new _003CGetAvailableRespawnsInSea_003Ed__62(-2)
		{
			_003C_003E4__this = this,
			_003C_003E3__p = _007B3064_007D,
			_003C_003E3__maxDistance = _007B3065_007D,
			_003C_003E3__manyPvpShipsAroundPort = _007B3066_007D,
			_003C_003E3__account = _007B3067_007D
		};
	}

	public float GetDeepnessLevel(Vector2 _007B3068_007D)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		if (IsWorldmap)
		{
			Index2D index2D = new Index2D(_007B3068_007D, _007B3119_007D);
			Index2D index2D2 = new Index2D(index2D.X + 1, index2D.Y);
			Index2D index2D3 = new Index2D(index2D.X, index2D.Y + 1);
			Index2D index2D4 = new Index2D(index2D.X + 1, index2D.Y + 1);
			index2D = index2D.Clamp(in _007B3117_007D, in _007B3118_007D);
			index2D2 = index2D2.Clamp(in _007B3117_007D, in _007B3118_007D);
			index2D3 = index2D3.Clamp(in _007B3117_007D, in _007B3118_007D);
			index2D4 = index2D4.Clamp(in _007B3117_007D, in _007B3118_007D);
			float num = _007B3068_007D.X / _007B3119_007D - (float)index2D.X;
			float num2 = _007B3068_007D.Y / _007B3119_007D - (float)index2D.Y;
			float waterDeepnessLevel = _007B3116_007D[index2D].WaterDeepnessLevel;
			float waterDeepnessLevel2 = _007B3116_007D[index2D2].WaterDeepnessLevel;
			float waterDeepnessLevel3 = _007B3116_007D[index2D3].WaterDeepnessLevel;
			float waterDeepnessLevel4 = _007B3116_007D[index2D4].WaterDeepnessLevel;
			return MathHelper.Lerp(MathHelper.Lerp(waterDeepnessLevel, waterDeepnessLevel2, num), MathHelper.Lerp(waterDeepnessLevel3, waterDeepnessLevel4, num), num2);
		}
		return 0.5f;
	}

	private static float MatchDeepnessLevel(ref Vector2 _007B3069_007D, Tlist<FenceSphereStruct> _007B3070_007D, Tlist<FenceSphereStruct> _007B3071_007D)
	{
		float num = 1f;
		float num2 = default(float);
		for (int i = 0; i < _007B3070_007D.Size; i++)
		{
			Vector2.Distance(ref _007B3069_007D, ref _007B3070_007D.Array[i].C, ref num2);
			num = Math.Min(num, (num2 - _007B3070_007D.Array[i].R) / 1700f);
		}
		float num3 = default(float);
		for (int j = 0; j < _007B3071_007D.Size; j++)
		{
			Vector2.Distance(ref _007B3069_007D, ref _007B3071_007D.Array[j].C, ref num3);
			num = Math.Min(num, 0.5f + 0.5f * (num3 - _007B3071_007D.Array[j].R) / 500f);
		}
		return Math.Max(0f, num);
	}

	public float GetRiversLevel(Vector2 _007B3072_007D)
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		float num = 0f;
		if (IsWorldmap)
		{
			Tlist<FenceSphereStruct> waterRiverAnchors = _007B3116_007D[new Index2D(_007B3072_007D, _007B3119_007D).Clamp(in _007B3117_007D, in _007B3118_007D)].WaterRiverAnchors;
			float num2 = default(float);
			for (int i = 0; i < waterRiverAnchors.Size; i++)
			{
				Vector2.Distance(ref _007B3072_007D, ref waterRiverAnchors.Array[i].C, ref num2);
				num = Math.Max(num, (waterRiverAnchors.Array[i].R + 10f - num2) / 10f);
			}
			return num;
		}
		return num;
	}

	private IslePortInfo GetNearAvailablePort(in Vector2 _007B3073_007D, Func<IslePortInfo, bool> _007B3074_007D)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		if (Ports.Size == 0)
		{
			throw new InvalidOperationException();
		}
		IslePortInfo result = null;
		float num = float.MaxValue;
		float num2 = 0f;
		foreach (IslePortInfo item in (IEnumerable<IslePortInfo>)Ports)
		{
			num2 = Vector2.DistanceSquared(item.EntryPos, _007B3073_007D);
			if (num2 < num && _007B3074_007D(item))
			{
				num = num2;
				result = item;
			}
		}
		return result;
	}

	internal WorldMapRegionInfo GetNearWorldRegion(in Vector2 _007B3075_007D)
	{
		if (RegionsInfo.Size == 0)
		{
			if (Regions == null)
			{
				throw new InvalidOperationException("Regions wasn't initialized");
			}
			return WorldMapRegionInfo.IdentityRegion;
		}
		return RegionsInfo.Array[Regions.Get(in _007B3075_007D)];
	}

	public bool CheckPosition(Vector2 _007B3076_007D, bool _007B3077_007D = true, bool _007B3078_007D = false, Func<IsleInstance, bool> _007B3079_007D = null)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		if (!IsInsideMap(in _007B3076_007D, _007B3077_007D) || !CheckPositionWithoutBorder(_007B3076_007D, 0f, _007B3078_007D, _007B3079_007D))
		{
			return false;
		}
		return true;
	}

	public bool CheckPosition(Vector2 _007B3080_007D, float _007B3081_007D, bool _007B3082_007D = true, bool _007B3083_007D = false)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		if (!IsInsideMap(in _007B3080_007D, _007B3082_007D) || !CheckPositionWithoutBorder(_007B3080_007D, _007B3081_007D, _007B3083_007D))
		{
			return false;
		}
		return true;
	}

	internal bool CheckPositionWithoutBorder(Vector2 _007B3084_007D, float _007B3085_007D, bool _007B3086_007D, Func<IsleInstance, bool> _007B3087_007D = null)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		WorldHashingSector worldHashingSector = _007B3055_007D(in _007B3084_007D);
		float num = 0f;
		if (_007B3086_007D && IsWorldmap)
		{
			IslePortInfo nearPort = worldHashingSector.NearPort;
			if (VectorExternsionsDistanceTest.DTest2(nearPort.EntryPos, _007B3084_007D, nearPort.GlobalEntryRadius))
			{
				return true;
			}
			if (worldHashingSector.ContainsCollisableObjects.Any((IsleInstance _007B3147_007D) => _007B3147_007D is FactoryPlaceIsleInfo factoryPlaceIsleInfo && VectorExternsionsDistanceTest.DTest2(factoryPlaceIsleInfo.InteropZone.C, _007B3084_007D, factoryPlaceIsleInfo.InteropZone.R)))
			{
				return true;
			}
		}
		for (int num2 = 0; num2 < worldHashingSector.VisibleCollisableObjects.Size; num2++)
		{
			IsleInstance isleInstance = worldHashingSector.VisibleCollisableObjects.Array[num2];
			for (int num3 = 0; num3 < isleInstance.TransformedFenceSpheres.Size; num3++)
			{
				if (_007B3087_007D == null || !_007B3087_007D(isleInstance))
				{
					FenceSphere fenceSphere = isleInstance.TransformedFenceSpheres.Array[num3];
					Vector2.DistanceSquared(ref _007B3084_007D, ref fenceSphere.C, ref num);
					if (num < (fenceSphere.R + _007B3085_007D) * (fenceSphere.R + _007B3085_007D))
					{
						return false;
					}
				}
			}
		}
		for (int num4 = 0; num4 < worldHashingSector.DynamicBuilding.Size; num4++)
		{
			PbsBuildingPlaceInfo pbsBuildingPlaceInfo = worldHashingSector.DynamicBuilding.Array[num4];
			Vector2.DistanceSquared(ref _007B3084_007D, ref pbsBuildingPlaceInfo.Position, ref num);
			if (num < pbsBuildingPlaceInfo.MaximalRadiusP2)
			{
				return false;
			}
		}
		if (worldHashingSector.NearPort != null)
		{
			Vector2 entryPos = worldHashingSector.NearPort.EntryPos;
			Vector2.DistanceSquared(ref _007B3084_007D, ref entryPos, ref num);
			if (num < worldHashingSector.NearPort.GlobalEntryRadius * worldHashingSector.NearPort.GlobalEntryRadius)
			{
				return false;
			}
		}
		if (Shallows.Get(in _007B3084_007D) == 10)
		{
			return false;
		}
		return true;
	}

	public float OutsideSeamLevel(in Vector2 _007B3088_007D)
	{
		if (!IsWorldmap)
		{
			return 0f;
		}
		float val = Math.Max((Math.Abs(_007B3088_007D.X) - 7073.2417f) / 3697.001f * 2f, (Math.Abs(_007B3088_007D.Y) - 8645.06f) / 4536f * 2f);
		return Math.Max(0f, Math.Min(1f, val));
	}

	public float OutsideSeamLevelAvailable(in Vector2 _007B3089_007D)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		if (!IsWorldmap)
		{
			return 0f;
		}
		float val = Math.Max((Math.Abs(_007B3089_007D.X) - 7073.2417f) / (Gameplay.WorldMaxAvailableSizeXY.X - 14146.483f) * 2f, (Math.Abs(_007B3089_007D.Y) - 8645.06f) / (Gameplay.WorldMaxAvailableSizeXY.Y - 17290.12f) * 2f);
		return Math.Max(0f, Math.Min(1f, val));
	}

	public float OutsideSeamLevelDistance(in Vector2 _007B3090_007D)
	{
		if (!IsWorldmap)
		{
			return 0f;
		}
		float val = Math.Max(Math.Abs(_007B3090_007D.X) - 7073.2417f, Math.Abs(_007B3090_007D.Y) - 8645.06f);
		return Math.Max(0f, val);
	}

	public float OutsideSeamLevelWithStep(in Vector2 _007B3091_007D)
	{
		if (!IsWorldmap)
		{
			return 0f;
		}
		float num = Math.Max((Math.Abs(_007B3091_007D.X) - 7073.2417f) / 3697.001f * 2f, (Math.Abs(_007B3091_007D.Y) - 8645.06f) / 4536f * 2f);
		return Math.Max(0f, Math.Min(1f, (num - 0.25f) / 0.5f));
	}

	public float OpenWorldWinterFactor(in Vector2 _007B3092_007D)
	{
		if (!IsWorldmap)
		{
			return (Style == WorldMapStyle.Snow) ? 1 : 0;
		}
		return Geometry.Saturate((_007B3092_007D.X - 3112.2263f) / 707.32416f);
	}

	public Vector2 RandomPosition(Sequence _007B3093_007D = null)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		return RandomPosition(new Vector2(EndCoordinates.X, EndCoordinates.Y), new Vector2(EndCoordinates.Z, EndCoordinates.W), 40f, _007B3093_007D);
	}

	public Vector2 RandomPositionInRegion(WorldMapRegionInfo _007B3094_007D, float _007B3095_007D = 40f)
	{
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		Vector2 _007B3075_007D = default(Vector2);
		do
		{
			((Vector2)(ref _007B3075_007D))._002Ector(Rand.Range(EndCoordinates.X, EndCoordinates.Z), Rand.Range(EndCoordinates.Y, EndCoordinates.W));
		}
		while (GetNearWorldRegion(in _007B3075_007D) != _007B3094_007D || !CheckPositionWithoutBorder(_007B3075_007D, _007B3095_007D, _007B3086_007D: false));
		return _007B3075_007D;
	}

	public Vector2 RandomPositionOutsideSeam(float _007B3096_007D = 100f)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		if (_007B3096_007D > 500f)
		{
			throw new ArgumentException("Wring fenceExtraRadius in RandomPositionOutsideSeam");
		}
		Vector2 val = -Gameplay.WorldMaxAvailableSizeXY / 2f;
		Vector2 val2 = Gameplay.WorldMaxAvailableSizeXY / 2f;
		Vector2 _007B3044_007D = default(Vector2);
		do
		{
			((Vector2)(ref _007B3044_007D))._002Ector(Rand.Range(val.X, val2.X), Rand.Range(val.Y, val2.Y));
		}
		while (CheckPositionBorder(in _007B3044_007D, 0f) || !CheckPositionWithoutBorder(_007B3044_007D, _007B3096_007D, _007B3086_007D: false));
		return _007B3044_007D;
	}

	public Vector2 RandomPosition(in Vector2 _007B3097_007D, in Vector2 _007B3098_007D, float _007B3099_007D = 40f, Sequence _007B3100_007D = null)
	{
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		_007B3100_007D = _007B3100_007D ?? Rand.Instance;
		Vector2 _007B3042_007D = default(Vector2);
		for (int i = 0; i < 10000; i++)
		{
			((Vector2)(ref _007B3042_007D))._002Ector(_007B3100_007D.Range(_007B3097_007D.X, _007B3098_007D.X), _007B3100_007D.Range(_007B3097_007D.Y, _007B3098_007D.Y));
			if ((!IsCircularShape || IsInsideMap(in _007B3042_007D)) && CheckPositionWithoutBorder(_007B3042_007D, _007B3099_007D, _007B3086_007D: false))
			{
				return _007B3042_007D;
			}
		}
		return new Vector2(_007B3100_007D.Range(_007B3097_007D.X, _007B3098_007D.X), _007B3100_007D.Range(_007B3097_007D.Y, _007B3098_007D.Y));
	}

	public Vector2 RandomPosition(in Vector3 _007B3101_007D, float _007B3102_007D = 40f, float _007B3103_007D = 0f, Sequence _007B3104_007D = null)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		_007B3104_007D = _007B3104_007D ?? Rand.Instance;
		for (int i = 0; i < 10000; i++)
		{
			Vector2 val = _007B3101_007D.XY();
			Vector2 val2 = _007B3104_007D.DiskVector2() * _007B3101_007D.Z + val;
			if (CheckPosition(val2, _007B3102_007D) && Vector2.DistanceSquared(val, val2) > _007B3103_007D)
			{
				return val2;
			}
		}
		return _007B3104_007D.DiskVector2() * _007B3101_007D.Z + _007B3101_007D.XY();
	}

	public Vector2 RandomPositionFarOffAnything(float _007B3105_007D, float? _007B3106_007D = null)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		return RandomPositionFarOffAnything(Rand.Instance, _007B3105_007D, _007B3106_007D);
	}

	public Vector2 RandomPositionFarOffAnything(Sequence _007B3107_007D, float _007B3108_007D, float? _007B3109_007D = null)
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		if (_007B3109_007D.HasValue && _007B3109_007D.Value - _007B3108_007D < 100f)
		{
			throw new ArgumentException("RandomPositionFarOff has wrong arguments - too small difference");
		}
		if (CollisableObjects.Size == 0)
		{
			return RandomPosition(_007B3107_007D);
		}
		Vector2 val = default(Vector2);
		for (int i = 0; i < 10000; i++)
		{
			((Vector2)(ref val))._002Ector(_007B3107_007D.Range(EndCoordinates.X, EndCoordinates.Z), _007B3107_007D.Range(EndCoordinates.Y, EndCoordinates.W));
			if (CheckPositionWithoutBorder(val, _007B3108_007D, _007B3086_007D: false) && (!_007B3109_007D.HasValue || !CheckPositionWithoutBorder(val, _007B3109_007D.Value, _007B3086_007D: false)))
			{
				return val;
			}
		}
		return RandomPosition(_007B3107_007D);
	}

	public Vector2 RandomPositionFarOffPorts(float _007B3110_007D)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		if (_007B3110_007D > 3000f)
		{
			throw new ArgumentException("RandomPositionFarOffPorts has wrong argument - too big");
		}
		if (Ports.Size == 0)
		{
			return RandomPosition();
		}
		_007B3110_007D *= _007B3110_007D;
		Vector2 _007B3051_007D = default(Vector2);
		do
		{
			((Vector2)(ref _007B3051_007D))._002Ector(Rand.Range(EndCoordinates.X, EndCoordinates.Z), Rand.Range(EndCoordinates.Y, EndCoordinates.W));
		}
		while (!(Vector2.DistanceSquared(GetNearPort(in _007B3051_007D).EntryPos, _007B3051_007D) > _007B3110_007D) || !CheckPositionWithoutBorder(_007B3051_007D, 60f, _007B3086_007D: false));
		return _007B3051_007D;
	}

	public Vector2? NextRandomPosition(Vector2 _007B3111_007D, float _007B3112_007D, Vector2? _007B3113_007D = null, float _007B3114_007D = 40f)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		int num = 50;
		int num2 = 100;
		Vector2 _007B3044_007D;
		while (true)
		{
			if (num2-- == 0)
			{
				return null;
			}
			Vector2 val = Rand.NextNormal() * _007B3112_007D;
			_007B3044_007D = _007B3111_007D + val;
			if ((_007B3113_007D.HasValue && Vector2.Dot(val.Normal(), _007B3113_007D.Value) < 0f) || !CheckPositionBorder(in _007B3044_007D, _007B3114_007D))
			{
				continue;
			}
			float num3 = ((Vector2)(ref val)).Length();
			bool flag = false;
			for (int i = 0; (float)i < num3; i += num)
			{
				Vector2 _007B3084_007D = Vector2.Lerp(_007B3044_007D, _007B3111_007D, (float)i / num3);
				if (!CheckPositionWithoutBorder(_007B3084_007D, _007B3114_007D, _007B3086_007D: false))
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				break;
			}
		}
		return _007B3044_007D;
	}
}
