using System;
using System.Collections.Generic;
using Common.Data;
using Common.Game;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using TheraEngine;
using TheraEngine.Core;

namespace Common.Resources;

public class CannonBallInfo : XmlAsset<CannonBallInfoToken>, IStorageAsset
{
	internal string nameKey;

	internal string desc1Key;

	public readonly CannonAmmoType AmmoType;

	public readonly float Penetration;

	public readonly float DamageFactor;

	public readonly float DamageToSailes;

	public readonly float DamageToCrew;

	public readonly float MortarBallCommonDamageToSailes;

	public readonly float MortarBallCommonCrewDamage;

	public readonly float CurveMultiplier;

	public readonly float MinDamageThroughAnyHitbox;

	public readonly float DistanceFactor;

	public readonly float ReloadFactor;

	public readonly float Speed;

	public readonly RTI ShopCostGold;

	public readonly GSI ShopCostItems;

	public readonly RTI CraftOrShopPack;

	public readonly float MassKg;

	public readonly float CollisionRadius;

	public readonly Texture2D IconTexture;

	public readonly Texture2D IconTextureCircular;

	public readonly bool IsRare;

	public readonly Dictionary<CannonLocation, Texture2D> IconTextureShards4;

	public readonly Dictionary<CannonLocation, Texture2D> IconTextureShards2;

	private bool[] _007B2231_007D;

	public bool this[CannonBallInfoEffects _007B2222_007D] => _007B2231_007D[(int)_007B2222_007D];

	public string Name => Local.Current(nameKey);

	public string Description => Local.Current(desc1Key);

	public int CountParts => (base.ID == 16) ? 6 : ((base.ID != 14) ? 1 : 2);

	public bool IsBoardingHook => base.ID == 17;

	public bool FalkonetGoesAbove => base.ID == 14;

	public bool Infinity => base.ID == 13;

	float IStorageAsset.getStorageMass => MassKg;

	string IStorageAsset.getName => Name;

	string IStorageAsset.getDescription => Description;

	Texture2D IStorageAsset.getIconTexture => IconTexture;

	StorageAssetEnum IStorageAsset.getType => StorageAssetEnum.Ammo;

	public CannonBallInfo(ContentManager _007B2223_007D, CannonBallInfoToken _007B2224_007D, int _007B2225_007D, bool _007B2226_007D)
		: base(_007B2225_007D)
	{
		//IL_0313: Unknown result type (might be due to invalid IL or missing references)
		//IL_0322: Unknown result type (might be due to invalid IL or missing references)
		//IL_034a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0359: Unknown result type (might be due to invalid IL or missing references)
		//IL_0381: Unknown result type (might be due to invalid IL or missing references)
		//IL_0390: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0426: Unknown result type (might be due to invalid IL or missing references)
		//IL_0435: Unknown result type (might be due to invalid IL or missing references)
		_007B2231_007D = new bool[10];
		if (!string.IsNullOrEmpty(_007B2224_007D.Effects))
		{
			string[] array = _007B2224_007D.Effects.Split(' ');
			string[] array2 = array;
			foreach (string value in array2)
			{
				object obj = Enum.Parse(typeof(CannonBallInfoEffects), value);
				_007B2231_007D[(int)obj] = true;
			}
		}
		nameKey = ((_007B2224_007D.ID == "removed") ? _007B2224_007D.ID : (_007B2224_007D.ID + "_name"));
		desc1Key = ((_007B2224_007D.ID == "removed") ? _007B2224_007D.ID : (_007B2224_007D.ID + "_desc1"));
		string name = Name;
		string description = Description;
		Speed = _007B2224_007D.Speed;
		Penetration = _007B2224_007D.Penetration;
		DamageFactor = _007B2224_007D.DamageFactor;
		DamageToSailes = _007B2224_007D.DamageToSailes;
		MortarBallCommonDamageToSailes = _007B2224_007D.DamageToSailes / 120f;
		MortarBallCommonCrewDamage = _007B2224_007D.CrewDamage / 100f;
		DamageToCrew = _007B2224_007D.CrewDamage;
		CurveMultiplier = _007B2224_007D.CurveMultiplier;
		ShopCostGold = _007B2224_007D.SingleCost;
		ShopCostItems = new GSI();
		if (_007B2224_007D.SingleCost < 0f)
		{
			ShopCostItems.AddOrRemove(37, -(int)_007B2224_007D.SingleCost);
			ShopCostGold = 0;
		}
		CraftOrShopPack = ((_007B2224_007D.SingleCost < 0f) ? 1 : ((!(_007B2224_007D.SingleCost < 1f)) ? 1 : ((int)(1.0 / (double)_007B2224_007D.SingleCost))));
		MassKg = _007B2224_007D.MassKg;
		CollisionRadius = _007B2224_007D.Radius;
		IsRare = _007B2224_007D.IsRare;
		DistanceFactor = _007B2224_007D.DistanceFactor;
		ReloadFactor = _007B2224_007D.ReloadFactor;
		MinDamageThroughAnyHitbox = _007B2224_007D.MinDamageThroughAnyHitbox;
		if (!_007B2226_007D)
		{
			IconTexture = _007B2223_007D.Load<Texture2D>("_lzcommon\\Items\\CannonBalls\\" + _007B2224_007D.IconTexture);
			IconTextureCircular = _007B2223_007D.Load<Texture2D>(string.Concat("_lzcommon\\Items\\CannonBalls\\", _007B2224_007D.IconTexture + "_cir"));
		}
		AmmoType = ((base.ID == 6 || base.ID == 8 || base.ID == 11 || base.ID == 19) ? CannonAmmoType.MortarBall : ((base.ID >= 13 && base.ID != 21) ? CannonAmmoType.FalkonetBall : CannonAmmoType.CannonBall));
		IconTextureShards4 = new Dictionary<CannonLocation, Texture2D>(10);
		IconTextureShards2 = new Dictionary<CannonLocation, Texture2D>(10);
		if (AmmoType != CannonAmmoType.FalkonetBall && !CommonGlobal.IsServer)
		{
			IconTextureShards4.Add(CannonLocation.InBack, _007B2227_007D(IconTextureCircular, new Vector2(1f, 1f), new Vector2(-1f, 1f)));
			IconTextureShards4.Add(CannonLocation.LeftSide, _007B2227_007D(IconTextureCircular, new Vector2(1f, -1f), new Vector2(1f, 1f)));
			IconTextureShards4.Add(CannonLocation.InFront, _007B2227_007D(IconTextureCircular, new Vector2(-1f, -1f), new Vector2(1f, -1f)));
			IconTextureShards4.Add(CannonLocation.RightSide, _007B2227_007D(IconTextureCircular, new Vector2(-1f, 1f), new Vector2(-1f, -1f)));
			IconTextureShards2.Add(CannonLocation.RightSide, _007B2227_007D(IconTextureCircular, new Vector2(-1f, 0f), new Vector2(-1f, 0f)));
			IconTextureShards2.Add(CannonLocation.LeftSide, _007B2227_007D(IconTextureCircular, new Vector2(1f, 0f), new Vector2(1f, 0f)));
		}
	}

	private Texture2D _007B2227_007D(Texture2D _007B2228_007D, Vector2 _007B2229_007D, Vector2 _007B2230_007D)
	{
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Expected O, but got Unknown
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		Color[] array = (Color[])(object)new Color[_007B2228_007D.Width * _007B2228_007D.Height];
		_007B2228_007D.GetData<Color>(array);
		for (int i = 0; i < _007B2228_007D.Width; i++)
		{
			for (int j = 0; j < _007B2228_007D.Height; j++)
			{
				Vector2 val = ExtensionMethods.Normal(new Vector2((float)(j - _007B2228_007D.Width / 2), (float)(i - _007B2228_007D.Height / 2)));
				if (Vector2.Dot(_007B2229_007D, val) < 0f || Vector2.Dot(_007B2230_007D, val) < 0f)
				{
					array[i * _007B2228_007D.Width + j] = default(Color);
				}
			}
		}
		Texture2D val2 = new Texture2D(Engine.GS.graphicsDevice, _007B2228_007D.Width, _007B2228_007D.Height, false, (SurfaceFormat)0);
		val2.SetData<Color>(array);
		return val2;
	}
}
