using System;
using TheraEngine;
using TheraEngine.Components.Architecture;
using TheraEngine.Scene;

namespace UWPhysics.SimulationEntities;

public class GravityOnlyEntity : IUpdateableObject
{
	public readonly ModelTransformedScene SceneObject;

	private float _007B9_007D;

	public GravityOnlyEntity(ModelTransformedScene _007B7_007D)
	{
		if (_007B7_007D == null)
		{
			throw new ArgumentNullException();
		}
		SceneObject = _007B7_007D;
	}

	public void Update(ref FrameTime _007B8_007D)
	{
		float num = PhysicMaterial.Wood.Dencity * (4.1887903f * MathF.Pow(SceneObject.SingleSize, 3f)) * 0.75f;
		float num2 = (num * 9.81f - 0.57f * SceneObject.SingleSize * SceneObject.SingleSize) / num;
		_007B9_007D += num2 * _007B8_007D.secElapsed;
		SceneObject.Transform.Translation.Y -= _007B9_007D * _007B8_007D.secElapsed + num2 * _007B8_007D.secElapsed * _007B8_007D.secElapsed * 0.5f;
	}

	public void Stop()
	{
		_007B9_007D = 0f;
	}
}
