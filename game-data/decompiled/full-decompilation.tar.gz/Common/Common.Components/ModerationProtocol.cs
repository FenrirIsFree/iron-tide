using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.Account;
using Common.Packets;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;
using World_Of_Sea_Battle.Constants;

namespace Common.Components;

public class ModerationProtocol
{
	public struct ApplySanction : IMPSerializable
	{
		public SanctionType Sanction;

		public TimeSpan Time;

		public uint Sid;

		public string Message;

		public bool WriteMessage;

		public ApplySanction(SanctionType _007B10588_007D, TimeSpan _007B10589_007D, uint _007B10590_007D, string _007B10591_007D, bool _007B10592_007D = false)
		{
			Sanction = _007B10588_007D;
			Time = _007B10589_007D;
			Sid = _007B10590_007D;
			Message = _007B10591_007D;
			WriteMessage = _007B10592_007D;
		}

		public void Boxing(WriterExtern _007B10593_007D)
		{
			_007B10593_007D.WriteEnum((object)Sanction);
			_007B10593_007D.WriteStruct<TimeSpan>(Time);
			_007B10593_007D.WriteStruct<uint>(Sid);
			_007B10593_007D.Write(Message, (Encoding)null);
			_007B10593_007D.Write(WriteMessage);
		}

		public void Unboxing(WriterExtern _007B10594_007D)
		{
			_007B10594_007D.ReadEnum<SanctionType>(ref Sanction);
			_007B10594_007D.ReadStruct<TimeSpan>(ref Time);
			_007B10594_007D.ReadStruct<uint>(ref Sid);
			_007B10594_007D.ReadString(ref Message, (Encoding)null);
			_007B10594_007D.ReadBoolean(ref WriteMessage);
		}
	}

	public struct LoginMessage : IMPSerializable
	{
		public string ID;

		public string Password;

		public LoginMessage(string _007B10597_007D, string _007B10598_007D)
		{
			ID = _007B10597_007D;
			Password = _007B10598_007D;
		}

		public void Boxing(WriterExtern _007B10599_007D)
		{
			_007B10599_007D.Write(ID, (Encoding)null);
			_007B10599_007D.Write(Password, (Encoding)null);
		}

		public void Unboxing(WriterExtern _007B10600_007D)
		{
			_007B10600_007D.ReadString(ref ID, (Encoding)null);
			_007B10600_007D.ReadString(ref Password, (Encoding)null);
		}
	}

	public struct FindPlayer : IMPSerializable
	{
		public uint SID;

		public string Nickname;

		public FindPlayer(uint _007B10603_007D, string _007B10604_007D)
		{
			SID = _007B10603_007D;
			Nickname = _007B10604_007D;
		}

		public void Boxing(WriterExtern _007B10605_007D)
		{
			_007B10605_007D.WriteStruct<uint>(SID);
			_007B10605_007D.Write(Nickname, (Encoding)null);
		}

		public void Unboxing(WriterExtern _007B10606_007D)
		{
			_007B10606_007D.ReadStruct<uint>(ref SID);
			_007B10606_007D.ReadString(ref Nickname, (Encoding)null);
		}
	}

	public struct LoginResultMessage : IMPSerializable
	{
		public bool IsSuccess;

		public bool IsHelper;

		public LoginResultMessage(bool _007B10609_007D, bool _007B10610_007D)
		{
			IsSuccess = _007B10609_007D;
			IsHelper = _007B10610_007D;
		}

		public void Boxing(WriterExtern _007B10611_007D)
		{
			_007B10611_007D.Write(IsSuccess);
			_007B10611_007D.Write(IsHelper);
		}

		public void Unboxing(WriterExtern _007B10612_007D)
		{
			_007B10612_007D.ReadBoolean(ref IsSuccess);
			_007B10612_007D.ReadBoolean(ref IsHelper);
		}
	}

	public struct NewMessageAdded : IMPSerializable
	{
		public OnChatMessageEvent Message;

		public DateTime Time;

		public NewMessageAdded(OnChatMessageEvent _007B10615_007D, DateTime _007B10616_007D)
		{
			Message = _007B10615_007D;
			Time = _007B10616_007D;
		}

		public void Boxing(WriterExtern _007B10617_007D)
		{
			Message.Boxing(_007B10617_007D);
			_007B10617_007D.WriteStruct<DateTime>(Time);
		}

		public void Unboxing(WriterExtern _007B10618_007D)
		{
			Message.Unboxing(_007B10618_007D);
			_007B10618_007D.ReadStruct<DateTime>(ref Time);
		}
	}

	public struct MessagesHistory : IMPSerializable
	{
		public NewMessageAdded[] History;

		public MessagesHistory(NewMessageAdded[] _007B10620_007D)
		{
			History = _007B10620_007D;
		}

		public void Boxing(WriterExtern _007B10621_007D)
		{
			_007B10621_007D.WriteStruct<int>(History.Length);
			for (int i = 0; i < History.Length; i++)
			{
				History[i].Boxing(_007B10621_007D);
			}
		}

		public void Unboxing(WriterExtern _007B10622_007D)
		{
			int num = default(int);
			_007B10622_007D.ReadStruct<int>(ref num);
			History = new NewMessageAdded[num];
			for (int i = 0; i < num; i++)
			{
				History[i] = default(NewMessageAdded);
				History[i].Unboxing(_007B10622_007D);
			}
		}
	}

	public struct NicknamesHistory : IMPSerializable
	{
		public string[] History;

		public bool Online;

		public NicknamesHistory(string[] _007B10625_007D, bool _007B10626_007D)
		{
			History = _007B10625_007D;
			Online = _007B10626_007D;
		}

		public void Boxing(WriterExtern _007B10627_007D)
		{
			_007B10627_007D.WriteStruct<int>(History.Length);
			for (int i = 0; i < History.Length; i++)
			{
				_007B10627_007D.Write(History[i], (Encoding)null);
			}
			_007B10627_007D.Write(Online);
		}

		public void Unboxing(WriterExtern _007B10628_007D)
		{
			int num = default(int);
			_007B10628_007D.ReadStruct<int>(ref num);
			History = new string[num];
			for (int i = 0; i < num; i++)
			{
				_007B10628_007D.ReadString(ref History[i], (Encoding)null);
			}
			_007B10628_007D.ReadBoolean(ref Online);
		}
	}

	public struct PersonalNotes : IMPSerializable
	{
		public string Notes;

		public uint Sid;

		public PersonalNotes(string _007B10631_007D, uint _007B10632_007D)
		{
			Notes = _007B10631_007D;
			Sid = _007B10632_007D;
		}

		public void Boxing(WriterExtern _007B10633_007D)
		{
			_007B10633_007D.Write(Notes, (Encoding)null);
			_007B10633_007D.WriteStruct<uint>(Sid);
		}

		public void Unboxing(WriterExtern _007B10634_007D)
		{
			_007B10634_007D.ReadString(ref Notes, (Encoding)null);
			_007B10634_007D.ReadStruct<uint>(ref Sid);
		}
	}

	public struct OnlineModerators : IMPSerializable
	{
		public string List;

		public OnlineModerators(string _007B10636_007D)
		{
			List = _007B10636_007D;
		}

		public void Boxing(WriterExtern _007B10637_007D)
		{
			_007B10637_007D.Write(List, (Encoding)null);
		}

		public void Unboxing(WriterExtern _007B10638_007D)
		{
			_007B10638_007D.ReadString(ref List, (Encoding)null);
		}
	}

	public struct GlobalNotes : IMPSerializable
	{
		public string Notes;

		public InfoType Type;

		public GlobalNotes(string _007B10641_007D, InfoType _007B10642_007D)
		{
			Notes = _007B10641_007D;
			Type = _007B10642_007D;
		}

		public void Boxing(WriterExtern _007B10643_007D)
		{
			_007B10643_007D.Write(Notes, (Encoding)null);
			_007B10643_007D.WriteEnum((object)Type);
		}

		public void Unboxing(WriterExtern _007B10644_007D)
		{
			_007B10644_007D.ReadString(ref Notes, (Encoding)null);
			_007B10644_007D.ReadEnum<InfoType>(ref Type);
		}
	}

	public struct SendMessage : IMPSerializable
	{
		public string Message;

		public Locale Locale;

		public SendMessage(string _007B10647_007D, Locale _007B10648_007D)
		{
			Message = _007B10647_007D;
			Locale = _007B10648_007D;
		}

		public void Boxing(WriterExtern _007B10649_007D)
		{
			_007B10649_007D.Write(Message, (Encoding)null);
			_007B10649_007D.WriteEnum((object)Locale);
		}

		public void Unboxing(WriterExtern _007B10650_007D)
		{
			_007B10650_007D.ReadString(ref Message, (Encoding)null);
			_007B10650_007D.ReadEnum<Locale>(ref Locale);
		}
	}

	public struct RequestInfo : IMPSerializable
	{
		public InfoType InfoType;

		public uint Sid;

		public RequestInfo(InfoType _007B10653_007D, uint _007B10654_007D)
		{
			InfoType = _007B10653_007D;
			Sid = _007B10654_007D;
		}

		public void Boxing(WriterExtern _007B10655_007D)
		{
			_007B10655_007D.WriteEnum((object)InfoType);
			_007B10655_007D.WriteStruct<uint>(Sid);
		}

		public void Unboxing(WriterExtern _007B10656_007D)
		{
			_007B10656_007D.ReadEnum<InfoType>(ref InfoType);
			_007B10656_007D.ReadStruct<uint>(ref Sid);
		}
	}

	public enum InfoType
	{
		NickHistory,
		Notes,
		GlobalNotes,
		PostNotes,
		BlackList
	}

	public class Reflection : IReflectionSource
	{
		private readonly Tlist<Type> _007B10661_007D;

		private readonly Dictionary<Type, short> _007B10662_007D;

		public int CountTypes => _007B10661_007D.Size;

		public Reflection()
		{
			_007B10661_007D = new Tlist<Type>(10)
			{
				typeof(ApplySanction),
				typeof(NewMessageAdded),
				typeof(SendMessage),
				typeof(RequestInfo),
				typeof(PersonalNotes),
				typeof(NicknamesHistory),
				typeof(MessagesHistory),
				typeof(LoginResultMessage),
				typeof(FindPlayer),
				typeof(LoginMessage),
				typeof(GlobalNotes),
				typeof(OnlineModerators)
			};
			_007B10662_007D = new Dictionary<Type, short>(_007B10661_007D.Size);
			for (int i = 0; i < _007B10661_007D.Size; i++)
			{
				_007B10662_007D.Add(_007B10661_007D.Array[i], (short)(i + 1));
			}
		}

		public void GetNUID(Type _007B10657_007D, out short _007B10658_007D)
		{
			short num = _007B10662_007D[_007B10657_007D];
			_007B10658_007D = num;
		}

		public IMPSerializable GetStructureInstance(short _007B10659_007D, out Type _007B10660_007D)
		{
			//IL_003f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0045: Expected O, but got Unknown
			int num = _007B10659_007D - 1;
			if (num < 0 || num >= _007B10661_007D.Size)
			{
				_007B10660_007D = null;
				return null;
			}
			_007B10660_007D = _007B10661_007D.Array[num];
			return (IMPSerializable)Activator.CreateInstance(_007B10660_007D);
		}
	}

	public static IReflectionSource TransferReflectionSource = (IReflectionSource)(object)new Reflection();

	public static OnChatMessageEvent ParseMessage(in OnChatMessageEvent _007B10582_007D)
	{
		if (!_007B10582_007D.IsLocalized)
		{
			string message = _007B10582_007D.Payload1.Message;
			if (message.StartsWith("|RAW"))
			{
				string[] array = (from _007B10663_007D in message.Split('|')
					where !string.IsNullOrEmpty(_007B10663_007D)
					select _007B10663_007D).ToArray();
				if (array.Length == 3)
				{
					string text = Local.NetworkManager_13_reason(Sanction.GetLocalizedReason(array[0]));
					string text2 = array[1];
					string text3 = StringHelper.TimeDHM(int.Parse(array[2]));
					string _007B859_007D = text2 + ",";
					string _007B860_007D;
					if (!text3.EndsWith('.'))
					{
						_007B860_007D = text3;
					}
					else
					{
						string text4 = text3;
						_007B860_007D = text4.Substring(0, text4.Length - 1);
					}
					message = Local.NetworkManager_13(_007B859_007D, _007B860_007D) + text;
					OnChatMessageEvent result = _007B10582_007D;
					result.Payload1.Message = message;
					return result;
				}
			}
		}
		return _007B10582_007D;
	}
}
