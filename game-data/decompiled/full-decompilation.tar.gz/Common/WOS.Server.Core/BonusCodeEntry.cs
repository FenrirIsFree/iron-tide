using System;
using System.Text;
using Common;
using Common.Account;
using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace WOS.Server.Core;

public struct BonusCodeEntry : IMPSerializable
{
	private BonusCodeEntryType _007B21_007D;

	private string _007B22_007D;

	public BonusCodeEntryType Type
	{
		get
		{
			return _007B21_007D;
		}
		set
		{
			_007B21_007D = value;
		}
	}

	public string Value
	{
		get
		{
			return _007B22_007D;
		}
		set
		{
			_007B22_007D = value;
		}
	}

	public BonusCodeEntry(BonusCodeEntryType _007B14_007D, string _007B15_007D)
	{
		_007B22_007D = string.Empty;
		_007B21_007D = _007B14_007D;
		_007B22_007D = _007B15_007D;
	}

	public void Apply(PlayerAccount _007B16_007D, DateTime _007B17_007D)
	{
		switch (Type)
		{
		case BonusCodeEntryType.Coins:
		{
			int num2 = int.Parse(Value);
			_007B16_007D.Monets.Value += num2;
			break;
		}
		case BonusCodeEntryType.Premium:
		{
			int num = (int)TimeSpan.Parse(Value + ":00").TotalDays;
			_007B16_007D.AddPremium(num, _007B17_007D);
			break;
		}
		case BonusCodeEntryType.Ship:
		{
			int _007B3506_007D = int.Parse(Value);
			_007B16_007D.Shipyard.CreateNewShip(Gameplay.PlayersInfo.FromID(_007B3506_007D), _007B16_007D);
			break;
		}
		case BonusCodeEntryType.Resource:
			var (_007B5451_007D2, _007B5452_007D2) = ParseBonusEntryIdAndCountValue(Value);
			_007B16_007D.NearPortStorage.AddOrRemove(_007B5451_007D2, _007B5452_007D2);
			break;
		case BonusCodeEntryType.Design:
			var (_007B5451_007D, _007B5452_007D) = ParseBonusEntryIdAndCountValue(Value);
			_007B16_007D.DesingElementsAtStorage.AddOrRemove(_007B5451_007D, _007B5452_007D);
			break;
		}
	}

	public static (int id, int amount) ParseBonusEntryIdAndCountValue(string _007B18_007D)
	{
		string[] array = _007B18_007D.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
		return (id: int.Parse(array[0]), amount: int.Parse(array[1]));
	}

	public string GetUIText()
	{
		switch (Type)
		{
		case BonusCodeEntryType.Coins:
		{
			string monets = Local.Monets2;
			return $"{monets.Replace(":", "")} +{int.Parse(Value)}";
		}
		case BonusCodeEntryType.Premium:
		{
			int num = _007B22_007D.IndexOf(',');
			if (num < 0)
			{
				num = _007B22_007D.Length;
			}
			return $"{Local.premium} +{(int)TimeSpan.Parse(Value.Substring(0, num) + ":00").TotalDays}";
		}
		case BonusCodeEntryType.Ship:
			return $"{Gameplay.PlayersInfo.FromID(int.Parse(Value)).ShipName} +{1}";
		case BonusCodeEntryType.Resource:
			var (_007B3506_007D2, value2) = ParseBonusEntryIdAndCountValue(Value);
			return $"{Gameplay.ItemsInfo.FromID(_007B3506_007D2).Name} +{value2}";
		case BonusCodeEntryType.Design:
			var (_007B3506_007D, value) = ParseBonusEntryIdAndCountValue(Value);
			return $"{Gameplay.DesignsInfo.FromID(_007B3506_007D).Name} +{value}";
		default:
			return string.Empty;
		}
	}

	public void Boxing(WriterExtern _007B19_007D)
	{
		_007B19_007D.WriteEnum((object)Type);
		_007B19_007D.Write(Value, (Encoding)null);
	}

	public void Unboxing(WriterExtern _007B20_007D)
	{
		_007B20_007D.ReadEnum<BonusCodeEntryType>(ref _007B21_007D);
		_007B20_007D.ReadString(ref _007B22_007D, (Encoding)null);
	}
}
