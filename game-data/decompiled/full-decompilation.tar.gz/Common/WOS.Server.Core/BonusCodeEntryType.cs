namespace WOS.Server.Core;

public enum BonusCodeEntryType
{
	Coins,
	Premium,
	Ship,
	Resource,
	Design
}
