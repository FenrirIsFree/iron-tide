using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

namespace WOS.Server.Core;

public class BonusCodeInfo
{
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private TimeSpan _007B39_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private int _007B40_007D;

	public List<BonusCodeEntry> Entries = new List<BonusCodeEntry>();

	public List<uint> PlayersActivated = new List<uint>();

	public DateTime CreationTime;

	private object _007B41_007D = new object();

	public TimeSpan Validity
	{
		[CompilerGenerated]
		get
		{
			return _007B39_007D;
		}
		[CompilerGenerated]
		set
		{
			_007B39_007D = value;
		}
	}

	public int RemainActivations
	{
		[CompilerGenerated]
		get
		{
			return _007B40_007D;
		}
		[CompilerGenerated]
		set
		{
			_007B40_007D = value;
		}
	}

	public bool IsValid => RemainActivations > 0 && DateTime.Now.Subtract(CreationTime) <= Validity;

	public BonusCodeInfo()
	{
	}

	public BonusCodeInfo(TimeSpan _007B31_007D, int _007B32_007D, IEnumerable<BonusCodeEntry> _007B33_007D)
	{
		CreationTime = DateTime.Now;
		Validity = _007B31_007D;
		RemainActivations = _007B32_007D;
		Entries = _007B33_007D.ToList();
	}

	public BonusCodeInfo(TimeSpan _007B34_007D, int _007B35_007D, params BonusCodeEntry[] _007B36_007D)
		: this(_007B34_007D, _007B35_007D, _007B36_007D.ToList())
	{
	}

	public bool IsValidForPlayer(uint _007B37_007D)
	{
		lock (_007B41_007D)
		{
			return IsValid && !PlayersActivated.Contains(_007B37_007D);
		}
	}

	public bool TryActivate(in uint _007B38_007D)
	{
		lock (_007B41_007D)
		{
			if (!IsValidForPlayer(_007B38_007D))
			{
				return false;
			}
			PlayersActivated.Add(_007B38_007D);
			int remainActivations = RemainActivations - 1;
			RemainActivations = remainActivations;
		}
		return true;
	}

	public override string ToString()
	{
		StringBuilder builder = new StringBuilder();
		TimeSpan timeSpan = (CreationTime + Validity).Subtract(DateTime.Now);
		StringBuilder stringBuilder = builder;
		StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(40, 4, stringBuilder);
		handler.AppendLiteral("Validity: ");
		handler.AppendFormatted(timeSpan.Days);
		handler.AppendLiteral(":");
		handler.AppendFormatted(timeSpan.Hours);
		handler.AppendLiteral(":");
		handler.AppendFormatted(timeSpan.Minutes);
		handler.AppendLiteral("\nActivation count: ");
		handler.AppendFormatted(RemainActivations);
		handler.AppendLiteral("\nEntries:");
		stringBuilder.AppendLine(ref handler);
		Entries.ForEach(delegate(BonusCodeEntry _007B42_007D)
		{
			StringBuilder stringBuilder2 = builder;
			StringBuilder.AppendInterpolatedStringHandler handler2 = new StringBuilder.AppendInterpolatedStringHandler(1, 2, stringBuilder2);
			handler2.AppendFormatted(_007B42_007D.Type);
			handler2.AppendLiteral(" ");
			handler2.AppendFormatted(_007B42_007D.Value);
			stringBuilder2.AppendLine(ref handler2);
		});
		return builder.ToString();
	}
}
