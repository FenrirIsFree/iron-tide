using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Account;
using Common.Resources;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;

namespace Common.Game;

public class QuestInfo
{
	public string QuestShortName;

	internal string FinalTextDialog;

	public string TextToolTipOrNull;

	public static readonly RTI GiveQuestInSeaRadius = new RTI(40);

	public int ID;

	public IslePortInfo LocationPort;

	public Vector2 LocationPos;

	public QuestCompany Company;

	public Tlist<QuestPortrait> Portraits;

	public int Group;

	internal int OpenGroupNext;

	public PregQuestCompleteInfo Steps;

	public Tlist<QuestAdditionalLimit> Limits;

	public int RegularInterval;

	public int LimitedTimeMinutes;

	public bool FailWhenTimeLeft = true;

	public bool ShareRewardWithGoup;

	public int HardnessLevel;

	internal ComplexBonus Bonus;

	public ShipBonus[] ShipEffects = new ShipBonus[0];

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private int _007B7239_007D = 1;

	public int? CalendarQuestDay;

	public int? TreasuryMapID;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private float _007B7240_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B7241_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B7242_007D;

	public Rectangle Icon = new Rectangle(589, 377, 92, 92);

	internal RTI InternalPirateMonetBonus = 0;

	internal RTI InternalCraftTimnSkillBonus = 0;

	public bool CountToLimit => Company != QuestCompany.Daily && Company != QuestCompany.Education;

	public int MinimalRank
	{
		[CompilerGenerated]
		get
		{
			return _007B7239_007D;
		}
		[CompilerGenerated]
		set
		{
			_007B7239_007D = value;
		}
	}

	public QuestStepHeader FirstStep => Steps.Array[0];

	public bool HasContinue => OpenGroupNext != 0;

	internal bool HasChallenges => Limits.Count((QuestAdditionalLimit _007B7243_007D) => _007B7243_007D.ToString()[0] == 'C') > 0;

	public float RistrictionKeepShipHealth
	{
		[CompilerGenerated]
		get
		{
			return _007B7240_007D;
		}
		[CompilerGenerated]
		set
		{
			_007B7240_007D = value;
		}
	}

	public bool DisableReputation
	{
		[CompilerGenerated]
		get
		{
			return _007B7241_007D;
		}
		[CompilerGenerated]
		set
		{
			_007B7241_007D = value;
		}
	}

	public bool NeedDailyQuestsTier2
	{
		[CompilerGenerated]
		get
		{
			return _007B7242_007D;
		}
		[CompilerGenerated]
		set
		{
			_007B7242_007D = value;
		}
	}

	public string TextDialog(PlayerAccount _007B7231_007D)
	{
		return FinalTextDialog.Replace("PLAYER_NAME", _007B7231_007D.PlayerName);
	}

	public QuestInfo()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		Limits = new Tlist<QuestAdditionalLimit>();
		LimitedTimeMinutes = -1;
		Bonus = new ComplexBonus();
		Portraits = new Tlist<QuestPortrait>();
	}

	public ComplexBonus GetBonus(GuildCommon? _007B7236_007D, PlayerAccount _007B7237_007D)
	{
		int num = ((_007B7236_007D != null && _007B7236_007D.Fraction == FractionID.Pirate) ? InternalPirateMonetBonus.Value : 0);
		int num2 = ((_007B7237_007D.CaptainSkills[PDynamicAccountBonus.BCraftTimeForQuests] > 0) ? InternalCraftTimnSkillBonus.Value : 0);
		if (num > 0 || num2 > 0)
		{
			ComplexBonus complexBonus = Bonus.ShallowCopy();
			complexBonus.Items = complexBonus.Items.Clone();
			complexBonus.Items[72] += num;
			complexBonus.CraftTimeRecovery.Value += num2;
			return complexBonus;
		}
		return Bonus;
	}

	public string GetName(PlayerAccount _007B7238_007D)
	{
		if (CalendarQuestDay.HasValue)
		{
			CalendarEventInfo currentEvent = CalendarEvents.CurrentEvent;
			for (int i = 1; i <= currentEvent.Days.Length; i++)
			{
				int questDay = CalendarEvents.CurrentEvent.GetQuestDay(_007B7238_007D, i);
				if (CalendarQuestDay.Value == questDay)
				{
					return CalendarEvents.CurrentEvent.GetQuestNameAndDesc(i).Name;
				}
			}
		}
		return QuestShortName;
	}
}
