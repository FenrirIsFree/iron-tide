using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using Common.Data;
using Common.Resources;
using CommonDataTypes;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Helpers;
using TheraEngine.Interface.Controls;

namespace Common.Game;

public class GSI : IMPSerializable, IEnumerable<GSILocalPair>, IEnumerable
{
	private struct LocalEnumenator : IEnumerator<GSILocalPair>, IEnumerator, IDisposable
	{
		private GSI _007B5507_007D;

		private int _007B5508_007D;

		public GSILocalPair Current => _007B5507_007D.items.Array[_007B5508_007D];

		object IEnumerator.Current => Current;

		public LocalEnumenator(GSI _007B5506_007D)
		{
			_007B5506_007D.CheckProtection();
			_007B5508_007D = -1;
			_007B5507_007D = _007B5506_007D;
		}

		public void Dispose()
		{
			_007B5507_007D = null;
		}

		public bool MoveNext()
		{
			_007B5508_007D++;
			return _007B5508_007D < _007B5507_007D.items.Size;
		}

		public void Reset()
		{
			_007B5508_007D = 0;
		}
	}

	[CompilerGenerated]
	private sealed class _003CRandItemsId_003Ed__127 : IEnumerable<int>, IEnumerable, IEnumerator<int>, IEnumerator, IDisposable
	{
		private int _007B5519_007D;

		private int _007B5520_007D;

		private int _007B5521_007D;

		private int _007B5522_007D;

		public int _003C_003E3__countItems;

		private bool _007B5523_007D;

		public bool _003C_003E3__allowRepeat;

		private bool _007B5524_007D;

		public bool _003C_003E3__useCountAsProbability;

		private Sequence _007B5525_007D;

		public Sequence _003C_003E3__random;

		public GSI _003C_003E4__this;

		private Tlist<int> _007B5526_007D;

		private int _007B5527_007D;

		private int _007B5528_007D;

		private int _007B5529_007D;

		private GSILocalPair _007B5530_007D;

		private int _007B5531_007D;

		private Tlist<int> _007B5532_007D;

		private int _007B5533_007D;

		int IEnumerator<int>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B5520_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B5520_007D;
			}
		}

		[DebuggerHidden]
		public _003CRandItemsId_003Ed__127(int _007B5514_007D)
		{
			_007B5519_007D = _007B5514_007D;
			_007B5521_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B5515_007D()
		{
			_007B5526_007D = null;
			_007B5532_007D = null;
			_007B5519_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {5515}
			this._007B5515_007D();
		}

		private bool _007B5516_007D()
		{
			switch (_007B5519_007D)
			{
			default:
				return false;
			case 0:
				_007B5519_007D = -1;
				_007B5522_007D = Math.Min(_003C_003E4__this.items.Size, _007B5522_007D);
				if (_007B5522_007D == 1)
				{
					_007B5520_007D = _003C_003E4__this.items.Rand().ID;
					_007B5519_007D = 1;
					return true;
				}
				if (_007B5522_007D == 0)
				{
					return false;
				}
				if (_007B5525_007D == null)
				{
					_007B5525_007D = Rand.Instance;
				}
				if (_007B5524_007D)
				{
					_007B5526_007D = new Tlist<int>(_007B5522_007D);
					_007B5527_007D = _003C_003E4__this.GetTotalItemsCount();
					goto IL_021c;
				}
				if (_007B5523_007D)
				{
					_007B5531_007D = 0;
					goto IL_028e;
				}
				_007B5532_007D = new Tlist<int>(_007B5522_007D);
				goto IL_0335;
			case 1:
				_007B5519_007D = -1;
				return false;
			case 2:
				_007B5519_007D = -1;
				_007B5522_007D--;
				goto IL_021c;
			case 3:
				_007B5519_007D = -1;
				_007B5531_007D++;
				goto IL_028e;
			case 4:
				{
					_007B5519_007D = -1;
					_007B5522_007D--;
					goto IL_0335;
				}
				IL_028e:
				if (_007B5531_007D < _007B5522_007D)
				{
					_007B5520_007D = _003C_003E4__this.items.Rand().ID;
					_007B5519_007D = 3;
					return true;
				}
				break;
				IL_0335:
				while (_007B5522_007D > 0)
				{
					_007B5533_007D = _003C_003E4__this.items.Rand().ID;
					if (!_007B5532_007D.Contains(_007B5533_007D))
					{
						_007B5532_007D.Add(in _007B5533_007D);
						_007B5520_007D = _007B5533_007D;
						_007B5519_007D = 4;
						return true;
					}
				}
				_007B5532_007D = null;
				break;
				IL_021c:
				while (_007B5522_007D > 0)
				{
					_007B5528_007D = _007B5525_007D.RangeInt(0, _007B5527_007D);
					_007B5529_007D = 0;
					while (_007B5529_007D < _003C_003E4__this.items.Size)
					{
						_007B5530_007D = _003C_003E4__this.items.Array[_007B5529_007D];
						if (_007B5528_007D < _007B5530_007D.Count)
						{
							if (_007B5523_007D || !_007B5526_007D.Contains(_007B5530_007D.ID))
							{
								_007B5526_007D.Add(in _007B5530_007D.ID);
								_007B5520_007D = _007B5530_007D.ID;
								_007B5519_007D = 2;
								return true;
							}
						}
						else
						{
							_007B5528_007D -= _007B5530_007D.Count;
						}
						_007B5529_007D++;
					}
				}
				_007B5526_007D = null;
				break;
			}
			return false;
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {5516}
			return this._007B5516_007D();
		}

		[DebuggerHidden]
		private void _007B5517_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {5517}
			this._007B5517_007D();
		}

		[DebuggerHidden]
		IEnumerator<int> IEnumerable<int>.GetEnumerator()
		{
			_003CRandItemsId_003Ed__127 _003CRandItemsId_003Ed__;
			if (_007B5519_007D == -2 && _007B5521_007D == Environment.CurrentManagedThreadId)
			{
				_007B5519_007D = 0;
				_003CRandItemsId_003Ed__ = this;
			}
			else
			{
				_003CRandItemsId_003Ed__ = new _003CRandItemsId_003Ed__127(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			_003CRandItemsId_003Ed__._007B5522_007D = _003C_003E3__countItems;
			_003CRandItemsId_003Ed__._007B5523_007D = _003C_003E3__allowRepeat;
			_003CRandItemsId_003Ed__._007B5524_007D = _003C_003E3__useCountAsProbability;
			_003CRandItemsId_003Ed__._007B5525_007D = _003C_003E3__random;
			return _003CRandItemsId_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B5518_007D()
		{
			return ((IEnumerable<int>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {5518}
			return this._007B5518_007D();
		}
	}

	[CompilerGenerated]
	private sealed class _003CSelectRandomNames_003Ed__128 : IEnumerable<int>, IEnumerable, IEnumerator<int>, IEnumerator, IDisposable
	{
		private int _007B5540_007D;

		private int _007B5541_007D;

		private int _007B5542_007D;

		private int _007B5543_007D;

		public int _003C_003E3__count;

		public GSI _003C_003E4__this;

		private int _007B5544_007D;

		int IEnumerator<int>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B5541_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B5541_007D;
			}
		}

		[DebuggerHidden]
		public _003CSelectRandomNames_003Ed__128(int _007B5535_007D)
		{
			_007B5540_007D = _007B5535_007D;
			_007B5542_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B5536_007D()
		{
			_007B5540_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {5536}
			this._007B5536_007D();
		}

		private bool _007B5537_007D()
		{
			switch (_007B5540_007D)
			{
			default:
				return false;
			case 0:
				_007B5540_007D = -1;
				_003C_003E4__this.CheckProtection();
				if (_007B5543_007D > _003C_003E4__this.items.Size)
				{
					throw new ArgumentException();
				}
				_007B5544_007D = 0;
				break;
			case 1:
				_007B5540_007D = -1;
				_007B5544_007D++;
				break;
			}
			if (_007B5544_007D < _007B5543_007D)
			{
				_007B5541_007D = _003C_003E4__this.items.Rand().ID;
				_007B5540_007D = 1;
				return true;
			}
			return false;
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {5537}
			return this._007B5537_007D();
		}

		[DebuggerHidden]
		private void _007B5538_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {5538}
			this._007B5538_007D();
		}

		[DebuggerHidden]
		IEnumerator<int> IEnumerable<int>.GetEnumerator()
		{
			_003CSelectRandomNames_003Ed__128 _003CSelectRandomNames_003Ed__;
			if (_007B5540_007D == -2 && _007B5542_007D == Environment.CurrentManagedThreadId)
			{
				_007B5540_007D = 0;
				_003CSelectRandomNames_003Ed__ = this;
			}
			else
			{
				_003CSelectRandomNames_003Ed__ = new _003CSelectRandomNames_003Ed__128(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			_003CSelectRandomNames_003Ed__._007B5543_007D = _003C_003E3__count;
			return _003CSelectRandomNames_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B5539_007D()
		{
			return ((IEnumerable<int>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {5539}
			return this._007B5539_007D();
		}
	}

	[CompilerGenerated]
	private sealed class _003CWriteToolTipData_ResourcesOnly_003Ed__120 : IEnumerable<(string, Color)>, IEnumerable, IEnumerator<(string, Color)>, IEnumerator, IDisposable
	{
		private int _007B5551_007D;

		private (string, Color) _007B5552_007D;

		private int _007B5553_007D;

		private GSI _007B5554_007D;

		public GSI _003C_003E3__storage;

		private bool _007B5555_007D;

		public bool _003C_003E3__nameIsPortStorageOrShip;

		public GSI _003C_003E4__this;

		private int _007B5556_007D;

		private GSILocalPair _007B5557_007D;

		private (string, Color) _007B5558_007D;

		(string, Color) IEnumerator<(string, Color)>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B5552_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B5552_007D;
			}
		}

		[DebuggerHidden]
		public _003CWriteToolTipData_ResourcesOnly_003Ed__120(int _007B5546_007D)
		{
			_007B5551_007D = _007B5546_007D;
			_007B5553_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B5547_007D()
		{
			_007B5558_007D = default((string, Color));
			_007B5551_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {5547}
			this._007B5547_007D();
		}

		private bool _007B5548_007D()
		{
			int num = _007B5551_007D;
			if (num != 0)
			{
				if (num != 1)
				{
					return false;
				}
				_007B5551_007D = -1;
				goto IL_00b8;
			}
			_007B5551_007D = -1;
			_003C_003E4__this.CheckProtection();
			_007B5556_007D = 0;
			goto IL_00d5;
			IL_00b8:
			_007B5558_007D = default((string, Color));
			_007B5556_007D++;
			goto IL_00d5;
			IL_00d5:
			if (_007B5556_007D < _003C_003E4__this.items.Size)
			{
				_007B5557_007D = _003C_003E4__this.items.Array[_007B5556_007D];
				_007B5558_007D = _003C_003E4__this.AddResourceToolTip(_007B5557_007D.ID, _007B5554_007D, _007B5555_007D);
				if (_007B5558_007D.Item1.Length > 0)
				{
					_007B5552_007D = _007B5558_007D;
					_007B5551_007D = 1;
					return true;
				}
				goto IL_00b8;
			}
			return false;
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {5548}
			return this._007B5548_007D();
		}

		[DebuggerHidden]
		private void _007B5549_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {5549}
			this._007B5549_007D();
		}

		[DebuggerHidden]
		IEnumerator<(string, Color)> IEnumerable<(string, Color)>.GetEnumerator()
		{
			_003CWriteToolTipData_ResourcesOnly_003Ed__120 _003CWriteToolTipData_ResourcesOnly_003Ed__;
			if (_007B5551_007D == -2 && _007B5553_007D == Environment.CurrentManagedThreadId)
			{
				_007B5551_007D = 0;
				_003CWriteToolTipData_ResourcesOnly_003Ed__ = this;
			}
			else
			{
				_003CWriteToolTipData_ResourcesOnly_003Ed__ = new _003CWriteToolTipData_ResourcesOnly_003Ed__120(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			_003CWriteToolTipData_ResourcesOnly_003Ed__._007B5554_007D = _003C_003E3__storage;
			_003CWriteToolTipData_ResourcesOnly_003Ed__._007B5555_007D = _003C_003E3__nameIsPortStorageOrShip;
			return _003CWriteToolTipData_ResourcesOnly_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B5550_007D()
		{
			return ((IEnumerable<(string, Color)>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {5550}
			return this._007B5550_007D();
		}
	}

	public static readonly GSI Empty = new GSI();

	public const int TWoodID = 1;

	public const int TCottonID = 3;

	public const int TIronID = 4;

	public const int TCopper = 11;

	public const int TCoal = 12;

	public const int TResinLaquer = 13;

	public const int RDebris = 20;

	public const int RVulkanoOre = 23;

	public const int FIronOre = 31;

	public const int FCopperOre = 32;

	public const int TRumID = 2;

	public const int TFruitsAndOthers = 9;

	public const int TCorn = 10;

	public const int RBondman = 8;

	public const int TWater = 5;

	public const int TMeat = 21;

	public const int TAnimals = 22;

	public const int TFinery = 30;

	public const int CGoldIngot = 24;

	public const int CBronze = 14;

	public const int CBlock = 16;

	public const int CSailcloth = 17;

	public const int CBulkWood = 27;

	public const int CBulkIron = 29;

	public const int CFishingRod = 36;

	public const int CProvision = 39;

	public const int ArenaLoot = 19;

	public const int RVuduSkull = 38;

	public const int RMarks = 37;

	public const int REscudo = 15;

	public const int RGuildPaper = 40;

	public const int RDonateChestKey = 43;

	public const int RInsuranePaper = 33;

	public const int REmpireShipDraft = 67;

	public const int REmpireShipCompletedDraft = 68;

	public const int TPearl = 25;

	public const int TFish = 34;

	public const int TGoldFish = 69;

	public const int TBeer = 7;

	public const int TSugar = 6;

	public const int TISilk = 53;

	public const int TILeather = 59;

	public const int TWhaleOil = 70;

	public const int DisplayOnly_Gold = 255;

	public const int DisplayOnly_Cannons = 253;

	public const int DisplayOnly_Monets = 252;

	public const int Map_Scrolls = 35;

	public const int Map_Ny25 = 71;

	public const int Map_PirateMonet = 72;

	public const int Map_Merchant = 73;

	public const int Map_Pirate = 74;

	public const int Map_Cult = 75;

	public const int CBallsSimple = 1;

	public const int CBallsFire = 2;

	public const int CBallsAntisail = 3;

	public const int CBallsAnticrew = 4;

	public const int CBallsHeavy = 5;

	public const int CBallsMortar = 6;

	public const int CBallsSakson = 7;

	public const int CBallsMortar2 = 8;

	public const int CBallsSpecialFire = 9;

	public const int CBallsSpecialIce = 10;

	public const int CBallsMortarTower = 11;

	public const int CBallsFiregunshot = 12;

	public const int CBallsFalkonet1 = 13;

	public const int CBallsMortarSuper = 20;

	public const int CBallSnow = 21;

	public const int CBallsFalkonet2 = 14;

	public const int CBallsFalkonetPhosp = 16;

	public const int CBoardingHooks_Display = 17;

	public const int CBallsFalkonetFirework = 18;

	public const int CBallsMortarKeg = 19;

	public const int CBallsSpecialPhosphor = 500;

	public const int PowderKegSimple = 1;

	public const int PowderKegFire = 2;

	public const int PowderKegPhosphor = 3;

	public const int PowderKeg_removed = 4;

	public const int PowderKegBigMine = 5;

	public const int PowderKegDebrisMines = 6;

	public const int PowderKegFirebrand = 7;

	public const int PowderKegSpecialRaft = 8;

	internal Tlist<GSILocalPair> items;

	private RTI _007B5502_007D;

	private RTI _007B5503_007D;

	private RTI _007B5504_007D;

	public int NamesCount => items.Size;

	public bool IsEmpty => items.Size == 0;

	public int this[int _007B5440_007D]
	{
		get
		{
			CheckProtection();
			for (int i = 0; i < items.Size; i++)
			{
				if (items.Array[i].ID == _007B5440_007D)
				{
					return items.Array[i].Count;
				}
			}
			return 0;
		}
		set
		{
			if (value < 0)
			{
				throw new InvalidOperationException();
			}
			CheckProtection();
			for (int i = 0; i < items.Size; i++)
			{
				if (items.Array[i].ID == _007B5441_007D)
				{
					if (value == 0)
					{
						items.RemoveAt(i);
					}
					else
					{
						items.Array[i].Count = value;
					}
					Protect();
					return;
				}
			}
			if (value != 0)
			{
				items.Add(new GSILocalPair(_007B5441_007D, value));
				Protect();
			}
		}
	}

	public GSILocalEnumerable<ResourceInfo> ResourceInfo => new GSILocalEnumerable<ResourceInfo>(this, Gameplay.ItemsInfo.FromID);

	public GSILocalEnumerable<CannonGameInfo> CannonGameInfo => new GSILocalEnumerable<CannonGameInfo>(this, Gameplay.CannonsGameInfo.FromID);

	public GSILocalEnumerable<PowderKegInfo> PowderKegInfo => new GSILocalEnumerable<PowderKegInfo>(this, Gameplay.PowderKegsInfo.FromID);

	public GSILocalEnumerable<CannonBallInfo> CannonBallInfo => new GSILocalEnumerable<CannonBallInfo>(this, Gameplay.BallsInfo.FromID);

	public GSILocalEnumerable<ShipDesignInfo> DesignElementInfo => new GSILocalEnumerable<ShipDesignInfo>(this, ShipDesignInfo.Resolve);

	public GSILocalEnumerable<ShipDesignInfo> EnvDecorElementInfo => new GSILocalEnumerable<ShipDesignInfo>(this, Gameplay.EnvDecorElementsInfo.FromID);

	public GSILocalEnumerable<PowerupItemInfo> PowerupItemInfo => new GSILocalEnumerable<PowerupItemInfo>(this, (int _007B5511_007D) => Gameplay.PowerupItems.Array[_007B5511_007D]);

	public GSILocalEnumerable<UnitInfo> UnitInfo => new GSILocalEnumerable<UnitInfo>(this, Gameplay.UnitsInfo.FromID);

	public GSILocalEnumerable<AchievementDisplayInfo> AchievementInfo => new GSILocalEnumerable<AchievementDisplayInfo>(this, Gameplay.AchievementsDisplayInfo.FromID);

	public GSI()
	{
		items = new Tlist<GSILocalPair>(0);
		_007B5502_007D = new RTI(0);
		_007B5503_007D = new RTI(0);
		_007B5504_007D = new RTI(0);
	}

	private void _007B5436_007D(out int _007B5437_007D, out int _007B5438_007D, out int _007B5439_007D)
	{
		_007B5437_007D = items.Size;
		_007B5438_007D = items.Size;
		_007B5439_007D = 0;
		for (int i = 0; i < items.Size; i++)
		{
			_007B5437_007D = _007B5437_007D * 258743 + items.Array[i].ID;
			_007B5438_007D = _007B5438_007D * 64717 + items.Array[i].Count;
			_007B5439_007D += items.Array[i].Count;
		}
	}

	internal void CheckProtection()
	{
		if (!CommonGlobal.IsServer)
		{
			_007B5436_007D(out var _007B5437_007D, out var _007B5438_007D, out var _007B5439_007D);
			if (_007B5437_007D != _007B5502_007D.Value || _007B5438_007D != _007B5503_007D.Value || _007B5439_007D != _007B5504_007D.Value)
			{
				throw new AccessViolationException("GSI protection data has been changed");
			}
		}
	}

	protected void Protect()
	{
		if (!CommonGlobal.IsServer)
		{
			_007B5436_007D(out var _007B5437_007D, out var _007B5438_007D, out var _007B5439_007D);
			_007B5502_007D.Value = _007B5437_007D;
			_007B5503_007D.Value = _007B5438_007D;
			_007B5504_007D.Value = _007B5439_007D;
		}
	}

	private int _007B5443_007D(int _007B5444_007D)
	{
		for (int i = 0; i < items.Size; i++)
		{
			if (items.Array[i].ID == _007B5444_007D)
			{
				return items.Array[i].Count;
			}
		}
		return 0;
	}

	private void _007B5445_007D(int _007B5446_007D, int _007B5447_007D)
	{
		if (_007B5447_007D == 0)
		{
			return;
		}
		for (int i = 0; i < items.Size; i++)
		{
			if (items.Array[i].ID == _007B5446_007D)
			{
				if (items.Array[i].Count + _007B5447_007D < 0)
				{
					throw new InvalidOperationException("Not enough item");
				}
				items.Array[i].Count += _007B5447_007D;
				if (items.Array[i].Count == 0)
				{
					items.RemoveAt(i);
				}
				return;
			}
		}
		if (_007B5447_007D > 0)
		{
			items.Add(new GSILocalPair(_007B5446_007D, _007B5447_007D));
			return;
		}
		throw new InvalidOperationException("Not enough item");
	}

	public GSI Exs(int _007B5448_007D, int _007B5449_007D)
	{
		AddOrRemove(_007B5448_007D, _007B5449_007D);
		return this;
	}

	public int GetTotalItemsCount()
	{
		CheckProtection();
		int num = 0;
		for (int i = 0; i < items.Size; i++)
		{
			num += items.Array[i].Count;
		}
		return num;
	}

	[Obsolete("Use indexer")]
	public int GetCount(int _007B5450_007D)
	{
		return this[_007B5450_007D];
	}

	public void AddOrRemove(int _007B5451_007D, int _007B5452_007D)
	{
		if (_007B5452_007D != 0)
		{
			CheckProtection();
			_007B5445_007D(_007B5451_007D, _007B5452_007D);
			Protect();
		}
	}

	public bool CanRemove(GSI _007B5453_007D)
	{
		CheckProtection();
		for (int i = 0; i < _007B5453_007D.items.Size; i++)
		{
			GSILocalPair gSILocalPair = _007B5453_007D.items.Array[i];
			if (_007B5443_007D(gSILocalPair.ID) < gSILocalPair.Count)
			{
				return false;
			}
		}
		return true;
	}

	public void OrderByQuantity()
	{
		CheckProtection();
		items.SortTop((GSILocalPair _007B5509_007D) => _007B5509_007D.Count);
		Protect();
	}

	public int CanRemoveMaxCount(GSI _007B5454_007D)
	{
		if (_007B5454_007D.items.Size == 0)
		{
			throw new ArgumentException();
		}
		if (items.Size == 0)
		{
			return 0;
		}
		CheckProtection();
		float num = float.MaxValue;
		for (int i = 0; i < _007B5454_007D.items.Size; i++)
		{
			GSILocalPair gSILocalPair = _007B5454_007D.items.Array[i];
			num = Math.Min(num, _007B5443_007D(gSILocalPair.ID) / gSILocalPair.Count);
		}
		return (int)Math.Floor(num);
	}

	public bool TryRemove(GSI _007B5455_007D)
	{
		if (!CanRemove(_007B5455_007D))
		{
			return false;
		}
		Remove(_007B5455_007D);
		return true;
	}

	public void Remove(GSI _007B5456_007D, int _007B5457_007D = 1, bool _007B5458_007D = false)
	{
		if (_007B5456_007D.items.Size == 0)
		{
			return;
		}
		CheckProtection();
		_007B5456_007D.CheckProtection();
		if (_007B5456_007D == this)
		{
			if (_007B5457_007D == 1)
			{
				items.Clear();
				Protect();
				return;
			}
			_007B5456_007D = _007B5456_007D.Clone();
		}
		for (int i = 0; i < _007B5456_007D.items.Size; i++)
		{
			GSILocalPair gSILocalPair = _007B5456_007D.items.Array[i];
			if (_007B5458_007D)
			{
				_007B5445_007D(gSILocalPair.ID, -_007B5457_007D * Math.Min(gSILocalPair.Count, _007B5443_007D(gSILocalPair.ID)));
			}
			else
			{
				_007B5445_007D(gSILocalPair.ID, -_007B5457_007D * gSILocalPair.Count);
			}
		}
		Protect();
	}

	public GSI ExceptWith(GSI _007B5459_007D)
	{
		if (items.Size == 0)
		{
			return Empty;
		}
		if (_007B5459_007D.items.Size == 0)
		{
			return Clone();
		}
		GSI gSI = new GSI();
		CheckProtection();
		_007B5459_007D.CheckProtection();
		foreach (GSILocalPair item in (IEnumerable<GSILocalPair>)items)
		{
			int num = Math.Max(0, item.Count - _007B5459_007D._007B5443_007D(item.ID));
			if (num > 0)
			{
				gSI._007B5445_007D(item.ID, num);
			}
		}
		gSI.Protect();
		return gSI;
	}

	public void Add(GSI _007B5460_007D)
	{
		if (_007B5460_007D.items.Size != 0)
		{
			CheckProtection();
			_007B5460_007D.CheckProtection();
			for (int i = 0; i < _007B5460_007D.items.Size; i++)
			{
				GSILocalPair gSILocalPair = _007B5460_007D.items.Array[i];
				_007B5445_007D(gSILocalPair.ID, gSILocalPair.Count);
			}
			Protect();
		}
	}

	public void Add(GSI _007B5461_007D, int _007B5462_007D)
	{
		if (_007B5461_007D.items.Size != 0)
		{
			CheckProtection();
			_007B5461_007D.CheckProtection();
			for (int i = 0; i < _007B5461_007D.items.Size; i++)
			{
				GSILocalPair gSILocalPair = _007B5461_007D.items.Array[i];
				_007B5445_007D(gSILocalPair.ID, gSILocalPair.Count * _007B5462_007D);
			}
			Protect();
		}
	}

	internal void CleanRemovedResources(out int _007B5463_007D)
	{
		_007B5463_007D = 0;
		CheckProtection();
		GSI gSI = null;
		for (int i = 0; i < items.Size; i++)
		{
			GSILocalPair gSILocalPair = items.Array[i];
			if (gSILocalPair.ID <= 0 || gSILocalPair.ID > Gameplay.ItemsInfo.Count)
			{
				items.RemoveAt(i);
				i--;
				continue;
			}
			ResourceInfo resourceInfo = Gameplay.ItemsInfo.FromID(gSILocalPair.ID);
			if (resourceInfo.AllowStorage != ResourceIDStatus.REMOVEfromAccounts)
			{
				continue;
			}
			int _007B407_007D;
			int num = RemovedResMap.Map(gSILocalPair.ID, gSILocalPair.Count, out _007B407_007D);
			_007B5463_007D += _007B407_007D;
			if (num != -1)
			{
				if (gSI == null)
				{
					gSI = new GSI();
				}
				gSI[num] += gSILocalPair.Count;
			}
			items.RemoveAt(i);
			i--;
		}
		Protect();
		if (gSI != null)
		{
			Add(gSI);
		}
	}

	internal void CleanRemovedCannonBalls()
	{
		CheckProtection();
		for (int i = 0; i < items.Size; i++)
		{
			GSILocalPair gSILocalPair = items.Array[i];
			if (gSILocalPair.ID > Gameplay.BallsInfo.Count)
			{
				items.RemoveAt(i);
				i--;
				continue;
			}
			CannonBallInfo cannonBallInfo = Gameplay.BallsInfo.FromID(gSILocalPair.ID);
			if (cannonBallInfo.Infinity || cannonBallInfo.Name[0] == 'r')
			{
				items.RemoveAt(i);
				i--;
			}
		}
		Protect();
	}

	internal void CleanRemovedPowderKegs()
	{
		CheckProtection();
		for (int i = 0; i < items.Size; i++)
		{
			GSILocalPair gSILocalPair = items.Array[i];
			if (gSILocalPair.ID > Gameplay.PowderKegsInfo.Count)
			{
				items.RemoveAt(i);
				i--;
			}
		}
		Protect();
	}

	public void CleanRemovedPowerupItems()
	{
		CheckProtection();
		for (int i = 0; i < items.Size; i++)
		{
			GSILocalPair gSILocalPair = items.Array[i];
			if (gSILocalPair.ID >= Gameplay.PowerupItems.Size)
			{
				items.RemoveAt(i);
				i--;
				continue;
			}
			PowerupItemInfo powerupItemInfo = Gameplay.PowerupItems.Array[gSILocalPair.ID];
			if (powerupItemInfo.Name[0] == 'r')
			{
				items.RemoveAt(i);
				i--;
			}
		}
		Protect();
	}

	public void RemoveAll(Func<GSILocalPair, bool> _007B5464_007D)
	{
		CheckProtection();
		for (int i = 0; i < items.Size; i++)
		{
			if (_007B5464_007D(items.Array[i]))
			{
				items.RemoveAt(i);
				i--;
			}
		}
		Protect();
	}

	public void Clean()
	{
		CheckProtection();
		items.Clear();
		Protect();
	}

	public float ComputeMass<T>() where T : IStorageAsset
	{
		float num = 0f;
		for (int i = 0; i < items.Size; i++)
		{
			num += (float)items.Array[i].Count * Gameplay.GetResource2<T>(items.Array[i].ID).getStorageMass;
		}
		return num;
	}

	public void SetCountTo1()
	{
		CheckProtection();
		for (int i = 0; i < items.Size; i++)
		{
			items.Array[i].Count = 1;
		}
		Protect();
	}

	public void WriteToolTipData_ResourcesOnly(TextBlockBuilder _007B5465_007D, GSI _007B5466_007D, bool _007B5467_007D)
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		CheckProtection();
		for (int i = 0; i < items.Size; i++)
		{
			GSILocalPair gSILocalPair = items.Array[i];
			(string, Color) tuple = AddResourceToolTip(gSILocalPair.ID, _007B5466_007D, _007B5467_007D);
			if (tuple.Item1.Length > 0)
			{
				_007B5465_007D.WriteLine(tuple.Item1, tuple.Item2);
			}
		}
	}

	[IteratorStateMachine(typeof(_003CWriteToolTipData_ResourcesOnly_003Ed__120))]
	public IEnumerable<(string, Color)> WriteToolTipData_ResourcesOnly(GSI _007B5468_007D, bool _007B5469_007D)
	{
		//yield-return decompiler failed: Method not found
		return new _003CWriteToolTipData_ResourcesOnly_003Ed__120(-2)
		{
			_003C_003E4__this = this,
			_003C_003E3__storage = _007B5468_007D,
			_003C_003E3__nameIsPortStorageOrShip = _007B5469_007D
		};
	}

	private (string, Color) AddResourceToolTip(int _007B5470_007D, GSI _007B5471_007D, bool _007B5472_007D)
	{
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		CheckProtection();
		int num = _007B5443_007D(_007B5470_007D);
		if (num != 0)
		{
			int num2 = _007B5471_007D._007B5443_007D(_007B5470_007D);
			return (string.Format("• " + (_007B5472_007D ? Local.Current("res_exists1") : Local.Current("res_exists2")), Gameplay.ItemsInfo.FromID(_007B5470_007D).Name, num, num2), (num <= num2) ? Color.Lime : Color.Gray);
		}
		return ("", Color.White);
	}

	public int TotalPrice()
	{
		CheckProtection();
		int num = 0;
		for (int i = 0; i < items.Size; i++)
		{
			num += items.Array[i].Count * Gameplay.ItemsInfo.FromID(items.Array[i].ID).MediumCost.Value;
		}
		return num;
	}

	public GSI Clone()
	{
		CheckProtection();
		GSI gSI = new GSI();
		gSI.items = items.Clone();
		gSI.Protect();
		return gSI;
	}

	public GSI Clone(float _007B5473_007D, RoundMode _007B5474_007D = RoundMode.Floor)
	{
		CheckProtection();
		GSI gSI = Clone();
		for (int i = 0; i < gSI.items.Size; i++)
		{
			float num = (float)gSI.items.Array[i].Count * _007B5473_007D;
			GSILocalPair[] array = gSI.items.Array;
			int num2 = i;
			_ = ref array[num2];
			if (1 == 0)
			{
			}
			int count = _007B5474_007D switch
			{
				RoundMode.Floor => (int)num, 
				RoundMode.SoftFloor => (int)((num < 0.1f) ? 0f : ((num < 1f) ? 1f : MathF.Round(num))), 
				RoundMode.Round => (int)MathF.Round(num), 
				RoundMode.Ceiling => (int)MathF.Ceiling(num), 
				RoundMode.SoftCeiling => (int)((num < 0.2f) ? ((float)Rand.Round(num)) : MathF.Ceiling(num)), 
				RoundMode.Rand => Rand.Round(num), 
				_ => throw new NotImplementedException(), 
			};
			if (1 == 0)
			{
			}
			array[num2].Count = count;
			if (gSI.items.Array[i].Count == 0)
			{
				gSI.items.RemoveAt(i);
				i--;
			}
		}
		gSI.Protect();
		return gSI;
	}

	public void Limitize(GSI _007B5475_007D)
	{
		_007B5475_007D.CheckProtection();
		CheckProtection();
		for (int i = 0; i < items.Size; i++)
		{
			items.Array[i].Count = Math.Min(_007B5475_007D._007B5443_007D(items.Array[i].ID), items.Array[i].Count);
			if (items.Array[i].Count == 0)
			{
				items.FastRemoveAt(i);
				i--;
			}
		}
		Protect();
	}

	public void Agregate(Func<GSILocalPair, int> _007B5476_007D)
	{
		CheckProtection();
		for (int i = 0; i < items.Size; i++)
		{
			int num = _007B5476_007D(items.Array[i]);
			if (num <= 0)
			{
				if (num < 0)
				{
					throw new InvalidOperationException();
				}
				items.FastRemoveAt(i);
			}
			else
			{
				items.Array[i].Count = num;
			}
		}
		Protect();
	}

	[IteratorStateMachine(typeof(_003CRandItemsId_003Ed__127))]
	public IEnumerable<int> RandItemsId(int _007B5477_007D, bool _007B5478_007D = true, bool _007B5479_007D = false, Sequence? _007B5480_007D = null)
	{
		//yield-return decompiler failed: Method not found
		return new _003CRandItemsId_003Ed__127(-2)
		{
			_003C_003E4__this = this,
			_003C_003E3__countItems = _007B5477_007D,
			_003C_003E3__allowRepeat = _007B5478_007D,
			_003C_003E3__useCountAsProbability = _007B5479_007D,
			_003C_003E3__random = _007B5480_007D
		};
	}

	[IteratorStateMachine(typeof(_003CSelectRandomNames_003Ed__128))]
	[Obsolete("Use RandItemsId")]
	public IEnumerable<int> SelectRandomNames(int _007B5481_007D)
	{
		//yield-return decompiler failed: Method not found
		return new _003CSelectRandomNames_003Ed__128(-2)
		{
			_003C_003E4__this = this,
			_003C_003E3__count = _007B5481_007D
		};
	}

	[Obsolete("Use RandItemsId")]
	public int SelectRandomNameByHash(int _007B5482_007D)
	{
		return items.Array[HashHelper.greaterInt(_007B5482_007D, items.Size)].ID;
	}

	[Obsolete("Use RandItemsId")]
	public Tlist<int> RandomSelection(int _007B5483_007D, int _007B5484_007D = -1)
	{
		if (_007B5483_007D > NamesCount)
		{
			throw new InvalidOperationException("iterations>NamesCount");
		}
		if (_007B5483_007D == NamesCount)
		{
			return new Tlist<int>(items.Select((GSILocalPair _007B5510_007D) => _007B5510_007D.ID));
		}
		Tlist<int> tlist = new Tlist<int>();
		int totalItemsCount = GetTotalItemsCount();
		int num = 0;
		while (_007B5483_007D > 0)
		{
			int num2 = ((_007B5484_007D == -1) ? Rand.RangeInt(0, totalItemsCount) : HashHelper.greaterInt(_007B5484_007D + num++, totalItemsCount));
			for (int num3 = 0; num3 < items.Size; num3++)
			{
				if (num2 < items.Array[num3].Count)
				{
					if (!tlist.Contains(items.Array[num3].ID))
					{
						tlist.Add(in items.Array[num3].ID);
						_007B5483_007D--;
						break;
					}
				}
				else
				{
					num2 -= items.Array[num3].Count;
				}
			}
		}
		return tlist;
	}

	public int RandomName()
	{
		CheckProtection();
		return SelectRandomNames(1).First();
	}

	public GSI RandomCut(float _007B5485_007D, int _007B5486_007D = -1)
	{
		if (_007B5485_007D < 0f)
		{
			throw new ArgumentOutOfRangeException("RandomCut-cut");
		}
		CheckProtection();
		if (items.Size == 0)
		{
			return new GSI();
		}
		int num = ((_007B5486_007D == -1) ? Rand.Round(_007B5485_007D) : HashHelper.RoundRandHash(_007B5485_007D, -_007B5486_007D));
		int totalItemsCount = GetTotalItemsCount();
		if (num >= totalItemsCount)
		{
			GSI result = Clone();
			Clean();
			return result;
		}
		GSI gSI = new GSI();
		while (num > 0)
		{
			float num2 = ((_007B5486_007D == -1) ? Rand.Range(0f, totalItemsCount) : (HashHelper.greater(_007B5486_007D) * (float)totalItemsCount));
			float num3 = 0f;
			int num4 = 0;
			for (int i = 0; i < items.Size; i++)
			{
				float num5 = items.Array[i].Count;
				num3 += num5;
				if (num3 > num2)
				{
					num4 = i;
					break;
				}
			}
			GSILocalPair gSILocalPair = items.Array[num4];
			int num6 = Math.Min(gSILocalPair.Count, (_007B5486_007D == -1) ? Rand.RangeInt(1, num) : Math.Max(1, HashHelper.greaterInt(_007B5486_007D, num)));
			_007B5445_007D(gSILocalPair.ID, -num6);
			gSI._007B5445_007D(gSILocalPair.ID, num6);
			num -= num6;
			if (_007B5486_007D != -1)
			{
				_007B5486_007D++;
			}
		}
		Protect();
		gSI.Protect();
		return gSI;
	}

	public int? RandomNameOrDefault(Func<int, int, bool> _007B5487_007D)
	{
		CheckProtection();
		GSILocalPair gSILocalPair = items.Rand((GSILocalPair _007B5512_007D) => _007B5487_007D(_007B5512_007D.ID, _007B5512_007D.Count));
		if (gSILocalPair.ID == 0)
		{
			return null;
		}
		return gSILocalPair.ID;
	}

	private void _007B5488_007D(WriterExtern _007B5489_007D)
	{
		CheckProtection();
		if (items.Size >= 255)
		{
			_007B5489_007D.WriteByte(byte.MaxValue);
			_007B5489_007D.WriteStruct<short>((short)items.Size);
		}
		else
		{
			_007B5489_007D.WriteByte((byte)items.Size);
		}
		for (int i = 0; i < items.Size; i++)
		{
			GSILocalPair gSILocalPair = items.Array[i];
			byte b = (byte)((gSILocalPair.ID < 256 && gSILocalPair.Count < 256) ? 1 : ((gSILocalPair.ID < 256 && gSILocalPair.Count < 32767) ? 2 : ((gSILocalPair.ID >= 256) ? 4 : 3)));
			_007B5489_007D.WriteByte(b);
			switch (b)
			{
			case 1:
				_007B5489_007D.WriteByte((byte)gSILocalPair.ID);
				_007B5489_007D.WriteByte((byte)gSILocalPair.Count);
				break;
			case 2:
				_007B5489_007D.WriteByte((byte)gSILocalPair.ID);
				_007B5489_007D.WriteStruct<short>((short)gSILocalPair.Count);
				break;
			case 3:
				_007B5489_007D.WriteByte((byte)gSILocalPair.ID);
				_007B5489_007D.WriteStruct<int>(gSILocalPair.Count);
				break;
			default:
				_007B5489_007D.WriteStruct<int>(gSILocalPair.ID);
				_007B5489_007D.WriteStruct<int>(gSILocalPair.Count);
				break;
			}
		}
	}

	private void _007B5490_007D(WriterExtern _007B5491_007D)
	{
		byte b = _007B5491_007D.ReadByte();
		short num = b;
		if (b == byte.MaxValue)
		{
			_007B5491_007D.ReadStruct<short>(ref num);
		}
		items = new Tlist<GSILocalPair>(num);
		short _007B5427_007D3 = default(short);
		int _007B5427_007D2 = default(int);
		int _007B5426_007D = default(int);
		int _007B5427_007D = default(int);
		for (int i = 0; i < num; i++)
		{
			switch (_007B5491_007D.ReadByte())
			{
			case 1:
			{
				byte _007B5426_007D4 = _007B5491_007D.ReadByte();
				byte _007B5427_007D4 = _007B5491_007D.ReadByte();
				items.Array[i] = new GSILocalPair(_007B5426_007D4, _007B5427_007D4);
				break;
			}
			case 2:
			{
				byte _007B5426_007D3 = _007B5491_007D.ReadByte();
				_007B5491_007D.ReadStruct<short>(ref _007B5427_007D3);
				items.Array[i] = new GSILocalPair(_007B5426_007D3, _007B5427_007D3);
				break;
			}
			case 3:
			{
				byte _007B5426_007D2 = _007B5491_007D.ReadByte();
				_007B5491_007D.ReadStruct<int>(ref _007B5427_007D2);
				items.Array[i] = new GSILocalPair(_007B5426_007D2, _007B5427_007D2);
				break;
			}
			default:
				_007B5491_007D.ReadStruct<int>(ref _007B5426_007D);
				_007B5491_007D.ReadStruct<int>(ref _007B5427_007D);
				items.Array[i] = new GSILocalPair(_007B5426_007D, _007B5427_007D);
				break;
			}
		}
		items.Size = num;
		Protect();
	}

	public bool Equals(GSI _007B5492_007D)
	{
		if (_007B5492_007D == null || items.Size != _007B5492_007D.items.Size)
		{
			return false;
		}
		CheckProtection();
		_007B5492_007D.CheckProtection();
		for (int i = 0; i < items.Size; i++)
		{
			if (_007B5492_007D._007B5443_007D(items.Array[i].ID) != items.Array[i].Count)
			{
				return false;
			}
		}
		return true;
	}

	public static bool Equals(GSI _007B5493_007D, GSI _007B5494_007D)
	{
		if (_007B5493_007D == null && _007B5494_007D == _007B5493_007D)
		{
			return true;
		}
		if (_007B5493_007D == null || _007B5494_007D == null)
		{
			return false;
		}
		return _007B5493_007D.Equals(_007B5494_007D);
	}

	public static void PutDiff(GSI _007B5495_007D, GSI _007B5496_007D, out GSI _007B5497_007D, out GSI _007B5498_007D)
	{
		_007B5497_007D = new GSI();
		_007B5498_007D = new GSI();
		for (int i = 0; i < _007B5496_007D.items.Size; i++)
		{
			int iD = _007B5496_007D.items.Array[i].ID;
			_007B5497_007D[iD] = Math.Max(0, _007B5496_007D.items.Array[i].Count - _007B5495_007D[iD]);
		}
		for (int j = 0; j < _007B5495_007D.items.Size; j++)
		{
			int iD2 = _007B5495_007D.items.Array[j].ID;
			_007B5498_007D[iD2] = Math.Max(0, _007B5495_007D.items.Array[j].Count - _007B5496_007D[iD2]);
		}
	}

	public static string PutDiff(GSI _007B5499_007D, GSI _007B5500_007D)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (GSILocalEnumerablePair<ResourceInfo> item in (IEnumerable<GSILocalEnumerablePair<ResourceInfo>>)_007B5499_007D.ResourceInfo/*cast due to .constrained prefix*/)
		{
			int num = _007B5500_007D[item.Info.ID] - item.Count;
			if (num != 0)
			{
				stringBuilder.Append((num > 0) ? '+' : '-');
				stringBuilder.Append(Math.Abs(num));
				stringBuilder.Append('x');
				stringBuilder.Append(item.Info.Name);
				stringBuilder.Append(", ");
			}
		}
		foreach (GSILocalEnumerablePair<ResourceInfo> item2 in (IEnumerable<GSILocalEnumerablePair<ResourceInfo>>)_007B5500_007D.ResourceInfo/*cast due to .constrained prefix*/)
		{
			if (_007B5499_007D[item2.Info.ID] == 0)
			{
				stringBuilder.Append('+');
				stringBuilder.Append(item2.Count);
				stringBuilder.Append('x');
				stringBuilder.Append(item2.Info.Name);
				stringBuilder.Append(", ");
			}
		}
		return stringBuilder.ToString();
	}

	IEnumerator<GSILocalPair> IEnumerable<GSILocalPair>.GetEnumerator()
	{
		return new LocalEnumenator(this);
	}

	private IEnumerator _007B5501_007D()
	{
		return new LocalEnumenator(this);
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		//ILSpy generated this explicit interface implementation from .override directive in {5501}
		return this._007B5501_007D();
	}
}
