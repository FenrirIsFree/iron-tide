using System.Text;
using Common.Account;
using Common.Resources;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.PacketValues;

namespace Common.Game;

public struct AllyStateTransfer : IMPSerializable
{
	public CompressedShipPositionInfo Position;

	public byte Health;

	public int uID;

	public byte ShipClass;

	public string DisplayName;

	public CapturedShipShortInfo CapturedShipInfo;

	public int CapturedShipInfoId;

	public byte ActiveAvanpostRemainRespawns;

	public Bits8 Flags;

	public bool IsOneMap
	{
		get
		{
			return Flags[0];
		}
		set
		{
			Flags[0] = value;
		}
	}

	public bool IsOneGroup
	{
		get
		{
			return Flags[1];
		}
		set
		{
			Flags[1] = value;
		}
	}

	public bool IsInsidePort
	{
		get
		{
			return Flags[2];
		}
		set
		{
			Flags[2] = value;
		}
	}

	public bool IsActiveAvanpostShip
	{
		get
		{
			return Flags[3];
		}
		set
		{
			Flags[3] = value;
		}
	}

	public bool IsPeaceActivated
	{
		get
		{
			return Flags[4];
		}
		set
		{
			Flags[4] = value;
		}
	}

	public bool IsWaitingTrainingArena
	{
		get
		{
			return Flags[5];
		}
		set
		{
			Flags[5] = value;
		}
	}

	public string FetchName(GroupCommon _007B6021_007D)
	{
		if (ShipClass == byte.MaxValue)
		{
			NpcInfo npcInfo = Gameplay.NpcsInfo.FromID(CapturedShipInfoId);
			return "(NPS) " + npcInfo.NpcName;
		}
		if (_007B6021_007D == null)
		{
			return DisplayName;
		}
		GroupMemberInfo memberFromUID = _007B6021_007D.GetMemberFromUID(uID);
		return (memberFromUID == null) ? DisplayName : memberFromUID.Name;
	}

	public AllyStateTransfer(CapturedShipIntance _007B6022_007D)
	{
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		uID = 0;
		CapturedShipInfo = default(CapturedShipShortInfo);
		CapturedShipInfoId = 0;
		ActiveAvanpostRemainRespawns = 0;
		Flags = default(Bits8);
		DisplayName = "";
		Health = 0;
		Position = new CompressedShipPositionInfo(_007B6022_007D.SavedPosition, 0f);
		ShipClass = byte.MaxValue;
		IsOneMap = false;
		IsOneGroup = true;
		uID = -1;
		CapturedShipInfoId = _007B6022_007D.ReferenceNpcShipId;
		CapturedShipInfo = new CapturedShipShortInfo(1, _007B6022_007D.RepairsCount, _007B6022_007D.AmmoInHold[1], _007B6022_007D.AmmoInHold[6], _007B6022_007D.CurrentHoldLoad, null, _007B6022_007D.BehaviorMode)
		{
			TargetUID = _007B6022_007D.LastServerUid
		};
	}

	public AllyStateTransfer(bool _007B6023_007D, Npc _007B6024_007D, CapturedShipShortInfo _007B6025_007D)
	{
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		uID = 0;
		CapturedShipInfo = default(CapturedShipShortInfo);
		CapturedShipInfoId = 0;
		ActiveAvanpostRemainRespawns = 0;
		Flags = default(Bits8);
		DisplayName = "";
		Health = _007B6024_007D.UsedShip.CompressedHP;
		Position = new CompressedShipPositionInfo(_007B6024_007D.PositionClampedToMap, _007B6024_007D.Rotation);
		ShipClass = byte.MaxValue;
		IsOneMap = true;
		IsOneGroup = _007B6023_007D;
		uID = _007B6024_007D.uID;
		CapturedShipInfoId = _007B6024_007D.UsedShipNpc.Information.ID;
		CapturedShipInfo = _007B6025_007D;
	}

	public AllyStateTransfer(Player _007B6026_007D)
	{
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		uID = 0;
		CapturedShipInfo = default(CapturedShipShortInfo);
		CapturedShipInfoId = 0;
		ActiveAvanpostRemainRespawns = 0;
		Flags = default(Bits8);
		DisplayName = _007B6026_007D.AccountConnection.PlayerName;
		Health = (byte)((!_007B6026_007D.IsDestroyed) ? _007B6026_007D.UsedShip.CompressedHP : 0);
		Position = new CompressedShipPositionInfo(_007B6026_007D.PositionClampedToMap, _007B6026_007D.Rotation);
		ShipClass = (byte)_007B6026_007D.UsedShipPlayer.CraftFrom.Class;
		IsOneMap = true;
		IsOneGroup = true;
		IsInsidePort = _007B6026_007D.IsPortEntry;
		IsPeaceActivated = _007B6026_007D.AccountConnection.WorldFlag.IsPeaceMode();
		uID = _007B6026_007D.uID;
		CapturedShipInfo = default(CapturedShipShortInfo);
		CapturedShipInfoId = -1;
	}

	public AllyStateTransfer(Player _007B6027_007D, bool _007B6028_007D, bool _007B6029_007D, byte _007B6030_007D, bool _007B6031_007D)
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		uID = 0;
		CapturedShipInfo = default(CapturedShipShortInfo);
		CapturedShipInfoId = 0;
		ActiveAvanpostRemainRespawns = 0;
		Flags = default(Bits8);
		DisplayName = "";
		Position = new CompressedShipPositionInfo(_007B6027_007D.PositionClampedToMap, _007B6027_007D.Rotation);
		Health = (byte)((!_007B6027_007D.IsDestroyed) ? (_007B6027_007D.IsPortEntry ? byte.MaxValue : _007B6027_007D.UsedShip.CompressedHP) : 0);
		ShipClass = (byte)_007B6027_007D.UsedShipPlayer.CraftFrom.Class;
		IsOneMap = _007B6028_007D;
		IsOneGroup = true;
		IsInsidePort = _007B6027_007D.IsPortEntry;
		IsPeaceActivated = _007B6027_007D.AccountConnection.WorldFlag.IsPeaceMode();
		uID = _007B6027_007D.uID;
		CapturedShipInfo = default(CapturedShipShortInfo);
		CapturedShipInfoId = -1;
		IsActiveAvanpostShip = _007B6029_007D;
		ActiveAvanpostRemainRespawns = _007B6030_007D;
		IsWaitingTrainingArena = _007B6031_007D;
	}

	private void _007B6032_007D(WriterExtern _007B6033_007D)
	{
		_007B6033_007D.Write<CompressedShipPositionInfo>(ref Position);
		_007B6033_007D.WriteByte(Flags.Value);
		_007B6033_007D.WriteByte(Health);
		_007B6033_007D.Write(DisplayName, (Encoding)null);
		_007B6033_007D.WriteByte(ShipClass);
		_007B6033_007D.WriteStruct<int>(uID);
		_007B6033_007D.WriteStruct<int>(CapturedShipInfoId);
		if (CapturedShipInfoId != -1)
		{
			_007B6033_007D.Write<CapturedShipShortInfo>(ref CapturedShipInfo);
		}
		if (IsActiveAvanpostShip)
		{
			_007B6033_007D.WriteByte(ActiveAvanpostRemainRespawns);
		}
	}

	private void _007B6034_007D(WriterExtern _007B6035_007D)
	{
		_007B6035_007D.ReadIMPS_struct<CompressedShipPositionInfo>(ref Position);
		Flags.Value = _007B6035_007D.ReadByte();
		Health = _007B6035_007D.ReadByte();
		_007B6035_007D.ReadString(ref DisplayName, (Encoding)null);
		ShipClass = _007B6035_007D.ReadByte();
		_007B6035_007D.ReadStruct<int>(ref uID);
		_007B6035_007D.ReadStruct<int>(ref CapturedShipInfoId);
		if (CapturedShipInfoId != -1)
		{
			_007B6035_007D.ReadIMPS_struct<CapturedShipShortInfo>(ref CapturedShipInfo);
		}
		if (IsActiveAvanpostShip)
		{
			ActiveAvanpostRemainRespawns = _007B6035_007D.ReadByte();
		}
	}
}
