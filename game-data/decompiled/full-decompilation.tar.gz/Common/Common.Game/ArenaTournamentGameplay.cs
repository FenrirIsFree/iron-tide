using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using Common.Resources;
using CommonDataTypes;
using TheraEngine.Collections;

namespace Common.Game;

public static class ArenaTournamentGameplay
{
	[CompilerGenerated]
	private sealed class _003CGetRewards_003Ed__14 : IEnumerable<ArenaPlaceReward>, IEnumerable, IEnumerator<ArenaPlaceReward>, IEnumerator, IDisposable
	{
		private int _007B7064_007D;

		private ArenaPlaceReward _007B7065_007D;

		private int _007B7066_007D;

		private int _007B7067_007D;

		public int _003C_003E3__playersCount;

		private int _007B7068_007D;

		private int _007B7069_007D;

		private int _007B7070_007D;

		private int _007B7071_007D;

		ArenaPlaceReward IEnumerator<ArenaPlaceReward>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B7065_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B7065_007D;
			}
		}

		[DebuggerHidden]
		public _003CGetRewards_003Ed__14(int _007B7059_007D)
		{
			_007B7064_007D = _007B7059_007D;
			_007B7066_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B7060_007D()
		{
			_007B7064_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7060}
			this._007B7060_007D();
		}

		private bool _007B7061_007D()
		{
			switch (_007B7064_007D)
			{
			default:
				return false;
			case 0:
				_007B7064_007D = -1;
				_007B7068_007D = 1 + _007B7067_007D / 50;
				_007B7065_007D = new ArenaPlaceReward(0, _007B7068_007D - 1, usualFirstPlaceReward, RatingRewardId.Gold);
				_007B7064_007D = 1;
				return true;
			case 1:
				_007B7064_007D = -1;
				_007B7069_007D = Math.Min(_007B7067_007D, 1 + _007B7067_007D / 25);
				_007B7070_007D = Math.Min(_007B7067_007D, 1 + _007B7067_007D / 15);
				_007B7065_007D = new ArenaPlaceReward(_007B7068_007D, _007B7068_007D + _007B7069_007D - 1, usualSecoundPlaceReward, RatingRewardId.Silver);
				_007B7064_007D = 2;
				return true;
			case 2:
				_007B7064_007D = -1;
				_007B7065_007D = new ArenaPlaceReward(_007B7068_007D + _007B7069_007D, _007B7068_007D + _007B7069_007D + _007B7070_007D - 1, usualThirdPlaceReward, RatingRewardId.Bronze);
				_007B7064_007D = 3;
				return true;
			case 3:
				_007B7064_007D = -1;
				_007B7071_007D = 0;
				goto IL_0195;
			case 4:
				{
					_007B7064_007D = -1;
					goto IL_0186;
				}
				IL_0195:
				if (_007B7071_007D < _007B7067_007D)
				{
					if (_007B7071_007D > _007B7068_007D + _007B7069_007D + _007B7070_007D)
					{
						_007B7065_007D = new ArenaPlaceReward(_007B7071_007D, _007B7071_007D, usualLuckyPlaceReward, RatingRewardId.LuckyPlace);
						_007B7064_007D = 4;
						return true;
					}
					goto IL_0186;
				}
				return false;
				IL_0186:
				_007B7071_007D += 7;
				goto IL_0195;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7061}
			return this._007B7061_007D();
		}

		[DebuggerHidden]
		private void _007B7062_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7062}
			this._007B7062_007D();
		}

		[DebuggerHidden]
		IEnumerator<ArenaPlaceReward> IEnumerable<ArenaPlaceReward>.GetEnumerator()
		{
			_003CGetRewards_003Ed__14 _003CGetRewards_003Ed__;
			if (_007B7064_007D == -2 && _007B7066_007D == Environment.CurrentManagedThreadId)
			{
				_007B7064_007D = 0;
				_003CGetRewards_003Ed__ = this;
			}
			else
			{
				_003CGetRewards_003Ed__ = new _003CGetRewards_003Ed__14(0);
			}
			_003CGetRewards_003Ed__._007B7067_007D = _003C_003E3__playersCount;
			return _003CGetRewards_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B7063_007D()
		{
			return ((IEnumerable<ArenaPlaceReward>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7063}
			return this._007B7063_007D();
		}
	}

	public const int MinDisplayRating = 10;

	public const int ATPointsInitial = 80;

	public const int InitialLives = 3;

	public static readonly int[] rangsCycle = new int[3] { 3, 4, 5 };

	public static int[] ATPointsLeagues = new int[4] { 50, 150, 250, 350 };

	public static float MinRatingToHaveLuckyPlace = 10f;

	private static ComplexBonus usualFirstPlaceReward = new ComplexBonus
	{
		LegendaryFlagDays = 30,
		Items = new GSI().Exs(43, 30).Exs(37, 2000).Exs(67, 90),
		DesignElements = ArenaRewardsHelper.Wrap(Gameplay.DesignsInfo.Where((ShipDesignInfo _007B7054_007D) => _007B7054_007D.Category == ShipDesignCategory.Satellite)),
		RandomDesign = true,
		AchievementsServer = new Tlist<AchievementEnum>().AddFirst(AchievementEnum.ArenaTournamentGold),
		GuildConquerorBadgesServer = 7
	};

	private static ComplexBonus usualSecoundPlaceReward = new ComplexBonus
	{
		LegendaryFlagDays = 14,
		Items = new GSI().Exs(43, 20).Exs(37, 1500).Exs(67, 60),
		DesignElements = ArenaRewardsHelper.Wrap(Gameplay.DesignsInfo.Where((ShipDesignInfo _007B7055_007D) => _007B7055_007D.InShop && _007B7055_007D.Category == ShipDesignCategory.Decal2)),
		RandomDesign = true,
		AchievementsServer = new Tlist<AchievementEnum>().AddFirst(AchievementEnum.ArenaTournamentSilver),
		GuildConquerorBadgesServer = 5
	};

	private static ComplexBonus usualThirdPlaceReward = new ComplexBonus
	{
		LegendaryFlagDays = 7,
		Items = new GSI().Exs(43, 10).Exs(37, 1000).Exs(67, 30),
		DesignElements = ArenaRewardsHelper.Wrap(Gameplay.DesignsInfo.Where((ShipDesignInfo _007B7056_007D) => _007B7056_007D.InShop && _007B7056_007D.Category == ShipDesignCategory.Flag)),
		RandomDesign = true,
		AchievementsServer = new Tlist<AchievementEnum>().AddFirst(AchievementEnum.ArenaTournamentBronze),
		GuildConquerorBadgesServer = 3
	};

	private static ComplexBonus usualLuckyPlaceReward = new ComplexBonus
	{
		Items = new GSI().Exs(37, 400)
	};

	public static int GetLeagueIndex(float _007B7046_007D)
	{
		return ATPointsLeagues.Count((int _007B7057_007D) => _007B7046_007D >= (float)_007B7057_007D);
	}

	public static float GetPointsLossAmount(float _007B7047_007D, float _007B7048_007D)
	{
		int leagueIndex = GetLeagueIndex(_007B7047_007D);
		int leagueIndex2 = GetLeagueIndex(_007B7048_007D);
		return Math.Max(leagueIndex, leagueIndex2) switch
		{
			3 => 0.05f, 
			2 => 0.1f, 
			1 => 0.2f, 
			0 => 10f, 
			_ => 0.04f, 
		};
	}

	public static bool WillForgetLive(DateTime _007B7049_007D, float _007B7050_007D, float _007B7051_007D)
	{
		if (_007B7049_007D.DayOfWeek == DayOfWeek.Monday || _007B7049_007D.DayOfWeek == DayOfWeek.Tuesday || _007B7049_007D.DayOfWeek == DayOfWeek.Wednesday)
		{
			return false;
		}
		if (_007B7049_007D.DayOfWeek == DayOfWeek.Thursday || _007B7049_007D.DayOfWeek == DayOfWeek.Friday)
		{
			return _007B7050_007D + _007B7051_007D <= (float)ATPointsLeagues[0] && _007B7050_007D > (float)ATPointsLeagues[0];
		}
		for (int i = 0; i < ATPointsLeagues.Length; i++)
		{
			if (_007B7050_007D + _007B7051_007D <= (float)ATPointsLeagues[i] && _007B7050_007D > (float)ATPointsLeagues[i])
			{
				return true;
			}
		}
		return false;
	}

	public static ComplexBonus GetReward(RatingRewardId _007B7052_007D)
	{
		return _007B7052_007D switch
		{
			RatingRewardId.Gold => usualFirstPlaceReward, 
			RatingRewardId.Silver => usualSecoundPlaceReward, 
			RatingRewardId.Bronze => usualThirdPlaceReward, 
			RatingRewardId.LuckyPlace => usualLuckyPlaceReward, 
			_ => throw new NotSupportedException(), 
		};
	}

	[IteratorStateMachine(typeof(_003CGetRewards_003Ed__14))]
	public static IEnumerable<ArenaPlaceReward> GetRewards(int _007B7053_007D)
	{
		//yield-return decompiler failed: Method not found
		return new _003CGetRewards_003Ed__14(-2)
		{
			_003C_003E3__playersCount = _007B7053_007D
		};
	}
}
