using TheraEngine;

namespace Common.Game;

internal class Idea_Ship
{
	public MovementBehavior Movement;

	public WheelBehavior Wheel;

	public void Update(ref FrameTime _007B5217_007D)
	{
		ShipOperatingParameters _007B5216_007D = default(ShipOperatingParameters);
		Wheel.Update(ref _007B5217_007D, ref _007B5216_007D);
	}
}
