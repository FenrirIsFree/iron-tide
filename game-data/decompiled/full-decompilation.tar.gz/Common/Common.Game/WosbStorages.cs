using TheraEngine;

namespace Common.Game;

public static class WosbStorages
{
	public static readonly StorageLevelInfo[] Port = new StorageLevelInfo[7]
	{
		new StorageLevelInfo(50000, 0, GSI.Empty),
		new StorageLevelInfo(200000, 5000, GSI.Empty),
		new StorageLevelInfo(400000, 20000, GSI.Empty),
		new StorageLevelInfo(800000, 50000, GSI.Empty),
		new StorageLevelInfo(1200000, 100000, GSI.Empty),
		new StorageLevelInfo(1600000, 250000, GSI.Empty),
		new StorageLevelInfo(2000000, 0, new GSI().Exs(40, 1))
	};

	public static readonly RTI[] PersonalIsle = new RTI[2]
	{
		new RTI(50000),
		new RTI(500000)
	};

	public const int RentDurationDays = 14;

	public static readonly (RTI bonus, RTI goldCost)[] RentOptions = new(RTI, RTI)[7]
	{
		(100000, 5000),
		(200000, 12000),
		(400000, 25000),
		(800000, 50000),
		(1600000, 100000),
		(3200000, 250000),
		(6400000, 500000)
	};

	internal static int MigrateLevel_11_07_2025(int _007B4313_007D)
	{
		if (1 == 0)
		{
		}
		int result = _007B4313_007D switch
		{
			1 => 2, 
			2 => 3, 
			3 => 4, 
			4 => 5, 
			5 => 5, 
			_ => _007B4313_007D, 
		};
		if (1 == 0)
		{
		}
		return result;
	}
}
