using System;
using Common.Packets;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Game;

public class QuestsSerializedChanges : IMPSerializable
{
	public struct CompletedQuest : IMPSerializable
	{
		public int ID;

		public QuestInfo Info => Gameplay.QuestsInfo.FromID(ID);

		public CompletedQuest(int _007B7480_007D)
		{
			ID = _007B7480_007D;
		}

		public void Boxing(WriterExtern _007B7481_007D)
		{
			_007B7481_007D.WriteStruct<int>(ID);
		}

		public void Unboxing(WriterExtern _007B7482_007D)
		{
			_007B7482_007D.ReadStruct<int>(ref ID);
		}
	}

	public struct FailedChallenge : IMPSerializable
	{
		public int ID;

		public QuestAdditionalLimit Challenge;

		public FailedChallenge(int _007B7485_007D, QuestAdditionalLimit _007B7486_007D)
		{
			ID = _007B7485_007D;
			Challenge = _007B7486_007D;
		}

		public void Boxing(WriterExtern _007B7487_007D)
		{
			_007B7487_007D.WriteStruct<int>(ID);
			_007B7487_007D.WriteByte((byte)Challenge);
		}

		public void Unboxing(WriterExtern _007B7488_007D)
		{
			_007B7488_007D.ReadStruct<int>(ref ID);
			Challenge = (QuestAdditionalLimit)_007B7488_007D.ReadByte();
		}
	}

	public struct VisibleQuestRemove : IMPSerializable
	{
		public int ID;

		public QuestAction RemoveMode;

		public VisibleQuestRemove(int _007B7491_007D, QuestAction _007B7492_007D)
		{
			ID = _007B7491_007D;
			RemoveMode = _007B7492_007D;
		}

		public void Boxing(WriterExtern _007B7493_007D)
		{
			_007B7493_007D.WriteStruct<int>(ID);
			_007B7493_007D.WriteByte((byte)RemoveMode);
		}

		public void Unboxing(WriterExtern _007B7494_007D)
		{
			_007B7494_007D.ReadStruct<int>(ref ID);
			RemoveMode = (QuestAction)_007B7494_007D.ReadByte();
		}
	}

	public Tlist<CompletedQuest> CompletedQuests;

	public Tlist<int> FailedQuests;

	public Tlist<QuestRunningUpgrade> Progress;

	public Tlist<int> RemovedDisablesInteractive;

	public Tlist<VisibleQuestRemove> SeparateRemovalVisibleQuests;

	public Tlist<FailedChallenge> FailedChallenges;

	public QuestsSerializedChanges()
	{
		CompletedQuests = new Tlist<CompletedQuest>();
		FailedQuests = new Tlist<int>();
		Progress = new Tlist<QuestRunningUpgrade>();
		RemovedDisablesInteractive = new Tlist<int>();
		SeparateRemovalVisibleQuests = new Tlist<VisibleQuestRemove>();
		FailedChallenges = new Tlist<FailedChallenge>();
	}

	private void _007B7475_007D(WriterExtern _007B7476_007D)
	{
		if (CompletedQuests.Size > 255 || Progress.Size > 255)
		{
			throw new NotSupportedException("size StoryQuestsSerializedInteractiveChanges");
		}
		_007B7476_007D.WriteTlistStruct<CompletedQuest>(CompletedQuests);
		_007B7476_007D.WriteTlist(FailedQuests);
		_007B7476_007D.WriteTlistStruct<QuestRunningUpgrade>(Progress);
		_007B7476_007D.WriteTlist(RemovedDisablesInteractive);
		_007B7476_007D.WriteTlistStruct<VisibleQuestRemove>(SeparateRemovalVisibleQuests);
		_007B7476_007D.WriteTlistStruct<FailedChallenge>(FailedChallenges);
	}

	private void _007B7477_007D(WriterExtern _007B7478_007D)
	{
		_007B7478_007D.ReadTlistStruct<CompletedQuest>(out CompletedQuests);
		_007B7478_007D.ReadTlist(out FailedQuests);
		_007B7478_007D.ReadTlistStruct<QuestRunningUpgrade>(out Progress);
		_007B7478_007D.ReadTlist(out RemovedDisablesInteractive);
		_007B7478_007D.ReadTlistStruct<VisibleQuestRemove>(out SeparateRemovalVisibleQuests);
		_007B7478_007D.ReadTlistStruct<FailedChallenge>(out FailedChallenges);
	}
}
