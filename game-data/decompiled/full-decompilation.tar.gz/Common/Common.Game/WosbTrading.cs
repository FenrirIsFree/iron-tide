using System;
using System.Collections.Generic;
using System.Linq;
using Common.Account;
using Common.Data;
using Common.Resources;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Helpers;

namespace Common.Game;

public static class WosbTrading
{
	private static readonly int[] resourcesForTransferringBase = new int[8] { 1, 6, 10, 39, 21, 7, 12, 22 };

	public static int TradeOrderLifetime = 7;

	public static int TradeOrderLifetimeHolding = 14;

	public static readonly RTI CostGetAllAuctionData = new RTI(500);

	public const float TradingInSeaBetweenPlayersMaxDist = 13f;

	public static GSI PiratePortBuyCraftItems = new GSI().Exs(5, 1).Exs(29, 1).Exs(27, 1)
		.Exs(14, 1)
		.Exs(39, 1)
		.Exs(16, 1)
		.Exs(17, 1);

	public static readonly RTI RefreshTraderOffersByEscudoPrice = 4;

	public static readonly List<TraderOffer> PirateTrader = new List<TraderOffer>(26)
	{
		new TraderOffer(8, null, 1000),
		new TraderOffer(60, new TraderOffer.Resource(15, 1)),
		new TraderOffer(120, new TraderOffer.Resource(38, 1)),
		new TraderOffer(180, new TraderOffer.Resource(67, 1)),
		new TraderOffer(600, new TraderOffer.Resource(43, 1)),
		new TraderOffer(45, null, 0, 0, -1, 4),
		new TraderOffer(55, null, 0, 0, -1, 5),
		new TraderOffer(40, null, 0, 0, -1, 15),
		new TraderOffer(60, null, 0, 0, -1, 16),
		new TraderOffer(80, null, 0, 0, -1, 17),
		new TraderOffer(120, null, 0, 0, -1, 13),
		new TraderOffer(150, null, 0, 0, -1, 14),
		new TraderOffer(100, null, 0, 0, -1, 25),
		new TraderOffer(150, null, 0, 0, -1, 26),
		new TraderOffer(200, null, 0, 0, -1, 27),
		new TraderOffer(300, null, 0, 0, -1, 28),
		new TraderOffer(380, null, 0, 0, -1, 29),
		new TraderOffer(670, null, 0, 0, -1, 41),
		new TraderOffer(500, null, 0, 0, -1, 42),
		new TraderOffer(4500, null, 0, 0, 19),
		new TraderOffer(2200, null, 0, 0, 462),
		new TraderOffer(1450, null, 0, 0, 463),
		new TraderOffer(1800, null, 0, 0, 93),
		new TraderOffer(4500, null, 0, 0, 499),
		new TraderOffer(1800, null, 0, 0, 483),
		new TraderOffer(5800, null, 0, 0, 512)
	};

	public static readonly List<(int category, TraderOffer offer)> ArenaTrader = new List<(int, TraderOffer)>(80)
	{
		(1, new TraderOffer(4, new TraderOffer.Resource(1, 5, StorageAssetEnum.Powerup_DisplayOnly))),
		(1, new TraderOffer(8, new TraderOffer.Resource(2, 5, StorageAssetEnum.Powerup_DisplayOnly))),
		(1, new TraderOffer(12, new TraderOffer.Resource(7, 100, StorageAssetEnum.Ammo))),
		(1, new TraderOffer(12, null, 0, 0, -1, -1, _007B6857_007D: false, _007B6858_007D: false, 0, 100)),
		(1, new TraderOffer(12, null, 1000)),
		(1, new TraderOffer(70, new TraderOffer.Resource(37, 10))),
		(1, new TraderOffer(500, null, 0, 0, -1, -1, _007B6857_007D: false, _007B6858_007D: false, 2, 0, 0, 21)),
		(1, new TraderOffer(1200, null, 0, 0, 476)),
		(1, new TraderOffer(1200, null, 0, 0, 478)),
		(1, new TraderOffer(1200, null, 0, 0, 479)),
		(1, new TraderOffer(1200, null, 0, 0, 480)),
		(1, new TraderOffer(1200, null, 0, 0, 481)),
		(1, new TraderOffer(1200, null, 0, 0, 482)),
		(1, new TraderOffer(1200, null, 0, 0, 484)),
		(1, new TraderOffer(1200, null, 0, 0, 485)),
		(1, new TraderOffer(1200, null, 0, 0, 487)),
		(1, new TraderOffer(1200, null, 0, 0, 488)),
		(1, new TraderOffer(1200, null, 0, 0, 538)),
		(1, new TraderOffer(1200, null, 0, 0, 539)),
		(1, new TraderOffer(1200, null, 0, 0, 540)),
		(1, new TraderOffer(1200, null, 0, 0, 541)),
		(1, new TraderOffer(1200, null, 0, 0, 542)),
		(1, new TraderOffer(1200, null, 0, 0, 543)),
		(1, new TraderOffer(1200, null, 0, 0, 544)),
		(1, new TraderOffer(1200, null, 0, 0, 545)),
		(2, new TraderOffer(25, new TraderOffer.Resource(23, 10))),
		(2, new TraderOffer(40, new TraderOffer.Resource(40, 5, StorageAssetEnum.Powerup_DisplayOnly))),
		(2, new TraderOffer(80, new TraderOffer.Resource(15, 5, StorageAssetEnum.Powerup_DisplayOnly))),
		(2, new TraderOffer(80, new TraderOffer.Resource(30, 5, StorageAssetEnum.Powerup_DisplayOnly))),
		(2, new TraderOffer(100, new TraderOffer.Resource(31, 5, StorageAssetEnum.Powerup_DisplayOnly))),
		(2, new TraderOffer(100, new TraderOffer.Resource(5, 100, StorageAssetEnum.Ammo))),
		(2, new TraderOffer(250, new TraderOffer.Resource(15, 5))),
		(2, new TraderOffer(250, new TraderOffer.Resource(67, 1))),
		(2, new TraderOffer(1000, null, 0, 0, -1, -1, _007B6857_007D: false, _007B6858_007D: false, 4, 0, 0, 21)),
		(2, new TraderOffer(2500, null, 0, 0, 489)),
		(2, new TraderOffer(2500, null, 0, 0, 490)),
		(2, new TraderOffer(2500, null, 0, 0, 492)),
		(2, new TraderOffer(2500, null, 0, 0, 493)),
		(2, new TraderOffer(2500, null, 0, 0, 494)),
		(2, new TraderOffer(2500, null, 0, 0, 496)),
		(2, new TraderOffer(2500, null, 0, 0, 497)),
		(2, new TraderOffer(2500, null, 0, 0, 498)),
		(2, new TraderOffer(2500, null, 0, 0, 500)),
		(2, new TraderOffer(2500, null, 0, 0, 501)),
		(2, new TraderOffer(2500, null, 0, 0, 546)),
		(2, new TraderOffer(2500, null, 0, 0, 547)),
		(2, new TraderOffer(2500, null, 0, 0, 548)),
		(2, new TraderOffer(2500, null, 0, 0, 549)),
		(2, new TraderOffer(2500, null, 0, 0, 550)),
		(2, new TraderOffer(2500, null, 0, 0, 551)),
		(2, new TraderOffer(2500, null, 0, 0, 552)),
		(2, new TraderOffer(2500, null, 0, 0, 553)),
		(3, new TraderOffer(170, new TraderOffer.Resource(72, 100))),
		(3, new TraderOffer(500, new TraderOffer.Resource(43, 1))),
		(3, new TraderOffer(1500, null, 0, 0, -1, -1, _007B6857_007D: false, _007B6858_007D: false, 6, 0, 0, 21)),
		(3, new TraderOffer(2000, null, 0, 0, -1, -1, _007B6857_007D: false, _007B6858_007D: false, 0, 0, 7, 21)),
		(3, new TraderOffer(4000, null, 0, 0, 502)),
		(3, new TraderOffer(4000, null, 0, 0, 503)),
		(3, new TraderOffer(4000, null, 0, 0, 505)),
		(3, new TraderOffer(4000, null, 0, 0, 506)),
		(3, new TraderOffer(4000, null, 0, 0, 507)),
		(3, new TraderOffer(4000, null, 0, 0, 509)),
		(3, new TraderOffer(4000, null, 0, 0, 510)),
		(3, new TraderOffer(4000, null, 0, 0, 511)),
		(3, new TraderOffer(4000, null, 0, 0, 513)),
		(3, new TraderOffer(4000, null, 0, 0, 514)),
		(3, new TraderOffer(4000, null, 0, 0, 554)),
		(3, new TraderOffer(4000, null, 0, 0, 555)),
		(3, new TraderOffer(4000, null, 0, 0, 556)),
		(3, new TraderOffer(4000, null, 0, 0, 557)),
		(3, new TraderOffer(4000, null, 0, 0, 558)),
		(3, new TraderOffer(4000, null, 0, 0, 559)),
		(3, new TraderOffer(4000, null, 0, 0, 560)),
		(3, new TraderOffer(4000, null, 0, 0, 561)),
		(3, new TraderOffer(6000, new TraderOffer.Resource(40, 1), 0, 0, -1, -1, _007B6857_007D: false, _007B6858_007D: false, 0, 0, 0, 21)),
		(3, new TraderOffer(7100, null, 0, 0, 12)),
		(3, new TraderOffer(7100, null, 0, 0, 11)),
		(3, new TraderOffer(7100, null, 0, 0, 8)),
		(3, new TraderOffer(8500, null, 0, 0, 10)),
		(3, new TraderOffer(10000, null, 0, 0, 9))
	};

	internal static GSI waterMiddles => new GSI().Exs(5, 100000);

	internal static int GetResForTransferring(Vector2 _007B4314_007D, Sequence _007B4315_007D)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		EconomyRegion region = Gameplay.GetNearWorldRegion(in _007B4314_007D).ItemsEconomyReigion;
		WorldMapRegionInfo worldMapRegionInfo = Gameplay.WorldMap.RegionsInfo.FindNear(_007B4314_007D, (WorldMapRegionInfo _007B4360_007D) => (Vector2)((_007B4360_007D.ItemsEconomyReigion == EconomyRegion.None) ? new Vector2(100000f, 0f) : _007B4360_007D.CenterPos));
		if (region == EconomyRegion.None && _007B4315_007D.Chanse(33f))
		{
			region = worldMapRegionInfo.ItemsEconomyReigion;
		}
		ResourceInfo[] array = Gameplay.ItemsInfo.Where((ResourceInfo _007B4365_007D) => _007B4365_007D.IsTradingItem && _007B4365_007D.ID != 25 && !_007B4365_007D.TradingItemShouldBeOnIsle && (_007B4365_007D.TradingItemEconomyRegion == region || region == EconomyRegion.Center)).ToArray();
		if (array.Length != 0 && _007B4315_007D.Chanse(33f))
		{
			return _007B4315_007D.Pick(array).ID;
		}
		return _007B4315_007D.Pick(resourcesForTransferringBase);
	}

	public static bool AllowTradeOrderWith(IStorageAsset _007B4316_007D, IslePortInfo _007B4317_007D, bool _007B4318_007D)
	{
		if (_007B4316_007D.getType == StorageAssetEnum.SimpleItem)
		{
			short iD = ((IGameResource)_007B4316_007D).ID;
			if ((_007B4317_007D.LiveTrading[iD] > 0 && iD != 5) || iD == 68)
			{
				return false;
			}
			if (iD == 8)
			{
				return _007B4317_007D.Type == PortType.PirateBay || _007B4318_007D;
			}
		}
		if (_007B4316_007D is CannonGameInfo { CraftingType: ShipCannonCrafting.ByGold })
		{
			return false;
		}
		return true;
	}

	public static bool CanTradeWater(GuildCommon _007B4319_007D, FractionID _007B4320_007D)
	{
		return true;
	}

	public static bool AllowFreeTradeBetweenPlayers(ResourceInfo _007B4321_007D)
	{
		return !_007B4321_007D.IsRareItem;
	}

	public static bool AllowTradeByMonents(IStorageAsset _007B4322_007D)
	{
		return false;
	}

	public static Vector2 GetTradeMinAndMaxCost(IStorageAsset _007B4323_007D, bool _007B4324_007D)
	{
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0268: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_023b: Unknown result type (might be due to invalid IL or missing references)
		//IL_024c: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		if (_007B4323_007D.getType == StorageAssetEnum.SimpleItem)
		{
			short iD = ((IGameResource)_007B4323_007D).ID;
			float num = Gameplay.ItemsInfo.FromID(iD).MediumCost.Value;
			if (iD == 25)
			{
				((Vector2)(ref val))._002Ector(1f, 1000f);
			}
			if (iD == 37 || iD == 38 || iD == 15 || iD == 33 || iD == 40 || iD == 43 || iD == 5 || iD == 8 || iD == 69 || iD == 67)
			{
				((Vector2)(ref val))._002Ector(num * 1f, num * 30f);
			}
			else
			{
				switch (iD)
				{
				case 70:
					((Vector2)(ref val))._002Ector(num * 0.666f, num * 15f);
					break;
				case 23:
					((Vector2)(ref val))._002Ector(num * 1f, num * 40f);
					break;
				default:
					((Vector2)(ref val))._002Ector(num * 0.666f, num * 4f);
					break;
				}
			}
		}
		else if (_007B4323_007D.getType == StorageAssetEnum.Ammo)
		{
			CannonBallInfo cannonBallInfo = (CannonBallInfo)_007B4323_007D;
			((Vector2)(ref val))._002Ector((float)cannonBallInfo.ShopCostGold.Value * 0.666f, (float)cannonBallInfo.ShopCostGold.Value * 8f);
		}
		else if (_007B4323_007D.getType == StorageAssetEnum.Ship_DisplayOnly)
		{
			ProceduralShipInfo proceduralShipInfo = (ProceduralShipInfo)(object)_007B4323_007D;
			int num2 = proceduralShipInfo.ShipInfo.CraftCostDefault.TotalPrice() + proceduralShipInfo.ShipInfo.CraftCostDefaultGold.Value;
			((Vector2)(ref val))._002Ector(0.75f * (float)num2, 4f * (float)num2);
		}
		else
		{
			if (_007B4323_007D.getType != StorageAssetEnum.Cannon_DiplayOnly)
			{
				throw new NotSupportedException();
			}
			CannonGameInfo cannonGameInfo = (CannonGameInfo)_007B4323_007D;
			int value = cannonGameInfo.CostAsGold.Value;
			((Vector2)(ref val))._002Ector(0.75f * (float)value, 8f * (float)value);
		}
		Vector2 val2 = default(Vector2);
		((Vector2)(ref val2))._002Ector((float)Math.Max(1, (int)Math.Floor(val.X)), (float)(int)Math.Ceiling(val.Y));
		if (_007B4324_007D)
		{
			((Vector2)(ref val2))._002Ector(MathF.Floor(val2.X / 1000f), MathF.Ceiling(val2.Y / 100f) + 1f);
		}
		return val2;
	}

	public static float? HasHighTradingTax(IStorageAsset _007B4325_007D)
	{
		if (_007B4325_007D.getType == StorageAssetEnum.SimpleItem && (_007B4325_007D.ID == 69 || _007B4325_007D.ID == 37 || _007B4325_007D.ID == 38 || _007B4325_007D.ID == 40 || _007B4325_007D.ID == 33 || _007B4325_007D.ID == 15 || _007B4325_007D.ID == 43 || _007B4325_007D.ID == 67))
		{
			return 0.12f;
		}
		if (_007B4325_007D is CannonGameInfo { CraftingType: ShipCannonCrafting.NotAvailable })
		{
			return 0.1f;
		}
		return null;
	}

	public static float GetTradingTax(IslePortInfo _007B4326_007D, IStorageAsset _007B4327_007D, bool _007B4328_007D, bool _007B4329_007D)
	{
		float num = _007B4326_007D.InternalTradingTax;
		if (_007B4328_007D)
		{
			num *= 0.75f;
		}
		else if (_007B4329_007D)
		{
			num *= 2f;
		}
		else
		{
			float? num2 = HasHighTradingTax(_007B4327_007D);
			if (num2.HasValue)
			{
				num = Math.Max(num2.Value, num);
			}
		}
		return num;
	}

	public static float TradingInSeaBetweenPlayersTax()
	{
		return 0.07f;
	}

	internal static GSI GetPortMiddles(PortType _007B4330_007D, int _007B4331_007D = -1)
	{
		GSI gSI = new GSI().Exs(1, 400000).Exs(3, 150000).Exs(4, 150000)
			.Exs(2, 100000)
			.Exs(12, 60000)
			.Exs(22, 50000)
			.Exs(13, 40000)
			.Exs(11, 20000)
			.Exs(10, 20000)
			.Exs(34, 20000)
			.Exs(21, 20000);
		GSI gSI2 = new GSI();
		int[] portResIds = GetPortResIds(_007B4330_007D, _007B4331_007D);
		foreach (int num in portResIds)
		{
			gSI2.AddOrRemove(num, gSI[num]);
		}
		return gSI2;
	}

	private static int[] GetPortResIds(PortType _007B4332_007D, int _007B4333_007D = -1)
	{
		HashSet<int> hashSet = new HashSet<int>();
		hashSet.Add(1);
		hashSet.Add(13);
		switch (_007B4332_007D)
		{
		case PortType.PirateBay:
			hashSet.Add(4);
			hashSet.Add(12);
			hashSet.Add(2);
			hashSet.Add(22);
			break;
		case PortType.City:
			hashSet.Add(12);
			hashSet.Add(2);
			hashSet.Add(3);
			hashSet.Add(11);
			break;
		case PortType.Bay:
		case PortType.NeutralBay:
			hashSet.Add(3);
			hashSet.Add(10);
			hashSet.Add(2);
			hashSet.Add(21);
			break;
		}
		if (_007B4333_007D != -1)
		{
			hashSet.Add(_007B4333_007D);
		}
		return hashSet.ToArray();
	}

	public static GSI GetPortUniqueOffers(IslePortInfo _007B4334_007D)
	{
		GSI gSI = new GSI();
		EconomyRegion itemsEconomyReigion = Gameplay.GetNearWorldRegion(in _007B4334_007D.EntryPos).ItemsEconomyReigion;
		foreach (ResourceInfo item in Gameplay.ItemsInfo.Where((ResourceInfo _007B4361_007D) => (!_007B4361_007D.TradingItemShouldBeOnIsle && _007B4361_007D.IsTradingItem && _007B4361_007D.TradingItemEconomyRegion != EconomyRegion.None) || _007B4361_007D.ID == 25))
		{
			if (_007B4334_007D.IsArabPort && item.ID == 25)
			{
				continue;
			}
			if (item.ID == 25)
			{
				gSI[item.ID] = 10;
			}
			else if (Rand.Chanse(60f))
			{
				float num = 9000f * _007B4334_007D.Leveling * Rand.Range(0.7f, 1.3f);
				if (_007B4334_007D.LessGoodsTradingPage)
				{
					num *= 0.6f;
				}
				int _007B5442_007D = (int)Math.Ceiling(num / (float)item.MediumCost.Value / 100f) * 100;
				if (item.TradingItemEconomyRegion == itemsEconomyReigion)
				{
					gSI[item.ID] = _007B5442_007D;
				}
			}
		}
		return gSI;
	}

	internal static void GetPortOtherTrading(Vector2 _007B4335_007D, PortType _007B4336_007D, out GSI _007B4337_007D, out GSI _007B4338_007D)
	{
		//IL_02da: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f8: Unknown result type (might be due to invalid IL or missing references)
		_007B4337_007D = new GSI();
		_007B4338_007D = new GSI();
		_007B4337_007D.AddOrRemove(37, Gameplay.ItemsInfo.FromID(37).MediumCost.Value);
		_007B4337_007D.AddOrRemove(38, Gameplay.ItemsInfo.FromID(38).MediumCost.Value);
		_007B4337_007D.AddOrRemove(15, Gameplay.ItemsInfo.FromID(15).MediumCost.Value);
		_007B4337_007D.AddOrRemove(9, Gameplay.ItemsInfo.FromID(9).MediumCost.Value - 1);
		_007B4337_007D.AddOrRemove(34, Gameplay.ItemsInfo.FromID(34).MediumCost.Value - 1);
		_007B4337_007D.AddOrRemove(70, Gameplay.ItemsInfo.FromID(70).MediumCost.Value - 1);
		_007B4337_007D.AddOrRemove(43, Gameplay.ItemsInfo.FromID(43).MediumCost.Value);
		_007B4337_007D.AddOrRemove(67, Gameplay.ItemsInfo.FromID(67).MediumCost.Value);
		_007B4337_007D.AddOrRemove(68, Gameplay.ItemsInfo.FromID(68).MediumCost.Value);
		if (_007B4336_007D == PortType.PirateBay)
		{
			foreach (GSILocalEnumerablePair<ResourceInfo> item2 in (IEnumerable<GSILocalEnumerablePair<ResourceInfo>>)PiratePortBuyCraftItems.ResourceInfo/*cast due to .constrained prefix*/)
			{
				_007B4337_007D.AddOrRemove(item2.Info.ID, (item2.Info.ID == 5) ? (item2.Info.MediumCost.Value + 1) : ((int)Math.Max(item2.Info.MediumCost.Value + 1, 1.25f * (float)item2.Info.MediumCost.Value)));
			}
		}
		if (_007B4336_007D == PortType.PirateBay)
		{
			_007B4337_007D.AddOrRemove(8, Gameplay.ItemsInfo.FromID(8).MediumCost.Value - 2);
		}
		WorldMapRegionInfo nearWorldRegion = Gameplay.GetNearWorldRegion(in _007B4335_007D);
		foreach (ResourceInfo item in Gameplay.ItemsInfo.Where((ResourceInfo _007B4362_007D) => _007B4362_007D.IsTradingItem && _007B4362_007D.TradingItemEconomyRegion != EconomyRegion.None))
		{
			if (item.TradingItemEconomyRegion == nearWorldRegion.ItemsEconomyReigion)
			{
				_007B4337_007D.AddOrRemove(item.ID, item.MediumCost.Value);
				continue;
			}
			float num = Vector2.Distance(_007B4335_007D, Gameplay.WorldMap.Ports.FindNear(_007B4335_007D, (IslePortInfo _007B4366_007D) => (Vector2)((_007B4366_007D.NearRegion.ItemsEconomyReigion == item.TradingItemEconomyRegion) ? _007B4366_007D.EntryPos : new Vector2(100000f, 0f))).EntryPos);
			float val = Math.Min(1f, 2f * num / 14146.483f);
			val = Math.Max(0.14f, val);
			val = MathF.Pow(val, 1.3f);
			_007B4337_007D.AddOrRemove(item.ID, (item.ID == 25) ? item.MediumCost.Value : ((int)Math.Ceiling((float)item.MediumCost.Value * (1f + 0.69f * val))));
		}
	}

	public static TraderInSeaPoint GenerateArenaOffers()
	{
		int avgPricePerOrder = 1000;
		Tlist<TraderInSeaPoint.Offer> tlist = new Tlist<TraderInSeaPoint.Offer>(20);
		tlist.Add(offerHelper(StorageAssetEnum.Ammo, 1, Gameplay.BallsInfo.FromID(1).ShopCostGold.Value, _007B4351_007D: true));
		tlist.Add(offerHelper(StorageAssetEnum.Ammo, 3, Gameplay.BallsInfo.FromID(3).ShopCostGold.Value, _007B4351_007D: true));
		tlist.Add(offerHelper(StorageAssetEnum.Ammo, 4, Gameplay.BallsInfo.FromID(4).ShopCostGold.Value, _007B4351_007D: true));
		tlist.Add(offerHelper(StorageAssetEnum.Ammo, 6, Gameplay.BallsInfo.FromID(6).ShopCostGold.Value, _007B4351_007D: true));
		tlist.Add(offerHelper(StorageAssetEnum.PowderKeg, 1, Gameplay.PowderKegsInfo.FromID(1).ShopCostGold.Value, _007B4351_007D: true));
		tlist.Add(offerHelper(StorageAssetEnum.PowderKeg, 2, Gameplay.PowderKegsInfo.FromID(2).ShopCostGold.Value, _007B4351_007D: true));
		tlist.Add(offerHelper(StorageAssetEnum.Unit_DiplayOnly, 1, Gameplay.UnitsInfo.FromID(1).CostGold.Value, _007B4351_007D: true));
		tlist.Add(offerHelper(StorageAssetEnum.Unit_DiplayOnly, 4, Gameplay.UnitsInfo.FromID(4).CostGold.Value, _007B4351_007D: true));
		return new TraderInSeaPoint(tlist);
		int countHelper(int _007B4346_007D)
		{
			return (int)((float)(avgPricePerOrder / _007B4346_007D) * Rand.Range(0.7f, 1.3f));
		}
		TraderInSeaPoint.Offer offerHelper(StorageAssetEnum _007B4348_007D, int _007B4349_007D, int _007B4350_007D, bool _007B4351_007D)
		{
			int num = 0;
			float num2 = 0.2f;
			num = ((!_007B4351_007D) ? ((int)Math.Floor((float)_007B4350_007D * (1f - num2))) : ((int)Math.Ceiling((float)_007B4350_007D * (1f + num2))));
			return new TraderInSeaPoint.Offer(0, Gameplay.GetResource(_007B4349_007D, _007B4348_007D), countHelper(_007B4350_007D), _007B4351_007D ? (-num) : num);
		}
	}

	public static TraderInSeaPoint GenerateWanderingTraderOffers(NpcInfo _007B4339_007D, EventActionsPipelineBase _007B4340_007D)
	{
		int avgPricePerOrder = 800 + _007B4339_007D.Location.HzLevel * 200;
		Tlist<TraderInSeaPoint.Offer> tlist = new Tlist<TraderInSeaPoint.Offer>(10);
		GSI gSI = WosbNpcs.allowDropTraderRare().Clone().Exs(37, 4)
			.Exs(8, 3);
		if (_007B4339_007D.Descritpion == NpcType.Trader_Ferryman)
		{
			gSI.Exs(23, 4);
		}
		gSI[1] = 0;
		Tlist<int> tlist2 = gSI.RandomSelection(4);
		foreach (int item2 in (IEnumerable<int>)tlist2)
		{
			if (item2 == 37 || item2 == 23)
			{
				TraderInSeaPoint.Offer item = offerHelperExchange(StorageAssetEnum.SimpleItem, item2, 60, 34);
				item.CountAbs /= 3;
				tlist.Add(in item);
			}
			else
			{
				ResourceInfo resourceInfo = Gameplay.ItemsInfo.FromID(item2);
				tlist.Add(offerHelperExchange(StorageAssetEnum.SimpleItem, resourceInfo.ID, resourceInfo.MediumCost.Value, 34));
			}
		}
		tlist.Add(new TraderInSeaPoint.Offer(0, Gameplay.ItemsInfo.FromID(8), avgPricePerOrder / 50, Gameplay.ItemsInfo.FromID(8).MediumCost.Value));
		if (_007B4340_007D.EventCategoryAmount(EActionCaterory.RareTrader) > 0f)
		{
			foreach (GSILocalEnumerablePair<ResourceInfo> item3 in (IEnumerable<GSILocalEnumerablePair<ResourceInfo>>)GetPortMiddles(PortType.City).ResourceInfo/*cast due to .constrained prefix*/)
			{
				tlist.Add(new TraderInSeaPoint.Offer(0, item3.Info, avgPricePerOrder * 12 / item3.Info.MediumCost.Value, -item3.Info.MediumCost.Value)
				{
					OnceTradeMode = true
				});
			}
			ResourceInfo resourceInfo2 = Gameplay.ItemsInfo.FromID(67);
			tlist.Add(new TraderInSeaPoint.Offer(0, resourceInfo2, Rand.RangeInt(2, 5), (int)((float)resourceInfo2.MediumCost.Value * 2f)));
		}
		if (Rand.Chanse(25f))
		{
			tlist.Add(new TraderInSeaPoint.Offer(0, Gameplay.ItemsInfo.FromID(73), 1, -100, 34));
		}
		return new TraderInSeaPoint(tlist);
		int countHelper(int _007B4353_007D)
		{
			return (int)((float)(avgPricePerOrder / _007B4353_007D) * Rand.Range(0.7f, 1.3f));
		}
		TraderInSeaPoint.Offer offerHelperExchange(StorageAssetEnum _007B4355_007D, int _007B4356_007D, int _007B4357_007D, int _007B4358_007D)
		{
			return new TraderInSeaPoint.Offer(0, Gameplay.GetResource(_007B4356_007D, _007B4355_007D), countHelper(_007B4357_007D), -Math.Max(1, (int)Math.Round((float)_007B4357_007D / (float)Gameplay.ItemsInfo.FromID(_007B4358_007D).MediumCost.Value)), _007B4358_007D);
		}
	}

	public static TraderInSeaPoint GenerateTraderInSeaOffers(TraderInSeaPlaceInfo _007B4341_007D, PlayerAccount _007B4342_007D, int _007B4343_007D)
	{
		Random rand = new Random(_007B4343_007D);
		Random randMoreRandom = new Random(_007B4343_007D + (int)_007B4342_007D.SID);
		int num = ((_007B4341_007D.Type == TraderInSeaType.SmallVilage) ? 3 : ((_007B4341_007D.Type == TraderInSeaType.TraderInSea) ? 5 : 7));
		float avgPricePerOrder = ((_007B4341_007D.Type == TraderInSeaType.SmallVilage) ? 1400f : ((_007B4341_007D.Type == TraderInSeaType.TraderInSea) ? 4500f : 12000f));
		float maxPriceProfit = 1f / (float)(1 + num);
		avgPricePerOrder *= 0.5f + 0.5f * (float)_007B4341_007D.NearRegion.LevelInt / 4f;
		if (_007B4342_007D.TradingSubscriptionSec > 0f && (_007B4341_007D.Type == TraderInSeaType.SmallVilage || _007B4341_007D.Type == TraderInSeaType.TraderInSea))
		{
			avgPricePerOrder *= 2f;
		}
		float chanseOfGoodDeal = 50f;
		if (!Gameplay.WorldMap.IsInsideMap(in _007B4341_007D.Position))
		{
			chanseOfGoodDeal = 100f;
		}
		Tlist<TraderInSeaPoint.Offer> tlist = new Tlist<TraderInSeaPoint.Offer>(20);
		tlist.Add(offerHelper(_007B4368_007D: false, StorageAssetEnum.Ammo, 1, Gameplay.BallsInfo.FromID(1).ShopCostGold.Value, _007B4372_007D: true));
		tlist.Add(offerHelper(_007B4368_007D: false, StorageAssetEnum.Ammo, 4, Gameplay.BallsInfo.FromID(4).ShopCostGold.Value, _007B4372_007D: true));
		if (_007B4341_007D.Type != TraderInSeaType.SmallVilage)
		{
			tlist.Add(offerHelper(_007B4368_007D: false, StorageAssetEnum.Ammo, 2, Gameplay.BallsInfo.FromID(2).ShopCostGold.Value, _007B4372_007D: true));
			tlist.Add(offerHelper(_007B4368_007D: false, StorageAssetEnum.Ammo, 3, Gameplay.BallsInfo.FromID(3).ShopCostGold.Value, _007B4372_007D: true));
			tlist.Add(offerHelper(_007B4368_007D: false, StorageAssetEnum.Ammo, 6, Gameplay.BallsInfo.FromID(6).ShopCostGold.Value, _007B4372_007D: true));
			if (rand.NextDouble() <= 0.3)
			{
				tlist.Add(offerHelper(_007B4368_007D: false, StorageAssetEnum.Ammo, 8, Gameplay.BallsInfo.FromID(8).ShopCostGold.Value, _007B4372_007D: true));
			}
		}
		if (_007B4341_007D.Type == TraderInSeaType.SmallVilage)
		{
			UnitInfo unitInfo = Gameplay.UnitsInfo.First((UnitInfo _007B4363_007D) => _007B4363_007D.Type == UnitType.Sailor);
			tlist.Add(offerHelper(_007B4368_007D: false, StorageAssetEnum.Unit_DiplayOnly, unitInfo.ID, unitInfo.CostGold.Value, _007B4372_007D: true, _007B4373_007D: true));
		}
		else
		{
			UnitInfo[] array = Gameplay.UnitsInfo.Where((UnitInfo _007B4364_007D) => _007B4364_007D.Type == UnitType.Boarding).ToArray();
			UnitInfo unitInfo2 = array[rand.Next(0, array.Length)];
			tlist.Add(offerHelper(_007B4368_007D: false, StorageAssetEnum.Unit_DiplayOnly, unitInfo2.ID, unitInfo2.CostGold.Value, _007B4372_007D: true, _007B4373_007D: true));
		}
		if (_007B4341_007D.Type != TraderInSeaType.SmallVilage)
		{
			tlist.Add(offerHelper(_007B4368_007D: false, StorageAssetEnum.PowderKeg, 1, Gameplay.PowderKegsInfo.FromID(1).ShopCostGold.Value, _007B4372_007D: true));
			if (rand.NextDouble() <= 0.3)
			{
				tlist.Add(offerHelper(_007B4368_007D: false, StorageAssetEnum.PowderKeg, 2, Gameplay.PowderKegsInfo.FromID(2).ShopCostGold.Value, _007B4372_007D: true));
			}
		}
		else
		{
			TraderInSeaPoint.Offer item = offerHelper(_007B4368_007D: false, StorageAssetEnum.SimpleItem, 36, Gameplay.ItemsInfo.FromID(36).MediumCost.Value * 2, _007B4372_007D: true);
			item.CountAbs /= 2;
			tlist.Add(in item);
		}
		if (randMoreRandom.NextDouble() <= 0.18)
		{
			ResourceInfo _007B6812_007D = Gameplay.ItemsInfo.FromID(15);
			tlist.Add(new TraderInSeaPoint.Offer(0, _007B6812_007D, Rand.Round(5.5f + (float)_007B4341_007D.NearRegion.LevelInt), -5000));
		}
		GSI gSI = new GSI().Exs(10, 5).Exs(1, 4).Exs(3, 2)
			.Exs(2, 2)
			.Exs(4, 1)
			.Exs(6, 1);
		GSI gSI2 = new GSI().Exs(34, 1).Exs(7, 1).Exs(30, 1)
			.Exs(6, 1)
			.Exs(21, 1)
			.Exs(70, 1)
			.Exs(9, 1);
		IEnumerable<ResourceInfo> enumerable = Gameplay.ItemsInfo.Where((ResourceInfo _007B4374_007D) => _007B4374_007D.IsTradingItem && _007B4374_007D.TradingItemEconomyRegion == Gameplay.GetNearWorldRegion(in _007B4341_007D.Position).ItemsEconomyReigion);
		foreach (ResourceInfo item2 in enumerable)
		{
			gSI2.Exs(item2.ID, 1);
		}
		IslePortInfo nearPort = Gameplay.WorldMap.GetNearPort(in _007B4341_007D.Position);
		foreach (GSILocalPair item3 in (IEnumerable<GSILocalPair>)GetPortMiddles(nearPort.Type, nearPort.PbsManufacture?.ID ?? (-1)))
		{
			if (gSI2[item3.ID] == 0 && item3.ID != 4)
			{
				gSI2.Exs(item3.ID, 1);
			}
		}
		int num2 = HashHelper.RoundRandHash((float)num * 0.4f + 1f, rand.Next(0, 10000));
		int num3 = HashHelper.RoundRandHash((float)num * 0.6f, rand.Next(0, 10000));
		if (num2 > 0)
		{
			Tlist<int> tlist2 = gSI.RandomSelection(num2, rand.Next(0, 10000));
			foreach (int item4 in (IEnumerable<int>)tlist2)
			{
				ResourceInfo resourceInfo = Gameplay.ItemsInfo.FromID(item4);
				tlist.Add(offerHelper(_007B4368_007D: true, StorageAssetEnum.SimpleItem, resourceInfo.ID, resourceInfo.MediumCost.Value + ((resourceInfo.ID == 1 && rand.NextDouble() <= 0.75) ? 1 : 0), _007B4372_007D: true));
			}
		}
		if (num3 > 0)
		{
			Tlist<int> tlist3 = gSI2.RandomSelection(num3, rand.Next(0, 10000));
			foreach (int item5 in (IEnumerable<int>)tlist3)
			{
				ResourceInfo info = Gameplay.ItemsInfo.FromID(item5);
				if (tlist.Count((TraderInSeaPoint.Offer _007B4375_007D) => _007B4375_007D.Item == info) <= 0)
				{
					float num4 = maxPriceProfit;
					maxPriceProfit += (info.IsTradingItem ? 0.8f : 0.7f);
					ResourceInfo resourceInfo2 = Gameplay.ItemsInfo.FromID(item5);
					tlist.Add(offerHelper(_007B4368_007D: true, StorageAssetEnum.SimpleItem, resourceInfo2.ID, resourceInfo2.MediumCost.Value, _007B4372_007D: false));
					maxPriceProfit = num4;
				}
			}
		}
		tlist.Add(new TraderInSeaPoint.Offer(0, Gameplay.ItemsInfo.FromID(24), (int)(10f + avgPricePerOrder / 100f), Gameplay.ItemsInfo.FromID(24).MediumCost.Value));
		if (rand.NextDouble() <= 0.5)
		{
			int[] array2 = new int[4] { 17, 29, 14, 16 };
			int _007B3506_007D = array2[rand.Next(0, array2.Length)];
			tlist.Add(new TraderInSeaPoint.Offer(0, Gameplay.ItemsInfo.FromID(_007B3506_007D), (int)(4f + avgPricePerOrder / (float)Gameplay.ItemsInfo.FromID(_007B3506_007D).MediumCost.Value * 0.5f), -Math.Max(1, Gameplay.ItemsInfo.FromID(_007B3506_007D).MediumCost.Value / Gameplay.ItemsInfo.FromID(34).MediumCost.Value), 34));
		}
		return new TraderInSeaPoint(tlist);
		int countHelper(int _007B4367_007D)
		{
			return (int)(avgPricePerOrder / (float)_007B4367_007D * MathHelper.Lerp(0.7f, 1.3f, (float)randMoreRandom.NextDouble()));
		}
		TraderInSeaPoint.Offer offerHelper(bool _007B4368_007D, StorageAssetEnum _007B4369_007D, int _007B4370_007D, int _007B4371_007D, bool _007B4372_007D, bool _007B4373_007D = false)
		{
			int num5 = 0;
			num5 = (_007B4368_007D ? (((float)rand.Next(0, 100) < chanseOfGoodDeal) ? _007B4371_007D : ((!_007B4372_007D) ? ((int)Math.Ceiling((float)_007B4371_007D * (1f + maxPriceProfit))) : ((int)Math.Floor((float)_007B4371_007D * (1f - maxPriceProfit))))) : ((!_007B4372_007D) ? ((int)Math.Floor((float)_007B4371_007D * 0.8f)) : ((int)Math.Ceiling((float)_007B4371_007D * 1.2f))));
			int num6 = countHelper(_007B4371_007D);
			if (_007B4373_007D)
			{
				num6 *= 5;
			}
			if (_007B4369_007D == StorageAssetEnum.Unit_DiplayOnly)
			{
				num6 /= 4;
			}
			if (_007B4370_007D == 4)
			{
				num6 /= 2;
			}
			return new TraderInSeaPoint.Offer(0, Gameplay.GetResource(_007B4370_007D, _007B4369_007D), num6, _007B4372_007D ? (-num5) : num5);
		}
	}

	private static int upCost(int _007B4344_007D)
	{
		return Math.Max(_007B4344_007D + 1, _007B4344_007D + _007B4344_007D / 10);
	}

	private static int reduceCost(int _007B4345_007D)
	{
		return Math.Min(_007B4345_007D - 1, _007B4345_007D - _007B4345_007D / 7);
	}
}
