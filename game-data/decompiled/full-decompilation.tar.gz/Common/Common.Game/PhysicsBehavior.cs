namespace Common.Game;

internal class PhysicsBehavior
{
}
