using System;
using Common.Account;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class OneTimeBonus
{
	public struct AdditionBonus
	{
		public readonly string NameForInterface;

		public readonly Action<int, PlayerAccount> Apply;

		public readonly Func<PlayerAccount, bool> Validate;

		public AdditionBonus(string _007B6211_007D, Action<int, PlayerAccount> _007B6212_007D, Func<PlayerAccount, bool> _007B6213_007D)
		{
			NameForInterface = _007B6211_007D;
			Apply = _007B6212_007D;
			Validate = _007B6213_007D;
		}
	}

	public static readonly AdditionBonus[] AdditionBonusDictionary = new AdditionBonus[0];

	public int GoldBonus;

	public int XpBonusForComplete;

	public short AdditionBonusId;

	public int AdditionBonusCount;

	protected void WriteData(WriterExtern _007B6204_007D)
	{
		_007B6204_007D.WriteStruct<int>(ref GoldBonus);
		_007B6204_007D.WriteStruct<int>(ref XpBonusForComplete);
		_007B6204_007D.WriteStruct<short>(ref AdditionBonusId);
		_007B6204_007D.WriteStruct<int>(ref AdditionBonusCount);
	}

	protected void ReadData(WriterExtern _007B6205_007D)
	{
		_007B6205_007D.ReadStruct<int>(ref GoldBonus);
		_007B6205_007D.ReadStruct<int>(ref XpBonusForComplete);
		_007B6205_007D.ReadStruct<short>(ref AdditionBonusId);
		_007B6205_007D.ReadStruct<int>(ref AdditionBonusCount);
	}

	public virtual void Apply(PlayerAccount _007B6206_007D)
	{
		_007B6206_007D.Gold += GoldBonus;
		_007B6206_007D.AddXp(XpBonusForComplete);
		if (AdditionBonusId != -1 && AdditionBonusCount != 0 && AdditionBonusDictionary[AdditionBonusId].Validate(_007B6206_007D))
		{
			AdditionBonusDictionary[AdditionBonusId].Apply(AdditionBonusCount, _007B6206_007D);
		}
	}

	public bool ValidateAdditionBonusFor(PlayerAccount _007B6207_007D)
	{
		if (AdditionBonusId == -1 || AdditionBonusCount == 0)
		{
			return true;
		}
		return AdditionBonusDictionary[AdditionBonusId].Validate(_007B6207_007D);
	}
}
