using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;

namespace Common.Game;

public struct SingleShipCollisionData : IMPSerializable
{
	public int uID;

	public int SourceShipUID;

	public float Damage;

	public Vector2 PositionOffset;

	public float AngleOffset;

	public float SpeedAdd;

	public Vector3 CollisionPoint;

	public bool CorpusCrit;

	public bool MakeBurning;

	public bool SoftCollision;

	public bool UpgradeDestroyFloodingShip;

	private void _007B5218_007D(WriterExtern _007B5219_007D)
	{
		_007B5219_007D.WriteStruct<int>(ref uID);
		_007B5219_007D.WriteStruct<int>(ref SourceShipUID);
		_007B5219_007D.WriteStruct<float>(ref Damage);
		_007B5219_007D.WriteStruct<Vector2>(ref PositionOffset);
		_007B5219_007D.WriteStruct<float>(ref AngleOffset);
		_007B5219_007D.WriteStruct<float>(ref SpeedAdd);
		_007B5219_007D.WriteStruct<Vector3>(ref CollisionPoint);
		_007B5219_007D.Write(CorpusCrit);
		_007B5219_007D.Write(MakeBurning);
		_007B5219_007D.Write(SoftCollision);
		_007B5219_007D.Write(UpgradeDestroyFloodingShip);
	}

	private void _007B5220_007D(WriterExtern _007B5221_007D)
	{
		_007B5221_007D.ReadStruct<int>(ref uID);
		_007B5221_007D.ReadStruct<int>(ref SourceShipUID);
		_007B5221_007D.ReadStruct<float>(ref Damage);
		_007B5221_007D.ReadStruct<Vector2>(ref PositionOffset);
		_007B5221_007D.ReadStruct<float>(ref AngleOffset);
		_007B5221_007D.ReadStruct<float>(ref SpeedAdd);
		_007B5221_007D.ReadStruct<Vector3>(ref CollisionPoint);
		_007B5221_007D.ReadBoolean(ref CorpusCrit);
		_007B5221_007D.ReadBoolean(ref MakeBurning);
		_007B5221_007D.ReadBoolean(ref SoftCollision);
		_007B5221_007D.ReadBoolean(ref UpgradeDestroyFloodingShip);
	}
}
