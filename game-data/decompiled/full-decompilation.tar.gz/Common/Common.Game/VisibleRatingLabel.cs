using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct VisibleRatingLabel : IMPSerializable
{
	public string PlayerName;

	public uint AccuntSID;

	public float LastPoints;

	private void _007B6251_007D(WriterExtern _007B6252_007D)
	{
		_007B6252_007D.Write(PlayerName, (Encoding)null);
		_007B6252_007D.WriteStruct<uint>(ref AccuntSID);
		_007B6252_007D.WriteStruct<float>(ref LastPoints);
	}

	private void _007B6253_007D(WriterExtern _007B6254_007D)
	{
		_007B6254_007D.ReadString(ref PlayerName, (Encoding)null);
		_007B6254_007D.ReadStruct<uint>(ref AccuntSID);
		_007B6254_007D.ReadStruct<float>(ref LastPoints);
	}
}
