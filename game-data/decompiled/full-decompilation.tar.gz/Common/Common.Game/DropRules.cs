namespace Common.Game;

public enum DropRules
{
	Default,
	OnlyEngaged,
	OnlyEngagedOwnPart,
	OnlyEngagedOwnPartWithoutCombat,
	DefaultWithoutPeace
}
