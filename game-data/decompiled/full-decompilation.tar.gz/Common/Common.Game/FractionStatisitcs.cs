using TheraEngine.PacketValues;

namespace Common.Game;

public struct FractionStatisitcs
{
	public int GuildsCount;

	public Bits64 TotalPortsIds;

	public int TradersPortsCount;

	public int LegalPortsCount;

	public int SinkingsCount;

	public int WarPoints;
}
