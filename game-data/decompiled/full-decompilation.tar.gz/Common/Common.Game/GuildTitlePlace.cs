namespace Common.Game;

public enum GuildTitlePlace
{
	None,
	Gold,
	Silver,
	Bronze,
	Copper
}
