using Common.Account;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class MercanaryOrderTrackingInfo : IMPSerializable
{
	public MercanaryOrder Order;

	public bool IsTargetAvailable;

	public byte WorldRegionId;

	public MercanaryOrderTrackingInfo()
	{
	}

	public MercanaryOrderTrackingInfo(MercanaryOrder _007B8488_007D, Player _007B8489_007D)
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		Order = _007B8488_007D;
		if (_007B8489_007D == null)
		{
			IsTargetAvailable = false;
			return;
		}
		IsTargetAvailable = _007B8489_007D.MapInfo.IsWorldmap && !_007B8489_007D.IsPortEntry && !_007B8489_007D.AccountConnection.WorldFlag.IsPeaceMode();
		if (IsTargetAvailable)
		{
			WorldRegionId = (byte)Gameplay.WorldMap.GetNearWorldRegion(_007B8489_007D.Position).ID;
		}
	}

	public MercanaryOrderTrackingInfo(MercanaryOrder _007B8490_007D, bool _007B8491_007D, byte _007B8492_007D)
	{
		Order = _007B8490_007D;
		IsTargetAvailable = _007B8491_007D;
		WorldRegionId = _007B8492_007D;
	}

	private void _007B8493_007D(WriterExtern _007B8494_007D)
	{
		_007B8494_007D.WriteNoNull<MercanaryOrder>(Order);
		_007B8494_007D.Write(IsTargetAvailable);
		_007B8494_007D.WriteByte(WorldRegionId);
	}

	private void _007B8495_007D(WriterExtern _007B8496_007D)
	{
		_007B8496_007D.ReadIMPSNoNull<MercanaryOrder>(ref Order);
		_007B8496_007D.ReadBoolean(ref IsTargetAvailable);
		_007B8496_007D.ReadStruct<byte>(ref WorldRegionId);
	}

	public override string ToString()
	{
		string text = Order.GetTargetName(_007B8506_007D: true) + " +" + Order.PaymentForHeadToCustomer;
		if (Order.Target is MercanaryOrder.TargetPlayer)
		{
			text = (IsTargetAvailable ? (text + " (~" + Gameplay.WorldMap.RegionsInfo.Array[WorldRegionId].Name + ")") : (text + " " + Local.target_unavailable));
		}
		return text;
	}
}
