namespace Common.Game;

public class TimeConvertion
{
	public static float GetSceneSunValue(float _007B5759_007D)
	{
		float num = 0f;
		if (_007B5759_007D < -0.3f)
		{
			return 0f;
		}
		if (_007B5759_007D < 0f)
		{
			float num2 = (_007B5759_007D - -0.3f) / 0.3f;
			return num2 * 0.5f;
		}
		if (_007B5759_007D < 0.35f)
		{
			float num3 = (_007B5759_007D - 0f) / 0.35f;
			return 0.5f + num3 * 0.5f;
		}
		if (_007B5759_007D < 0.5f)
		{
			return 1f;
		}
		return 1f;
	}
}
