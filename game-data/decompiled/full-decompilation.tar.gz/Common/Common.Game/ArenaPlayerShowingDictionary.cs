using System.Collections.Generic;

namespace Common.Game;

public class ArenaPlayerShowingDictionary : Dictionary<uint, ArenaPlayerShowing>
{
	protected object syncRoot = new object();

	public ArenaPlayerShowingDictionary()
		: base(1000)
	{
	}

	public void Add(ArenaShowingProperty _007B6967_007D, float _007B6968_007D, string _007B6969_007D, uint _007B6970_007D, int _007B6971_007D)
	{
		lock (syncRoot)
		{
			if (TryGetValue(_007B6970_007D, out ArenaPlayerShowing value))
			{
				value.AddStat(_007B6967_007D, _007B6968_007D, _007B6971_007D);
				base[_007B6970_007D] = value;
				return;
			}
			value = new ArenaPlayerShowing();
			value.PlayerName = _007B6969_007D;
			value.ComputedServerReward = new Bonus(0f, 0);
			value.AddStat(_007B6967_007D, _007B6968_007D, _007B6971_007D);
			Add(_007B6970_007D, value);
		}
	}

	public float GetProperty(ArenaShowingProperty _007B6972_007D, uint _007B6973_007D)
	{
		lock (syncRoot)
		{
			if (TryGetValue(_007B6973_007D, out ArenaPlayerShowing value))
			{
				return value.GetStat(_007B6972_007D);
			}
			return 0f;
		}
	}
}
