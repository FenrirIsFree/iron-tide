using System;

namespace Common.Game;

public static class FractionDisputeHelper
{
	private static int kingshipDisputeNum => 3;

	public static FractionDisputeType DisputeType(this FractionID _007B8628_007D)
	{
		if (1 == 0)
		{
		}
		FractionDisputeType result = _007B8628_007D switch
		{
			FractionID.Antilia => FractionDisputeType.None, 
			FractionID.Espaniol => FractionDisputeType.Voting, 
			FractionID.KaiAndSeveria => FractionDisputeType.Kingship, 
			_ => FractionDisputeType.None, 
		};
		if (1 == 0)
		{
		}
		return result;
	}

	public static string GetDesc(this FractionDisputeType _007B8629_007D)
	{
		if (1 == 0)
		{
		}
		string result = _007B8629_007D switch
		{
			FractionDisputeType.None => Local.fraction_dispute_none, 
			FractionDisputeType.Voting => Local.fraction_dispute_voting, 
			FractionDisputeType.Kingship => Local.fraction_dispute_kingship(kingshipDisputeNum), 
			_ => throw new NotSupportedException(), 
		};
		if (1 == 0)
		{
		}
		return result;
	}

	public static int GetVotingWeight(FractionID _007B8630_007D, int _007B8631_007D, int _007B8632_007D)
	{
		if (_007B8630_007D.DisputeType() == FractionDisputeType.Kingship)
		{
			return 1;
		}
		return (int)MathF.Floor((float)(_007B8631_007D * _007B8632_007D) / 100f);
	}

	public static int GetNecessaryVotingWeight(FractionID _007B8633_007D, int _007B8634_007D, int _007B8635_007D)
	{
		if (_007B8633_007D.DisputeType() == FractionDisputeType.Kingship)
		{
			return kingshipDisputeNum;
		}
		return 3 + (int)MathF.Floor((float)GetVotingWeight(_007B8633_007D, _007B8634_007D, _007B8635_007D) * 3.5f);
	}

	public static bool CanMakeDispute(GuildCommon _007B8636_007D, FractionID _007B8637_007D)
	{
		FractionDisputeType fractionDisputeType = _007B8637_007D.DisputeType();
		return _007B8636_007D.Fraction == _007B8637_007D && fractionDisputeType != FractionDisputeType.None && (fractionDisputeType != FractionDisputeType.Kingship || KingshipTitleAllowVoting(_007B8636_007D.PotentialTitleId));
	}

	public static bool KingshipTitleAllowVoting(int _007B8638_007D)
	{
		if (_007B8638_007D == 0)
		{
			return false;
		}
		GuildTitlePlace place = Gameplay.GuildTitles[_007B8638_007D].Place;
		return (uint)(place - 1) <= 1u;
	}
}
