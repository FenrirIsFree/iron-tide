using System;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class UpgradeSlotsResearch : IMPSerializable
{
	private const int maxSlot = 3;

	public byte MaxOpenedSlotIndex;

	public int GainedXp;

	public bool IsEmpty => MaxOpenedSlotIndex == 0 && GainedXp == 0;

	public void AddXp(int _007B4843_007D, bool _007B4844_007D)
	{
		if (MaxOpenedSlotIndex < 3 && (MaxOpenedSlotIndex < 2 || _007B4844_007D))
		{
			GainedXp += _007B4843_007D;
		}
	}

	public void MakeUpgrade(int _007B4845_007D)
	{
		MaxOpenedSlotIndex = (byte)Math.Min(MaxOpenedSlotIndex + 1, 3);
		GainedXp = Math.Max(0, GainedXp - _007B4845_007D);
	}

	public void Boxing(WriterExtern _007B4846_007D)
	{
		_007B4846_007D.WriteByte(MaxOpenedSlotIndex);
		_007B4846_007D.WriteStruct<int>(GainedXp);
	}

	public void Unboxing(WriterExtern _007B4847_007D)
	{
		MaxOpenedSlotIndex = _007B4847_007D.ReadByte();
		_007B4847_007D.ReadStruct<int>(ref GainedXp);
	}

	public bool IsSlotOpened(int _007B4848_007D)
	{
		return MaxOpenedSlotIndex >= _007B4848_007D;
	}
}
