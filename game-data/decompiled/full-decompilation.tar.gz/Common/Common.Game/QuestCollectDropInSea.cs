namespace Common.Game;

public class QuestCollectDropInSea : QuestStepHeader
{
	public readonly int Count;

	public readonly DropModel? DropModel;

	public override int ProgressComparand => Count;

	public QuestCollectDropInSea(string _007B7563_007D, int _007B7564_007D, DropModel? _007B7565_007D = null)
		: base(_007B7563_007D)
	{
		Count = _007B7564_007D;
		DropModel = _007B7565_007D;
	}
}
