using System;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Game;

public class ServerGuildRatingCounter : IMPSerializable
{
	private struct Event : IMPSerializable
	{
		public byte ConquestBangesAdd;

		public DateTime StepKey;

		private void _007B6601_007D(WriterExtern _007B6602_007D)
		{
			_007B6602_007D.WriteByte(ConquestBangesAdd);
			_007B6602_007D.WriteStruct<long>(StepKey.Ticks);
		}

		private void _007B6603_007D(WriterExtern _007B6604_007D)
		{
			ConquestBangesAdd = _007B6604_007D.ReadByte();
			long ticks = default(long);
			_007B6604_007D.ReadStruct<long>(ref ticks);
			StepKey = new DateTime(ticks);
		}
	}

	public const byte RatingDays = 90;

	public const byte StepSize = 5;

	private Tlist<Event> _007B6600_007D = new Tlist<Event>();

	public int DebugEventsCount => _007B6600_007D.Size;

	public int ComputeRating(DateTime _007B6593_007D)
	{
		_007B6593_007D = new DateTime(_007B6593_007D.Year, _007B6593_007D.Month, _007B6593_007D.Day);
		int num = 0;
		for (int i = 0; i < _007B6600_007D.Size; i++)
		{
			Event obj = _007B6600_007D.Array[i];
			if (_007B6593_007D.Subtract(obj.StepKey).TotalDays > 90.0)
			{
				_007B6600_007D.RemoveAt(i);
				i--;
			}
			else
			{
				num += obj.ConquestBangesAdd;
			}
		}
		return num;
	}

	public int Add(DateTime _007B6594_007D, int _007B6595_007D)
	{
		int num = ComputeRating(_007B6594_007D);
		_007B6594_007D = new DateTime(_007B6594_007D.Year, _007B6594_007D.Month, _007B6594_007D.Day);
		if (_007B6600_007D.Size == 0 || _007B6594_007D.Subtract(_007B6600_007D.Array[_007B6600_007D.Size - 1].StepKey).TotalDays >= 5.0)
		{
			Tlist<Event> tlist = _007B6600_007D;
			Event item = new Event
			{
				ConquestBangesAdd = (byte)_007B6595_007D,
				StepKey = _007B6594_007D
			};
			tlist.Add(in item);
		}
		else
		{
			_007B6600_007D.Array[_007B6600_007D.Size - 1].ConquestBangesAdd = (byte)Math.Min(255, _007B6600_007D.Array[_007B6600_007D.Size - 1].ConquestBangesAdd + _007B6595_007D);
		}
		return num + _007B6595_007D;
	}

	private void _007B6596_007D(WriterExtern _007B6597_007D)
	{
		_007B6597_007D.WriteStruct<int>(_007B6600_007D.Size);
		for (int i = 0; i < _007B6600_007D.Size; i++)
		{
			_007B6597_007D.Write<Event>(ref _007B6600_007D.Array[i]);
		}
	}

	private void _007B6598_007D(WriterExtern _007B6599_007D)
	{
		int num = default(int);
		_007B6599_007D.ReadStruct<int>(ref num);
		_007B6600_007D = new Tlist<Event>(num);
		Event item = default(Event);
		for (int i = 0; i < num; i++)
		{
			_007B6599_007D.ReadIMPS_struct<Event>(ref item);
			_007B6600_007D.Add(in item);
		}
	}
}
