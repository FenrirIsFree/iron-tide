using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Game;

public class BattleResultsInfo : IMPSerializable
{
	public long ServerTime;

	public Tlist<BattleSingleInfo> PlayersInfo;

	private void _007B8683_007D(WriterExtern _007B8684_007D)
	{
		_007B8684_007D.WriteStruct<long>(ServerTime);
		_007B8684_007D.WriteTlistStruct<BattleSingleInfo>(PlayersInfo);
	}

	private void _007B8685_007D(WriterExtern _007B8686_007D)
	{
		_007B8686_007D.ReadStruct<long>(ref ServerTime);
		_007B8686_007D.ReadTlistStruct<BattleSingleInfo>(out PlayersInfo);
	}
}
