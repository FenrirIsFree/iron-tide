using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Account;
using Common.Data;
using Common.Resources;
using CommonDataTypes;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Game;

public class TraderInSeaPoint : IMPSerializable
{
	public struct Offer : IMPSerializable
	{
		public byte OfferId;

		public IStorageAsset Item;

		public int CountAbs;

		public ushort PriceID;

		public bool OnceTradeMode;

		private int _007B6820_007D;

		public bool IsPlayerBuy => _007B6820_007D < 0;

		public ResourceInfo PriceRes => Gameplay.ItemsInfo.FromID(PriceID);

		public int PriceWithSign(PlayerAccount _007B6810_007D)
		{
			return (_007B6820_007D < 0 && (Item.getType == StorageAssetEnum.Ammo || Item.getType == StorageAssetEnum.PowderKeg) && _007B6810_007D.CaptainSkills[PDynamicAccountBonus.BReduceCostTraderInSea] > 0) ? ((int)Math.Ceiling(Math.Min(_007B6820_007D + 1, (float)_007B6820_007D * 0.799f))) : _007B6820_007D;
		}

		public Offer(byte _007B6811_007D, IStorageAsset _007B6812_007D, int _007B6813_007D, int _007B6814_007D, int _007B6815_007D = 0)
		{
			OfferId = _007B6811_007D;
			Item = _007B6812_007D;
			CountAbs = _007B6813_007D;
			_007B6820_007D = _007B6814_007D;
			PriceID = (ushort)_007B6815_007D;
			OnceTradeMode = false;
		}

		private void _007B6816_007D(WriterExtern _007B6817_007D)
		{
			_007B6817_007D.WriteByte(OfferId);
			_007B6817_007D.WriteByte((byte)Item.ID);
			_007B6817_007D.WriteByte((byte)Item.getType);
			_007B6817_007D.WriteStruct<int>(_007B6820_007D);
			_007B6817_007D.WriteStruct<int>(CountAbs);
			_007B6817_007D.WriteStruct<ushort>(PriceID);
			_007B6817_007D.Write(OnceTradeMode);
		}

		private void _007B6818_007D(WriterExtern _007B6819_007D)
		{
			OfferId = _007B6819_007D.ReadByte();
			Item = Gameplay.GetResource(_007B6819_007D.ReadByte(), (StorageAssetEnum)_007B6819_007D.ReadByte());
			_007B6819_007D.ReadStruct<int>(ref _007B6820_007D);
			_007B6819_007D.ReadStruct<int>(ref CountAbs);
			_007B6819_007D.ReadStruct<ushort>(ref PriceID);
			_007B6819_007D.ReadBoolean(ref OnceTradeMode);
		}
	}

	[CompilerGenerated]
	private sealed class _003CEnumerate_003Ed__6 : IEnumerable<Offer>, IEnumerable, IEnumerator<Offer>, IEnumerator, IDisposable
	{
		private int _007B6829_007D;

		private Offer _007B6830_007D;

		private int _007B6831_007D;

		public TraderInSeaPoint _003C_003E4__this;

		private int _007B6832_007D;

		Offer IEnumerator<Offer>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B6830_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B6830_007D;
			}
		}

		[DebuggerHidden]
		public _003CEnumerate_003Ed__6(int _007B6824_007D)
		{
			_007B6829_007D = _007B6824_007D;
			_007B6831_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B6825_007D()
		{
			_007B6829_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {6825}
			this._007B6825_007D();
		}

		private bool _007B6826_007D()
		{
			switch (_007B6829_007D)
			{
			default:
				return false;
			case 0:
				_007B6829_007D = -1;
				_007B6832_007D = 0;
				break;
			case 1:
				_007B6829_007D = -1;
				_007B6832_007D++;
				break;
			}
			if (_007B6832_007D < _003C_003E4__this._007B6804_007D.Size)
			{
				_007B6830_007D = _003C_003E4__this._007B6804_007D.Array[_007B6832_007D];
				_007B6829_007D = 1;
				return true;
			}
			return false;
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {6826}
			return this._007B6826_007D();
		}

		[DebuggerHidden]
		private void _007B6827_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {6827}
			this._007B6827_007D();
		}

		[DebuggerHidden]
		IEnumerator<Offer> IEnumerable<Offer>.GetEnumerator()
		{
			_003CEnumerate_003Ed__6 result;
			if (_007B6829_007D == -2 && _007B6831_007D == Environment.CurrentManagedThreadId)
			{
				_007B6829_007D = 0;
				result = this;
			}
			else
			{
				result = new _003CEnumerate_003Ed__6(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			return result;
		}

		[DebuggerHidden]
		private IEnumerator _007B6828_007D()
		{
			return ((IEnumerable<Offer>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {6828}
			return this._007B6828_007D();
		}
	}

	public const float BDeprofit = 0.2f;

	private Tlist<Offer> _007B6804_007D;

	public int SomeParameter;

	public TraderInSeaPoint()
	{
	}

	public TraderInSeaPoint(Tlist<Offer> _007B6797_007D)
	{
		_007B6804_007D = _007B6797_007D;
		for (int i = 0; i < _007B6797_007D.Size; i++)
		{
			_007B6797_007D.Array[i].OfferId = (byte)i;
		}
	}

	[IteratorStateMachine(typeof(_003CEnumerate_003Ed__6))]
	public IEnumerable<Offer> Enumerate()
	{
		//yield-return decompiler failed: Method not found
		return new _003CEnumerate_003Ed__6(-2)
		{
			_003C_003E4__this = this
		};
	}

	public bool MakeOfferOrPartInSea(Player _007B6798_007D, Offer _007B6799_007D)
	{
		int num = _007B6804_007D.FindIndex((Offer _007B6822_007D) => _007B6822_007D.OfferId == _007B6799_007D.OfferId);
		if (num == -1)
		{
			return false;
		}
		ref Offer reference = ref _007B6804_007D.Array[num];
		if (_007B6799_007D.CountAbs > reference.CountAbs)
		{
			return false;
		}
		int num2 = _007B6799_007D.PriceWithSign(_007B6798_007D.AccountConnection);
		if (reference.PriceID == 0)
		{
			if (_007B6798_007D.AccountConnection.Gold + num2 * _007B6799_007D.CountAbs < 0)
			{
				return false;
			}
		}
		else if (_007B6798_007D.ResourcesOfHold[reference.PriceID] + num2 * _007B6799_007D.CountAbs < 0)
		{
			return false;
		}
		if (num2 > 0 && _007B6798_007D.UsedShipPlayer.GetItemsCountInHold(_007B6799_007D.Item) < _007B6799_007D.CountAbs)
		{
			return false;
		}
		if (_007B6799_007D.Item is ResourceInfo { IsMap: not false })
		{
			_007B6798_007D.AccountConnection.TreasuryMaps[_007B6799_007D.Item.ID] += -_007B6799_007D.CountAbs * Math.Sign(num2);
		}
		else
		{
			_007B6798_007D.UsedShipPlayer.AddOrRemoveItemsInHold(_007B6799_007D.Item, -_007B6799_007D.CountAbs * Math.Sign(num2));
		}
		if (reference.PriceID == 0)
		{
			_007B6798_007D.AccountConnection.Gold += num2 * _007B6799_007D.CountAbs;
		}
		else
		{
			_007B6798_007D.ResourcesOfHold[reference.PriceID] += num2 * _007B6799_007D.CountAbs;
		}
		reference.CountAbs -= _007B6799_007D.CountAbs;
		if (reference.OnceTradeMode)
		{
			_007B6804_007D.RemoveAll((Offer _007B6821_007D) => _007B6821_007D.OnceTradeMode);
		}
		else if (reference.CountAbs == 0)
		{
			_007B6804_007D.RemoveAt(num);
		}
		return true;
	}

	private void _007B6800_007D(WriterExtern _007B6801_007D)
	{
		_007B6801_007D.WriteTlistStruct<Offer>(_007B6804_007D);
		_007B6801_007D.WriteStruct<int>(SomeParameter);
	}

	private void _007B6802_007D(WriterExtern _007B6803_007D)
	{
		_007B6803_007D.ReadTlistStruct<Offer>(out _007B6804_007D);
		_007B6803_007D.ReadStruct<int>(ref SomeParameter);
	}
}
