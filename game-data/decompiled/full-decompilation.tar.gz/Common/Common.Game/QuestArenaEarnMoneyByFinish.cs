namespace Common.Game;

public class QuestArenaEarnMoneyByFinish : QuestStepHeader
{
	public readonly int Count;

	public override int ProgressComparand => Count;

	public QuestArenaEarnMoneyByFinish(string _007B7536_007D, int _007B7537_007D)
		: base(_007B7536_007D)
	{
		Count = _007B7537_007D;
	}
}
