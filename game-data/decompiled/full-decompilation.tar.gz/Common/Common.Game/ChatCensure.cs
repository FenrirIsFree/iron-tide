using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common.Game;

public static class ChatCensure
{
	private struct Entry
	{
		public string Key;

		public string[] Exceptions;

		public Entry(string _007B8055_007D, string[] _007B8056_007D)
		{
			Key = _007B8055_007D;
			Exceptions = _007B8056_007D;
		}
	}

	private static readonly string[] disableGuildTags;

	private static List<Entry> entries;

	private static Dictionary<char, bool> removeChars;

	public static string LastKey;

	public static bool ValidateGuildTag(string _007B8047_007D)
	{
		NormalizedString normalizedString = new NormalizedString(_007B8047_007D);
		string[] array = disableGuildTags;
		foreach (string obj in array)
		{
			if (default(NormalizedString).Equals(obj))
			{
				return false;
			}
		}
		return true;
	}

	public static string CapsFilter(string _007B8048_007D)
	{
		if (_007B8048_007D.Length < 8)
		{
			return _007B8048_007D;
		}
		int num = 0;
		foreach (char c in _007B8048_007D)
		{
			if (char.IsUpper(c))
			{
				num++;
			}
		}
		if (num < _007B8048_007D.Length / 2 + 2)
		{
			return _007B8048_007D;
		}
		return _007B8048_007D.ToLower();
	}

	private static void addEntry(string _007B8049_007D, params string[] _007B8050_007D)
	{
		entries.Add(new Entry(_007B8049_007D, _007B8050_007D));
	}

	static ChatCensure()
	{
		disableGuildTags = new string[16]
		{
			"хуй", "бля", "пзд", "пзц", "гей", "еба", "ебл", "ебт", "хер", "йух",
			"кал", "лох", "xui", "hui", "huy", "her"
		};
		entries = new List<Entry>();
		removeChars = new Dictionary<char, bool>();
		addEntry("хуй", "ихуй", "рахуй");
		addEntry("хуе", "ихуе", "хуех", "ерхуе");
		addEntry("хуя");
		addEntry("хуям");
		addEntry("куйня");
		addEntry("бля", "абля", "рбля", "блям", "робля", "рубля", "лобля", "ребля", "ибля", "орбля", "добля", "юбля", "блях", "бляш", "облял", "губля", "тубля", "ябля", "кобля", "мбля");
		addEntry("пизд");
		addEntry("пздц");
		addEntry("ебля", "ребля", "тебля", "мебля");
		addEntry("ебал", "тебал", "жебал", "лебал", "небал", "ребал", "себал", "оебал");
		addEntry("доебал");
		addEntry("ебат", "ребат", "дебат", "тебат", "лебат", "бебат", "себат", "небат", "ебата");
		addEntry("ебану", "гребану", "стеб");
		addEntry("ебанько");
		addEntry("ебнрот");
		addEntry("ебнрт");
		addEntry("гондон");
		addEntry("гандон");
		addEntry("еблуша");
		addEntry("ебантя");
		addEntry("еблан");
		addEntry("ебло", "ребло", "тебло", "еблок");
		addEntry("ебли", "ребли", "тебли", "бебли", "себли", "небли", "ближ", "еблин", "еблиз");
		addEntry("ебу", "небу", "ребу", "лебу", "тебу", "ебур", "чебу", "жебу", "ебуд", "кебу", "себу");
		addEntry("епать", "репать");
		addEntry("уеба");
		addEntry("уебок");
		addEntry("уебывай");
		addEntry("ебаны", "гребаны");
		addEntry("ебанны", "гребанны");
		addEntry("проеб");
		addEntry("наеб");
		addEntry("ебну", "шебну", "дебну", "лебну");
		addEntry("заебись");
		addEntry("заебал");
		addEntry("заебаты");
		addEntry("заебно");
		addEntry("долбаеб");
		addEntry("долбоеб");
		addEntry("далбаеб");
		addEntry("далбоеб");
		addEntry("ебтво");
		addEntry("епта", "ептал", "ептам", "цепта", "гепта", "септа", "ептан");
		addEntry("залуп");
		addEntry("пизд");
		addEntry("пездо");
		addEntry("пидр");
		addEntry("пидор");
		addEntry("педорас");
		addEntry("пидар", "ипидар");
		addEntry("шлюха");
		addEntry("мудак");
		addEntry("мудень");
		addEntry("залупа");
		addEntry("дрочь");
		addEntry("даун", "даунт");
		addEntry("х у й");
		addEntry("х уй");
		addEntry("ху й");
		addEntry(".!.");
		addEntry("_!_");
		addEntry(".|.");
		addEntry("слава украине");
		addEntry("fuck", "firefucking");
		addEntry("motherfuck");
		addEntry("fck");
		addEntry("fuk");
		addEntry("fucc");
		addEntry("fukin", "fuking");
		addEntry("mfck");
		addEntry("bullshit");
		addEntry("bitch", "abitchin");
		addEntry("b1tch");
		addEntry("cunt", "scunt");
		addEntry("dick", "dict", "dickey", "raddick", "murdock");
		addEntry("d1ck");
		addEntry("d!ck");
		addEntry("wank", "swanky", "wanaka");
		addEntry("wanker");
		addEntry("twat");
		addEntry("asshol");
		addEntry("bastard", "bastardo");
		addEntry("bollock", "bollocks", "bullock");
		addEntry("slut", "slutsky");
		addEntry("fagot");
		addEntry("gay", "gayle", "agay");
		addEntry("tranny");
		addEntry("shemale");
		addEntry("suck", "sucrose", "suckerfish");
		addEntry("blowjob");
		addEntry("handjob");
		addEntry("rimjob");
		addEntry("porn", "sporn");
		addEntry("porno");
		addEntry("anal", "analy", "anali");
		addEntry("vagina");
		addEntry("foreskin");
		addEntry("masturbat");
		addEntry("nigg");
		addEntry("wetback");
		addEntry("sandnigg");
		addEntry("retard");
		addEntry("mongol");
		addEntry("paki");
		addEntry("redskin");
		addEntry("tarbaby");
		addEntry("femboy");
		addEntry("whitetrash");
		addEntry("blackface");
		addEntry("puta", "putamen");
		addEntry("puto");
		addEntry("putita");
		addEntry("putear");
		addEntry("mierda");
		addEntry("pendej");
		addEntry("ching", "michigan");
		addEntry("chingada");
		addEntry("caralho");
		addEntry("merda");
		addEntry("buceta");
		addEntry("otario");
		addEntry("scheiß");
		addEntry("scheiB");
		addEntry("kurwa", "kurwan");
		addEntry("pierdol");
		addEntry("jebal");
		addEntry("jebac");
		addEntry("jebać");
		addEntry("skurwysyn");
		addEntry("dziwka");
		addEntry("씨발");
		addEntry("병신");
		addEntry("좆");
		addEntry("개새끼");
		addEntry("操你");
		addEntry("他妈");
		addEntry("傻逼");
		addEntry("鸡巴");
		addEntry("狗日");
		string text = "!@#$%^&*()[]{}-=_+|\\/~`';\"?.,<>№";
		string text2 = text;
		foreach (char key in text2)
		{
			removeChars.Add(key, value: true);
		}
	}

	public static bool CheckIsNormal(string _007B8051_007D)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (char c in _007B8051_007D)
		{
			char c2 = c;
			if (!removeChars.ContainsKey(c2))
			{
				switch (c2)
				{
				case 'y':
					c2 = 'у';
					break;
				case 'x':
					c2 = 'х';
					break;
				case 'i':
					c2 = 'й';
					break;
				case 'a':
					c2 = 'а';
					break;
				case '6':
					c2 = 'б';
					break;
				}
				stringBuilder.Append(c2);
			}
		}
		string text = stringBuilder.ToString().ToLower();
		foreach (Entry entry in entries)
		{
			LastKey = entry.Key;
			int num = text.IndexOf(entry.Key);
			if (num == -1)
			{
				continue;
			}
			bool flag = false;
			string[] exceptions = entry.Exceptions;
			foreach (string text2 in exceptions)
			{
				int num2 = Math.Max(0, num - (text2.Length - entry.Key.Length));
				int num3 = text.IndexOf(text2, num2, Math.Min(text.Length - num2, entry.Key.Length - 1 + text2.Length));
				if (num3 != -1)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				return false;
			}
		}
		return true;
	}

	public static bool CheatWordWarning(string _007B8052_007D)
	{
		string[] source = _007B8052_007D.ToLower().Replace('4', 'ч').Split(' ');
		return source.Any(delegate(string _007B8057_007D)
		{
			int result;
			switch (_007B8057_007D)
			{
			default:
				result = ((_007B8057_007D == "читеры") ? 1 : 0);
				break;
			case "чит":
			case "читы":
			case "cheat":
			case "читерство":
			case "читер":
				result = 1;
				break;
			}
			return (byte)result != 0;
		});
	}
}
