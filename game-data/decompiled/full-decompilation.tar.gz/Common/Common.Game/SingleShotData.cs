using Common.Resources;
using Microsoft.Xna.Framework;

namespace Common.Game;

public struct SingleShotData
{
	public int SenderUID;

	public float StartSightFactor;

	public CannonsAttackMode ShotMode;

	public CannonBallInfo BallInfo;

	public float StartDistance;

	public float BonusDistanceValue;

	public CannonBallExtraEffects Effects;

	public float FinalBallDamageFactorShips;

	public float FinalBallDamageFactorBuildings;

	public float FinalSailDamage;

	public float FinalCrewDamage;

	public float PenetrationBonus;

	public Vector3 BallServerCannonLocalPos;

	public Vector3 BallServerStartPos;

	public Vector3 BallNormal;

	public float BallFinalSpeed;

	public float BallFinalDistance;

	public float BallFinalCurve;

	public float BallWeaponPenetration;

	public int BallUID;
}
