namespace Common.Game;

public enum NpcIcon
{
	None,
	Star,
	Legendary2l,
	Legendary3l,
	Blades,
	Skull
}
