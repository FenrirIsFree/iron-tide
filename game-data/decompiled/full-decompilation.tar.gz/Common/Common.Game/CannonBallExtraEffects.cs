using System;

namespace Common.Game;

[Flags]
public enum CannonBallExtraEffects : byte
{
	None = 0,
	SingleShotBoostSkill = 1,
	PhosphorBoost = 2,
	BombershellBoos = 4,
	MoreFireAreaAndBurning = 8,
	ImprovedBackOrRearWeapons = 0x10,
	BuckshotDamage = 0x20,
	TowerSource = 0x40
}
