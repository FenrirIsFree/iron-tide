using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct FriendRequest : IMPSerializable
{
	public const int MaxFriends = 300;

	public const byte FlagsOnline = 1;

	public const byte FlagsRefferal = 2;

	public uint FromSID;

	public string CachedName;

	public byte Flags;

	public FriendRequest(uint _007B8387_007D, string _007B8388_007D, byte _007B8389_007D)
	{
		FromSID = _007B8387_007D;
		CachedName = _007B8388_007D;
		Flags = _007B8389_007D;
	}

	public void Boxing(WriterExtern _007B8390_007D)
	{
		_007B8390_007D.WriteStruct<uint>(FromSID);
		_007B8390_007D.Write(CachedName, (Encoding)null);
		_007B8390_007D.WriteByte(Flags);
	}

	public void Unboxing(WriterExtern _007B8391_007D)
	{
		_007B8391_007D.ReadStruct<uint>(ref FromSID);
		_007B8391_007D.ReadString(ref CachedName, (Encoding)null);
		Flags = _007B8391_007D.ReadByte();
	}
}
