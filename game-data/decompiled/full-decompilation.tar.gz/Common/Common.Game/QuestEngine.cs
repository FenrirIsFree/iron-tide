using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using Common.Account;
using Common.Packets;
using Common.Resources;
using CommonDataTypes;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Helpers;

namespace Common.Game;

public class QuestEngine : IMPSerializable
{
	public struct CompletedQuestArgs
	{
		public QuestInfo Info;

		public float FinalBonusMultiplier;

		public float BasicBonusMultiplier;

		public bool DisplayNextQuestWasOpened;

		public CompletedQuestArgs(QuestInfo _007B7348_007D, float _007B7349_007D, float _007B7350_007D, bool _007B7351_007D)
		{
			Info = _007B7348_007D;
			FinalBonusMultiplier = _007B7349_007D;
			BasicBonusMultiplier = _007B7350_007D;
			DisplayNextQuestWasOpened = _007B7351_007D;
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass59_0
	{
		public QuestInfo q;

		internal bool _003CGetAvailableQuests_003Eb__0(QuestRunningProgress _007B7371_007D)
		{
			return _007B7371_007D.Info.ID == q.ID;
		}

		internal bool _003CGetAvailableQuests_003Eb__1(QuestDisableInfo _007B7372_007D)
		{
			return _007B7372_007D.ID == q.ID;
		}

		internal bool _003CGetAvailableQuests_003Eb__2(QuestVisibleInfo _007B7373_007D)
		{
			return _007B7373_007D.ID == q.ID;
		}
	}

	[CompilerGenerated]
	private sealed class _003CEnumerateDisables_003Ed__41 : IEnumerable<QuestInfo>, IEnumerable, IEnumerator<QuestInfo>, IEnumerator, IDisposable
	{
		private int _007B7386_007D;

		private QuestInfo _007B7387_007D;

		private int _007B7388_007D;

		public QuestEngine _003C_003E4__this;

		private IEnumerator<QuestDisableInfo> _007B7389_007D;

		private QuestDisableInfo _007B7390_007D;

		QuestInfo IEnumerator<QuestInfo>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B7387_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B7387_007D;
			}
		}

		[DebuggerHidden]
		public _003CEnumerateDisables_003Ed__41(int _007B7380_007D)
		{
			_007B7386_007D = _007B7380_007D;
			_007B7388_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B7381_007D()
		{
			int num = _007B7386_007D;
			if (num == -3 || num == 1)
			{
				try
				{
				}
				finally
				{
					_007B7383_007D();
				}
			}
			_007B7389_007D = null;
			_007B7386_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7381}
			this._007B7381_007D();
		}

		private bool _007B7382_007D()
		{
			try
			{
				switch (_007B7386_007D)
				{
				default:
					return false;
				case 0:
					_007B7386_007D = -1;
					_007B7389_007D = ((IEnumerable<QuestDisableInfo>)_003C_003E4__this._007B7341_007D).GetEnumerator();
					_007B7386_007D = -3;
					break;
				case 1:
					_007B7386_007D = -3;
					break;
				}
				if (_007B7389_007D.MoveNext())
				{
					_007B7390_007D = _007B7389_007D.Current;
					_007B7387_007D = Gameplay.QuestsInfo.FromID(_007B7390_007D.ID);
					_007B7386_007D = 1;
					return true;
				}
				_007B7383_007D();
				_007B7389_007D = null;
				return false;
			}
			catch
			{
				//try-fault
				_007B7381_007D();
				throw;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7382}
			return this._007B7382_007D();
		}

		private void _007B7383_007D()
		{
			_007B7386_007D = -1;
			if (_007B7389_007D != null)
			{
				_007B7389_007D.Dispose();
			}
		}

		[DebuggerHidden]
		private void _007B7384_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7384}
			this._007B7384_007D();
		}

		[DebuggerHidden]
		IEnumerator<QuestInfo> IEnumerable<QuestInfo>.GetEnumerator()
		{
			_003CEnumerateDisables_003Ed__41 result;
			if (_007B7386_007D == -2 && _007B7388_007D == Environment.CurrentManagedThreadId)
			{
				_007B7386_007D = 0;
				result = this;
			}
			else
			{
				result = new _003CEnumerateDisables_003Ed__41(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			return result;
		}

		[DebuggerHidden]
		private IEnumerator _007B7385_007D()
		{
			return ((IEnumerable<QuestInfo>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7385}
			return this._007B7385_007D();
		}
	}

	[CompilerGenerated]
	private sealed class _003CEvaluteAndEnumerateDisables_003Ed__40 : IEnumerable<int>, IEnumerable, IEnumerator<int>, IEnumerator, IDisposable
	{
		private int _007B7397_007D;

		private int _007B7398_007D;

		private int _007B7399_007D;

		private int _007B7400_007D;

		public int _003C_003E3__daysLeft;

		public QuestEngine _003C_003E4__this;

		private int _007B7401_007D;

		private QuestInfo _007B7402_007D;

		int IEnumerator<int>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B7398_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B7398_007D;
			}
		}

		[DebuggerHidden]
		public _003CEvaluteAndEnumerateDisables_003Ed__40(int _007B7392_007D)
		{
			_007B7397_007D = _007B7392_007D;
			_007B7399_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B7393_007D()
		{
			_007B7402_007D = null;
			_007B7397_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7393}
			this._007B7393_007D();
		}

		private bool _007B7394_007D()
		{
			int num = _007B7397_007D;
			if (num != 0)
			{
				if (num != 1)
				{
					return false;
				}
				_007B7397_007D = -1;
				goto IL_00e3;
			}
			_007B7397_007D = -1;
			if (_007B7400_007D == 0)
			{
				return false;
			}
			_007B7401_007D = 0;
			goto IL_00fb;
			IL_00fb:
			if (_007B7401_007D < _003C_003E4__this._007B7341_007D.Size)
			{
				_007B7402_007D = Gameplay.QuestsInfo.FromID(_003C_003E4__this._007B7341_007D.Array[_007B7401_007D].ID);
				if (_003C_003E4__this._007B7341_007D.Array[_007B7401_007D].Evalute(_007B7400_007D))
				{
					_003C_003E4__this._007B7341_007D.FastRemoveAt(_007B7401_007D);
					_007B7401_007D--;
					_007B7398_007D = _007B7402_007D.ID;
					_007B7397_007D = 1;
					return true;
				}
				goto IL_00e3;
			}
			return false;
			IL_00e3:
			_007B7402_007D = null;
			_007B7401_007D++;
			goto IL_00fb;
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7394}
			return this._007B7394_007D();
		}

		[DebuggerHidden]
		private void _007B7395_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7395}
			this._007B7395_007D();
		}

		[DebuggerHidden]
		IEnumerator<int> IEnumerable<int>.GetEnumerator()
		{
			_003CEvaluteAndEnumerateDisables_003Ed__40 _003CEvaluteAndEnumerateDisables_003Ed__;
			if (_007B7397_007D == -2 && _007B7399_007D == Environment.CurrentManagedThreadId)
			{
				_007B7397_007D = 0;
				_003CEvaluteAndEnumerateDisables_003Ed__ = this;
			}
			else
			{
				_003CEvaluteAndEnumerateDisables_003Ed__ = new _003CEvaluteAndEnumerateDisables_003Ed__40(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			_003CEvaluteAndEnumerateDisables_003Ed__._007B7400_007D = _003C_003E3__daysLeft;
			return _003CEvaluteAndEnumerateDisables_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B7396_007D()
		{
			return ((IEnumerable<int>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7396}
			return this._007B7396_007D();
		}
	}

	[CompilerGenerated]
	private sealed class _003CGetAvailableQuests_003Ed__59 : IEnumerable<QuestInfo>, IEnumerable, IEnumerator<QuestInfo>, IEnumerator, IDisposable
	{
		private int _007B7410_007D;

		private QuestInfo _007B7411_007D;

		private int _007B7412_007D;

		private IslePortInfo _007B7413_007D;

		public IslePortInfo _003C_003E3__port;

		private Player _007B7414_007D;

		public Player _003C_003E3__player;

		public QuestEngine _003C_003E4__this;

		private PlayerAccount _007B7415_007D;

		private Sequence _007B7416_007D;

		private bool _007B7417_007D;

		private IEnumerator<QuestInfo> _007B7418_007D;

		private _003C_003Ec__DisplayClass59_0 _007B7419_007D;

		private QuestTransferOrder _007B7420_007D;

		QuestInfo IEnumerator<QuestInfo>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B7411_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B7411_007D;
			}
		}

		[DebuggerHidden]
		public _003CGetAvailableQuests_003Ed__59(int _007B7404_007D)
		{
			_007B7410_007D = _007B7404_007D;
			_007B7412_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B7405_007D()
		{
			int num = _007B7410_007D;
			if (num == -3 || num == 1)
			{
				try
				{
				}
				finally
				{
					_007B7407_007D();
				}
			}
			_007B7415_007D = null;
			_007B7416_007D = null;
			_007B7418_007D = null;
			_007B7419_007D = null;
			_007B7420_007D = null;
			_007B7410_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7405}
			this._007B7405_007D();
		}

		private bool _007B7406_007D()
		{
			try
			{
				int num = _007B7410_007D;
				if (num != 0)
				{
					if (num != 1)
					{
						return false;
					}
					_007B7410_007D = -3;
					goto IL_0210;
				}
				_007B7410_007D = -1;
				_007B7415_007D = _007B7414_007D.AccountConnection;
				_007B7416_007D = new Sequence(_007B7415_007D.Xp + _003C_003E4__this._007B7343_007D.Size * _003C_003E4__this._007B7343_007D.Size * 10 + _007B7415_007D.Gold * 13);
				_007B7417_007D = _007B7415_007D.CaptainSkills[PDynamicAccountBonus.BTradeQuestSmuggling] > 0;
				_007B7418_007D = ((IEnumerable<QuestInfo>)Gameplay.QuestsInfo).GetEnumerator();
				_007B7410_007D = -3;
				goto IL_021f;
				IL_0210:
				_007B7420_007D = null;
				_007B7419_007D = null;
				goto IL_021f;
				IL_021f:
				if (_007B7418_007D.MoveNext())
				{
					_007B7419_007D = new _003C_003Ec__DisplayClass59_0();
					_007B7419_007D.q = _007B7418_007D.Current;
					if (_007B7419_007D.q.LocationPort != null && _007B7419_007D.q.LocationPort.PortID == _007B7413_007D.PortID && _003C_003E4__this._007B7342_007D.Count((QuestRunningProgress _007B7371_007D) => _007B7371_007D.Info.ID == _007B7419_007D.q.ID) == 0 && _003C_003E4__this._007B7341_007D.Count((QuestDisableInfo _007B7372_007D) => _007B7372_007D.ID == _007B7419_007D.q.ID) == 0 && _003C_003E4__this._007B7343_007D.Count((QuestVisibleInfo _007B7373_007D) => _007B7373_007D.ID == _007B7419_007D.q.ID) == 0)
					{
						QuestStepHeader firstStep = _007B7419_007D.q.FirstStep;
						_007B7420_007D = firstStep as QuestTransferOrder;
						if ((_007B7420_007D == null || !_007B7420_007D.IsSmuggling || _007B7417_007D) && _007B7415_007D.Rang >= _007B7419_007D.q.MinimalRank)
						{
							_007B7411_007D = _007B7419_007D.q;
							_007B7410_007D = 1;
							return true;
						}
					}
					goto IL_0210;
				}
				_007B7407_007D();
				_007B7418_007D = null;
				return false;
			}
			catch
			{
				//try-fault
				_007B7405_007D();
				throw;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7406}
			return this._007B7406_007D();
		}

		private void _007B7407_007D()
		{
			_007B7410_007D = -1;
			if (_007B7418_007D != null)
			{
				_007B7418_007D.Dispose();
			}
		}

		[DebuggerHidden]
		private void _007B7408_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7408}
			this._007B7408_007D();
		}

		[DebuggerHidden]
		IEnumerator<QuestInfo> IEnumerable<QuestInfo>.GetEnumerator()
		{
			_003CGetAvailableQuests_003Ed__59 _003CGetAvailableQuests_003Ed__;
			if (_007B7410_007D == -2 && _007B7412_007D == Environment.CurrentManagedThreadId)
			{
				_007B7410_007D = 0;
				_003CGetAvailableQuests_003Ed__ = this;
			}
			else
			{
				_003CGetAvailableQuests_003Ed__ = new _003CGetAvailableQuests_003Ed__59(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			_003CGetAvailableQuests_003Ed__._007B7413_007D = _003C_003E3__port;
			_003CGetAvailableQuests_003Ed__._007B7414_007D = _003C_003E3__player;
			return _003CGetAvailableQuests_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B7409_007D()
		{
			return ((IEnumerable<QuestInfo>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7409}
			return this._007B7409_007D();
		}
	}

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private Action<QuestInfo> _007B7336_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private Action<QuestInfo> _007B7337_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private Action<CompletedQuestArgs> _007B7338_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private Action<QuestInfo, QuestRunningProgress, bool> _007B7339_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private Action _007B7340_007D;

	private Tlist<QuestDisableInfo> _007B7341_007D;

	private Tlist<QuestRunningProgress> _007B7342_007D;

	private Tlist<QuestVisibleInfo> _007B7343_007D;

	public static float FineForFailedTime = 0.7f;

	public Tlist<QuestRunningProgress> ProgressRunningQuests => _007B7342_007D;

	public Tlist<QuestVisibleInfo> VisibleQuests => _007B7343_007D;

	public int RunningQuestsCount => _007B7342_007D.Count((QuestRunningProgress _007B7352_007D) => _007B7352_007D.Info.CountToLimit);

	public int VisibleQuestsCount => _007B7343_007D.Count((QuestVisibleInfo _007B7353_007D) => !_007B7353_007D.WasHidden);

	public bool HasWorldQuests => _007B7342_007D.Contains((QuestRunningProgress _007B7354_007D) => _007B7354_007D.Info.LocationPort != null);

	public bool HasBoardingQuests => _007B7342_007D.Contains(delegate(QuestRunningProgress _007B7355_007D)
	{
		QuestBoardingShip questBoardingShip = _007B7355_007D.Info.FirstStep as QuestBoardingShip;
		return questBoardingShip != null || _007B7355_007D.Info.FirstStep is QuestCaptureNpc || (_007B7355_007D.Info.FirstStep is QuestEducationFlag questEducationFlag && questEducationFlag.Conditions.Any((QuestEducationFlag.Item _007B7356_007D) => _007B7356_007D.Marker == EducationOnboarding.GameTT_CaptureShip));
	});

	public bool ShowSmugglingIcon => _007B7342_007D.Contains((QuestRunningProgress _007B7357_007D) => _007B7357_007D.Info.FirstStep is QuestTransferOrder questTransferOrder && questTransferOrder.IsSmuggling);

	public event Action<QuestInfo> OnRunQuest
	{
		[CompilerGenerated]
		add
		{
			Action<QuestInfo> action = _007B7336_007D;
			Action<QuestInfo> action2;
			do
			{
				action2 = action;
				Action<QuestInfo> value2 = (Action<QuestInfo>)Delegate.Combine(action2, value);
				action = Interlocked.CompareExchange(ref _007B7336_007D, value2, action2);
			}
			while ((object)action != action2);
		}
		[CompilerGenerated]
		remove
		{
			Action<QuestInfo> action = _007B7336_007D;
			Action<QuestInfo> action2;
			do
			{
				action2 = action;
				Action<QuestInfo> value2 = (Action<QuestInfo>)Delegate.Remove(action2, value);
				action = Interlocked.CompareExchange(ref _007B7336_007D, value2, action2);
			}
			while ((object)action != action2);
		}
	}

	public event Action<QuestInfo> OnFailQuest
	{
		[CompilerGenerated]
		add
		{
			Action<QuestInfo> action = _007B7337_007D;
			Action<QuestInfo> action2;
			do
			{
				action2 = action;
				Action<QuestInfo> value2 = (Action<QuestInfo>)Delegate.Combine(action2, value);
				action = Interlocked.CompareExchange(ref _007B7337_007D, value2, action2);
			}
			while ((object)action != action2);
		}
		[CompilerGenerated]
		remove
		{
			Action<QuestInfo> action = _007B7337_007D;
			Action<QuestInfo> action2;
			do
			{
				action2 = action;
				Action<QuestInfo> value2 = (Action<QuestInfo>)Delegate.Remove(action2, value);
				action = Interlocked.CompareExchange(ref _007B7337_007D, value2, action2);
			}
			while ((object)action != action2);
		}
	}

	public event Action<CompletedQuestArgs> OnCompleteQuest
	{
		[CompilerGenerated]
		add
		{
			Action<CompletedQuestArgs> action = _007B7338_007D;
			Action<CompletedQuestArgs> action2;
			do
			{
				action2 = action;
				Action<CompletedQuestArgs> value2 = (Action<CompletedQuestArgs>)Delegate.Combine(action2, value);
				action = Interlocked.CompareExchange(ref _007B7338_007D, value2, action2);
			}
			while ((object)action != action2);
		}
		[CompilerGenerated]
		remove
		{
			Action<CompletedQuestArgs> action = _007B7338_007D;
			Action<CompletedQuestArgs> action2;
			do
			{
				action2 = action;
				Action<CompletedQuestArgs> value2 = (Action<CompletedQuestArgs>)Delegate.Remove(action2, value);
				action = Interlocked.CompareExchange(ref _007B7338_007D, value2, action2);
			}
			while ((object)action != action2);
		}
	}

	public event Action<QuestInfo, QuestRunningProgress, bool> OnProgress
	{
		[CompilerGenerated]
		add
		{
			Action<QuestInfo, QuestRunningProgress, bool> action = _007B7339_007D;
			Action<QuestInfo, QuestRunningProgress, bool> action2;
			do
			{
				action2 = action;
				Action<QuestInfo, QuestRunningProgress, bool> value2 = (Action<QuestInfo, QuestRunningProgress, bool>)Delegate.Combine(action2, value);
				action = Interlocked.CompareExchange(ref _007B7339_007D, value2, action2);
			}
			while ((object)action != action2);
		}
		[CompilerGenerated]
		remove
		{
			Action<QuestInfo, QuestRunningProgress, bool> action = _007B7339_007D;
			Action<QuestInfo, QuestRunningProgress, bool> action2;
			do
			{
				action2 = action;
				Action<QuestInfo, QuestRunningProgress, bool> value2 = (Action<QuestInfo, QuestRunningProgress, bool>)Delegate.Remove(action2, value);
				action = Interlocked.CompareExchange(ref _007B7339_007D, value2, action2);
			}
			while ((object)action != action2);
		}
	}

	public event Action OnInteractiveSomeDisablesRemoved
	{
		[CompilerGenerated]
		add
		{
			Action action = _007B7340_007D;
			Action action2;
			do
			{
				action2 = action;
				Action value2 = (Action)Delegate.Combine(action2, value);
				action = Interlocked.CompareExchange(ref _007B7340_007D, value2, action2);
			}
			while ((object)action != action2);
		}
		[CompilerGenerated]
		remove
		{
			Action action = _007B7340_007D;
			Action action2;
			do
			{
				action2 = action;
				Action value2 = (Action)Delegate.Remove(action2, value);
				action = Interlocked.CompareExchange(ref _007B7340_007D, value2, action2);
			}
			while ((object)action != action2);
		}
	}

	public int LimitParallelQuests(PlayerAccount _007B7269_007D)
	{
		return 2 + _007B7269_007D.CaptainSkills[PDynamicAccountBonus.CQuestsLimit];
	}

	public QuestRunningProgress TrySearchProgress(int _007B7280_007D)
	{
		return _007B7342_007D.Find((QuestRunningProgress _007B7362_007D) => _007B7362_007D.QuestID == _007B7280_007D);
	}

	public bool ContainsResourceIDInProgressTransfQuests(int _007B7281_007D)
	{
		return _007B7342_007D.Any((QuestRunningProgress _007B7363_007D) => _007B7363_007D.CurrentStep is QuestTransferOrder questTransferOrder && questTransferOrder.ResourceID == _007B7281_007D);
	}

	public int TradeQuestsDangerLevel()
	{
		int num = -1;
		for (int i = 0; i < _007B7342_007D.Size; i++)
		{
			if (_007B7342_007D.Array[i].Info.FirstStep is QuestTransferOrder)
			{
				num = Math.Max(num, _007B7342_007D.Array[i].Info.HardnessLevel);
			}
		}
		return num;
	}

	public bool ContainsQuestTypeCurrentStep(Type _007B7282_007D)
	{
		for (int i = 0; i < _007B7342_007D.Size; i++)
		{
			if (_007B7342_007D.Array[i].CurrentStep.GetType() == _007B7282_007D)
			{
				return true;
			}
		}
		return false;
	}

	public void GetNpcsToDisplayOnMinimap(Tlist<(int, QuestStepHeader)> _007B7283_007D)
	{
		for (int i = 0; i < _007B7342_007D.Size; i++)
		{
			QuestInfo questInfo = Gameplay.QuestsInfo.FromID(_007B7342_007D.Array[i].QuestID);
			QuestStepHeader currentStep = _007B7342_007D.Array[i].CurrentStep;
			if (currentStep.Target != null && currentStep.Target.ShowOnMinimap)
			{
				_007B7283_007D.Add((questInfo.ID, currentStep));
			}
		}
	}

	public QuestEngine()
	{
		_007B7342_007D = new Tlist<QuestRunningProgress>();
		_007B7341_007D = new Tlist<QuestDisableInfo>(4);
		_007B7343_007D = new Tlist<QuestVisibleInfo>();
	}

	[IteratorStateMachine(typeof(_003CEvaluteAndEnumerateDisables_003Ed__40))]
	private IEnumerable<int> EvaluteAndEnumerateDisables(int _007B7284_007D)
	{
		//yield-return decompiler failed: Method not found
		return new _003CEvaluteAndEnumerateDisables_003Ed__40(-2)
		{
			_003C_003E4__this = this,
			_003C_003E3__daysLeft = _007B7284_007D
		};
	}

	[IteratorStateMachine(typeof(_003CEnumerateDisables_003Ed__41))]
	public IEnumerable<QuestInfo> EnumerateDisables()
	{
		//yield-return decompiler failed: Method not found
		return new _003CEnumerateDisables_003Ed__41(-2)
		{
			_003C_003E4__this = this
		};
	}

	public QuestsSerializedChanges EvaluteDisables(int _007B7285_007D)
	{
		if (_007B7285_007D == 0)
		{
			return null;
		}
		int[] array = EvaluteAndEnumerateDisables(_007B7285_007D).ToArray();
		if (array.Length != 0)
		{
			QuestsSerializedChanges questsSerializedChanges = new QuestsSerializedChanges();
			int[] array2 = array;
			for (int i = 0; i < array2.Length; i++)
			{
				int item = array2[i];
				questsSerializedChanges.RemovedDisablesInteractive.Add(in item);
			}
			return questsSerializedChanges;
		}
		return null;
	}

	public QuestsSerializedChanges Server_EvaluteLiveHours(float _007B7286_007D, Vector2 _007B7287_007D, bool _007B7288_007D)
	{
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		if (_007B7286_007D <= 0f)
		{
			return null;
		}
		QuestsSerializedChanges questsSerializedChanges = null;
		for (int i = 0; i < _007B7343_007D.Size; i++)
		{
			_007B7343_007D.Array[i].Timeout -= _007B7286_007D * 3600f;
			if (!(_007B7343_007D.Array[i].Timeout <= 0f))
			{
				continue;
			}
			ushort iD = _007B7343_007D.Array[i].ID;
			if (!(Vector2.Distance(Gameplay.QuestsInfo.FromID(iD).LocationPos, _007B7287_007D) < 300f) || !((double)_007B7286_007D < 0.5))
			{
				if (questsSerializedChanges == null)
				{
					questsSerializedChanges = new QuestsSerializedChanges();
				}
				questsSerializedChanges.SeparateRemovalVisibleQuests.Add(new QuestsSerializedChanges.VisibleQuestRemove(iD, QuestAction.Get));
				_007B7343_007D.FastRemoveAt(i);
				i--;
			}
		}
		return questsSerializedChanges;
	}

	public bool CheckDisable(int _007B7289_007D, out int _007B7290_007D)
	{
		_007B7290_007D = 0;
		for (int i = 0; i < _007B7341_007D.Size; i++)
		{
			if (_007B7341_007D.Array[i].ID == _007B7289_007D)
			{
				_007B7290_007D = _007B7341_007D.Array[i].Code;
				return true;
			}
		}
		return false;
	}

	public bool CheckIsActive(int _007B7291_007D)
	{
		for (int i = 0; i < _007B7342_007D.Size; i++)
		{
			if (_007B7342_007D.Array[i].QuestID == _007B7291_007D)
			{
				return true;
			}
		}
		return false;
	}

	private void _007B7292_007D(QuestInfo _007B7293_007D)
	{
		if (_007B7293_007D.RegularInterval != 0)
		{
			_007B7341_007D.Add(new QuestDisableInfo(_007B7293_007D));
		}
	}

	internal void CommonEvaluteDisplayTime(ref FrameTime _007B7294_007D)
	{
		for (int i = 0; i < _007B7342_007D.Size; i++)
		{
			QuestRunningProgress questRunningProgress = _007B7342_007D.Array[i];
			if (questRunningProgress.TimeSecLeft != 0f && questRunningProgress.Info.LimitedTimeMinutes != -1)
			{
				questRunningProgress.TimeSecLeft -= _007B7294_007D.secElapsed;
				if (questRunningProgress.TimeSecLeft < 0f)
				{
					questRunningProgress.TimeSecLeft = 0f;
				}
			}
		}
	}

	public bool CommonRunQuest(int _007B7295_007D, PlayerAccount _007B7296_007D, QuestRuntimeParameter _007B7297_007D)
	{
		QuestInfo questInfo = Gameplay.QuestsInfo.FromID(_007B7295_007D);
		_007B7342_007D.Add(new QuestRunningProgress(_007B7295_007D, _007B7297_007D));
		if (questInfo.FirstStep is QuestTransferOrder questTransferOrder)
		{
			_007B7296_007D.Shipyard.CurrentRealShip.PrivateResourcesOfHold.AddOrRemove(questTransferOrder.ResourceID, questTransferOrder.ResourceCount.Value);
		}
		if (questInfo.FirstStep is QuestEducationFlag questEducationFlag)
		{
			int num = questEducationFlag.Conditions.Count((QuestEducationFlag.Item _007B7364_007D) => _007B7296_007D.EducationQuest.HasFlag(_007B7364_007D.Marker));
			if (num == questEducationFlag.Conditions.Size && questEducationFlag.Conditions.Any((QuestEducationFlag.Item _007B7358_007D) => _007B7358_007D.Marker != EducationOnboarding.BuildOrBuyShipRank5))
			{
				_007B7296_007D.EducationQuest[questEducationFlag.Conditions.First((QuestEducationFlag.Item _007B7359_007D) => _007B7359_007D.Marker != EducationOnboarding.BuildOrBuyShipRank5).Marker] = false;
			}
		}
		_007B7336_007D?.Invoke(questInfo);
		return true;
	}

	public void SkipCalendarQuest(in Decorator _007B7298_007D, int _007B7299_007D, int _007B7300_007D)
	{
		CalendarEventInfo currentEvent = CalendarEvents.CurrentEvent;
		if (_007B7299_007D == currentEvent.CurrentDayCached)
		{
			IEnumerable<QuestsSerializedChanges.CompletedQuest> enumerable = from _007B7360_007D in ProgressRunningQuests
				where _007B7360_007D.Info.CalendarQuestDay == _007B7300_007D
				select new QuestsSerializedChanges.CompletedQuest(_007B7360_007D.Info.ID);
			if (enumerable.Any())
			{
				QuestsSerializedChanges questsSerializedChanges = new QuestsSerializedChanges();
				QuestsSerializedChanges questsSerializedChanges2 = questsSerializedChanges;
				Tlist<QuestsSerializedChanges.CompletedQuest> tlist = new Tlist<QuestsSerializedChanges.CompletedQuest>();
				foreach (QuestsSerializedChanges.CompletedQuest item in enumerable)
				{
					tlist.Add(item);
				}
				questsSerializedChanges2.CompletedQuests = tlist;
				CommonApplyChanges(in _007B7298_007D, questsSerializedChanges, null);
			}
		}
		currentEvent.CloseDay(_007B7298_007D.account, _007B7299_007D);
	}

	public void CommonApplyChanges(in Decorator _007B7301_007D, QuestsSerializedChanges _007B7302_007D, Action? _007B7303_007D)
	{
		PlayerAccount account = _007B7301_007D.account;
		for (int i = 0; i < _007B7302_007D.FailedQuests.Size; i++)
		{
			int failedQuestId = _007B7302_007D.FailedQuests.Array[i];
			_007B7342_007D.Remove((QuestRunningProgress _007B7366_007D) => _007B7366_007D.QuestID == failedQuestId);
			QuestInfo questInfo = Gameplay.QuestsInfo.FromID(failedQuestId);
			if (questInfo.FirstStep is QuestTransferOrder questTransferOrder)
			{
				if (_007B7301_007D.ship.ResourcesOfHold[questTransferOrder.ResourceID] < questTransferOrder.ResourceCount.Value)
				{
					throw new InvalidOperationException("Server probably don't sync with client while canceling QuestTransferOrder");
				}
				_007B7301_007D.ship.ResourcesOfHold[questTransferOrder.ResourceID] -= questTransferOrder.ResourceCount.Value;
			}
			_007B7337_007D?.Invoke(questInfo);
			_007B7329_007D(account, questInfo);
			_007B7343_007D.Remove((QuestVisibleInfo _007B7367_007D) => _007B7367_007D.ID == failedQuestId);
			_007B7292_007D(questInfo);
		}
		foreach (QuestsSerializedChanges.FailedChallenge item2 in (IEnumerable<QuestsSerializedChanges.FailedChallenge>)_007B7302_007D.FailedChallenges)
		{
			QuestsSerializedChanges.FailedChallenge current = item2;
			foreach (QuestRunningProgress item3 in (IEnumerable<QuestRunningProgress>)_007B7342_007D)
			{
				if (item3.QuestID == current.ID)
				{
					if (item3.FailedLimitsOrNull == null)
					{
						item3.FailedLimitsOrNull = new Tlist<QuestAdditionalLimit>();
					}
					item3.FailedLimitsOrNull.Add(in current.Challenge);
					break;
				}
			}
		}
		for (int num = 0; num < _007B7302_007D.CompletedQuests.Size; num++)
		{
			QuestsSerializedChanges.CompletedQuest completedQuest = _007B7302_007D.CompletedQuests.Array[num];
			bool flag = true;
			float num2 = 0f;
			for (int num3 = 0; num3 < _007B7342_007D.Size; num3++)
			{
				if (_007B7342_007D.Array[num3].QuestID == completedQuest.ID)
				{
					flag = (_007B7342_007D.Array[num3].FailedLimitsOrNull?.Size ?? 0) == 0;
					num2 = _007B7342_007D.Array[num3].TimeSecLeft;
					_007B7342_007D.FastRemoveAt(num3);
					break;
				}
			}
			QuestInfo questInfo2 = Gameplay.QuestsInfo.FromID(completedQuest.ID);
			_007B7329_007D(account, questInfo2);
			float num4 = 1f;
			float num5 = 1f;
			if (questInfo2.FirstStep is QuestTransferOrder questTransferOrder2)
			{
				int num6 = account.Shipyard.CurrentRealShip.PrivateResourcesOfHold[questTransferOrder2.ResourceID];
				int value = questTransferOrder2.ResourceCount.Value;
				num4 = Math.Min(1f, (float)num6 / (float)value);
				account.Shipyard.CurrentRealShip.PrivateResourcesOfHold.AddOrRemove(questTransferOrder2.ResourceID, -Math.Min(num6, value));
				num5 *= num4;
			}
			if (questInfo2.LimitedTimeMinutes != -1 && num2 == 0f && questInfo2.FailWhenTimeLeft)
			{
				num5 *= 1f - FineForFailedTime;
			}
			if (CalendarEvents.CurrentEvent.IsActive)
			{
				CalendarEventInfo currentEvent = CalendarEvents.CurrentEvent;
				int currentQuestDay = currentEvent.GetCurrentQuestDay(_007B7301_007D.account);
				if (questInfo2.CalendarQuestDay.HasValue && questInfo2.CalendarQuestDay.Value == currentQuestDay)
				{
					currentEvent.CloseDay(account, currentEvent.CurrentDayCached);
				}
			}
			bool _007B7351_007D = false;
			bool flag2 = false;
			float num7 = 1f;
			if (questInfo2.Company != QuestCompany.Education)
			{
				num7 += account.Shipyard.CurrentRealShip.PlayerXpAndRewardBonus + (account.IsPremium ? 0.4f : 0f) + ((questInfo2.FirstStep is QuestTransferOrder) ? account.WorldFlag.TradingQuestsBonus(in _007B7301_007D) : 0f) + _007B7301_007D.account.WorldFlag.LootBonus(_007B7301_007D);
			}
			num7 += ((!questInfo2.HasChallenges) ? 0f : (flag ? 0f : (-0.2f)));
			num5 *= num7;
			_007B7292_007D(questInfo2);
			if (!questInfo2.ShareRewardWithGoup)
			{
				questInfo2.GetBonus(_007B7301_007D.guild, account).Apply(account, !_007B7301_007D.IsInPortOrIsleWithStorage, num5);
			}
			FractionAPI.ChangeReputationWhenQuestComplete(_007B7301_007D, questInfo2);
			if (questInfo2.Company != QuestCompany.Daily && questInfo2.Company != QuestCompany.Education)
			{
				account.AvailCraftTime.Value = MathF.Min(account.AvailCraftTime.Value + Math.Max(_007B7301_007D.PortMissionCraftTimeBonus(questInfo2.LocationPort), _007B7301_007D.PortMissionCraftTimeBonus(_007B7301_007D.ship.NearPort)), account.CraftTimeLimit);
			}
			if (questInfo2.Company == QuestCompany.Education && questInfo2.HasContinue)
			{
				foreach (QuestInfo item in (IEnumerable<QuestInfo>)Gameplay.EducationQuestsList)
				{
					if (item.Group == questInfo2.OpenGroupNext)
					{
						if (_007B7342_007D.Any((QuestRunningProgress _007B7368_007D) => _007B7368_007D.Info.ID == item.ID))
						{
							_007B7303_007D?.Invoke();
							_007B7302_007D.CompletedQuests.Clear();
							break;
						}
						CommonRunQuest(item.ID, account, null);
					}
				}
			}
			_007B7338_007D?.Invoke(new CompletedQuestArgs(questInfo2, num5, num4, _007B7351_007D));
			if (questInfo2.Company != QuestCompany.Education && questInfo2.Company != QuestCompany.Daily)
			{
				account.WantedLevelNps = Math.Max(0f, account.WantedLevelNps - 0.3f);
			}
		}
		for (int num8 = 0; num8 < _007B7302_007D.Progress.Size; num8++)
		{
			QuestRunningUpgrade upgrade = _007B7302_007D.Progress.Array[num8];
			QuestRunningProgress questRunningProgress = _007B7342_007D.Find((QuestRunningProgress _007B7369_007D) => _007B7369_007D.QuestID == upgrade.QuestID);
			bool arg = upgrade.NewStep != questRunningProgress.ProgressStepIndex;
			questRunningProgress.Upgrade(upgrade);
			_007B7339_007D?.Invoke(Gameplay.QuestsInfo.FromID(upgrade.QuestID), questRunningProgress, arg);
		}
		for (int num9 = 0; num9 < _007B7302_007D.RemovedDisablesInteractive.Size; num9++)
		{
			int num10 = _007B7302_007D.RemovedDisablesInteractive.Array[num9];
			for (int num11 = 0; num11 < _007B7341_007D.Size; num11++)
			{
				if (_007B7341_007D.Array[num11].ID == num10)
				{
					_007B7341_007D.FastRemoveAt(num11);
					break;
				}
			}
		}
		foreach (QuestsSerializedChanges.VisibleQuestRemove visibleQChange in (IEnumerable<QuestsSerializedChanges.VisibleQuestRemove>)_007B7302_007D.SeparateRemovalVisibleQuests)
		{
			int num12 = _007B7343_007D.FindIndex((QuestVisibleInfo _007B7370_007D) => _007B7370_007D.ID == visibleQChange.ID);
			if (num12 == -1)
			{
				continue;
			}
			if (visibleQChange.RemoveMode == QuestAction.HideMarker)
			{
				for (int num13 = 0; num13 < _007B7343_007D.Size; num13++)
				{
					if (_007B7343_007D.Array[num13].ID == visibleQChange.ID)
					{
						_007B7343_007D.Array[num13].WasHidden = true;
					}
				}
			}
			else
			{
				_007B7343_007D.RemoveAt(num12);
				if (visibleQChange.RemoveMode == QuestAction.Undo)
				{
					_007B7292_007D(Gameplay.QuestsInfo.FromID(visibleQChange.ID));
				}
			}
		}
		if (_007B7302_007D.RemovedDisablesInteractive.Size != 0 && _007B7340_007D != null)
		{
			_007B7340_007D();
		}
	}

	public QuestsSerializedChanges ServerManualQuestRemoveWriteChanges(int _007B7304_007D)
	{
		QuestsSerializedChanges questsSerializedChanges = new QuestsSerializedChanges();
		questsSerializedChanges.FailedQuests.Add(in _007B7304_007D);
		return questsSerializedChanges;
	}

	private void _007B7305_007D(QuestsSerializedChanges _007B7306_007D, int _007B7307_007D, int _007B7308_007D)
	{
		for (int i = 0; i < _007B7342_007D.Size; i++)
		{
			QuestRunningProgress questRunningProgress = _007B7342_007D.Array[i];
			if (questRunningProgress.QuestID != _007B7307_007D)
			{
				continue;
			}
			QuestInfo questInfo = Gameplay.QuestsInfo.FromID(questRunningProgress.QuestID);
			if (questRunningProgress.ProgressInStep + _007B7308_007D >= questRunningProgress.CurrentStep.ProgressComparand)
			{
				if (questRunningProgress.ProgressStepIndex + 1 == questInfo.Steps.Size)
				{
					Tlist<QuestsSerializedChanges.CompletedQuest> completedQuests = _007B7306_007D.CompletedQuests;
					QuestsSerializedChanges.CompletedQuest item = new QuestsSerializedChanges.CompletedQuest
					{
						ID = _007B7307_007D
					};
					completedQuests.Add(in item);
				}
				else
				{
					_007B7306_007D.Progress.Add(new QuestRunningUpgrade(_007B7307_007D, (byte)(questRunningProgress.ProgressStepIndex + 1), 0));
				}
			}
			else
			{
				_007B7306_007D.Progress.Add(new QuestRunningUpgrade(_007B7307_007D, questRunningProgress.ProgressStepIndex, questRunningProgress.ProgressInStep + _007B7308_007D));
			}
			break;
		}
	}

	public QuestsSerializedChanges ServerEnumerateNewActionContextAndWriteChanges(Func<QuestStepHeader, bool> _007B7309_007D, Type _007B7310_007D, int _007B7311_007D, Func<QuestInfo, bool> _007B7312_007D = null)
	{
		QuestsSerializedChanges questsSerializedChanges = null;
		for (int i = 0; i < _007B7342_007D.Size; i++)
		{
			QuestRunningProgress questRunningProgress = _007B7342_007D.Array[i];
			QuestInfo questInfo = Gameplay.QuestsInfo.FromID(questRunningProgress.QuestID);
			try
			{
				if ((!(questRunningProgress.CurrentStep is QuestPassDistance questPassDistance) || questRunningProgress.ProgressInStep >= questPassDistance.RequiredDistance) && questRunningProgress.CurrentStep.GetType() == _007B7310_007D && _007B7309_007D(questRunningProgress.CurrentStep) && (_007B7312_007D == null || _007B7312_007D(Gameplay.QuestsInfo.FromID(questRunningProgress.QuestID))))
				{
					if (questsSerializedChanges == null)
					{
						questsSerializedChanges = new QuestsSerializedChanges();
					}
					_007B7305_007D(questsSerializedChanges, questRunningProgress.QuestID, _007B7311_007D);
				}
			}
			catch (Exception ex)
			{
				_007B7342_007D.FastRemoveAt(i);
				throw ex;
			}
		}
		return questsSerializedChanges;
	}

	public QuestsSerializedChanges ServerMakeQuestFailed(Func<QuestStepHeader, bool> _007B7313_007D, Type _007B7314_007D)
	{
		QuestsSerializedChanges questsSerializedChanges = null;
		for (int i = 0; i < _007B7342_007D.Size; i++)
		{
			QuestRunningProgress questRunningProgress = _007B7342_007D.Array[i];
			QuestInfo questInfo = Gameplay.QuestsInfo.FromID(questRunningProgress.QuestID);
			if (questRunningProgress.CurrentStep.GetType() == _007B7314_007D && _007B7313_007D(questRunningProgress.CurrentStep))
			{
				if (questsSerializedChanges == null)
				{
					questsSerializedChanges = new QuestsSerializedChanges();
				}
				questsSerializedChanges.FailedQuests.Add(in questInfo.ID);
			}
		}
		return questsSerializedChanges;
	}

	public QuestsSerializedChanges ServerLimitsUpdate(QuestAdditionalLimit _007B7315_007D, Player _007B7316_007D, Func<Ship> _007B7317_007D)
	{
		QuestsSerializedChanges questsSerializedChanges = null;
		for (int i = 0; i < _007B7342_007D.Size; i++)
		{
			QuestRunningProgress questRunningProgress = _007B7342_007D.Array[i];
			QuestInfo questInfo = Gameplay.QuestsInfo.FromID(questRunningProgress.QuestID);
			if (questInfo.Limits.Contains(_007B7315_007D) && (questRunningProgress.FailedLimitsOrNull == null || !questRunningProgress.FailedLimitsOrNull.Contains(_007B7315_007D)) && (_007B7317_007D == null || _007B7315_007D != QuestAdditionalLimit.RDontGetDamageFromTarget || !(questRunningProgress.CurrentStep is QuestKillShip { Target: TargetShipNpcForQuest target }) || !(_007B7317_007D() is Npc _007B7743_007D) || target.DoesShipFit(_007B7743_007D, _007B7316_007D, _007B7745_007D: false)))
			{
				if (questsSerializedChanges == null)
				{
					questsSerializedChanges = new QuestsSerializedChanges();
				}
				if (_007B7315_007D.ToString()[0] == 'C')
				{
					questsSerializedChanges.FailedChallenges.Add(new QuestsSerializedChanges.FailedChallenge(questInfo.ID, _007B7315_007D));
				}
				else
				{
					questsSerializedChanges.FailedQuests.Add(in questInfo.ID);
				}
			}
		}
		return questsSerializedChanges;
	}

	public QuestsSerializedChanges ServerLimitsUpdate(Player _007B7318_007D, OpenWorldFlag _007B7319_007D)
	{
		QuestsSerializedChanges questsSerializedChanges = null;
		int rank = _007B7318_007D.CraftFrom.Rank;
		for (int i = 0; i < _007B7342_007D.Size; i++)
		{
			QuestRunningProgress questRunningProgress = _007B7342_007D.Array[i];
			QuestInfo questInfo = Gameplay.QuestsInfo.FromID(questRunningProgress.QuestID);
			bool flag = !(questRunningProgress.CurrentStep is QuestTransferOrder questTransferOrder) || _007B7318_007D.ResourcesOfHold[questTransferOrder.ResourceID] >= questTransferOrder.ResourceCount.Value;
			if (((questInfo.Limits.Contains(QuestAdditionalLimit.RWithoutPeacefulFlag) && _007B7319_007D == OpenWorldFlag.Peaceful) || (questInfo.Limits.Contains(QuestAdditionalLimit.RShipRankRelyOnPortPlusOne) && rank + 1 < questInfo.LocationPort.BuildShipRangs)) && flag)
			{
				if (questsSerializedChanges == null)
				{
					questsSerializedChanges = new QuestsSerializedChanges();
				}
				questsSerializedChanges.FailedQuests.Add(in questRunningProgress.QuestID);
			}
		}
		return questsSerializedChanges;
	}

	public QuestsSerializedChanges ServerLimitsTimeUpdate()
	{
		QuestsSerializedChanges questsSerializedChanges = null;
		for (int i = 0; i < _007B7342_007D.Size; i++)
		{
			QuestRunningProgress questRunningProgress = _007B7342_007D.Array[i];
			QuestInfo questInfo = Gameplay.QuestsInfo.FromID(questRunningProgress.QuestID);
			if (questInfo.LimitedTimeMinutes != -1 && questRunningProgress.TimeSecLeft == 0f && questInfo.FailWhenTimeLeft)
			{
				if (questsSerializedChanges == null)
				{
					questsSerializedChanges = new QuestsSerializedChanges();
				}
				questsSerializedChanges.FailedQuests.Add(in questRunningProgress.QuestID);
			}
		}
		return questsSerializedChanges;
	}

	[IteratorStateMachine(typeof(_003CGetAvailableQuests_003Ed__59))]
	public IEnumerable<QuestInfo> GetAvailableQuests(IslePortInfo _007B7320_007D, Player _007B7321_007D)
	{
		//yield-return decompiler failed: Method not found
		return new _003CGetAvailableQuests_003Ed__59(-2)
		{
			_003C_003E4__this = this,
			_003C_003E3__port = _007B7320_007D,
			_003C_003E3__player = _007B7321_007D
		};
	}

	public IEnumerable<QuestInfo> GetOpenedQuests(IslePortInfo? _007B7322_007D, QuestCompany? _007B7323_007D, bool _007B7324_007D, bool _007B7325_007D)
	{
		int _007B7290_007D;
		return from _007B7361_007D in _007B7343_007D
			where _007B7324_007D || !_007B7361_007D.WasHidden
			where _007B7325_007D || (!CheckDisable(_007B7361_007D.ID, out _007B7290_007D) && !CheckIsActive(_007B7361_007D.ID))
			select Gameplay.QuestsInfo.FromID(_007B7361_007D.ID) into _007B7376_007D
			where (!_007B7323_007D.HasValue || _007B7376_007D.Company == _007B7323_007D) && (_007B7322_007D == null || _007B7376_007D.LocationPort == _007B7322_007D)
			select _007B7376_007D;
	}

	public bool TryReopenCategory(IslePortInfo _007B7326_007D, Player _007B7327_007D, QuestCompany _007B7328_007D)
	{
		QuestInfo[] array = (from _007B7377_007D in GetAvailableQuests(_007B7326_007D, _007B7327_007D)
			where _007B7377_007D.Company == _007B7328_007D
			select _007B7377_007D).ToArray();
		if (array.Length == 0)
		{
			return false;
		}
		_007B7343_007D.RemoveAll((QuestVisibleInfo _007B7378_007D) => _007B7378_007D.Info.Company == _007B7328_007D && _007B7378_007D.Info.LocationPort == _007B7326_007D);
		QuestInfo[] array2 = Rand.PickMany(Math.Min(array.Length, 3), array).ToArray();
		QuestInfo[] array3 = array2;
		foreach (QuestInfo questInfo in array3)
		{
			_007B7343_007D.Add(new QuestVisibleInfo((ushort)questInfo.ID, 86400f));
		}
		return true;
	}

	private void _007B7329_007D(PlayerAccount _007B7330_007D, QuestInfo _007B7331_007D)
	{
		for (int i = 0; i < _007B7331_007D.ShipEffects.Length; i++)
		{
			_007B7330_007D.Shipyard.CurrentRealShip.DynamicBonus.RemoveSpecificArenaUpgrade(in _007B7331_007D.ShipEffects[i]);
		}
	}

	private void _007B7332_007D(WriterExtern _007B7333_007D)
	{
		_007B7333_007D.WriteStruct<int>(Gameplay.QuestsInfo.Size);
		_007B7333_007D.WriteStruct<int>(CommonGlobal.MagicNumberQuestsOnly);
		_007B7333_007D.WriteTlistStruct<QuestDisableInfo>(_007B7341_007D);
		_007B7333_007D.WriteTlistImps(_007B7342_007D);
		_007B7333_007D.WriteTlistStruct<QuestVisibleInfo>(_007B7343_007D);
	}

	private void _007B7334_007D(WriterExtern _007B7335_007D)
	{
		int num = default(int);
		_007B7335_007D.ReadStruct<int>(ref num);
		int num2 = default(int);
		_007B7335_007D.ReadStruct<int>(ref num2);
		_007B7335_007D.ReadTlistStruct<QuestDisableInfo>(out _007B7341_007D);
		_007B7335_007D.ReadTlistImps(out _007B7342_007D);
		_007B7335_007D.ReadTlistStruct<QuestVisibleInfo>(out _007B7343_007D);
		if (num != Gameplay.QuestsInfo.Size || num2 != CommonGlobal.MagicNumberQuestsOnly)
		{
			_007B7341_007D.Clear();
			_007B7342_007D.Clear();
			_007B7343_007D.Clear();
		}
	}
}
