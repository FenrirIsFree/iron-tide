using System;
using Common.Resources;
using Microsoft.Xna.Framework;

namespace Common.Game;

public class Functions
{
	public struct HeightDist
	{
		public float SightHeight;

		public float SightDistance;
	}

	public static Vector2 MortarShotEndPosition(Vector2 _007B4644_007D, Vector3 _007B4645_007D, Player _007B4646_007D, CannonBallInfo _007B4647_007D)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		(float, float, float, float, float, float, float) mortarsAverageParameters = _007B4646_007D.UsedShip.GetMortarsAverageParameters(_007B4647_007D);
		float num = MathHelper.Lerp(mortarsAverageParameters.Item1, mortarsAverageParameters.Item2, _007B4645_007D.Z);
		return new Vector2(_007B4644_007D.X + _007B4645_007D.X * num, _007B4644_007D.Y + _007B4645_007D.Y * num);
	}

	public static HeightDist GetData(float _007B4648_007D, float _007B4649_007D, float _007B4650_007D, float _007B4651_007D)
	{
		_007B4648_007D -= 3f;
		_007B4649_007D -= 0.1f;
		float val = (0.6f + _007B4649_007D) * 2f;
		val = MathF.Pow(Math.Max(0f, val), 5f);
		HeightDist result = default(HeightDist);
		result.SightDistance = Math.Max(20f, _007B4651_007D * _007B4648_007D * (1.25f * Math.Min(0.8f, val)));
		result.SightHeight = (1f + MathHelper.Clamp((0.1f + _007B4649_007D * 0.6f) * 80f, 0f, 6f)) * (result.SightDistance / Math.Max(100f, _007B4648_007D)) * _007B4650_007D;
		result.SightHeight = Math.Max(0.2f, result.SightHeight);
		return result;
	}

	internal static float Function(float _007B4652_007D, HeightDist _007B4653_007D)
	{
		float num = 4f * _007B4652_007D - 4f * _007B4652_007D * _007B4652_007D;
		return num * (0.5f + _007B4653_007D.SightHeight);
	}

	public static float GetBallHeight(float _007B4654_007D, HeightDist _007B4655_007D, float _007B4656_007D)
	{
		float num = Math.Min(1f, _007B4655_007D.SightDistance / 35f);
		return MathHelper.Lerp(_007B4656_007D - 25f * _007B4654_007D / _007B4655_007D.SightDistance, _007B4656_007D + Function(_007B4654_007D, _007B4655_007D), num);
	}

	public static float FunctionRoot(float _007B4657_007D, HeightDist _007B4658_007D)
	{
		float num = -1f;
		float num2 = 1f;
		float num3 = (0f - _007B4657_007D) / (4f * _007B4658_007D.SightHeight);
		float num4 = MathF.Sqrt(num2 * num2 - 4f * num * num3);
		float val = (0f - num2 + num4) / (2f * num);
		float val2 = (0f - num2 - num4) / (2f * num);
		return Math.Max(val, val2);
	}

	public static float GetCannonBallSpeedMultiplier(float _007B4659_007D, float _007B4660_007D)
	{
		float num = _007B4660_007D / 140f;
		return ((1f - _007B4659_007D) * (1f - _007B4659_007D) * 0.2f + 0.9f) * num + (1f - num) * 0.9f;
	}
}
