namespace Common.Game;

public enum ServerInventType
{
	GuildKills
}
