using System;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct SlimDateInfo : IMPSerializable
{
	public short Year;

	public byte Month;

	public byte Day;

	public readonly DateTime ToDateTime => IsValid ? new DateTime(Year, Month, Day) : new DateTime(1970, 1, 1);

	public readonly bool IsValid => Year > 0 && Month > 0 && Day > 0;

	public SlimDateInfo(DateTime _007B5574_007D)
	{
		Year = (short)_007B5574_007D.Year;
		Month = (byte)_007B5574_007D.Month;
		Day = (byte)_007B5574_007D.Day;
	}

	private void _007B5575_007D(WriterExtern _007B5576_007D)
	{
		_007B5576_007D.WriteStruct<short>(ref Year);
		_007B5576_007D.WriteByte(Month);
		_007B5576_007D.WriteByte(Day);
	}

	private void _007B5577_007D(WriterExtern _007B5578_007D)
	{
		_007B5578_007D.ReadStruct<short>(ref Year);
		Month = _007B5578_007D.ReadByte();
		Day = _007B5578_007D.ReadByte();
	}

	public override string ToString()
	{
		LocalizedDateTime localizedDateTime = new LocalizedDateTime(this);
		localizedDateTime.PreferredTimeMode = TimeFormat.PreferServerTime;
		return localizedDateTime.GetDateAndTime();
	}
}
