using System;

namespace Common.Game;

[Flags]
public enum SpecificDamageFlags : ushort
{
	None = 0,
	SingleSailDamage = 1,
	BoardingHookConnected = 2,
	CorpusCritical = 4,
	CannonCritical = 8,
	BurningCritical = 0x10,
	TowerSource = 0x20,
	CreateMicroburning = 0x40,
	SternDamage = 0x80,
	CrewDamage = 0x100,
	DebufSpeed = 0x200,
	PvPDamage = 0x400,
	IsHealthDamageReduced = 0x800,
	RemoveCannonBall = 0x1000,
	TotalSailDamage = 0x2000,
	Fireworks = 0x4000
}
