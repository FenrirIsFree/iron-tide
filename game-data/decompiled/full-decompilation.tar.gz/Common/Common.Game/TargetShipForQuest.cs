namespace Common.Game;

public class TargetShipForQuest
{
	public bool ShowOnMinimap;
}
