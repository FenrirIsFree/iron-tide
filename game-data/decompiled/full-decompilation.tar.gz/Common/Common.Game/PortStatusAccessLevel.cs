namespace Common.Game;

public enum PortStatusAccessLevel
{
	Full,
	BuildingsOnlyPosition
}
