using System;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Game;

public class GroupCommon : IMPSerializable, IDisposable
{
	public const float GroupTimeout = 25000f;

	public const int MaxGroupLimit = 20;

	public const float WaitForConnectPlayersMultipliePassingMap = 60f;

	public Tlist<GroupMemberInfo> Members;

	public bool Roots => true;

	public int MembersCount => Members.Size;

	public bool IsAvailablePlaces => Members.Size < 20;

	public GroupCommon(Tlist<GroupMemberInfo> _007B5971_007D)
	{
		Members = _007B5971_007D;
	}

	public GroupCommon()
	{
		Members = new Tlist<GroupMemberInfo>();
	}

	public void RemoveMember(int _007B5972_007D)
	{
		for (int i = 0; i < Members.Size; i++)
		{
			if (Members.Array[i].UID == _007B5972_007D)
			{
				GroupMemberInfo groupMemberInfo = Members.Array[i];
				Members.RemoveAt(i);
				break;
			}
		}
	}

	public void Dispose()
	{
		Members.Clear();
	}

	public GroupMemberInfo GetMemberFromUID(int _007B5973_007D)
	{
		for (int i = 0; i < Members.Size; i++)
		{
			if (Members.Array[i].UID == _007B5973_007D)
			{
				return Members.Array[i];
			}
		}
		return null;
	}

	public uint TryFindAccountSID(int _007B5974_007D)
	{
		return GetMemberFromUID(_007B5974_007D)?.AccountSID ?? 0;
	}

	public bool ContainsSID(uint _007B5975_007D)
	{
		for (int i = 0; i < Members.Size; i++)
		{
			if (Members.Array[i].AccountSID == _007B5975_007D)
			{
				return true;
			}
		}
		return false;
	}

	public bool ContainsUID(int _007B5976_007D)
	{
		for (int i = 0; i < Members.Size; i++)
		{
			if (Members.Array[i].UID == _007B5976_007D)
			{
				return true;
			}
		}
		return false;
	}

	private void _007B5977_007D(WriterExtern _007B5978_007D)
	{
		_007B5978_007D.WriteTlistImps(Members);
	}

	private void _007B5979_007D(WriterExtern _007B5980_007D)
	{
		_007B5980_007D.ReadTlistImps(out Members);
	}
}
