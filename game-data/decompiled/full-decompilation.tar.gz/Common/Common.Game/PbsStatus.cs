using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using Common.Account;
using Common.Resources;
using CommonDataTypes;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using SDL2;
using TheraEngine;
using TheraEngine.Collections;

namespace Common.Game;

public class PbsStatus : PortCaptureStatus, IMPSerializable, ITKSerializable
{
	public const int TOWERS_VERSION = 112;

	public const int ProtectionDurationAfterSuccessfulDefence = 24;

	public string NextAttackBy = "";

	public string VassalTag = "";

	public float VassalTimeoutSec;

	public Tlist<PbsBuildingStatus> Buildings;

	public PbsTensity Tensity;

	public float EmpireCaptureLevel;

	public double TimeToBeginBattle;

	public float TimeToBattleCompletion;

	public float TimeToProtectionTensity;

	public float BlockMoneyTransferTimeout;

	public PbsAttackWindow AttackWindow;

	public int AccumulatedMoney;

	public float BlockAnyProtectionTimeout;

	public float TemporaryFactoryBoostTimeout;

	public float TimeToResetPortByTensitySec;

	public MooringChargePolicy MooringChargeNeutral = MooringChargePolicy.Free;

	public MooringChargePolicy MooringChargeEnemy = MooringChargePolicy.Normal;

	public bool Display_IsWindowActive;

	public PortBattleEvent Display_LastEvent;

	public string Display_LastEventArg;

	public const int TensityRollbackHours = 24;

	public int FortsCount => base.PortInstance.PbSystem.Count<KeyValuePair<int, PbsBuildingPlaceInfo>>((KeyValuePair<int, PbsBuildingPlaceInfo> _007B7829_007D) => _007B7829_007D.Value.GroupID == WorldObjectID.WGuildFort);

	public int TowersCount => base.PortInstance.PbSystem.Count<KeyValuePair<int, PbsBuildingPlaceInfo>>((KeyValuePair<int, PbsBuildingPlaceInfo> _007B7830_007D) => _007B7830_007D.Value.GroupID == WorldObjectID.WGuildFortTower);

	public int CityLevel => Dev.PortLevel;

	public WosbPbs.PbsBuildingStats FortLevelInfo => WosbPbs.FortLevelsByPort[CityLevel - 1];

	public WosbPbs.PbsBuildingStats TowerLevelInfo => WosbPbs.TowerLevelsByPort[CityLevel - 1];

	public bool IsBlockedByWindowOrBattle => Display_IsWindowActive || TimeToBattleCompletion > 0f || TimeToBeginBattle > 0.0;

	public bool IsBlockedByTensityOrBattle => Tensity.Effects.BlockFortWindowActions || TimeToBattleCompletion > 0f || TimeToBeginBattle > 0.0;

	public int grownCity => (CityLevel >= 6) ? 3 : ((CityLevel < 4) ? 1 : 2);

	public PbsStatus()
	{
	}

	public PbsStatus(IslePortInfo _007B7804_007D)
		: base(_007B7804_007D.PortID)
	{
		Buildings = new Tlist<PbsBuildingStatus>();
		Tensity = new PbsTensity();
		_007B7805_007D();
		AttackWindow = new PbsAttackWindow(20);
	}

	private void _007B7805_007D()
	{
		foreach (KeyValuePair<int, PbsBuildingPlaceInfo> item in base.PortInstance.PbSystem)
		{
			if (item.Value.GroupID == WorldObjectID.WGuildFort)
			{
				Buildings.Add(new PbsBuildingStatus(item.Key, -1, this));
			}
			if (item.Value.GroupID == WorldObjectID.WGuildFortTower)
			{
				Buildings.Add(new PbsBuildingStatus(item.Key, -1, this));
			}
		}
	}

	public void UpdatePositions()
	{
		if (Buildings.Size == 0)
		{
			_007B7805_007D();
			return;
		}
		PbsBuildingStatus pbsBuildingStatus = Buildings.First((PbsBuildingStatus _007B7831_007D) => _007B7831_007D.IsFort);
		KeyValuePair<int, PbsBuildingPlaceInfo> keyValuePair = base.PortInstance.PbSystem.First<KeyValuePair<int, PbsBuildingPlaceInfo>>((KeyValuePair<int, PbsBuildingPlaceInfo> _007B7832_007D) => _007B7832_007D.Value.GroupID == WorldObjectID.WGuildFort);
		PbsBuildingPlaceInfo[] array = base.PortInstance.PbSystem.Values.Where((PbsBuildingPlaceInfo _007B7833_007D) => _007B7833_007D.GroupID == WorldObjectID.WGuildFortTower).ToArray();
		if (pbsBuildingStatus.PlaceIDInPort != keyValuePair.Key)
		{
			pbsBuildingStatus.PlaceIDInPort = (byte)keyValuePair.Key;
			int num = 0;
			for (int num2 = 0; num2 < Buildings.Size; num2++)
			{
				PbsBuildingStatus pbsBuildingStatus2 = Buildings.Array[num2];
				if (pbsBuildingStatus2.IsTower)
				{
					if (num >= array.Length)
					{
						Buildings.RemoveAt(num2);
						num2--;
					}
					else
					{
						pbsBuildingStatus2.PlaceIDInPort = (byte)array[num].PlaceIDInPort;
						num++;
					}
				}
			}
		}
		PbsBuildingPlaceInfo[] array2 = array;
		foreach (PbsBuildingPlaceInfo expectingTower in array2)
		{
			if (!Buildings.Any((PbsBuildingStatus _007B7837_007D) => _007B7837_007D.PlaceIDInPort == expectingTower.PlaceIDInPort))
			{
				Buildings.Add(new PbsBuildingStatus(expectingTower.PlaceIDInPort, -1, this));
			}
		}
		if (Buildings.Size == array.Length + 1)
		{
			return;
		}
		throw new Exception("Something went wrong");
	}

	public void ServerInitUID(Func<int> _007B7806_007D)
	{
		foreach (PbsBuildingStatus item in (IEnumerable<PbsBuildingStatus>)Buildings)
		{
			item.uIDDynamicServerBuild = _007B7806_007D();
		}
	}

	public int GetTensityProtectionDuration(int _007B7807_007D)
	{
		return 24 * _007B7807_007D - 12;
	}

	public void AddTensityProtection(DateTime _007B7808_007D, int _007B7809_007D, bool _007B7810_007D = true)
	{
		if (_007B7809_007D == 0)
		{
			return;
		}
		if (!base.PortInstance.CaptureWithoutWindow)
		{
			DateTime dateTime = _007B7808_007D.AddHours(_007B7809_007D);
			if (AttackWindow.IsInInterval(base.PortInstance, dateTime.Hour))
			{
				_007B7809_007D += base.PortInstance.PbWindowDuration;
			}
		}
		if (_007B7810_007D)
		{
			BlockAnyProtectionTimeout = Math.Max(BlockAnyProtectionTimeout, _007B7809_007D + 24);
		}
		TimeToProtectionTensity = _007B7809_007D * 3600;
	}

	public IEnumerable<PbsBuildingStatus> EnumerateTowers(PbsStatus _007B7811_007D)
	{
		return _007B7811_007D.Buildings.Where((PbsBuildingStatus _007B7834_007D) => !_007B7834_007D.IsFort);
	}

	public PbsBuildingStatus FirstFort()
	{
		return Buildings.First((PbsBuildingStatus _007B7835_007D) => _007B7835_007D.IsFort);
	}

	public int GetMooringCharge(PlayerAccount _007B7812_007D, GuildCommon _007B7813_007D, in PbsTensityEffects _007B7814_007D)
	{
		if (_007B7812_007D.Rang <= 10)
		{
			return 0;
		}
		IslePortInfo portInstance = base.PortInstance;
		if (_007B7812_007D.Quests.TradeQuestsDangerLevel() != -1 || _007B7814_007D.DisableMooringCharge || (_007B7813_007D != null && _007B7813_007D.Tag == CapturedBy))
		{
			return 0;
		}
		int num = portInstance.MooringChargeBasic(((_007B7813_007D == null) ? Relation.Neutral : ((!_007B7813_007D.IsTrusted(CapturedBy)) ? FractionAPI.StatusWith(_007B7813_007D.Fraction, CapturerFraction) : Relation.Ally)) switch
		{
			Relation.Neutral => MooringChargeNeutral, 
			Relation.Ally => MooringChargePolicy.Free, 
			_ => MooringChargeEnemy, 
		}, _007B7812_007D.Shipyard.CurrentRealShip.CraftFrom.Rank, _007B7812_007D.Rang);
		return (int)((float)num * (1f - (float)_007B7812_007D.CaptainSkills[PDynamicAccountBonus.PReduceMooringCharge] / 100f));
	}

	public static int MooringChangeForHold(Player _007B7815_007D, FractionID? _007B7816_007D, FractionID _007B7817_007D, IslePortInfo _007B7818_007D)
	{
		if (_007B7815_007D.MapInfo.IsWorldmap && _007B7816_007D == FractionID.TradeUnion && !_007B7818_007D.AllowCapturePiratePort && _007B7817_007D != FractionID.Pirate)
		{
			int num = _007B7815_007D.ResourcesOfHold.ResourceInfo.Sum<GSILocalEnumerablePair<ResourceInfo>>((GSILocalEnumerablePair<ResourceInfo> _007B7836_007D) => _007B7836_007D.Info.MediumCost.Value * _007B7836_007D.Count);
			float num2 = (float)num / 200f;
			if (num2 < 30f)
			{
				return 0;
			}
			return (int)(MathF.Floor(num2 / 10f) * 10f);
		}
		return 0;
	}

	public override void Boxing(WriterExtern _007B7819_007D)
	{
		base.Boxing(_007B7819_007D);
		PortStatusAccessLevel portStatusAccessLevel = (PortStatusAccessLevel)(_007B7819_007D.CustomParameter ?? ((object)PortStatusAccessLevel.Full));
		_007B7819_007D.CustomParameter = portStatusAccessLevel;
		_007B7819_007D.WriteByte((byte)portStatusAccessLevel);
		_007B7819_007D.WriteTlistImps(Buildings);
		_007B7819_007D.Write<PbsTensity>(Tensity);
		_007B7819_007D.WriteStruct<float>(EmpireCaptureLevel);
		_007B7819_007D.WriteStruct<double>(TimeToBeginBattle);
		_007B7819_007D.WriteStruct<float>(TimeToBattleCompletion);
		_007B7819_007D.WriteStruct<float>(TimeToProtectionTensity);
		_007B7819_007D.Write(NextAttackBy, (Encoding)null);
		_007B7819_007D.Write(Display_IsWindowActive);
		_007B7819_007D.WriteByte((byte)Display_LastEvent);
		_007B7819_007D.Write(Display_LastEventArg, (Encoding)null);
		_007B7819_007D.Write<PbsAttackWindow>(ref AttackWindow);
		_007B7819_007D.WriteStruct<float>(TemporaryFactoryBoostTimeout);
		_007B7819_007D.WriteStruct<float>(BlockAnyProtectionTimeout);
		_007B7819_007D.WriteByte((byte)MooringChargeNeutral);
		_007B7819_007D.WriteByte((byte)MooringChargeEnemy);
		_007B7819_007D.WriteStruct<int>(AccumulatedMoney);
		_007B7819_007D.WriteStruct<float>(BlockMoneyTransferTimeout);
		_007B7819_007D.WriteStruct<float>(TimeToResetPortByTensitySec);
		_007B7819_007D.WriteStruct<float>(VassalTimeoutSec);
		if (VassalTimeoutSec > 0f)
		{
			_007B7819_007D.Write(VassalTag, (Encoding)null);
		}
	}

	public override void Unboxing(WriterExtern _007B7820_007D)
	{
		base.Unboxing(_007B7820_007D);
		PortStatusAccessLevel portStatusAccessLevel = (PortStatusAccessLevel)_007B7820_007D.ReadByte();
		_007B7820_007D.CustomParameter = this;
		_007B7820_007D.ReadTlistImps(out Buildings);
		_007B7820_007D.ReadIMPS<PbsTensity>(ref Tensity);
		_007B7820_007D.ReadStruct<float>(ref EmpireCaptureLevel);
		_007B7820_007D.ReadStruct<double>(ref TimeToBeginBattle);
		_007B7820_007D.ReadStruct<float>(ref TimeToBattleCompletion);
		_007B7820_007D.ReadStruct<float>(ref TimeToProtectionTensity);
		_007B7820_007D.ReadString(ref NextAttackBy, (Encoding)null);
		_007B7820_007D.ReadBoolean(ref Display_IsWindowActive);
		Display_LastEvent = (PortBattleEvent)_007B7820_007D.ReadByte();
		_007B7820_007D.ReadString(ref Display_LastEventArg, (Encoding)null);
		_007B7820_007D.ReadIMPS_struct<PbsAttackWindow>(ref AttackWindow);
		_007B7820_007D.ReadStruct<float>(ref TemporaryFactoryBoostTimeout);
		_007B7820_007D.ReadStruct<float>(ref BlockAnyProtectionTimeout);
		if (TemporaryFactoryBoostTimeout < 0f || TemporaryFactoryBoostTimeout > 3600000f)
		{
			TemporaryFactoryBoostTimeout = BitConverter.ToInt32(BitConverter.GetBytes(TemporaryFactoryBoostTimeout));
		}
		if (BlockAnyProtectionTimeout < 0f || BlockAnyProtectionTimeout > 3600000f)
		{
			BlockAnyProtectionTimeout = BitConverter.ToInt32(BitConverter.GetBytes(BlockAnyProtectionTimeout));
		}
		MooringChargeNeutral = (MooringChargePolicy)_007B7820_007D.ReadByte();
		MooringChargeEnemy = (MooringChargePolicy)_007B7820_007D.ReadByte();
		_007B7820_007D.ReadStruct<int>(ref AccumulatedMoney);
		_007B7820_007D.ReadStruct<float>(ref BlockMoneyTransferTimeout);
		_007B7820_007D.ReadStruct<float>(ref TimeToResetPortByTensitySec);
		_007B7820_007D.ReadStruct<float>(ref VassalTimeoutSec);
		if (VassalTimeoutSec > 0f)
		{
			_007B7820_007D.ReadString(ref VassalTag, (Encoding)null);
		}
	}

	public override void PreInit()
	{
		base.PreInit();
		Buildings = new Tlist<PbsBuildingStatus>();
	}

	public override void PostInit()
	{
		base.PostInit();
		if (Tensity == null)
		{
			Tensity = new PbsTensity();
		}
		if (CapturedBy == null)
		{
			CapturedBy = string.Empty;
		}
		UpdatePositions();
	}

	public override void Boxing(TKWriterExtern _007B7821_007D)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		base.Boxing(_007B7821_007D);
		((TKWriterExtern)(ref _007B7821_007D)).WriteContent((short)112, (Action<WriterExtern>)delegate(WriterExtern _007B7826_007D)
		{
			_007B7826_007D.WriteTlistImps(Buildings);
		});
		((TKWriterExtern)(ref _007B7821_007D)).WriteStruct<double>((short)6, ref TimeToBeginBattle);
		((TKWriterExtern)(ref _007B7821_007D)).WriteStruct<float>((short)7, ref TimeToBattleCompletion);
		((TKWriterExtern)(ref _007B7821_007D)).WriteStruct<float>((short)9, ref TimeToProtectionTensity);
		((TKWriterExtern)(ref _007B7821_007D)).Write((short)15, NextAttackBy);
		((TKWriterExtern)(ref _007B7821_007D)).WriteStruct<float>((short)16, ref EmpireCaptureLevel);
		((TKWriterExtern)(ref _007B7821_007D)).WriteIMP<PbsTensity>((short)33, Tensity);
		((TKWriterExtern)(ref _007B7821_007D)).WriteIMP<PbsAttackWindow>((short)22, ref AttackWindow);
		((TKWriterExtern)(ref _007B7821_007D)).WriteStruct<int>((short)30, ref AccumulatedMoney);
		((TKWriterExtern)(ref _007B7821_007D)).WriteStruct<float>((short)31, ref BlockMoneyTransferTimeout);
		((TKWriterExtern)(ref _007B7821_007D)).WriteContent((short)32, (Action<WriterExtern>)delegate(WriterExtern _007B7828_007D)
		{
			_007B7828_007D.WriteByte((byte)MooringChargeNeutral);
			_007B7828_007D.WriteByte((byte)MooringChargeEnemy);
		});
		((TKWriterExtern)(ref _007B7821_007D)).WriteStruct<float>((short)34, ref TimeToResetPortByTensitySec);
		((TKWriterExtern)(ref _007B7821_007D)).WriteStruct<float>((short)35, ref VassalTimeoutSec);
		((TKWriterExtern)(ref _007B7821_007D)).Write((short)36, VassalTag);
		((TKWriterExtern)(ref _007B7821_007D)).WriteStruct<float>((short)37, ref BlockAnyProtectionTimeout);
		((TKWriterExtern)(ref _007B7821_007D)).WriteStruct<float>((short)38, ref TemporaryFactoryBoostTimeout);
	}

	public override void Load(short _007B7822_007D, WriterExtern _007B7823_007D, out bool _007B7824_007D)
	{
		_007B7824_007D = true;
		base.Load(_007B7822_007D, _007B7823_007D, out var _007B7891_007D);
		if (_007B7891_007D)
		{
			return;
		}
		switch (_007B7822_007D)
		{
		case 112:
			try
			{
				_007B7823_007D.CustomParameter = this;
				_007B7823_007D.ReadTlistImps(out Buildings);
				break;
			}
			catch (Exception _007B361_007D)
			{
				Engine.ShowMessageBox("PbsStatus LOading Error " + _007B361_007D.ExceptionToStr(), "", (SDL_MessageBoxFlags)64);
				break;
			}
		case 6:
			_007B7823_007D.ReadStruct<double>(ref TimeToBeginBattle);
			break;
		case 7:
			_007B7823_007D.ReadStruct<float>(ref TimeToBattleCompletion);
			break;
		case 9:
			_007B7823_007D.ReadStruct<float>(ref TimeToProtectionTensity);
			break;
		case 15:
			_007B7823_007D.ReadString(ref NextAttackBy, (Encoding)null);
			break;
		case 16:
			_007B7823_007D.ReadStruct<float>(ref EmpireCaptureLevel);
			break;
		case 33:
			_007B7823_007D.ReadIMPS<PbsTensity>(ref Tensity);
			break;
		case 22:
			_007B7823_007D.ReadIMPS_struct<PbsAttackWindow>(ref AttackWindow);
			break;
		case 25:
		{
			int num2 = default(int);
			_007B7823_007D.ReadStruct<int>(ref num2);
			TemporaryFactoryBoostTimeout = num2;
			break;
		}
		case 26:
		{
			int num = default(int);
			_007B7823_007D.ReadStruct<int>(ref num);
			BlockAnyProtectionTimeout = num;
			break;
		}
		case 30:
			_007B7823_007D.ReadStruct<int>(ref AccumulatedMoney);
			break;
		case 31:
			_007B7823_007D.ReadStruct<float>(ref BlockMoneyTransferTimeout);
			break;
		case 32:
			MooringChargeNeutral = (MooringChargePolicy)_007B7823_007D.ReadByte();
			MooringChargeEnemy = (MooringChargePolicy)_007B7823_007D.ReadByte();
			break;
		case 34:
			_007B7823_007D.ReadStruct<float>(ref TimeToResetPortByTensitySec);
			break;
		case 35:
			_007B7823_007D.ReadStruct<float>(ref VassalTimeoutSec);
			break;
		case 36:
			_007B7823_007D.ReadString(ref VassalTag, (Encoding)null);
			break;
		case 37:
			_007B7823_007D.ReadStruct<float>(ref BlockAnyProtectionTimeout);
			break;
		case 38:
			_007B7823_007D.ReadStruct<float>(ref TemporaryFactoryBoostTimeout);
			break;
		default:
			_007B7824_007D = false;
			break;
		}
	}

	[CompilerGenerated]
	private void _007B7825_007D(WriterExtern _007B7826_007D)
	{
		_007B7826_007D.WriteTlistImps(Buildings);
	}

	[CompilerGenerated]
	private void _007B7827_007D(WriterExtern _007B7828_007D)
	{
		_007B7828_007D.WriteByte((byte)MooringChargeNeutral);
		_007B7828_007D.WriteByte((byte)MooringChargeEnemy);
	}
}
