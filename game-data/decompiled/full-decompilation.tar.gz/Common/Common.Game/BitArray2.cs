using System;
using System.Collections;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Common.Game;

public class BitArray2
{
	private int _007B5962_007D;

	private int _007B5963_007D;

	protected BitArray textureData;

	public bool this[int _007B5952_007D, int _007B5953_007D]
	{
		get
		{
			return textureData[Math.Clamp(_007B5953_007D, 0, _007B5963_007D - 1) * _007B5962_007D + Math.Clamp(_007B5952_007D, 0, _007B5962_007D - 1)];
		}
		set
		{
			textureData[Math.Clamp(_007B5955_007D, 0, _007B5963_007D - 1) * _007B5962_007D + Math.Clamp(_007B5954_007D, 0, _007B5962_007D - 1)] = value;
		}
	}

	public BitArray2(int _007B5949_007D, int _007B5950_007D, bool _007B5951_007D)
	{
		_007B5962_007D = _007B5949_007D;
		_007B5963_007D = _007B5950_007D;
		if (_007B5951_007D)
		{
			textureData = new BitArray(_007B5962_007D * _007B5963_007D);
		}
	}

	public void Clear()
	{
		textureData.SetAll(value: false);
	}

	public void DrawCircle(float _007B5957_007D, float _007B5958_007D, float _007B5959_007D)
	{
		if (_007B5959_007D <= 0f)
		{
			throw new ArgumentException("Radius must be greater than zero.");
		}
		for (int i = (int)(_007B5958_007D - _007B5959_007D); i <= (int)(_007B5958_007D + _007B5959_007D); i++)
		{
			for (int j = (int)(_007B5957_007D - _007B5959_007D); j <= (int)(_007B5957_007D + _007B5959_007D); j++)
			{
				if (Math.Pow((float)j - _007B5957_007D, 2.0) + Math.Pow((float)i - _007B5958_007D, 2.0) <= Math.Pow(_007B5959_007D, 2.0) && j >= 0 && i >= 0 && j < _007B5962_007D && i < _007B5963_007D)
				{
					this[j, i] = true;
				}
			}
		}
	}

	public void SetData(Texture2D _007B5960_007D)
	{
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		Color[] array = (Color[])(object)new Color[_007B5962_007D * _007B5963_007D];
		for (int i = 0; i < _007B5963_007D; i++)
		{
			for (int j = 0; j < _007B5962_007D; j++)
			{
				byte b = (byte)(this[_007B5962_007D - i - 1, j] ? 255u : 0u);
				array[i * _007B5962_007D + j] = new Color((int)b, (int)b, (int)b, (int)b);
			}
		}
		_007B5960_007D.SetData<Color>(array);
	}

	public static byte[] BitArrayToByteArray(BitArray _007B5961_007D)
	{
		byte[] array = new byte[(_007B5961_007D.Length - 1) / 8 + 1];
		_007B5961_007D.CopyTo(array, 0);
		return array;
	}
}
