namespace Common.Game;

public delegate void CommonCannonCompleteAttackCallback();
