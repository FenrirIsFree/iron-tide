using TheraEngine;

namespace Common.Game;

internal class WheelBehavior : IBehavior
{
	public bool CanUse;

	public void Update(ref FrameTime _007B5215_007D, ref ShipOperatingParameters _007B5216_007D)
	{
		if (CanUse)
		{
			_007B5216_007D.CurrentMaxSpeed += 10f;
		}
	}
}
