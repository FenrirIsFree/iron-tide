namespace Common.Game;

public class QuestArenaCollectLootingMode : QuestStepHeader
{
	public readonly int Count;

	public override int ProgressComparand => Count;

	public QuestArenaCollectLootingMode(string _007B7532_007D, int _007B7533_007D)
		: base(_007B7532_007D)
	{
		Count = _007B7533_007D;
	}
}
