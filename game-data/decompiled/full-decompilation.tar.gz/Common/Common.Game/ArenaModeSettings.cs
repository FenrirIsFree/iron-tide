using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace Common.Game;

public class ArenaModeSettings
{
	internal static readonly Dictionary<ArenaMode, ArenaModeSettings> ByEnum = new Dictionary<ArenaMode, ArenaModeSettings>
	{
		[ArenaMode.DuelTraning] = new ArenaModeSettings
		{
			HasRewards = false,
			ModeEnum = ArenaMode.DuelTraning,
			WinKretery = ArenaWinKretery.KillAll,
			TimeLimitMin = int.MaxValue,
			RangRitriction = (min: 0, max: 6),
			EnableDangerZone = true,
			DangerZoneStartTimeSec = 480,
			RespawnLimit = 0,
			EnableRandomLoot = true
		},
		[ArenaMode.DuelRating] = new ArenaModeSettings
		{
			HasRewards = true,
			ModeEnum = ArenaMode.DuelRating,
			WinKretery = ArenaWinKretery.KillAll,
			TimeLimitMin = int.MaxValue,
			RangRitriction = (min: 0, max: 0),
			EnableDangerZone = true,
			DangerZoneStartTimeSec = 480,
			RespawnLimit = 0,
			HideNames = true,
			EnableRandomLoot = true,
			HideQuantity = true
		},
		[ArenaMode.WallVsWall] = new ArenaModeSettings
		{
			HasRewards = true,
			ModeEnum = ArenaMode.WallVsWall,
			WinKretery = ArenaWinKretery.KillAll,
			TimeLimitMin = int.MaxValue,
			RangRitriction = (min: 0, max: 6),
			EnableDangerZone = true,
			DangerZoneStartTimeSec = 240,
			EnableRandomLoot = true,
			RespawnLimit = 0
		},
		[ArenaMode.TowerDefence] = new ArenaModeSettings
		{
			HasRewards = true,
			ModeEnum = ArenaMode.TowerDefence,
			WinKretery = ArenaWinKretery.DestroyFort,
			TimeLimitMin = int.MaxValue,
			RangRitriction = (min: 0, max: 6),
			EnableRandomLoot = true,
			EnableDooblonsAndUpgrades = true,
			EnableHoldManagement = true,
			RespawnLimit = int.MaxValue,
			LimitedPowerupItems = false
		},
		[ArenaMode.Collecting] = new ArenaModeSettings
		{
			HasRewards = true,
			ModeEnum = ArenaMode.Collecting,
			WinKretery = ArenaWinKretery.LootCount,
			TimeLimitMin = 9,
			RangRitriction = (min: 0, max: 6),
			EnableRandomLoot = false,
			EnableDooblonsAndUpgrades = false,
			EnableHoldManagement = true,
			RespawnLimit = int.MaxValue,
			FastRespawn = true,
			LimitedPowerupItems = false
		}
	};

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ArenaMode _007B6938_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B6939_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private ArenaWinKretery _007B6940_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B6941_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B6942_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private (int min, int max) _007B6943_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private int _007B6944_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B6945_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private int _007B6946_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B6947_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private int _007B6948_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B6949_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B6950_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private int _007B6951_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B6952_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B6953_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B6954_007D = true;

	public const float DeadZoneReducingSpeedPerSec = 1.5f;

	public const float DeadZoneMinimum = 120f;

	public const float DeadZoneThresholdDistance = 50f;

	public const float BaseRadius = 37f;

	public const float TowerAttakDistance = 150f;

	public const float FortAttakDistance = 165f;

	public ArenaMode ModeEnum
	{
		[CompilerGenerated]
		get
		{
			return _007B6938_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B6938_007D = value;
		}
	}

	public bool IsDuetl
	{
		get
		{
			ArenaMode modeEnum = ModeEnum;
			if ((uint)modeEnum <= 1u)
			{
				return true;
			}
			return false;
		}
	}

	public bool HasRewards
	{
		[CompilerGenerated]
		get
		{
			return _007B6939_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B6939_007D = value;
		}
	}

	public ArenaWinKretery WinKretery
	{
		[CompilerGenerated]
		get
		{
			return _007B6940_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B6940_007D = value;
		}
	}

	public bool EnableDooblonsAndUpgrades
	{
		[CompilerGenerated]
		get
		{
			return _007B6941_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B6941_007D = value;
		}
	}

	public bool EnableHoldManagement
	{
		[CompilerGenerated]
		get
		{
			return _007B6942_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B6942_007D = value;
		}
	}

	public (int min, int max) RangRitriction
	{
		[CompilerGenerated]
		get
		{
			return _007B6943_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B6943_007D = value;
		}
	}

	public int RespawnLimit
	{
		[CompilerGenerated]
		get
		{
			return _007B6944_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B6944_007D = value;
		}
	}

	public bool FastRespawn
	{
		[CompilerGenerated]
		get
		{
			return _007B6945_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B6945_007D = value;
		}
	}

	public int TimeLimitMin
	{
		[CompilerGenerated]
		get
		{
			return _007B6946_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B6946_007D = value;
		}
	}

	public bool EnableDangerZone
	{
		[CompilerGenerated]
		get
		{
			return _007B6947_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B6947_007D = value;
		}
	}

	public int DangerZoneStartTimeSec
	{
		[CompilerGenerated]
		get
		{
			return _007B6948_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B6948_007D = value;
		}
	}

	public bool EnableRandomLoot
	{
		[CompilerGenerated]
		get
		{
			return _007B6949_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B6949_007D = value;
		}
	}

	public bool OnlyGroup
	{
		[CompilerGenerated]
		get
		{
			return _007B6950_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B6950_007D = value;
		}
	}

	public int GroupFixedSize
	{
		[CompilerGenerated]
		get
		{
			return _007B6951_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B6951_007D = value;
		}
	}

	public bool HideNames
	{
		[CompilerGenerated]
		get
		{
			return _007B6952_007D;
		}
		[CompilerGenerated]
		private set
		{
			_007B6952_007D = value;
		}
	}

	public bool HideQuantity
	{
		[CompilerGenerated]
		get
		{
			return _007B6953_007D;
		}
		[CompilerGenerated]
		private set
		{
			_007B6953_007D = value;
		}
	}

	public bool LimitedPowerupItems
	{
		[CompilerGenerated]
		get
		{
			return _007B6954_007D;
		}
		[CompilerGenerated]
		private set
		{
			_007B6954_007D = value;
		}
	}

	public static int MinPlayersPeerTeamForMassiveModes { get; set; } = 4;
}
