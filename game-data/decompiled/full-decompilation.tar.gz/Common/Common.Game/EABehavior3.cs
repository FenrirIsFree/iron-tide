using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public sealed class EABehavior3 : OneTimeBonus, IEventActionBehavior, IMPSerializable
{
	public int InventLocations;

	public ServerInventType Type;

	private void _007B6153_007D(WriterExtern _007B6154_007D)
	{
		WriteData(_007B6154_007D);
	}

	private void _007B6155_007D(WriterExtern _007B6156_007D)
	{
		ReadData(_007B6156_007D);
	}
}
