using Microsoft.Xna.Framework;
using TheraEngine.Helpers;

namespace Common.Game;

public struct MicroburningEffect
{
	public Vector3 LocalPositionClient;

	public float TimeLeft;

	public int DamageSourceUID;

	public unsafe MicroburningEffect(Ship _007B5082_007D, Vector3 _007B5083_007D, int _007B5084_007D)
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		DamageSourceUID = _007B5084_007D;
		TimeLeft = HashHelper.greater(((object)(*(Vector3*)(&_007B5083_007D))/*cast due to .constrained prefix*/).GetHashCode()) * 4000f + 6000f;
		if (CommonGlobal.IsServer)
		{
			LocalPositionClient = default(Vector3);
			return;
		}
		Vector3 _007B14809_007D = _007B5082_007D.Position3D + _007B5083_007D;
		_007B5083_007D = _007B5082_007D.Transform.InvTransform3X3(_007B14809_007D);
		LocalPositionClient = _007B5082_007D.UsedShip.StaticInfo.ProjectHitPosition(_007B5082_007D, _007B5083_007D, null);
	}
}
