using System;
using System.Collections.Generic;
using Common.Account;
using TheraEngine;

namespace Common.Game;

public class CraftingRecipe
{
	public RTI InputMoney;

	public readonly GSI InputItems;

	public float ReduceCraftCost = 0f;

	public float InputItemsMul => 1f - ReduceCraftCost;

	public CraftingRecipe(int _007B5389_007D, int _007B5390_007D, int _007B5391_007D)
		: this(_007B5390_007D, _007B5391_007D)
	{
		InputMoney = _007B5389_007D;
	}

	public CraftingRecipe(int _007B5392_007D, int _007B5393_007D)
	{
		InputMoney = 0;
		InputItems = new GSI().Exs(_007B5392_007D, _007B5393_007D);
	}

	public CraftingRecipe(int[] _007B5394_007D, int[] _007B5395_007D, int _007B5396_007D)
	{
		InputMoney = 0;
		if (_007B5394_007D.Length != _007B5395_007D.Length)
		{
			throw new ArgumentException();
		}
		InputItems = new GSI();
		int num = 0;
		for (int i = 0; i < _007B5394_007D.Length; i++)
		{
			InputItems.AddOrRemove(_007B5394_007D[i], _007B5395_007D[i]);
			num += _007B5395_007D[i];
		}
	}

	public CraftingRecipe(GSI _007B5397_007D)
	{
		InputMoney = 0;
		InputItems = _007B5397_007D;
	}

	public CraftingRecipe(RTI _007B5398_007D)
	{
		InputMoney = _007B5398_007D.Value;
		InputItems = new GSI();
	}

	public CraftingRecipe(GSI _007B5399_007D, RTI _007B5400_007D)
	{
		InputMoney = new RTI(_007B5400_007D.Value);
		InputItems = _007B5399_007D;
	}

	public bool IsAvailableFull(PlayerAccount _007B5401_007D)
	{
		return IsAvailableFull(_007B5401_007D, _007B5401_007D.NearPortStorage);
	}

	public bool IsAvailableFull(PlayerAccount _007B5402_007D, GSI _007B5403_007D)
	{
		return _007B5403_007D.CanRemove(GetTotal(1)) && _007B5402_007D.Gold >= GetMoney(1);
	}

	public void Apply(PlayerAccount _007B5404_007D)
	{
		Apply(_007B5404_007D, _007B5404_007D.NearPortStorage);
	}

	public void Apply(PlayerAccount _007B5405_007D, GSI _007B5406_007D)
	{
		_007B5406_007D.Remove(GetTotal(1));
		_007B5405_007D.Gold -= GetMoney(1);
	}

	public void ApplyMultiplied(PlayerAccount _007B5407_007D, GSI _007B5408_007D, int _007B5409_007D)
	{
		_007B5408_007D.Remove(GetTotal(_007B5409_007D));
		_007B5407_007D.Gold -= GetMoney(_007B5409_007D);
	}

	public int MaxCount(PlayerAccount _007B5410_007D, GSI _007B5411_007D)
	{
		int num = int.MaxValue;
		foreach (GSILocalPair item in (IEnumerable<GSILocalPair>)InputItems)
		{
			num = Math.Min((int)Math.Floor((float)_007B5411_007D[item.ID] / ((float)item.Count * (1f - ReduceCraftCost))), num);
		}
		if (!_007B5411_007D.CanRemove(GetTotal(num)))
		{
			num--;
		}
		if (InputMoney.Value != 0)
		{
			num = Math.Min(num, (int)MathF.Floor((float)_007B5410_007D.Gold / ((float)InputMoney.Value * (1f - ReduceCraftCost))));
		}
		else if (InputItems.IsEmpty)
		{
			throw new InvalidOperationException();
		}
		return num;
	}

	public GSI GetTotal(int _007B5412_007D)
	{
		GSI gSI = new GSI();
		foreach (GSILocalPair item in (IEnumerable<GSILocalPair>)InputItems)
		{
			gSI.Exs(item.ID, (int)Math.Ceiling((double)(item.Count * _007B5412_007D) * (1.0 - (double)ReduceCraftCost)));
		}
		return gSI;
	}

	public int GetMoney(int _007B5413_007D)
	{
		return (int)Math.Ceiling((double)(InputMoney.Value * _007B5413_007D) * (1.0 - (double)ReduceCraftCost));
	}
}
