using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;
using TheraEngine.Collections;

namespace Common.Game;

public struct DropTransferPacket : IMPSerializable
{
	public struct Partition : IMPSerializable
	{
		public int PlayerUID;

		public float DamageFactor;

		public Partition(int _007B5636_007D, float _007B5637_007D)
		{
			PlayerUID = _007B5636_007D;
			DamageFactor = _007B5637_007D;
		}

		private void _007B5638_007D(WriterExtern _007B5639_007D)
		{
			_007B5639_007D.WriteStruct<int>(ref PlayerUID);
			_007B5639_007D.WriteStruct<float>(ref DamageFactor);
		}

		private void _007B5640_007D(WriterExtern _007B5641_007D)
		{
			_007B5641_007D.ReadStruct<int>(ref PlayerUID);
			_007B5641_007D.ReadStruct<float>(ref DamageFactor);
		}
	}

	public int uID;

	public DropModel Model;

	public NDropInteropMethod InteropMethod;

	public DropServerEffect Effects;

	public Vector2 Position;

	public float RemainingTtlMs;

	public float InitialTtlMs;

	public GSI DisplayResourcesOnWorldmap;

	public WhaleController? Whale;

	public float LoadFactor;

	public DropRules Rule;

	public Tlist<Partition> RulesData;

	public ShipVisualFloodingComponent BindedShipFloodingDataOrNull;

	private void _007B5630_007D(WriterExtern _007B5631_007D)
	{
		_007B5631_007D.WriteStruct<int>(ref uID);
		_007B5631_007D.WriteByte((byte)Model);
		_007B5631_007D.WriteByte((byte)InteropMethod);
		_007B5631_007D.WriteByte((byte)Effects);
		_007B5631_007D.WriteStruct<Vector2>(ref Position);
		_007B5631_007D.WriteStruct<float>(ref RemainingTtlMs);
		_007B5631_007D.WriteStruct<float>(ref InitialTtlMs);
		_007B5631_007D.Write<ShipVisualFloodingComponent>(BindedShipFloodingDataOrNull);
		_007B5631_007D.WriteStruct<float>(ref LoadFactor);
		_007B5631_007D.WriteByte((byte)Rule);
		if (Rule != DropRules.Default && Rule != DropRules.DefaultWithoutPeace)
		{
			_007B5631_007D.WriteTlistStruct<Partition>(RulesData);
		}
		_007B5631_007D.Write<GSI>(DisplayResourcesOnWorldmap);
		_007B5631_007D.Write<WhaleController>(Whale);
	}

	private void _007B5632_007D(WriterExtern _007B5633_007D)
	{
		_007B5633_007D.ReadStruct<int>(ref uID);
		Model = (DropModel)_007B5633_007D.ReadByte();
		InteropMethod = (NDropInteropMethod)_007B5633_007D.ReadByte();
		Effects = (DropServerEffect)_007B5633_007D.ReadByte();
		_007B5633_007D.ReadStruct<Vector2>(ref Position);
		_007B5633_007D.ReadStruct<float>(ref RemainingTtlMs);
		_007B5633_007D.ReadStruct<float>(ref InitialTtlMs);
		_007B5633_007D.ReadIMPS<ShipVisualFloodingComponent>(ref BindedShipFloodingDataOrNull);
		_007B5633_007D.ReadStruct<float>(ref LoadFactor);
		Rule = (DropRules)_007B5633_007D.ReadByte();
		if (Rule != DropRules.Default && Rule != DropRules.DefaultWithoutPeace)
		{
			_007B5633_007D.ReadTlistStruct<Partition>(out RulesData);
		}
		_007B5633_007D.ReadIMPS<GSI>(ref DisplayResourcesOnWorldmap);
		_007B5633_007D.ReadIMPS<WhaleController>(ref Whale);
	}
}
