using System;
using System.Linq;
using Common.Resources;

namespace Common.Game;

public class QuestTradeItem : QuestStepHeader
{
	public bool SellItem = false;

	public int ItemQuantity;

	public int? ItemId = null;

	public EconomyRegion[] ItemEconomyRegion = Array.Empty<EconomyRegion>();

	public int[] PortIds = Array.Empty<int>();

	public EconomyRegion[] PortEconomyRegion = Array.Empty<EconomyRegion>();

	public override int ProgressComparand => ItemQuantity;

	public QuestTradeItem(string _007B7698_007D, bool _007B7699_007D, int _007B7700_007D, int _007B7701_007D, params int[] _007B7702_007D)
		: base(_007B7698_007D)
	{
		SellItem = _007B7699_007D;
		ItemQuantity = _007B7700_007D;
		ItemId = _007B7701_007D;
		PortIds = _007B7702_007D;
	}

	public QuestTradeItem(string _007B7703_007D, bool _007B7704_007D, int _007B7705_007D, EconomyRegion[] _007B7706_007D, params int[] _007B7707_007D)
		: base(_007B7703_007D)
	{
		SellItem = _007B7704_007D;
		ItemQuantity = _007B7705_007D;
		ItemEconomyRegion = _007B7706_007D;
		PortIds = _007B7707_007D;
	}

	public QuestTradeItem(string _007B7708_007D, bool _007B7709_007D, int _007B7710_007D, int _007B7711_007D, EconomyRegion[] _007B7712_007D)
		: base(_007B7708_007D)
	{
		SellItem = _007B7709_007D;
		ItemQuantity = _007B7710_007D;
		ItemId = _007B7711_007D;
		PortEconomyRegion = _007B7712_007D;
	}

	public QuestTradeItem(string _007B7713_007D, bool _007B7714_007D, int _007B7715_007D, EconomyRegion[] _007B7716_007D, EconomyRegion[] _007B7717_007D)
		: base(_007B7713_007D)
	{
		SellItem = _007B7714_007D;
		ItemQuantity = _007B7715_007D;
		ItemEconomyRegion = _007B7716_007D;
		PortEconomyRegion = _007B7717_007D;
	}

	public bool SuitableItem(int _007B7718_007D, ResourceInfo _007B7719_007D, IslePortInfo _007B7720_007D)
	{
		if ((_007B7718_007D < 0 && SellItem) || (_007B7718_007D > 0 && !SellItem) || _007B7718_007D == 0)
		{
			return false;
		}
		if (PortIds.Length != 0)
		{
			if (_007B7720_007D != null)
			{
				_ = _007B7720_007D.PortID;
				if (0 == 0 && PortIds.Contains(_007B7720_007D.PortID))
				{
					goto IL_0069;
				}
			}
			return false;
		}
		goto IL_0069;
		IL_0069:
		if (ItemId.HasValue && ItemId != _007B7719_007D.ID)
		{
			return false;
		}
		return (ItemEconomyRegion.Length == 0 || ItemEconomyRegion.Contains(_007B7719_007D.TradingItemEconomyRegion)) && (PortEconomyRegion.Length == 0 || PortEconomyRegion.Contains(_007B7720_007D.NearRegion.ItemsEconomyReigion));
	}
}
