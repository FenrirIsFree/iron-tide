namespace Common.Game;

public enum FractionID
{
	Pirate,
	Antilia,
	Espaniol,
	KaiAndSeveria,
	Empire,
	TradeUnion,
	None
}
