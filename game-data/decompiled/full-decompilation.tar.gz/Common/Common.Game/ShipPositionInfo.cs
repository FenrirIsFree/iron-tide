using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;

namespace Common.Game;

public struct ShipPositionInfo : IMPSerializable
{
	public Vector2 Position;

	public float Rotation;

	public ShipPositionInfo(Vector2 _007B5191_007D, float _007B5192_007D)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		Position = _007B5191_007D;
		Rotation = _007B5192_007D;
	}

	public ShipPositionInfo(Vector3 _007B5193_007D, float _007B5194_007D)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		Position.X = _007B5193_007D.X;
		Position.Y = _007B5193_007D.Z;
		Rotation = _007B5194_007D;
	}

	private void _007B5195_007D(WriterExtern _007B5196_007D)
	{
		_007B5196_007D.WriteStruct<Vector2>(ref Position);
		_007B5196_007D.WriteStruct<float>(ref Rotation);
	}

	private void _007B5197_007D(WriterExtern _007B5198_007D)
	{
		_007B5198_007D.ReadStruct<Vector2>(ref Position);
		_007B5198_007D.ReadStruct<float>(ref Rotation);
	}
}
