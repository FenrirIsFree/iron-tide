using System;
using Common.Packets;
using Common.Resources;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;
using UWPhysicsWOSLib.Shapes;

namespace Common.Game;

public abstract class CannonBall : UIDSceneObject, IPoolObject
{
	public enum HitType
	{
		None,
		HitsWithWater,
		BombExplosion,
		Collision
	}

	public static readonly float BoardingHookDistance = 15f;

	public static readonly float BoardingHookTimeFullDist = 0.7f;

	public const int MaxSailHitboxesCount = 3;

	public Vector3 StartMomentNormal;

	public bool ManualEndOfLifeEvent;

	public Tlist<byte> PassedSailHitboxes;

	public CannonBallExtraEffects Effects;

	public int BoardingTaretUid;

	public byte SourceCannonLocationId;

	public CannonsAttackMode ShotMode;

	public Vector3 Sphere;

	internal LineShape Shape;

	private int _007B4427_007D;

	private CannonBallInfo _007B4428_007D;

	private Vector3 _007B4429_007D;

	private Vector2 _007B4430_007D;

	private float _007B4431_007D;

	protected Vector3 lastVelocity;

	private Functions.HeightDist _007B4432_007D;

	private float _007B4433_007D = 0f;

	private float _007B4434_007D;

	private float _007B4435_007D;

	private Action _007B4436_007D;

	public int SenderUID => _007B4427_007D;

	public CannonBallInfo BallInfo => _007B4428_007D;

	public Vector3 StartPosition => _007B4429_007D;

	public float StartSpeed => _007B4431_007D;

	public float CurrentDistance => MathF.Sqrt((_007B4429_007D.X - Sphere.X) * (_007B4429_007D.X - Sphere.X) + (_007B4429_007D.Z - Sphere.Z) * (_007B4429_007D.Z - Sphere.Z));

	public float Lerps
	{
		get
		{
			float num = MathF.Sqrt((_007B4429_007D.X - Sphere.X) * (_007B4429_007D.X - Sphere.X) + (_007B4429_007D.Z - Sphere.Z) * (_007B4429_007D.Z - Sphere.Z));
			return MathHelper.Clamp(num / _007B4432_007D.SightDistance, 0f, 1f);
		}
	}

	public Functions.HeightDist CurrentFunctionData => _007B4432_007D;

	public bool IsHiddenBomb => _007B4435_007D > 0f;

	public static float SailDamageEnergy(int _007B4406_007D)
	{
		return (_007B4406_007D >= 3) ? 0f : (1f / (1f + (float)_007B4406_007D));
	}

	public CannonBall()
		: base(-1)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		Shape = new LineShape(Vector3.Zero, Vector3.Zero, 0f);
		PassedSailHitboxes = new Tlist<byte>(10);
	}

	public virtual void ClearResources()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		Sphere = Vector3.Zero;
		_007B4427_007D = -1;
		_007B4429_007D = Vector3.Zero;
		StartMomentNormal = Vector3.Zero;
		_007B4431_007D = 0f;
		ManualEndOfLifeEvent = false;
		uID = -1;
		_007B4434_007D = 0f;
		_007B4435_007D = 0f;
		_007B4433_007D = 0f;
		PassedSailHitboxes.Clear();
		_007B4436_007D = null;
		Effects = CannonBallExtraEffects.None;
		BoardingTaretUid = 0;
		_007B4430_007D = Vector2.Zero;
		SourceCannonLocationId = 0;
	}

	public void InitializeNewUnit(ref SingleShotData _007B4407_007D, Ship? _007B4408_007D)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		uID = _007B4407_007D.BallUID;
		_007B4427_007D = _007B4407_007D.SenderUID;
		_007B4428_007D = _007B4407_007D.BallInfo;
		StartMomentNormal = _007B4407_007D.BallNormal;
		_007B4429_007D = _007B4407_007D.BallServerStartPos;
		_007B4431_007D = _007B4407_007D.BallFinalSpeed;
		_007B4432_007D.SightDistance = _007B4407_007D.BallFinalDistance;
		_007B4432_007D.SightHeight = _007B4407_007D.BallFinalCurve;
		Effects = _007B4407_007D.Effects;
		_007B4430_007D = _007B4408_007D?.physicsBody.VelocityPerSec ?? Vector2.Zero;
		Sphere = _007B4429_007D;
		Shape.SetData(_007B4429_007D, _007B4429_007D + StartMomentNormal);
		ShotMode = _007B4407_007D.ShotMode;
		_007B4418_007D();
		FinalInitialize();
	}

	public void InitializeUnitFromPacket(ref CommonShotInfo _007B4409_007D, Vector3 _007B4410_007D, Ship? _007B4411_007D, int _007B4412_007D, int _007B4413_007D, CannonsAttackMode _007B4414_007D)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		uID = _007B4409_007D.UID;
		StartMomentNormal = _007B4409_007D.StartNormalMultiplySpeed;
		((Vector3)(ref StartMomentNormal)).Normalize();
		_007B4431_007D = ((Vector3)(ref _007B4409_007D.StartNormalMultiplySpeed)).Length();
		_007B4428_007D = Gameplay.BallsInfo.FromID(_007B4412_007D);
		_007B4429_007D = _007B4410_007D;
		_007B4427_007D = _007B4413_007D;
		Effects = _007B4409_007D.Effects;
		_007B4432_007D.SightDistance = _007B4409_007D.FinalDistance;
		_007B4432_007D.SightHeight = _007B4409_007D.FinalCurve;
		_007B4430_007D = ((_007B4411_007D == null || _007B4411_007D is Npc) ? Vector2.Zero : _007B4411_007D.physicsBody.VelocityPerSec);
		SourceCannonLocationId = _007B4409_007D.SenderCannonSectionUID;
		ShotMode = _007B4414_007D;
		Sphere = _007B4429_007D;
		Shape.SetData(_007B4429_007D, _007B4429_007D + StartMomentNormal);
		_007B4418_007D();
		FinalInitialize();
	}

	public void InitializeNewUnitFalk(in FalkonetShotInfoRemote _007B4415_007D, int _007B4416_007D, Vector3 _007B4417_007D)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		uID = _007B4415_007D.UID;
		_007B4427_007D = _007B4416_007D;
		_007B4428_007D = Gameplay.BallsInfo.FromID(_007B4415_007D.AmmoID);
		StartMomentNormal = _007B4415_007D.SightDirection;
		_007B4429_007D = _007B4417_007D;
		_007B4431_007D = 1f;
		_007B4432_007D.SightDistance = 1f;
		_007B4432_007D.SightHeight = 1f;
		BoardingTaretUid = _007B4415_007D.BoardingHookTargetUid;
		Sphere = _007B4429_007D;
		Shape.SetData(_007B4429_007D, _007B4429_007D + StartMomentNormal);
		_007B4418_007D();
		FinalInitialize();
	}

	private void _007B4418_007D()
	{
		_007B4434_007D = 0f;
		Shape.radius = _007B4428_007D.CollisionRadius;
		Shape.OnUpdate();
	}

	protected abstract void FinalInitialize();

	public void UpdateFalkonetBall(ref FrameTime _007B4419_007D, Ship _007B4420_007D)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_035c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0362: Unknown result type (might be due to invalid IL or missing references)
		//IL_0368: Unknown result type (might be due to invalid IL or missing references)
		//IL_0372: Unknown result type (might be due to invalid IL or missing references)
		//IL_0377: Unknown result type (might be due to invalid IL or missing references)
		if (_007B4420_007D != null)
		{
			Sphere.X += _007B4420_007D.Position.X - _007B4429_007D.X;
			Sphere.Z += _007B4420_007D.Position.Y - _007B4429_007D.Z;
			_007B4429_007D.X = _007B4420_007D.Position.X;
			_007B4429_007D.Z = _007B4420_007D.Position.Y;
		}
		if (_007B4428_007D.IsBoardingHook)
		{
			float num = Vector2.Distance(Sphere.XZ(), _007B4429_007D.XZ());
			if (num < BoardingHookDistance)
			{
				lastVelocity.X = StartMomentNormal.X * _007B4419_007D.secElapsed * BoardingHookDistance / BoardingHookTimeFullDist;
				lastVelocity.Z = StartMomentNormal.Z * _007B4419_007D.secElapsed * BoardingHookDistance / BoardingHookTimeFullDist;
				lastVelocity.Y = -1f * _007B4419_007D.secElapsed;
			}
			else
			{
				lastVelocity.X = 0f;
				lastVelocity.Z = 0f;
				lastVelocity.Y = -2f * _007B4419_007D.secElapsed;
			}
			Sphere += lastVelocity;
		}
		else
		{
			float num2 = MathHelper.Lerp(0f, _007B4428_007D.DistanceFactor, StartMomentNormal.Y);
			float num3 = Vector2.Distance(_007B4429_007D.XZ(), Sphere.XZ());
			float num4 = num3 / num2;
			float num5 = _007B4428_007D.Speed * (0.4f + 0.6f * StartMomentNormal.Y);
			float num6 = _007B4419_007D.secElapsed * num5 * 1.396f * (1.05f - num4 * num4);
			_007B4433_007D += _007B4419_007D.secElapsed * num5 / num2;
			float num7 = _007B4433_007D - _007B4433_007D * _007B4433_007D * ((_007B4428_007D.ID == 18) ? 0.3f : 1f);
			lastVelocity.X = StartMomentNormal.X * num6 * 1.2f;
			lastVelocity.Z = StartMomentNormal.Z * num6 * 1.2f;
			Sphere.X += lastVelocity.X;
			Sphere.Z += lastVelocity.Z;
			float num8 = _007B4429_007D.Y * (1f - _007B4433_007D) + num7 * (_007B4428_007D.FalkonetGoesAbove ? (10f + num2 * 0.6f) : (num2 * 0.2f * (0.05f + 0.7f * StartMomentNormal.Y * StartMomentNormal.Y)));
			lastVelocity.Y = num8 - Sphere.Y;
			Sphere.Y = num8;
		}
		Shape.SetData(Sphere, Sphere + lastVelocity * 4f);
		_007B4434_007D += _007B4419_007D.msElapsed;
	}

	public void UpdateCannonBall(ref FrameTime _007B4421_007D)
	{
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fa: Unknown result type (might be due to invalid IL or missing references)
		if (_007B4435_007D > 0f)
		{
			_007B4435_007D = Math.Max(1f, _007B4435_007D - _007B4421_007D.msElapsed);
			_007B4436_007D?.Invoke();
			return;
		}
		float num = MathF.Sqrt((_007B4429_007D.X - Sphere.X) * (_007B4429_007D.X - Sphere.X) + (_007B4429_007D.Z - Sphere.Z) * (_007B4429_007D.Z - Sphere.Z));
		float ballHeight = Functions.GetBallHeight(num / _007B4432_007D.SightDistance, _007B4432_007D, _007B4429_007D.Y);
		float num2 = Functions.GetCannonBallSpeedMultiplier(num / _007B4432_007D.SightDistance, _007B4432_007D.SightDistance);
		if (_007B4428_007D.ID == 6)
		{
			num2 *= num2 * num2 * num2 * num2 * 1.4f;
		}
		num2 *= _007B4428_007D.Speed;
		Vector3.Multiply(ref StartMomentNormal, _007B4431_007D * _007B4421_007D.secElapsed * 45.760002f * num2 * CommonGameConfig.CurrentSettings.ExperimentalCannonBallsSpeed, ref lastVelocity);
		ref Vector3 reference = ref lastVelocity;
		((Vector3)(ref reference)).XZ = ((Vector3)(ref reference)).XZ + _007B4430_007D * _007B4421_007D.secElapsed * 0.2f;
		Sphere.X += lastVelocity.X;
		Sphere.Z += lastVelocity.Z;
		lastVelocity.Y = (ballHeight - Sphere.Y) * 0.5f;
		Sphere.Y = ballHeight;
		Shape.SetData(Sphere, Sphere - lastVelocity);
		_007B4434_007D += _007B4421_007D.msElapsed;
	}

	public void LifetimeCheck(WorldMapInfo _007B4422_007D, out HitType _007B4423_007D, WeatherEngine _007B4424_007D)
	{
		if (_007B4434_007D > 20000f)
		{
			_007B4423_007D = ((!Effects.HasFlag(CannonBallExtraEffects.BombershellBoos)) ? HitType.HitsWithWater : HitType.BombExplosion);
			return;
		}
		if (_007B4435_007D >= 1f)
		{
			_007B4423_007D = ((_007B4435_007D == 1f) ? HitType.BombExplosion : HitType.None);
			return;
		}
		if (ManualEndOfLifeEvent)
		{
			_007B4423_007D = HitType.Collision;
			return;
		}
		if (_007B4428_007D.ID == 18 && _007B4434_007D > 1400f)
		{
			_007B4423_007D = HitType.BombExplosion;
			return;
		}
		_007B4423_007D = HitType.None;
		if (WeatherEngine.MaxWaveHeightDangerStorm > Sphere.Y + 0.15f && _007B4424_007D.HeightOnlyHelper(_007B4422_007D, Sphere.X, Sphere.Z) > Sphere.Y + 0.15f)
		{
			_007B4423_007D = HitType.HitsWithWater;
		}
	}

	public void OnBombCollision(WorldMapInfo _007B4425_007D)
	{
		_007B4435_007D = Math.Max(1000f, 4000f - _007B4434_007D);
		_007B4436_007D = delegate
		{
			Sphere.Y = _007B4425_007D.Weather.HeightOnlyHelper(_007B4425_007D, Sphere.X, Sphere.Z);
		};
	}

	public void OnBombCollision(Ship _007B4426_007D)
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		_007B4435_007D = Math.Max(1000f, 4000f - _007B4434_007D);
		int cachedUid = _007B4426_007D.uID;
		Vector3 localPosition = _007B4426_007D.Transform.InvTransform3X3(Sphere);
		_007B4436_007D = delegate
		{
			//IL_0047: Unknown result type (might be due to invalid IL or missing references)
			//IL_0051: Unknown result type (might be due to invalid IL or missing references)
			//IL_0056: Unknown result type (might be due to invalid IL or missing references)
			//IL_005b: Unknown result type (might be due to invalid IL or missing references)
			if (_007B4426_007D.InstanceAlive && !_007B4426_007D.IsDestroyed && _007B4426_007D.uID == cachedUid)
			{
				Sphere = _007B4426_007D.transform.Transform3X3(localPosition * 0.92f);
			}
			else
			{
				_007B4436_007D = null;
			}
		};
	}
}
