using System;
using System.Collections.Generic;
using Common.Account;
using Common.Resources;
using CommonDataTypes;

namespace Common.Game;

public static class WosbAchievements
{
	public static readonly Dictionary<int, (AchievementEnum Type, int Count)[]> AchievementsForShips = new Dictionary<int, (AchievementEnum, int)[]>
	{
		{
			50,
			new(AchievementEnum, int)[3]
			{
				(AchievementEnum.FullReputation, 1),
				(AchievementEnum.AuctionTrade10000k, 1),
				(AchievementEnum.CollectAllSailageLegends, 1)
			}
		},
		{
			57,
			new(AchievementEnum, int)[1] { (AchievementEnum.LuckyOne, 1) }
		},
		{
			63,
			new(AchievementEnum, int)[1] { (AchievementEnum.ArmedBusinessman, 30) }
		}
	};

	public static (GSI items, string info) GetReward(AchievementEnum _007B3864_007D)
	{
		string item = string.Empty;
		GSI gSI = new GSI();
		switch (_007B3864_007D)
		{
		case AchievementEnum.FirstPlayerKill:
			gSI.Exs(37, 20);
			break;
		case AchievementEnum.GladiatorMass:
			gSI.Exs(37, 20);
			break;
		case AchievementEnum.GladiatorRating:
			gSI.Exs(37, 20);
			break;
		case AchievementEnum.AllSinglePassed:
			gSI.Exs(15, 20);
			break;
		case AchievementEnum.RangFive:
			gSI.Exs(38, 3);
			break;
		case AchievementEnum.ContrabandaWithoutCannons:
			gSI.Exs(35, 2);
			break;
		case AchievementEnum.BeforeRang30:
			gSI.Exs(37, 200);
			gSI.Exs(38, 15);
			break;
		case AchievementEnum.ManyFriendsReferal:
			item = $"{1000} {Local.monets}";
			break;
		}
		return (items: gSI, info: item);
	}

	public static void AddReward(Player _007B3865_007D, GSI _007B3866_007D)
	{
		foreach (GSILocalPair item in (IEnumerable<GSILocalPair>)_007B3866_007D)
		{
			if (RewardAddToStorage(_007B3865_007D))
			{
				_007B3865_007D.AccountConnection.NearPortStorage[item.ID] += item.Count;
			}
			else
			{
				_007B3865_007D.AccountConnection.Shipyard.CurrentRealShip.PrivateResourcesOfHold[item.ID] += item.Count;
			}
		}
		WosbTreasuryMaps.DetachMaps(_007B3865_007D.AccountConnection);
	}

	public static bool RewardAddToStorage(Player _007B3867_007D)
	{
		return (_007B3867_007D.IsPortEntry && (_007B3867_007D.NearPortType == PortEnteringType.Port || _007B3867_007D.NearPortType == PortEnteringType.PersonalIsle)) || !_007B3867_007D.MapInfo.IsWorldmap;
	}

	public static bool CheckShipAchievementsCompleted(ShipStaticInfo _007B3868_007D, PlayerAccount _007B3869_007D)
	{
		if (AchievementsForShips.TryGetValue(_007B3868_007D.ID, out (AchievementEnum, int)[] value))
		{
			(AchievementEnum, int)[] array = value;
			for (int i = 0; i < array.Length; i++)
			{
				(AchievementEnum, int) tuple = array[i];
				if (_007B3869_007D.Achievements.Count(tuple.Item1) < tuple.Item2)
				{
					return false;
				}
			}
		}
		return true;
	}

	public static string GetShipAchievementState(AchievementEnum _007B3870_007D, PlayerAccount _007B3871_007D, GuildCommon _007B3872_007D, int _007B3873_007D)
	{
		switch (_007B3870_007D)
		{
		case AchievementEnum.CollectAllSailageLegends:
		{
			int num3 = Gameplay.PlayersInfo.Count((PlayerShipInfo _007B3874_007D) => _007B3874_007D.IsSailageLegend && _007B3874_007D.Coolness != PlayerShipCoolness.Elite);
			int sailageLegendsResearchedCount = _007B3871_007D.Shipyard.SailageLegendsResearchedCount;
			return Local.PortCraftShipWindow_BalloonInfo_1(sailageLegendsResearchedCount, num3);
		}
		case AchievementEnum.FullReputation:
		{
			bool flag = _007B3872_007D != null && _007B3872_007D.Fraction == FractionID.Pirate;
			float num = (flag ? _007B3871_007D.Reputations.AverageRound : _007B3871_007D.Reputations.MaxReputation);
			float num2 = (flag ? (-100f) : 100f);
			return Local.PortCraftShipWindow_BalloonInfo_2(num, num2);
		}
		case AchievementEnum.AuctionTrade10000k:
			return Local.PortCraftShipWindow_BalloonInfo_3($"{(float)_007B3873_007D / 1000000f:F1}");
		case AchievementEnum.LuckyOne:
			return Local.achiv_53_state(_007B3871_007D.OpenedChestsCount);
		case AchievementEnum.ArmedBusinessman:
			return Local.achiv_59_state(_007B3871_007D.Achievements.Count(AchievementEnum.ArmedBusinessman));
		default:
			throw new InvalidOperationException($"Unknown ship achivement {_007B3870_007D}");
		}
	}
}
