using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Game;

public struct RatingInformation : IMPSerializable
{
	public int MyPosition;

	public int MyRating;

	public Tlist<VisibleRatingLabel> Top100;

	public RatingType Rating;

	public int TotalPlayersCount;

	public int ExtraParameter;

	public RatingInformation(int _007B6241_007D, int _007B6242_007D, Tlist<VisibleRatingLabel> _007B6243_007D, RatingType _007B6244_007D, int _007B6245_007D, int _007B6246_007D)
	{
		MyPosition = _007B6241_007D;
		MyRating = _007B6242_007D;
		Top100 = _007B6243_007D;
		Rating = _007B6244_007D;
		TotalPlayersCount = _007B6245_007D;
		ExtraParameter = _007B6246_007D;
	}

	private void _007B6247_007D(WriterExtern _007B6248_007D)
	{
		_007B6248_007D.WriteStruct<int>(ref MyPosition);
		_007B6248_007D.WriteStruct<int>(ref MyRating);
		_007B6248_007D.WriteTlistStruct<VisibleRatingLabel>(Top100);
		_007B6248_007D.WriteByte((byte)Rating);
		_007B6248_007D.WriteStruct<int>(TotalPlayersCount);
		_007B6248_007D.WriteStruct<int>(ExtraParameter);
	}

	private void _007B6249_007D(WriterExtern _007B6250_007D)
	{
		_007B6250_007D.ReadStruct<int>(ref MyPosition);
		_007B6250_007D.ReadStruct<int>(ref MyRating);
		_007B6250_007D.ReadTlistStruct<VisibleRatingLabel>(out Top100);
		Rating = (RatingType)_007B6250_007D.ReadByte();
		_007B6250_007D.ReadStruct<int>(ref TotalPlayersCount);
		_007B6250_007D.ReadStruct<int>(ref ExtraParameter);
	}
}
