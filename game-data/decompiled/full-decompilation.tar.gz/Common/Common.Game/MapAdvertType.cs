namespace Common.Game;

public enum MapAdvertType : byte
{
	FleetSearch,
	FortOrShipAttack,
	PvPFightSearch,
	LowHpPlayer
}
