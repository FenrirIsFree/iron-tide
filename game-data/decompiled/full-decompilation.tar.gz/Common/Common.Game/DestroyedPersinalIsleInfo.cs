using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct DestroyedPersinalIsleInfo : IMPSerializable
{
	public byte PlaceIndex;

	public float IsleCraftTime;

	public DestroyedPersinalIsleInfo(PersonalIsleStatus _007B8399_007D)
	{
		PlaceIndex = _007B8399_007D.PlaceIndex;
		IsleCraftTime = _007B8399_007D.IsleCraftTime.Value;
	}

	public void Boxing(WriterExtern _007B8400_007D)
	{
		_007B8400_007D.WriteByte(PlaceIndex);
		_007B8400_007D.WriteStruct<float>(IsleCraftTime);
	}

	public void Unboxing(WriterExtern _007B8401_007D)
	{
		PlaceIndex = _007B8401_007D.ReadByte();
		_007B8401_007D.ReadStruct<float>(ref IsleCraftTime);
	}
}
