using System;
using System.Collections.Generic;
using Common.Account;
using Common.Resources;
using CommonDataTypes;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Helpers;
using TheraEngine.PacketValues;

namespace Common.Game;

public class CannonCollection : IDisposable
{
	public const bool WeightTest = false;

	public Tlist<CannonCommon> Items;

	public Tlist<CannonSerializedInfo> BrokenItems = new Tlist<CannonSerializedInfo>(1);

	public Vector2 MinMaxDistance;

	public Bits256 CannonsHavingFlagsBySectionId;

	private Tlist<CannonCommon> _007B4547_007D = new Tlist<CannonCommon>();

	private readonly TinyMap<CannonLocation, int> _007B4548_007D;

	private readonly TinyMap<CannonLocation, float> _007B4549_007D;

	internal bool isAllCannonsReloaded;

	private float _007B4550_007D;

	public int Count => Items.Size;

	public float CannonsWeight => _007B4550_007D;

	public bool HavingFireguns => _007B4547_007D.Size > 0;

	public Tlist<CannonCommon> Fireguns => _007B4547_007D;

	public bool IsAllReloadedApprox => isAllCannonsReloaded;

	public int NumberOfCannons(CannonLocation _007B4489_007D)
	{
		return _007B4548_007D[_007B4489_007D];
	}

	public bool IsBoardNotEmpty(CannonLocation _007B4490_007D)
	{
		return _007B4548_007D[_007B4490_007D] > 0;
	}

	public float BoardMiddleAxis(CannonLocation _007B4491_007D)
	{
		return _007B4549_007D[_007B4491_007D];
	}

	public CannonCollection()
	{
		_007B4548_007D = new TinyMap<CannonLocation, int>((CannonLocation _007B4551_007D) => (int)_007B4551_007D, 4);
		_007B4549_007D = new TinyMap<CannonLocation, float>((CannonLocation _007B4552_007D) => (int)_007B4552_007D, 4);
		base._002Ector();
		Items = new Tlist<CannonCommon>(3);
	}

	public CannonCollection(NpcInfo _007B4492_007D, ShipStaticInfo _007B4493_007D, bool _007B4494_007D)
	{
		_007B4548_007D = new TinyMap<CannonLocation, int>((CannonLocation _007B4553_007D) => (int)_007B4553_007D, 4);
		_007B4549_007D = new TinyMap<CannonLocation, float>((CannonLocation _007B4554_007D) => (int)_007B4554_007D, 4);
		base._002Ector();
		if (_007B4492_007D.CannonInfo == null)
		{
			_007B4492_007D.CannonInfo = new CannonGameInfo(_007B4492_007D);
		}
		Items = new Tlist<CannonCommon>(_007B4493_007D.Ports.Length);
		SetupAll(_007B4493_007D, _007B4492_007D.CannonInfo, _007B4494_007D ? new CannonFeature?(CannonFeature.EightShot) : ((CannonFeature?)null));
	}

	public CannonCollection(ShipStaticInfo _007B4495_007D, CannonGameInfo _007B4496_007D)
	{
		_007B4548_007D = new TinyMap<CannonLocation, int>((CannonLocation _007B4555_007D) => (int)_007B4555_007D, 4);
		_007B4549_007D = new TinyMap<CannonLocation, float>((CannonLocation _007B4556_007D) => (int)_007B4556_007D, 4);
		base._002Ector();
		Items = new Tlist<CannonCommon>(_007B4495_007D.Ports.Length);
		SetupAll(_007B4495_007D, _007B4496_007D, null);
	}

	public void SetupAll(ShipStaticInfo _007B4497_007D, CannonGameInfo _007B4498_007D, CannonFeature? _007B4499_007D)
	{
		if (Items.Size != 0)
		{
			throw new InvalidOperationException();
		}
		CannonLocationInfo[] ports = _007B4497_007D.Ports;
		foreach (CannonLocationInfo cannonLocationInfo in ports)
		{
			if (cannonLocationInfo.Mode == CannonLocationMode.Special)
			{
				if (_007B4499_007D.HasValue)
				{
					Items.Add(new CannonCommon(cannonLocationInfo, Gameplay.CannonsGameInfo.First((CannonGameInfo _007B4559_007D) => _007B4559_007D.Feature == _007B4499_007D.Value)));
				}
			}
			else
			{
				Items.Add(new CannonCommon(cannonLocationInfo, _007B4498_007D));
			}
		}
		CheckStatic(_007B4497_007D);
		UpdateInformation();
	}

	public bool CheckStatic(ShipStaticInfo _007B4500_007D)
	{
		bool result = false;
		CannonLocationInfo[] ports = _007B4500_007D.Ports;
		foreach (CannonLocationInfo cannonLocationInfo in ports)
		{
			if (!cannonLocationInfo.IsStatic)
			{
				continue;
			}
			CannonCommon cannonCommon = FindByLocation(cannonLocationInfo.SectionID);
			if (cannonCommon == null)
			{
				if (_007B4500_007D.ID != 63)
				{
					throw new InvalidOperationException("Unknown static cannon");
				}
				CannonCommon item = new CannonCommon(cannonLocationInfo, Gameplay.CannonsGameInfo.First((CannonGameInfo _007B4557_007D) => _007B4557_007D.Feature == CannonFeature.EightShot));
				Items.Add(in item);
				result = true;
			}
		}
		return result;
	}

	internal void UpdateEffects(ref FrameTime _007B4501_007D)
	{
		for (int i = 0; i < Items.Size; i++)
		{
			CannonCommon cannonCommon = Items.Array[i];
			_007B4501_007D.EvaluteTimerMs(ref cannonCommon.RollbackEffect);
			_007B4501_007D.EvaluteTimerMs(ref cannonCommon.ClientHitEffectMs);
		}
	}

	internal void UpdateReloading(FrameTime _007B4502_007D, Player _007B4503_007D, float _007B4504_007D)
	{
		if (isAllCannonsReloaded || _007B4502_007D.msElapsed == 0f)
		{
			return;
		}
		float num = _007B4503_007D.UsedShip.Crew.Effectivity(_007B4503_007D.UsedShip);
		int num2 = 0;
		for (int i = 0; i < Items.Size; i++)
		{
			CannonCommon cannonCommon = Items.Array[i];
			if (cannonCommon.reloadTimer == 0f && cannonCommon.overheat >= 0f && cannonCommon.overheat < 1f)
			{
				cannonCommon.overheat = Math.Max(0f, cannonCommon.overheat - _007B4502_007D.secElapsed / 25f);
				if (cannonCommon.overheat == 0f)
				{
					num2++;
				}
				continue;
			}
			cannonCommon.reloadTimer = Math.Max(0f, cannonCommon.reloadTimer - _007B4502_007D.msElapsed * (1f + _007B4504_007D) * num);
			if (cannonCommon.overheat > 1f)
			{
				cannonCommon.overheat = -1f;
			}
			if (cannonCommon.overheat < 0f)
			{
				cannonCommon.overheat += _007B4502_007D.secElapsed / 25f;
				if (cannonCommon.overheat > 0f)
				{
					cannonCommon.overheat = 0f;
				}
			}
			if (cannonCommon.reloadTimer == 0f && cannonCommon.overheat == 0f)
			{
				num2++;
			}
		}
		if (num2 == Items.Size)
		{
			isAllCannonsReloaded = true;
		}
	}

	public void UpdateReloadingNpcServer(ref FrameTime _007B4505_007D, Npc _007B4506_007D)
	{
		if (isAllCannonsReloaded)
		{
			return;
		}
		float num = _007B4506_007D.UsedShip.Crew.Effectivity(_007B4506_007D.UsedShip);
		int num2 = 0;
		for (int i = 0; i < Items.Size; i++)
		{
			CannonCommon cannonCommon = Items.Array[i];
			cannonCommon.reloadTimer = Math.Max(0f, cannonCommon.reloadTimer - _007B4505_007D.msElapsed * num);
			if (cannonCommon.reloadTimer == 0f)
			{
				num2++;
			}
		}
		if (num2 == Items.Size)
		{
			isAllCannonsReloaded = true;
		}
	}

	public void BeginReloadWeapons(Ship _007B4507_007D, CannonBallInfo _007B4508_007D, CannonBallInfo _007B4509_007D, CannonLocation? _007B4510_007D)
	{
		float num = 0f;
		if (_007B4507_007D is Player player)
		{
			num += player.UsedShipPlayer.ChangeCBallsBonus;
		}
		if (_007B4508_007D != null && _007B4509_007D != null)
		{
			num += 1.33f * Geometry.Saturate(Math.Max(1f - _007B4508_007D.ReloadFactor, 1f - _007B4509_007D.ReloadFactor));
		}
		num = _007B4507_007D.UsedShip.StaticInfo.ChangeBallsSpeedMul * (1f + num);
		for (int i = 0; i < Items.Size; i++)
		{
			if (!_007B4510_007D.HasValue || Items.Array[i].Location.Side == _007B4510_007D)
			{
				Items.Array[i].BeginReload(this, num);
			}
		}
	}

	public Functions.HeightDist? SelectAvailableCannons(Vector2 _007B4511_007D, Player _007B4512_007D, Tlist<CannonCommon> _007B4513_007D, CannonsAttackMode _007B4514_007D, float _007B4515_007D, PlayerShipDynamicInfo _007B4516_007D, CannonBallInfo _007B4517_007D, bool _007B4518_007D)
	{
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_030c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0326: Unknown result type (might be due to invalid IL or missing references)
		//IL_032d: Unknown result type (might be due to invalid IL or missing references)
		int num = ((_007B4514_007D == CannonsAttackMode.SingleCannon) ? 1 : 1000);
		int num2 = num;
		float cannonsAxisBonusRad = _007B4512_007D.UsedShip.CannonsAxisBonusRad;
		float val = MathHelper.ToRadians(5f);
		float rotation = _007B4512_007D.Rotation;
		bool flag = _007B4514_007D == CannonsAttackMode.X_AllAntiNormal;
		float num3 = 0f;
		float num4 = 0f;
		for (int i = 0; i < Items.Size; i++)
		{
			Vector2 _007B4568_007D = _007B4511_007D;
			CannonCommon cannonCommon = Items.Array[flag ? (Items.Size - i - 1) : i];
			if (cannonCommon.DirectionTestSide(ref _007B4568_007D, rotation))
			{
				num3 = Math.Max(num3, cannonCommon.GameInfo.MaxDistance);
				if (cannonCommon.DirectionTest(ref _007B4568_007D, rotation, CommonGlobal.IsServer, Math.Max(_007B4549_007D[cannonCommon.Location.Side] + cannonsAxisBonusRad, val)))
				{
					num4 = Math.Max(num4, cannonCommon.GameInfo.MaxDistance);
				}
			}
		}
		if (num3 == 0f || num4 == 0f)
		{
			return null;
		}
		Functions.HeightDist data = Functions.GetData(num3, _007B4515_007D, _007B4517_007D.CurveMultiplier, 1f);
		data.SightDistance = Math.Min(num4, data.SightDistance);
		num2 = num;
		for (int j = 0; j < Items.Size; j++)
		{
			Vector2 _007B4564_007D = _007B4511_007D;
			CannonCommon item = Items.Array[flag ? (Items.Size - j - 1) : j];
			if (item.DirectionTest(ref _007B4564_007D, rotation, CommonGlobal.IsServer, Math.Max(_007B4549_007D[item.Location.Side] + cannonsAxisBonusRad, val)) && (item.IsReloaded || _007B4512_007D.DebugEnabled || !_007B4518_007D) && data.SightDistance <= item.GameInfo.MaxDistance + 1f)
			{
				_007B4513_007D.Add(in item);
			}
		}
		if (_007B4514_007D != CannonsAttackMode.SingleCannon && (_007B4513_007D.Size - num2 < 4 || (_007B4513_007D.Size != 0 && (_007B4513_007D.Array[0].Location.Side == CannonLocation.InBack || _007B4513_007D.Array[0].Location.Side == CannonLocation.InFront))))
		{
			num2 = _007B4513_007D.Size;
		}
		_007B4513_007D.Size = Math.Min(_007B4513_007D.Size, num2);
		if (_007B4512_007D.UsedShip.FirstHP.FloodingFactor > 0f)
		{
			float _007B5859_007D = _007B4512_007D.MapInfo.Weather.WavesHeight(_007B4512_007D.MapInfo, _007B4512_007D.Position);
			for (int k = 0; k < _007B4513_007D.Size; k++)
			{
				CannonCommon cannonCommon2 = _007B4513_007D.Array[k];
				Vector3 position = cannonCommon2.GetPosition(_007B4512_007D.Transform);
				if (cannonCommon2.Location.Mode == CannonLocationMode.Special || position.Y - 0.5f < _007B4512_007D.MapInfo.Weather.HeightOnlyFast(_007B5859_007D, position.X, position.Z))
				{
					_007B4513_007D.FastRemoveAt(k);
					k--;
				}
			}
		}
		data.SightDistance *= _007B4517_007D.DistanceFactor;
		return data;
	}

	internal void OnExitFromPort()
	{
		for (int i = 0; i < Items.Size; i++)
		{
			Items.Array[i].OnExitFromPort();
		}
	}

	public int GetReloadedCountOfSide(CannonLocation _007B4519_007D)
	{
		int num = 0;
		for (int i = 0; i < Items.Size; i++)
		{
			if (Items.Array[i].Location.Side == _007B4519_007D && Items.Array[i].IsReloaded)
			{
				num++;
			}
		}
		return num;
	}

	public Vector2 GetMinMaxReloadFactor(CannonLocation _007B4520_007D)
	{
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector(1f, 0f);
		foreach (CannonCommon item in (IEnumerable<CannonCommon>)Items)
		{
			if (item.Location.Side == _007B4520_007D && !item.IsReloaded)
			{
				float reloadFactor = item.ReloadFactor;
				val.X = Math.Min(reloadFactor, val.X);
				val.Y = Math.Max(reloadFactor, val.Y);
			}
		}
		return val;
	}

	public float GetReloadFactor(CannonLocation _007B4521_007D)
	{
		float num = 0f;
		int num2 = 0;
		for (int i = 0; i < Items.Size; i++)
		{
			if (Items.Array[i].Location.Side == _007B4521_007D)
			{
				num += Items.Array[i].ReloadFactor;
				num2++;
			}
		}
		return (num2 == 0) ? 0f : (num / (float)num2);
	}

	public bool IsReloaded(CannonLocation _007B4522_007D)
	{
		for (int i = 0; i < Items.Size; i++)
		{
			if (Items.Array[i].Location.Side == _007B4522_007D && !Items.Array[i].IsReloaded)
			{
				return false;
			}
		}
		return true;
	}

	public void Install(CannonLocationInfo _007B4523_007D, CannonGameInfo _007B4524_007D)
	{
		if (FindByLocation(_007B4523_007D.SectionID) != null)
		{
			throw new InvalidOperationException("Cannons-Install " + _007B4523_007D.SectionID);
		}
		CannonCommon item = new CannonCommon(_007B4523_007D, _007B4524_007D);
		Items.Add(in item);
		UpdateInformation();
	}

	public void InstallMany(IEnumerable<CannonSerializedInfo> _007B4525_007D, ShipStaticInfo _007B4526_007D)
	{
		foreach (CannonSerializedInfo item2 in _007B4525_007D)
		{
			if (FindByLocation(item2.Location) != null)
			{
				throw new InvalidOperationException("Cannons-Install " + item2.Location);
			}
			CannonLocationInfo _007B4581_007D = _007B4526_007D.TryGetCannonPosFromSectionID(item2.Location);
			CannonCommon item = new CannonCommon(_007B4581_007D, Gameplay.CannonsGameInfo.FromID(item2.GameInfoID));
			Items.Add(in item);
		}
		UpdateInformation();
	}

	public bool RestoreBrokenDynamic(CannonSerializedInfo _007B4527_007D, ShipStaticInfo _007B4528_007D)
	{
		int num = BrokenItems.FindIndex((CannonSerializedInfo _007B4560_007D) => _007B4560_007D.Location == _007B4527_007D.Location);
		if (num == -1)
		{
			return false;
		}
		BrokenItems.FastRemoveAt(num);
		if (FindByLocation(_007B4527_007D.Location) != null)
		{
			return false;
		}
		CannonLocationInfo cannonLocationInfo = _007B4528_007D.TryGetCannonPosFromSectionID(_007B4527_007D.Location);
		if (cannonLocationInfo == null)
		{
			return false;
		}
		CannonGameInfo _007B4582_007D = Gameplay.CannonsGameInfo.FromID(_007B4527_007D.GameInfoID);
		CannonCommon item = new CannonCommon(cannonLocationInfo, _007B4582_007D);
		Items.Add(in item);
		return true;
	}

	public void RestoreBrokenDynamic(int _007B4529_007D, ShipStaticInfo _007B4530_007D)
	{
		while (_007B4529_007D > 0 && BrokenItems.Size > 0)
		{
			RestoreBrokenDynamic(BrokenItems.Array[0], _007B4530_007D);
			_007B4529_007D--;
		}
	}

	public int RestoreAllBroken(ShipStaticInfo _007B4531_007D)
	{
		foreach (CannonSerializedInfo item in (IEnumerable<CannonSerializedInfo>)BrokenItems)
		{
			CannonGameInfo _007B4582_007D = Gameplay.CannonsGameInfo.FromID(item.GameInfoID);
			CannonLocationInfo cannonLocationInfo = _007B4531_007D.TryGetCannonPosFromSectionID(item.Location);
			if (cannonLocationInfo != null)
			{
				Items.Add(new CannonCommon(cannonLocationInfo, _007B4582_007D));
			}
		}
		int size = BrokenItems.Size;
		BrokenItems.Clear();
		UpdateInformation();
		return size;
	}

	public bool MakeBroken(int _007B4532_007D, bool _007B4533_007D)
	{
		CannonCommon item = FindByLocation(_007B4532_007D);
		if (item == null || item.Location.IsStatic)
		{
			return false;
		}
		Items.Remove(in item);
		if (!_007B4533_007D)
		{
			BrokenItems.Add(new CannonSerializedInfo(item));
		}
		return true;
	}

	public void RemoveStolenCannons(GSI _007B4534_007D)
	{
		foreach (GSILocalPair cannon in (IEnumerable<GSILocalPair>)_007B4534_007D)
		{
			Items.Remove(Items.Find((CannonCommon _007B4561_007D) => _007B4561_007D.GameInfo.ID == cannon.ID));
		}
	}

	public CannonCommon? FindByLocation(int _007B4535_007D)
	{
		for (int i = 0; i < Items.Size; i++)
		{
			if (Items.Array[i].Location.SectionID == _007B4535_007D)
			{
				return Items.Array[i];
			}
		}
		return null;
	}

	public void Clear()
	{
		Items.Clear();
		UpdateInformation();
	}

	internal void UpdateInformation()
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		Items.SortTop((CannonCommon _007B4558_007D) => _007B4558_007D.Location.Position.X);
		MinMaxDistance = new Vector2(0f, 0f);
		_007B4550_007D = 0f;
		_007B4548_007D.CleanArray();
		_007B4549_007D.CleanArray();
		_007B4547_007D = new Tlist<CannonCommon>();
		CannonsHavingFlagsBySectionId.Clean();
		for (int num = 0; num < Items.Size; num++)
		{
			CannonCommon item = Items.Array[num];
			CannonsHavingFlagsBySectionId[item.Location.SectionID] = true;
			MinMaxDistance.Y = Math.Max(MinMaxDistance.Y, item.GameInfo.MaxDistance);
			if (MinMaxDistance.X == 0f)
			{
				MinMaxDistance.X = item.GameInfo.MaxDistance;
			}
			else
			{
				MinMaxDistance.X = Math.Min(MinMaxDistance.X, item.GameInfo.MaxDistance);
			}
			TinyMap<CannonLocation, float> tinyMap = _007B4549_007D;
			tinyMap[item.Location.Side] += item.GameInfo.MaxAxis;
			TinyMap<CannonLocation, int> tinyMap2 = _007B4548_007D;
			tinyMap2[item.Location.Side]++;
			if (item.GameInfo.Feature == CannonFeature.Firegun)
			{
				_007B4547_007D.Add(in item);
			}
		}
		CannonLocation[] array = new CannonLocation[4]
		{
			CannonLocation.InBack,
			CannonLocation.InFront,
			CannonLocation.LeftSide,
			CannonLocation.RightSide
		};
		foreach (CannonLocation key in array)
		{
			if (_007B4548_007D[key] > 0)
			{
				TinyMap<CannonLocation, float> tinyMap = _007B4549_007D;
				tinyMap[key] /= _007B4548_007D[key];
			}
		}
		isAllCannonsReloaded = false;
	}

	public bool Check(PlayerAccount _007B4536_007D)
	{
		PlayerShipDynamicInfo currentRealShip = _007B4536_007D.Shipyard.CurrentRealShip;
		bool flag = false;
		for (int i = 0; i < Items.Size; i++)
		{
			CannonCommon cannonCommon = Items.Array[i];
			if ((cannonCommon.GameInfo.Class != CannonClass.Special && !currentRealShip.CraftFrom.IsCannonsAllowed(cannonCommon.GameInfo.Category)) || cannonCommon.Location.Mode == CannonLocationMode.Special != (cannonCommon.GameInfo.Class == CannonClass.Special) || (cannonCommon.Location.Side != CannonLocation.InFront && cannonCommon.Location.Side != CannonLocation.InBack && cannonCommon.GameInfo.Class == CannonClass.Bombardier) || cannonCommon.Location.IsBlocked(currentRealShip))
			{
				Items.RemoveAt(i);
				i--;
				_007B4536_007D.CannonsAtStorage.Exs(cannonCommon.GameInfo.ID, 1);
				flag = true;
			}
		}
		flag |= CheckStatic(currentRealShip.StaticInfo);
		if (flag)
		{
			UpdateInformation();
		}
		return flag;
	}

	private static CannonCollection FromList(Tlist<CannonCommon> _007B4537_007D)
	{
		CannonCollection cannonCollection = new CannonCollection();
		cannonCollection.Items = _007B4537_007D;
		cannonCollection.UpdateInformation();
		return cannonCollection;
	}

	internal static CannonCollection ReadFromStreamNew3(WriterExtern _007B4538_007D, ShipStaticInfo _007B4539_007D)
	{
		byte b = _007B4538_007D.ReadByte();
		Tlist<CannonCommon> tlist = new Tlist<CannonCommon>(b + 10);
		for (int i = 0; i < b; i++)
		{
			byte b2 = _007B4538_007D.ReadByte();
			byte _007B2542_007D = _007B4538_007D.ReadByte();
			CannonLocationInfo cannonLocationInfo = _007B4539_007D.TryGetCannonPosFromSectionID(_007B2542_007D);
			if (cannonLocationInfo != null)
			{
				CannonGameInfo cannonGameInfo = Gameplay.CannonsGameInfo.FromID(b2);
				while (cannonGameInfo.IsRemoved)
				{
					b2++;
					cannonGameInfo = Gameplay.CannonsGameInfo.FromID(b2);
				}
				if (cannonGameInfo.Feature != CannonFeature.Firegun || _007B4539_007D.SpecialCannonsCount > 0)
				{
					tlist.Add(new CannonCommon(cannonLocationInfo, cannonGameInfo));
				}
			}
		}
		return FromList(tlist);
	}

	internal static CannonCollection ReadFromStreamNew2(WriterExtern _007B4540_007D, ShipStaticInfo _007B4541_007D)
	{
		byte b = _007B4540_007D.ReadByte();
		byte b2 = _007B4540_007D.ReadByte();
		if (b != b2)
		{
			throw new Exception("TEST Error cannons");
		}
		Tlist<CannonCommon> tlist = new Tlist<CannonCommon>(b + 10);
		for (int i = 0; i < b; i++)
		{
			byte key = _007B4540_007D.ReadByte();
			key = (byte)CannonsChange070619.Lookup[key];
			byte _007B2542_007D = _007B4540_007D.ReadByte();
			CannonLocationInfo cannonLocationInfo = _007B4541_007D.TryGetCannonPosFromSectionID(_007B2542_007D);
			if (cannonLocationInfo != null)
			{
				CannonGameInfo cannonGameInfo = Gameplay.CannonsGameInfo.FromID(key);
				while (cannonGameInfo.IsRemoved)
				{
					key++;
					cannonGameInfo = Gameplay.CannonsGameInfo.FromID(key);
				}
				if (cannonGameInfo.Feature != CannonFeature.Firegun || _007B4541_007D.SpecialCannonsCount > 0)
				{
					tlist.Add(new CannonCommon(cannonLocationInfo, cannonGameInfo));
				}
			}
		}
		if (_007B4540_007D.PeekByte() == 254)
		{
			_007B4540_007D.ReadByte();
			float num = default(float);
			_007B4540_007D.ReadStruct<float>(ref num);
		}
		else if (_007B4540_007D.PeekByte() == 253)
		{
			_007B4540_007D.ReadByte();
			for (int j = 0; j < 4; j++)
			{
				_007B4540_007D.ReadByte();
			}
		}
		return FromList(tlist);
	}

	internal void Boxing(WriterExtern _007B4542_007D, ShipStaticInfo _007B4543_007D)
	{
		if (Items.Size > _007B4543_007D.Ports.Length / 2)
		{
			_007B4542_007D.WriteByte(byte.MaxValue);
			_007B4542_007D.RawClean(_007B4543_007D.Ports.Length);
			for (int i = 0; i < Items.Size; i++)
			{
				_007B4542_007D.RawWriteByte((int)(byte)(Items.Array[i].Location.SectionID - 1), (byte)Items.Array[i].GameInfo.ID);
			}
			_007B4542_007D.Position += _007B4543_007D.Ports.Length;
			_007B4542_007D.WriteByte(byte.MaxValue);
		}
		else
		{
			_007B4542_007D.WriteByte((byte)Items.Size);
			for (int j = 0; j < Items.Size; j++)
			{
				_007B4542_007D.WriteByte((byte)Items.Array[j].Location.SectionID);
				_007B4542_007D.WriteByte((byte)Items.Array[j].GameInfo.ID);
			}
		}
		_007B4542_007D.WriteTlistStruct<CannonSerializedInfo>(BrokenItems);
	}

	internal void Unboxing(WriterExtern _007B4544_007D, PlayerShipDynamicInfoHolder _007B4545_007D, ShipStaticInfo _007B4546_007D)
	{
		byte b = _007B4544_007D.ReadByte();
		if (b == byte.MaxValue)
		{
			Items.EnsureCapacitry(_007B4546_007D.Ports.Length);
			for (short num = 1; num < 1000; num++)
			{
				byte b2 = _007B4544_007D.ReadByte();
				switch (b2)
				{
				default:
				{
					CannonLocationInfo cannonLocationInfo = _007B4546_007D.TryGetCannonPosFromSectionID(num);
					CannonGameInfo cannonGameInfo = Gameplay.CannonsGameInfo.FromID(b2);
					if (cannonLocationInfo != null && !cannonGameInfo.IsRemoved)
					{
						Items.Add(new CannonCommon(cannonLocationInfo, cannonGameInfo));
					}
					else if (!cannonGameInfo.IsRemoved && _007B4545_007D != null)
					{
						_007B4545_007D.CannonsShouldMoveToStorage = _007B4545_007D.CannonsShouldMoveToStorage ?? new GSI();
						_007B4545_007D.CannonsShouldMoveToStorage[cannonGameInfo.ID]++;
					}
					continue;
				}
				case 0:
					continue;
				case byte.MaxValue:
					break;
				}
				break;
			}
		}
		else
		{
			Items.EnsureCapacitry(b);
			for (int i = 0; i < b; i++)
			{
				CannonLocationInfo cannonLocationInfo2 = _007B4546_007D.TryGetCannonPosFromSectionID(_007B4544_007D.ReadByte());
				CannonGameInfo cannonGameInfo2 = Gameplay.CannonsGameInfo.FromID(_007B4544_007D.ReadByte());
				if (cannonLocationInfo2 != null && !cannonGameInfo2.IsRemoved)
				{
					Items.Add(new CannonCommon(cannonLocationInfo2, cannonGameInfo2));
				}
				else if (!cannonGameInfo2.IsRemoved && _007B4545_007D != null)
				{
					_007B4545_007D.CannonsShouldMoveToStorage = _007B4545_007D.CannonsShouldMoveToStorage ?? new GSI();
					_007B4545_007D.CannonsShouldMoveToStorage[cannonGameInfo2.ID]++;
				}
			}
		}
		_007B4544_007D.ReadTlistStruct<CannonSerializedInfo>(out BrokenItems);
		UpdateInformation();
	}

	public void Dispose()
	{
		Items?.Clear();
		Items = null;
		BrokenItems = null;
		_007B4547_007D = null;
	}
}
