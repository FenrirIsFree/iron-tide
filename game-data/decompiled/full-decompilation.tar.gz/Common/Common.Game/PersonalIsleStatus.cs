using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using Common.Account;
using Common.Resources;
using CommonDataTypes;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Helpers;

namespace Common.Game;

public class PersonalIsleStatus : IMPSerializable
{
	public enum InternalBuilding
	{
		BigStorage,
		Workshop,
		Dok,
		Shipbuilder,
		Avanpost,
		Pub,
		Factory,
		Lighthouse
	}

	public string Name;

	private byte _007B8480_007D = 1;

	public byte PlaceIndex;

	public Tlist<InternalBuilding> InternalBuildings;

	public FactoryType OpenedFactory;

	public bool IsFactoryEnabled;

	public FactoryType PickedWorkshop;

	public GSI StorageResources;

	public RTIf IsleCraftTime;

	public bool DisableFactoryWhenLowTime = false;

	private float _007B8481_007D;

	public Tlist<PersonalIsleInstalledDecorItem> InstalledDecor;

	internal int RemovedResourcesGoldCompensation;

	private static readonly FactoryType[] basicAvailableFactories = new FactoryType[4]
	{
		FactoryType.IsleBeerFactory,
		FactoryType.IsleCornFactory,
		FactoryType.IsleFruitsFactory,
		FactoryType.IsleSugarFactory
	};

	public float DisableFactoryWhenTimeLessThan => 25f;

	public FactoryPlaceIsleInfo Place => Gameplay.WorldMap.Factories.Array[PlaceIndex];

	public WosbCrafting.Recepie PickedWorkshopInfo => WosbCrafting.PersonalIsleWorkshops.First((WosbCrafting.Recepie _007B8473_007D) => _007B8473_007D.NeedsFactoryInPort == PickedWorkshop);

	public ResourceInfo PickedFactoryOutputRes => WosbCrafting.FactoriesInfo[OpenedFactory].Levels[0].DisplayOutputRes;

	private bool isFactoryWorking => IsleCraftTime.Value > (DisableFactoryWhenLowTime ? DisableFactoryWhenTimeLessThan : 0f) && IsFactoryEnabled && !HasOverload;

	public FactoryType[] AllowedFactories
	{
		get
		{
			FactoryType[] result;
			if (GetDecorBonus(PDynamicAccountBonus.BCurrentIsleAddVulcanoOreFactory) <= 0)
			{
				result = basicAvailableFactories;
			}
			else
			{
				FactoryType[] array = basicAvailableFactories;
				int num = 0;
				FactoryType[] array2 = new FactoryType[1 + array.Length];
				ReadOnlySpan<FactoryType> readOnlySpan = new ReadOnlySpan<FactoryType>(array);
				readOnlySpan.CopyTo(new Span<FactoryType>(array2).Slice(num, readOnlySpan.Length));
				num += readOnlySpan.Length;
				array2[num] = FactoryType.IsleVulkanoOreFactory;
				result = array2;
			}
			return result;
		}
	}

	public (FactoryType, FactoryMineLivelInfo)[] AllowedFactoriesInfo => AllowedFactories.Select((FactoryType _007B8482_007D) => (x: _007B8482_007D, WosbCrafting.FactoriesInfo[_007B8482_007D].Levels[0])).ToArray();

	public Vector2 MooringPosition => Place.GlobalTransform.Transform3X3(new Vector3(-78.413f, 0f, 21.822f)).XZ();

	public bool HasOverload => StorageResources.ComputeMass<ResourceInfo>() > (float)StorageLimit;

	public bool AllowChangeShipsAndMending => InternalBuildings.Contains(InternalBuilding.Dok);

	public bool AllowArenaAndModes => InternalBuildings.Contains(InternalBuilding.Dok);

	public bool AllowSendExpeditions => InternalBuildings.Contains(InternalBuilding.Avanpost);

	public bool AllowWorldTravel => InternalBuildings.Contains(InternalBuilding.Lighthouse);

	public bool AllowBuyingAmmo => GetDecorBonus(PDynamicAccountBonus.BCurrentIsleAllowShopAmmo) > 0;

	public int StorageLimit => WosbStorages.PersonalIsle[InternalBuildings.Contains(InternalBuilding.BigStorage) ? 1 : 0].Value + GetDecorBonus(PDynamicAccountBonus.СCurrentIsleStorage);

	public int IsleCraftTimeLimit => 50 + ((IEnumerable<InternalBuilding>)InternalBuildings).Sum((Func<InternalBuilding, int>)BonusCraftTimeLimitForBuilding) + GetDecorBonus(PDynamicAccountBonus.CCurrentIsleWorkLimit);

	public float CraftTimePerHour => ((InternalBuildings.Contains(InternalBuilding.Factory) && IsFactoryEnabled) ? (-2.5f) : 1f) + (float)(InternalBuildings.Contains(InternalBuilding.Pub) ? 1 : 0) + (float)GetDecorBonus(PDynamicAccountBonus.CCurrentIsleCraftTimePerHour);

	public int BonusCraftTimeForBondman => 1;

	public int ChangeFactoryOrWorkshopPriceCT => IsleCraftTimeLimit / 2;

	public int RecruitSpecialUnitCT => 50;

	public int RecruitSpecialUnitCTTrageted => 75;

	public int ExpeditionPriceCT => 50;

	public int ExpeditionDistance => 7000 + GetDecorBonus(PDynamicAccountBonus.CCurrentIsleExpeditionDistance);

	public int BuildingsWithBonusLimit => 7 + GetDecorBonus(PDynamicAccountBonus.CCurrentIsleBonusBuildingsLimit);

	public float CapitalRestoreDiscount => (float)GetDecorBonus(PDynamicAccountBonus.PCurrentIsleCapitalRestoreDiscount) / 100f;

	public float FactoryEffectivityBonus => (float)GetDecorBonus(PDynamicAccountBonus.PCurrentIsleFactoryProductivity) / 100f;

	public static float ExpeditionDurationSec(float _007B8459_007D)
	{
		return _007B8459_007D / 5f;
	}

	public float BonusCraftTimeForCrew(UnitInfo _007B8460_007D)
	{
		return ((_007B8460_007D.InternalPrice <= Gameplay.UnitsInfo.FromID(1).CostGold.Value + 1) ? 0.15f : 0.25f) * 4f / 4f / 20f;
	}

	public int BonusCraftTimeLimitForBuilding(InternalBuilding _007B8461_007D)
	{
		if (1 == 0)
		{
		}
		int result = _007B8461_007D switch
		{
			InternalBuilding.Workshop => 100, 
			InternalBuilding.Pub => 20, 
			InternalBuilding.Dok => 20, 
			InternalBuilding.Factory => 10, 
			_ => 0, 
		};
		if (1 == 0)
		{
		}
		return result;
	}

	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	internal int GetDecorBonus(PDynamicAccountBonus _007B8462_007D)
	{
		int num = 0;
		for (int i = 0; i < InstalledDecor.Size; i++)
		{
			PersonalIsleInstalledDecorItem personalIsleInstalledDecorItem = InstalledDecor[i];
			if (personalIsleInstalledDecorItem.Info.AccountBonus.Item1 == _007B8462_007D)
			{
				num += (int)personalIsleInstalledDecorItem.Info.AccountBonus.Item2;
			}
		}
		return num;
	}

	public CraftingRecipe NextBuildingPrice(PlayerAccount _007B8463_007D)
	{
		int num = ((_007B8463_007D.Rang < 10) ? 20 : ((_007B8463_007D.Rang < 20) ? 50 : 100));
		if (InternalBuildings.Size == 0)
		{
			return new CraftingRecipe(num * 10);
		}
		int num2 = num * InternalBuildings.Size * Math.Max(1, InternalBuildings.Size - 3);
		int num3 = num * Math.Max(1, InternalBuildings.Size - 2);
		return new CraftingRecipe(new GSI().Exs(16, num2 / 4).Exs(20, num2 / 2).Exs(1, num2), num2 / 2 * 6 + num3 / 3 * 100);
	}

	public bool AllowSendExpetionsCurrently(PlayerAccount _007B8464_007D)
	{
		return AllowSendExpeditions && !_007B8464_007D.WorldActivities.Any((PlayerWorldActivityStatus _007B8475_007D) => _007B8475_007D.Activity == PlayerWorldActivityStatus.Type.ExpeditionToAndFromIsle && _007B8475_007D.Position == Place.GlobalPosition);
	}

	public PlayerBuildingState[] FetchAvailableFactoriesForExpedition(PlayerAccount _007B8465_007D)
	{
		return _007B8465_007D.Buildings.AllBuildings.Where((PlayerBuildingState _007B8477_007D) => Gameplay.WorldMap.OutsideSeamLevel(in _007B8477_007D.Place.GlobalPosition) == 0f && Vector2.Distance(_007B8477_007D.Place.GlobalPosition, Place.GlobalPosition) < (float)ExpeditionDistance).ToArray();
	}

	public bool CreateExpeditions(PlayerAccount _007B8466_007D)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		PlayerBuildingState[] array = FetchAvailableFactoriesForExpedition(_007B8466_007D);
		for (int i = 0; i < array.Length; i++)
		{
			_007B8466_007D.WorldActivities.Add(new PlayerWorldActivityStatus(Place.GlobalPosition, PlayerWorldActivityStatus.Type.ExpeditionToAndFromIsle, ExpeditionDurationSec(Vector2.Distance(Place.GlobalPosition, array[i].Place.GlobalPosition)) / (1f + (float)GetDecorBonus(PDynamicAccountBonus.PCurrentIsleExpeditionSpeed) / 100f), array[i].Place.FcID, new GSI()));
		}
		if (array.Length != 0)
		{
			IsleCraftTime.Value = Math.Max(IsleCraftTime.Value - (float)ExpeditionPriceCT, 0f);
			return true;
		}
		return false;
	}

	public PersonalIsleStatus()
	{
	}

	public PersonalIsleStatus(byte _007B8467_007D, float _007B8468_007D)
	{
		Name = "";
		PlaceIndex = _007B8467_007D;
		InternalBuildings = new Tlist<InternalBuilding>();
		StorageResources = new GSI();
		OpenedFactory = FactoryType.IsleBeerFactory;
		PickedWorkshop = WosbCrafting.PersonalIsleWorkshops.First().NeedsFactoryInPort.Value;
		IsFactoryEnabled = true;
		InstalledDecor = new Tlist<PersonalIsleInstalledDecorItem>();
		IsleCraftTime = ((_007B8468_007D == 0f) ? ((float)IsleCraftTimeLimit) : Math.Min(IsleCraftTimeLimit, _007B8468_007D));
	}

	internal void InternalEvaluteTime(double _007B8469_007D)
	{
		float value = IsleCraftTime.Value;
		IsleCraftTime.Value = Math.Min(IsleCraftTime.Value + CraftTimePerHour * (float)(_007B8469_007D / 3600.0), IsleCraftTimeLimit);
		IsleCraftTime.Value = Math.Max(0f, IsleCraftTime.Value);
		if (!InternalBuildings.Contains(InternalBuilding.Factory) || !IsFactoryEnabled)
		{
			return;
		}
		float num = 1f;
		if (IsleCraftTime.Value <= DisableFactoryWhenTimeLessThan && DisableFactoryWhenLowTime)
		{
			num = Geometry.Saturate((value - DisableFactoryWhenTimeLessThan) / (value - IsleCraftTime.Value));
			IsFactoryEnabled = false;
		}
		else if (!isFactoryWorking)
		{
			num = 0f;
		}
		if (num > 0f)
		{
			num *= 1f + FactoryEffectivityBonus;
			FactoryMineLivelInfo factoryMineLivelInfo = WosbCrafting.FactoriesInfo[OpenedFactory].Levels[0];
			_007B8481_007D += num * Math.Min(100000f, (float)factoryMineLivelInfo.ProducedResCount * (float)(_007B8469_007D / 3600.0));
			if (_007B8481_007D > 1f)
			{
				_007B8481_007D -= 1f;
				StorageResources[factoryMineLivelInfo.ProducedResId]++;
			}
		}
	}

	public void Boxing(WriterExtern _007B8470_007D)
	{
		_007B8470_007D.Write(Name, (Encoding)null);
		_007B8470_007D.WriteByte(_007B8480_007D);
		_007B8470_007D.WriteByte(PlaceIndex);
		_007B8470_007D.WriteByte((byte)InternalBuildings.Size);
		for (int i = 0; i < InternalBuildings.Size; i++)
		{
			_007B8470_007D.WriteByte((byte)InternalBuildings.Array[i]);
		}
		_007B8470_007D.WriteByte((byte)OpenedFactory);
		_007B8470_007D.WriteNoNull<GSI>(StorageResources);
		_007B8470_007D.WriteStruct<float>(IsleCraftTime.Value);
		_007B8470_007D.WriteByte((byte)PickedWorkshop);
		_007B8470_007D.WriteStruct<float>(_007B8481_007D);
		_007B8470_007D.Write(IsFactoryEnabled);
		_007B8470_007D.WriteByte((byte)253);
		_007B8470_007D.Write(DisableFactoryWhenLowTime);
		_007B8470_007D.WriteByte((byte)254);
		_007B8470_007D.WriteTlistStruct<PersonalIsleInstalledDecorItem>(InstalledDecor);
	}

	public void Unboxing(WriterExtern _007B8471_007D)
	{
		_007B8471_007D.ReadString(ref Name, (Encoding)null);
		_007B8480_007D = _007B8471_007D.ReadByte();
		PlaceIndex = _007B8471_007D.ReadByte();
		byte b = _007B8471_007D.ReadByte();
		InternalBuildings = new Tlist<InternalBuilding>(b);
		for (int i = 0; i < b; i++)
		{
			InternalBuildings.Add((InternalBuilding)_007B8471_007D.ReadByte());
		}
		OpenedFactory = (FactoryType)_007B8471_007D.ReadByte();
		_007B8471_007D.ReadIMPSNoNull<GSI>(ref StorageResources);
		float num = default(float);
		_007B8471_007D.ReadStruct<float>(ref num);
		IsleCraftTime = num;
		PickedWorkshop = (FactoryType)_007B8471_007D.ReadByte();
		if (!WosbCrafting.PersonalIsleWorkshops.Any((WosbCrafting.Recepie _007B8479_007D) => _007B8479_007D.NeedsFactoryInPort == PickedWorkshop))
		{
			PickedWorkshop = WosbCrafting.PersonalIsleWorkshops.First().NeedsFactoryInPort.Value;
		}
		_007B8471_007D.ReadStruct<float>(ref _007B8481_007D);
		_007B8471_007D.ReadBoolean(ref IsFactoryEnabled);
		if (_007B8471_007D.PeekByte() == 253)
		{
			_007B8471_007D.ReadByte();
			_007B8471_007D.ReadBoolean(ref DisableFactoryWhenLowTime);
		}
		if (_007B8471_007D.PeekByte() == 254)
		{
			_007B8471_007D.ReadByte();
			_007B8471_007D.ReadTlistStruct<PersonalIsleInstalledDecorItem>(out InstalledDecor);
		}
		else
		{
			InstalledDecor = new Tlist<PersonalIsleInstalledDecorItem>();
		}
		StorageResources.CleanRemovedResources(out RemovedResourcesGoldCompensation);
	}

	[CompilerGenerated]
	private bool _007B8472_007D(WosbCrafting.Recepie _007B8473_007D)
	{
		return _007B8473_007D.NeedsFactoryInPort == PickedWorkshop;
	}

	[CompilerGenerated]
	private bool _007B8474_007D(PlayerWorldActivityStatus _007B8475_007D)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		return _007B8475_007D.Activity == PlayerWorldActivityStatus.Type.ExpeditionToAndFromIsle && _007B8475_007D.Position == Place.GlobalPosition;
	}

	[CompilerGenerated]
	private bool _007B8476_007D(PlayerBuildingState _007B8477_007D)
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		return Gameplay.WorldMap.OutsideSeamLevel(in _007B8477_007D.Place.GlobalPosition) == 0f && Vector2.Distance(_007B8477_007D.Place.GlobalPosition, Place.GlobalPosition) < (float)ExpeditionDistance;
	}

	[CompilerGenerated]
	private bool _007B8478_007D(WosbCrafting.Recepie _007B8479_007D)
	{
		return _007B8479_007D.NeedsFactoryInPort == PickedWorkshop;
	}
}
