using Common.Resources;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;

namespace Common.Game;

public struct PersonalIsleInstalledDecorItem : IMPSerializable
{
	public int ID;

	public byte PlaceIndex;

	public ShipDesignInfo Info => Gameplay.EnvDecorElementsInfo[ID];

	public PersonalIsleInstalledDecorItem(int _007B8450_007D, int _007B8451_007D)
	{
		ID = (byte)_007B8450_007D;
		PlaceIndex = (byte)_007B8451_007D;
	}

	public Vector3 GlobalPosition(PersonalIsleStatus _007B8452_007D)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		return _007B8452_007D.Place.ConnectionsPersonalIsleDecor[PlaceIndex].pos;
	}

	private void _007B8453_007D(WriterExtern _007B8454_007D)
	{
		_007B8454_007D.WriteStruct<int>(ID);
		_007B8454_007D.WriteByte(PlaceIndex);
	}

	private void _007B8455_007D(WriterExtern _007B8456_007D)
	{
		_007B8456_007D.ReadStruct<int>(ref ID);
		PlaceIndex = _007B8456_007D.ReadByte();
	}
}
