namespace Common.Game;

internal class ShootingBehavior
{
}
