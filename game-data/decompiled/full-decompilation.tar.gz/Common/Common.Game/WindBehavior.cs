namespace Common.Game;

internal class WindBehavior
{
}
