using System;
using System.Collections.Generic;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Game;

public class MercanaryQuestEngine : IMPSerializable, ITKSerializable
{
	private Tlist<MercanaryOrder> _007B8564_007D = new Tlist<MercanaryOrder>();

	private object _007B8565_007D = new object();

	public IEnumerable<MercanaryOrder> Orders => _007B8564_007D;

	public int Count => _007B8564_007D.Size;

	public IEnumerable<MercanaryOrder> SearchByTarget(string _007B8537_007D, string _007B8538_007D)
	{
		lock (_007B8565_007D)
		{
			return _007B8564_007D.Where((MercanaryOrder _007B8567_007D) => (_007B8567_007D.Target is MercanaryOrder.TargetPlayer targetPlayer && NormalizedString.CompareNormalizd(targetPlayer.InitialName, _007B8537_007D)) || (_007B8567_007D.Target is MercanaryOrder.TargetGuild targetGuild && targetGuild.InitialTag == _007B8538_007D));
		}
	}

	public void CompleteKill(string _007B8539_007D, string _007B8540_007D, Action<MercanaryOrder> _007B8541_007D)
	{
		lock (_007B8565_007D)
		{
			for (int i = 0; i < _007B8564_007D.Size; i++)
			{
				MercanaryOrder mercanaryOrder = _007B8564_007D.Array[i];
				if ((mercanaryOrder.Target is MercanaryOrder.TargetPlayer targetPlayer && NormalizedString.CompareNormalizd(targetPlayer.InitialName, _007B8539_007D)) || (mercanaryOrder.Target is MercanaryOrder.TargetGuild targetGuild && targetGuild.InitialTag == _007B8540_007D))
				{
					mercanaryOrder.RemainCount--;
					if (mercanaryOrder.RemainCount <= 0)
					{
						_007B8564_007D.FastRemoveAt(i);
						i--;
					}
					_007B8541_007D(mercanaryOrder);
				}
			}
		}
	}

	public void CompleteKill(MercanaryOrder _007B8542_007D, string _007B8543_007D, string _007B8544_007D, Action<MercanaryOrder> _007B8545_007D, Action<MercanaryOrder> _007B8546_007D)
	{
		lock (_007B8565_007D)
		{
			if ((_007B8542_007D.Target is MercanaryOrder.TargetPlayer targetPlayer && NormalizedString.CompareNormalizd(targetPlayer.InitialName, _007B8543_007D)) || (_007B8542_007D.Target is MercanaryOrder.TargetGuild targetGuild && targetGuild.InitialTag == _007B8544_007D))
			{
				_007B8542_007D.RemainCount--;
				_007B8545_007D(_007B8542_007D);
				if (_007B8542_007D.RemainCount <= 0)
				{
					_007B8564_007D.FastRemove(in _007B8542_007D);
					_007B8546_007D(_007B8542_007D);
				}
			}
		}
	}

	public MercanaryOrder SerachById(int _007B8547_007D)
	{
		lock (_007B8565_007D)
		{
			return _007B8564_007D.Find((MercanaryOrder _007B8566_007D) => _007B8566_007D.ServerID == _007B8547_007D);
		}
	}

	public void Add(MercanaryOrder _007B8548_007D)
	{
		lock (_007B8565_007D)
		{
			_007B8564_007D.Add(in _007B8548_007D);
		}
	}

	public bool Remove(MercanaryOrder _007B8549_007D)
	{
		lock (_007B8565_007D)
		{
			return _007B8564_007D.FastRemove(in _007B8549_007D);
		}
	}

	public void RemoveTimeouted(DateTime _007B8550_007D, Action<MercanaryOrder> _007B8551_007D)
	{
		lock (_007B8565_007D)
		{
			for (int i = 0; i < _007B8564_007D.Size; i++)
			{
				if (_007B8564_007D.Array[i].TimeoutDate.ToDateTime < _007B8550_007D)
				{
					_007B8551_007D(_007B8564_007D.Array[i]);
					_007B8564_007D.FastRemoveAt(i);
					i--;
				}
			}
		}
	}

	private void _007B8552_007D(WriterExtern _007B8553_007D)
	{
		lock (_007B8565_007D)
		{
			_007B8553_007D.WriteTlistImps(_007B8564_007D);
		}
	}

	private void _007B8554_007D(WriterExtern _007B8555_007D)
	{
		_007B8555_007D.ReadTlistImps(out _007B8564_007D);
	}

	private void _007B8556_007D()
	{
	}

	private void _007B8557_007D()
	{
	}

	private void _007B8558_007D(TKWriterExtern _007B8559_007D)
	{
		lock (_007B8565_007D)
		{
			((TKWriterExtern)(ref _007B8559_007D)).WriteDynamicTKArray<MercanaryOrder>((short)1, _007B8564_007D.Array, _007B8564_007D.Size);
		}
	}

	private void _007B8560_007D(short _007B8561_007D, WriterExtern _007B8562_007D, out bool _007B8563_007D)
	{
		MercanaryOrder[] collection = default(MercanaryOrder[]);
		_007B8562_007D.ReadDynamicTKArray<MercanaryOrder>(ref collection);
		_007B8564_007D = new Tlist<MercanaryOrder>(collection);
		_007B8563_007D = true;
	}
}
