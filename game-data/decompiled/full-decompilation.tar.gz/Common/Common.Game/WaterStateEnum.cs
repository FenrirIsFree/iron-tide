namespace Common.Game;

public enum WaterStateEnum
{
	Sunny,
	Cloudy,
	Rain,
	HeavyRain
}
