namespace Common.Game;

public enum RatingRewardId : byte
{
	None,
	Gold,
	Silver,
	Bronze,
	LuckyPlace
}
