using System;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Helpers;

namespace Common.Game;

public abstract class Drop : UIDSceneObject, IPoolObject
{
	protected const float floodingTTLStart = 4000f;

	public const float RadiusMinimum = 2f;

	public ShipVisualFloodingComponent BindedShipFloodingDataOrNull;

	public DropRules Rule;

	public Tlist<DropTransferPacket.Partition> RulesData;

	public DropServerEffect ServerEffects;

	public GSI DisplayResourcesOnWorldmap;

	public WhaleController? Whale;

	internal Vector2 position;

	private DropModel _007B5610_007D;

	private NDropInteropMethod _007B5611_007D;

	private float _007B5612_007D;

	private float _007B5613_007D;

	public Vector2 Position => position;

	public DropModel ModelType => _007B5610_007D;

	public NDropInteropMethod Method => _007B5611_007D;

	public float Ttl => _007B5612_007D;

	public float LifetimeMs => _007B5613_007D - _007B5612_007D;

	public float LifetimeSec => (_007B5613_007D - _007B5612_007D) / 1000f;

	public bool Available => _007B5612_007D > 4000f;

	public bool LongVisibleDistance => ModelType == DropModel.IsleFarming || ModelType == DropModel.Fishing;

	public bool VisibleOnMinimap => ModelType != DropModel.RuinsFarming && ModelType != DropModel.EmpireUnderwaterBox;

	public float UseCrewHungry => (ModelType == DropModel.IsleFarming) ? 0.2f : 0f;

	public bool HasBigIcon => ModelType == DropModel.IsleFarming || ModelType == DropModel.IsleTreasures || ModelType == DropModel.RealShipLoot;

	public bool NeedsCrew => ModelType != DropModel.Fishing && ModelType != DropModel.RealShipLoot && ModelType != DropModel.WorldFortLoot && ModelType != DropModel.DebrisWithBox && Method != NDropInteropMethod.PickUp;

	public float InteropRadius
	{
		get
		{
			switch (ModelType)
			{
			case DropModel.SmallDebris:
			case DropModel.SmallBox:
			case DropModel.UnitOnRaft:
			case DropModel.PlayerThrowBox:
			case DropModel.Pumkin:
			case DropModel.GiftBox:
				return 2f;
			case DropModel.Fishing:
				return 9f;
			case DropModel.ShipDebris:
			case DropModel.DebrisWithBox:
			case DropModel.FishingShip:
			case DropModel.SpecialBox:
			case DropModel.EmpireUnderwaterBox:
				return 4f;
			case DropModel.IsleFarming:
			case DropModel.RuinsFarming:
			case DropModel.IsleTreasures:
				return 15f;
			case DropModel.RealShipLoot:
				return 5f;
			case DropModel.WorldFortLoot:
				return 10f;
			case DropModel.Whale:
				return 4f;
			default:
				throw new NotSupportedException();
			}
		}
	}

	protected internal abstract Tlist<Drop> ConnectedWhales { get; }

	public static float TtlDrop(DropModel _007B5595_007D, int _007B5596_007D)
	{
		bool flag;
		switch (_007B5595_007D)
		{
		case DropModel.WorldFortLoot:
			return 600000f;
		case DropModel.RealShipLoot:
		case DropModel.PlayerThrowBox:
			flag = true;
			break;
		default:
			flag = false;
			break;
		}
		if (flag)
		{
			return 150000f;
		}
		return 300000f * new Sequence(_007B5596_007D).Range(0.8f, 1.2f);
	}

	public virtual void ClearResources()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		position = Vector2.Zero;
		_007B5610_007D = DropModel.SmallDebris;
		BindedShipFloodingDataOrNull = null;
		_007B5612_007D = 0f;
		_007B5613_007D = 0f;
		uID = -1;
		Whale = null;
		RulesData = null;
	}

	public Drop()
		: base(-1)
	{
	}

	public void InitializeNewUnit(int _007B5597_007D, Vector2 _007B5598_007D, DropModel _007B5599_007D, NDropInteropMethod _007B5600_007D, DropServerEffect _007B5601_007D, DropRules _007B5602_007D, Tlist<DropTransferPacket.Partition> _007B5603_007D, GSI _007B5604_007D)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		uID = _007B5597_007D;
		position = _007B5598_007D;
		_007B5610_007D = _007B5599_007D;
		_007B5611_007D = _007B5600_007D;
		_007B5612_007D = (_007B5613_007D = TtlDrop(_007B5610_007D, _007B5597_007D));
		ServerEffects = _007B5601_007D;
		Rule = _007B5602_007D;
		RulesData = _007B5603_007D;
		DisplayResourcesOnWorldmap = _007B5604_007D;
		FinalInitialize();
	}

	public void InitializeFromPacket(ref DropTransferPacket _007B5605_007D)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		uID = _007B5605_007D.uID;
		position = _007B5605_007D.Position;
		_007B5610_007D = _007B5605_007D.Model;
		_007B5611_007D = _007B5605_007D.InteropMethod;
		_007B5612_007D = _007B5605_007D.RemainingTtlMs;
		_007B5613_007D = _007B5605_007D.InitialTtlMs;
		BindedShipFloodingDataOrNull = _007B5605_007D.BindedShipFloodingDataOrNull;
		RulesData = _007B5605_007D.RulesData;
		Rule = _007B5605_007D.Rule;
		ServerEffects = _007B5605_007D.Effects;
		DisplayResourcesOnWorldmap = _007B5605_007D.DisplayResourcesOnWorldmap;
		Whale = _007B5605_007D.Whale;
		FinalInitialize();
	}

	public DropTransferPacket CreatePacket(float _007B5606_007D)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		DropTransferPacket result = default(DropTransferPacket);
		result.uID = uID;
		result.Position = position;
		result.Model = _007B5610_007D;
		result.InteropMethod = _007B5611_007D;
		result.InitialTtlMs = _007B5613_007D;
		result.RemainingTtlMs = _007B5612_007D;
		result.BindedShipFloodingDataOrNull = BindedShipFloodingDataOrNull;
		result.Rule = Rule;
		result.RulesData = RulesData;
		result.LoadFactor = _007B5606_007D;
		result.Effects = ServerEffects;
		result.DisplayResourcesOnWorldmap = DisplayResourcesOnWorldmap;
		result.Whale = Whale;
		return result;
	}

	protected abstract void FinalInitialize();

	public virtual void Update(ref FrameTime _007B5607_007D, bool _007B5608_007D, out bool _007B5609_007D)
	{
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		_007B5612_007D -= _007B5607_007D.msElapsed;
		if (_007B5608_007D)
		{
			_007B5609_007D = _007B5612_007D < 1f;
		}
		else
		{
			_007B5609_007D = false;
			_007B5612_007D = Math.Max(5000f, _007B5612_007D);
		}
		if (_007B5610_007D == DropModel.Fishing)
		{
			position += Geometry.SubstructRotateFast(_007B5612_007D / 10000f, _007B5607_007D.secElapsed * 1.25f);
		}
		if (_007B5610_007D == DropModel.FishingShip)
		{
			position += Geometry.SubstructRotateFast(_007B5612_007D / 10000f, _007B5607_007D.secElapsed);
		}
	}

	public void AddTtl()
	{
		_007B5612_007D = Math.Max(_007B5612_007D, 10000f);
	}
}
