using Common.Account;

namespace Common.Game;

public sealed class TargetShipPlayerForQuest : TargetShipForQuest
{
	public bool AcceptInWorld;

	public bool AccentInArena;

	public int RequiredMinShipRank = 7;

	public bool RequiredEnemyGuild;

	public bool RequiredGuildWithPort;

	public bool RequiredPirateOrBlackFlag;

	public bool RequiredNoLessShipRank;

	public TargetShipPlayerForQuest(bool _007B7753_007D, bool _007B7754_007D, int _007B7755_007D = 7, bool _007B7756_007D = false, bool _007B7757_007D = false, bool _007B7758_007D = false, bool _007B7759_007D = false)
	{
		AcceptInWorld = _007B7753_007D;
		AccentInArena = _007B7754_007D;
		RequiredMinShipRank = _007B7755_007D;
		RequiredEnemyGuild = _007B7756_007D;
		RequiredGuildWithPort = _007B7757_007D;
		RequiredPirateOrBlackFlag = _007B7758_007D;
		RequiredNoLessShipRank = _007B7759_007D;
	}

	public bool DoesShipFit(Player _007B7760_007D, Player _007B7761_007D, bool _007B7762_007D, bool _007B7763_007D, FractionID _007B7764_007D)
	{
		if ((AcceptInWorld && _007B7761_007D.MapInfo.IsWorldmap && _007B7760_007D.MapInfo.IsWorldmap) || (AccentInArena && _007B7761_007D.MapInfo.IsEnableArenaUi && _007B7760_007D.MapInfo.IsEnableArenaUi))
		{
			return _007B7760_007D.AccountConnection.Shipyard.CurrentRealShip.CraftFrom.Rank <= RequiredMinShipRank && (!RequiredEnemyGuild || _007B7762_007D) && (!RequiredGuildWithPort || _007B7763_007D) && (!RequiredPirateOrBlackFlag || _007B7760_007D.AccountConnection.WorldFlag == OpenWorldFlag.Pirate || (_007B7760_007D.AccountConnection.WorldFlag == OpenWorldFlag.War && _007B7764_007D == FractionID.Pirate)) && (!RequiredNoLessShipRank || _007B7761_007D.AccountConnection.Shipyard.CurrentRealShip.CraftFrom.Rank >= _007B7760_007D.AccountConnection.Shipyard.CurrentRealShip.CraftFrom.Rank);
		}
		return false;
	}
}
