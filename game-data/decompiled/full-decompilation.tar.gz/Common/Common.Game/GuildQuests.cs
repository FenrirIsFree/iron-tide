using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class GuildQuests : IMPSerializable, ITKSerializable
{
	[CompilerGenerated]
	private sealed class _003CGetQuestsWithAction_003Ed__1 : IEnumerable<GuildQuestAction>, IEnumerable, IEnumerator<GuildQuestAction>, IEnumerator, IDisposable
	{
		private int _007B6571_007D;

		private GuildQuestAction _007B6572_007D;

		private int _007B6573_007D;

		private FractionID? _007B6574_007D;

		public FractionID? _003C_003E3__fraction;

		private GuildQuestAction[] _007B6575_007D;

		private int _007B6576_007D;

		private GuildQuestAction _007B6577_007D;

		private string _007B6578_007D;

		GuildQuestAction IEnumerator<GuildQuestAction>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B6572_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B6572_007D;
			}
		}

		[DebuggerHidden]
		public _003CGetQuestsWithAction_003Ed__1(int _007B6566_007D)
		{
			_007B6571_007D = _007B6566_007D;
			_007B6573_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B6567_007D()
		{
			_007B6575_007D = null;
			_007B6578_007D = null;
			_007B6571_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {6567}
			this._007B6567_007D();
		}

		private bool _007B6568_007D()
		{
			int num = _007B6571_007D;
			if (num != 0)
			{
				if (num != 1)
				{
					return false;
				}
				_007B6571_007D = -1;
				goto IL_00cc;
			}
			_007B6571_007D = -1;
			if (!_007B6574_007D.HasValue || _007B6574_007D == FractionID.None)
			{
				return false;
			}
			_007B6575_007D = Enum.GetValues<GuildQuestAction>();
			_007B6576_007D = 0;
			goto IL_00e2;
			IL_00cc:
			_007B6578_007D = null;
			_007B6576_007D++;
			goto IL_00e2;
			IL_00e2:
			if (_007B6576_007D < _007B6575_007D.Length)
			{
				_007B6577_007D = _007B6575_007D[_007B6576_007D];
				_007B6578_007D = _007B6577_007D.ToString();
				if (GetReward(_007B6577_007D, _007B6574_007D.Value, 3) != 0f)
				{
					_007B6572_007D = _007B6577_007D;
					_007B6571_007D = 1;
					return true;
				}
				goto IL_00cc;
			}
			_007B6575_007D = null;
			return false;
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {6568}
			return this._007B6568_007D();
		}

		[DebuggerHidden]
		private void _007B6569_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {6569}
			this._007B6569_007D();
		}

		[DebuggerHidden]
		IEnumerator<GuildQuestAction> IEnumerable<GuildQuestAction>.GetEnumerator()
		{
			_003CGetQuestsWithAction_003Ed__1 _003CGetQuestsWithAction_003Ed__;
			if (_007B6571_007D == -2 && _007B6573_007D == Environment.CurrentManagedThreadId)
			{
				_007B6571_007D = 0;
				_003CGetQuestsWithAction_003Ed__ = this;
			}
			else
			{
				_003CGetQuestsWithAction_003Ed__ = new _003CGetQuestsWithAction_003Ed__1(0);
			}
			_003CGetQuestsWithAction_003Ed__._007B6574_007D = _003C_003E3__fraction;
			return _003CGetQuestsWithAction_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B6570_007D()
		{
			return ((IEnumerable<GuildQuestAction>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {6570}
			return this._007B6570_007D();
		}
	}

	[CompilerGenerated]
	private sealed class _003CGetQuestsWithProgress_003Ed__0 : IEnumerable<GuildQuestProgression>, IEnumerable, IEnumerator<GuildQuestProgression>, IEnumerator, IDisposable
	{
		private int _007B6585_007D;

		private GuildQuestProgression _007B6586_007D;

		private int _007B6587_007D;

		private FractionID? _007B6588_007D;

		public FractionID? _003C_003E3__fraction;

		private GuildQuestScoped[] _007B6589_007D;

		private int _007B6590_007D;

		private GuildQuestScoped _007B6591_007D;

		private GuildQuestProgression? _007B6592_007D;

		GuildQuestProgression IEnumerator<GuildQuestProgression>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B6586_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B6586_007D;
			}
		}

		[DebuggerHidden]
		public _003CGetQuestsWithProgress_003Ed__0(int _007B6580_007D)
		{
			_007B6585_007D = _007B6580_007D;
			_007B6587_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B6581_007D()
		{
			_007B6589_007D = null;
			_007B6585_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {6581}
			this._007B6581_007D();
		}

		private bool _007B6582_007D()
		{
			int num = _007B6585_007D;
			if (num != 0)
			{
				if (num != 1)
				{
					return false;
				}
				_007B6585_007D = -1;
				goto IL_00bc;
			}
			_007B6585_007D = -1;
			if (!_007B6588_007D.HasValue || _007B6588_007D == FractionID.None)
			{
				return false;
			}
			_007B6589_007D = Enum.GetValues<GuildQuestScoped>();
			_007B6590_007D = 0;
			goto IL_00cb;
			IL_00bc:
			_007B6590_007D++;
			goto IL_00cb;
			IL_00cb:
			if (_007B6590_007D < _007B6589_007D.Length)
			{
				_007B6591_007D = _007B6589_007D[_007B6590_007D];
				_007B6592_007D = MapQuestSubtype(_007B6588_007D.Value, _007B6591_007D);
				if (_007B6592_007D.HasValue)
				{
					_007B6586_007D = _007B6592_007D.Value;
					_007B6585_007D = 1;
					return true;
				}
				goto IL_00bc;
			}
			_007B6589_007D = null;
			return false;
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {6582}
			return this._007B6582_007D();
		}

		[DebuggerHidden]
		private void _007B6583_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {6583}
			this._007B6583_007D();
		}

		[DebuggerHidden]
		IEnumerator<GuildQuestProgression> IEnumerable<GuildQuestProgression>.GetEnumerator()
		{
			_003CGetQuestsWithProgress_003Ed__0 _003CGetQuestsWithProgress_003Ed__;
			if (_007B6585_007D == -2 && _007B6587_007D == Environment.CurrentManagedThreadId)
			{
				_007B6585_007D = 0;
				_003CGetQuestsWithProgress_003Ed__ = this;
			}
			else
			{
				_003CGetQuestsWithProgress_003Ed__ = new _003CGetQuestsWithProgress_003Ed__0(0);
			}
			_003CGetQuestsWithProgress_003Ed__._007B6588_007D = _003C_003E3__fraction;
			return _003CGetQuestsWithProgress_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B6584_007D()
		{
			return ((IEnumerable<GuildQuestProgression>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {6584}
			return this._007B6584_007D();
		}
	}

	private static readonly int numQuests = Enum.GetValues<GuildQuestProgression>().Length;

	private static readonly int numQuestsAction = Enum.GetValues<GuildQuestAction>().Length;

	private int[] _007B6562_007D;

	private int[] _007B6563_007D;

	private int[] _007B6564_007D;

	public (int progress, int completionCount) this[GuildQuestProgression _007B6531_007D]
	{
		get
		{
			return (progress: _007B6562_007D[(int)_007B6531_007D], completionCount: _007B6563_007D[(int)_007B6531_007D]);
		}
		set
		{
			ref int reference = ref _007B6562_007D[(int)_007B6532_007D];
			ref int reference2 = ref _007B6563_007D[(int)_007B6532_007D];
			(reference, reference2) = value;
		}
	}

	public int this[GuildQuestAction _007B6534_007D] => _007B6564_007D[(int)_007B6534_007D];

	[IteratorStateMachine(typeof(_003CGetQuestsWithProgress_003Ed__0))]
	public static IEnumerable<GuildQuestProgression> GetQuestsWithProgress(FractionID? _007B6520_007D)
	{
		//yield-return decompiler failed: Method not found
		return new _003CGetQuestsWithProgress_003Ed__0(-2)
		{
			_003C_003E3__fraction = _007B6520_007D
		};
	}

	[IteratorStateMachine(typeof(_003CGetQuestsWithAction_003Ed__1))]
	public static IEnumerable<GuildQuestAction> GetQuestsWithAction(FractionID? _007B6521_007D)
	{
		//yield-return decompiler failed: Method not found
		return new _003CGetQuestsWithAction_003Ed__1(-2)
		{
			_003C_003E3__fraction = _007B6521_007D
		};
	}

	public static GuildQuestProgression? MapQuestSubtype(FractionID _007B6522_007D, GuildQuestScoped _007B6523_007D)
	{
		bool flag = _007B6522_007D == FractionID.Pirate;
		bool flag2 = _007B6522_007D == FractionID.TradeUnion;
		bool flag3 = _007B6522_007D.IsNation();
		if (1 == 0)
		{
		}
		GuildQuestProgression? result = _007B6523_007D switch
		{
			GuildQuestScoped.GrowTensity => null, 
			GuildQuestScoped.BoardingEnemy => null, 
			GuildQuestScoped.GainExperience => GuildQuestProgression.AnyGainExperience, 
			GuildQuestScoped.MakeQuests => GuildQuestProgression.AnyMakeQuests, 
			GuildQuestScoped.GrowRanks => GuildQuestProgression.AnyGrowRanks, 
			GuildQuestScoped.Achievements => GuildQuestProgression.AnyGiveAchievements, 
			GuildQuestScoped.GoldTurnover => flag2 ? new GuildQuestProgression?(GuildQuestProgression.TradersGoldTurnover) : ((GuildQuestProgression?)null), 
			GuildQuestScoped.BuildTopShips => flag2 ? new GuildQuestProgression?(GuildQuestProgression.TradersBuildTopShips) : ((GuildQuestProgression?)null), 
			GuildQuestScoped.KillsAll => null, 
			GuildQuestScoped.KillsInGuild => flag ? new GuildQuestProgression?(GuildQuestProgression.PirateKills) : ((GuildQuestProgression?)null), 
			GuildQuestScoped.BoardingTraders => flag ? new GuildQuestProgression?(GuildQuestProgression.PirateTraderBoardings) : ((GuildQuestProgression?)null), 
			GuildQuestScoped.EnemyDamage => flag3 ? new GuildQuestProgression?(GuildQuestProgression.FractionMakeEnemyDamage) : ((GuildQuestProgression?)null), 
			GuildQuestScoped.SellPearlEvent => flag2 ? new GuildQuestProgression?(GuildQuestProgression.TradersSellPearl) : ((GuildQuestProgression?)null), 
			GuildQuestScoped.UseCraftTime => flag2 ? new GuildQuestProgression?(GuildQuestProgression.TradersUseCraftTime) : ((GuildQuestProgression?)null), 
			GuildQuestScoped.SupplyMission => flag2 ? ((GuildQuestProgression?)null) : new GuildQuestProgression?(GuildQuestProgression.SupplyMission), 
			_ => throw new NotSupportedException(), 
		};
		if (1 == 0)
		{
		}
		return result;
	}

	public static float GetReward(GuildQuestAction _007B6524_007D, FractionID _007B6525_007D, int _007B6526_007D, int _007B6527_007D = 1)
	{
		bool flag = _007B6525_007D == FractionID.Pirate;
		bool flag2 = _007B6525_007D == FractionID.TradeUnion;
		bool flag3 = _007B6525_007D.IsNation();
		if (1 == 0)
		{
		}
		float result = _007B6524_007D switch
		{
			GuildQuestAction.CaptureCity => (!flag2) ? (flag ? 6 : (_007B6526_007D * 4)) : 0, 
			GuildQuestAction.ProtectCity => (!flag2) ? (flag ? 4 : (3 + _007B6526_007D * 2)) : 0, 
			GuildQuestAction.HoldPort => flag3 ? (0.5f * (float)_007B6526_007D) : 0f, 
			GuildQuestAction.HoldOpenedPort => flag3 ? (_007B6526_007D * 2 - 1) : 0, 
			GuildQuestAction.FailedAttack => (!flag2) ? (-5) : 0, 
			GuildQuestAction.CooperatePb => flag3 ? ((_007B6527_007D > 4) ? 4 : ((_007B6527_007D > 2) ? 3 : ((_007B6527_007D > 0) ? 2 : 0))) : 0, 
			GuildQuestAction.ColonizeCity => flag ? 8 : 0, 
			_ => throw new NotSupportedException(), 
		};
		if (1 == 0)
		{
		}
		return result;
	}

	public static int GetRequiredAmountFor(GuildQuestProgression _007B6528_007D, GuildQuests _007B6529_007D)
	{
		if (1 == 0)
		{
		}
		int result = _007B6528_007D switch
		{
			GuildQuestProgression.FractionMakeEnemyDamage => 150000, 
			GuildQuestProgression.TradersGoldTurnover => 15000000, 
			GuildQuestProgression.TradersBuildTopShips => 5, 
			GuildQuestProgression.TradersSellPearl => 600, 
			GuildQuestProgression.TradersUseCraftTime => 50000, 
			GuildQuestProgression.PirateKills => 75, 
			GuildQuestProgression.PirateTraderBoardings => 8, 
			GuildQuestProgression.AnyGainExperience => 300000, 
			GuildQuestProgression.AnyMakeQuests => 50, 
			GuildQuestProgression.AnyGrowRanks => 5, 
			GuildQuestProgression.AnyGiveAchievements => 120, 
			GuildQuestProgression.SupplyMission => GetCountForSupplyMission(_007B6529_007D), 
			_ => throw new NotSupportedException(), 
		};
		if (1 == 0)
		{
		}
		return result;
	}

	public static int GetReward(GuildQuestProgression _007B6530_007D)
	{
		return 1;
	}

	public GuildQuests()
	{
		_007B6562_007D = new int[numQuests];
		_007B6563_007D = new int[numQuests];
		_007B6564_007D = new int[numQuestsAction];
	}

	public int EvaluteValue(int _007B6535_007D, GuildQuestProgression _007B6536_007D, out float _007B6537_007D)
	{
		int requiredAmountFor = GetRequiredAmountFor(_007B6536_007D, this);
		_007B6537_007D = (float)_007B6535_007D / (float)requiredAmountFor;
		int num = 0;
		this[_007B6536_007D] = (progress: this[_007B6536_007D].progress + _007B6535_007D, completionCount: this[_007B6536_007D].completionCount);
		while (this[_007B6536_007D].progress >= requiredAmountFor)
		{
			this[_007B6536_007D] = (progress: this[_007B6536_007D].progress - requiredAmountFor, completionCount: this[_007B6536_007D].completionCount + 1);
			num++;
			requiredAmountFor = GetRequiredAmountFor(_007B6536_007D, this);
		}
		return num;
	}

	public void EvaluteValue(GuildQuestAction _007B6538_007D)
	{
		_007B6564_007D[(int)_007B6538_007D]++;
	}

	public void ResetValue(GuildQuestProgression _007B6539_007D)
	{
		this[_007B6539_007D] = (progress: 0, completionCount: 0);
	}

	public void ResetAll()
	{
		Array.Clear(_007B6562_007D, 0, _007B6562_007D.Length);
		Array.Clear(_007B6563_007D, 0, _007B6563_007D.Length);
		Array.Clear(_007B6564_007D, 0, _007B6564_007D.Length);
	}

	private static int GetCountForSupplyMission(GuildQuests _007B6540_007D)
	{
		int item = _007B6540_007D[GuildQuestProgression.SupplyMission].completionCount;
		int num = 0;
		return item switch
		{
			0 => 400000, 
			1 => 600000, 
			2 => 900000, 
			3 => 1300000, 
			4 => 1800000, 
			5 => 2400000, 
			_ => 3000000, 
		};
	}

	private void _007B6541_007D(WriterExtern _007B6542_007D)
	{
		_007B6542_007D.WriteStruct8bitSize<int>(_007B6562_007D, 0, _007B6562_007D.Length);
		_007B6542_007D.WriteStruct8bitSize<int>(_007B6563_007D, 0, _007B6563_007D.Length);
		_007B6542_007D.WriteStruct8bitSize<int>(_007B6564_007D, 0, _007B6564_007D.Length);
	}

	private void _007B6543_007D(WriterExtern _007B6544_007D)
	{
		_007B6544_007D.ReadStruct8bitSize<int>(ref _007B6562_007D);
		_007B6544_007D.ReadStruct8bitSize<int>(ref _007B6563_007D);
		_007B6544_007D.ReadStruct8bitSize<int>(ref _007B6564_007D);
	}

	private void _007B6545_007D()
	{
	}

	private void _007B6546_007D()
	{
		if (_007B6562_007D.Length != numQuests)
		{
			Array.Resize(ref _007B6562_007D, numQuests);
			Array.Resize(ref _007B6563_007D, numQuests);
		}
		if (_007B6564_007D.Length != numQuestsAction)
		{
			Array.Resize(ref _007B6564_007D, numQuestsAction);
		}
	}

	private void _007B6547_007D(TKWriterExtern _007B6548_007D)
	{
		((TKWriterExtern)(ref _007B6548_007D)).WriteContent((short)9, (Action<WriterExtern>)delegate(WriterExtern _007B6557_007D)
		{
			_007B6557_007D.WriteStruct8bitSize<int>(_007B6562_007D, 0, _007B6562_007D.Length);
		});
		((TKWriterExtern)(ref _007B6548_007D)).WriteContent((short)10, (Action<WriterExtern>)delegate(WriterExtern _007B6559_007D)
		{
			_007B6559_007D.WriteStruct8bitSize<int>(_007B6563_007D, 0, _007B6563_007D.Length);
		});
		((TKWriterExtern)(ref _007B6548_007D)).WriteContent((short)11, (Action<WriterExtern>)delegate(WriterExtern _007B6561_007D)
		{
			_007B6561_007D.WriteStruct8bitSize<int>(_007B6564_007D, 0, _007B6564_007D.Length);
		});
	}

	private void _007B6549_007D(short _007B6550_007D, WriterExtern _007B6551_007D, out bool _007B6552_007D)
	{
		_007B6552_007D = true;
		switch (_007B6550_007D)
		{
		case 9:
			_007B6551_007D.ReadStruct8bitSize<int>(ref _007B6562_007D);
			break;
		case 10:
			_007B6551_007D.ReadStruct8bitSize<int>(ref _007B6563_007D);
			break;
		case 11:
			_007B6551_007D.ReadStruct8bitSize<int>(ref _007B6564_007D);
			break;
		default:
			_007B6552_007D = false;
			break;
		}
	}

	private static int GetNearRounded(int _007B6553_007D, int _007B6554_007D, float _007B6555_007D)
	{
		float num = (float)_007B6553_007D * _007B6555_007D / (float)_007B6554_007D;
		double num2 = Math.Floor(num);
		double num3 = Math.Ceiling(num);
		if ((double)num - num2 < num3 - (double)num)
		{
			return (int)num2 * _007B6554_007D;
		}
		return (int)num3 * _007B6554_007D;
	}

	[CompilerGenerated]
	private void _007B6556_007D(WriterExtern _007B6557_007D)
	{
		_007B6557_007D.WriteStruct8bitSize<int>(_007B6562_007D, 0, _007B6562_007D.Length);
	}

	[CompilerGenerated]
	private void _007B6558_007D(WriterExtern _007B6559_007D)
	{
		_007B6559_007D.WriteStruct8bitSize<int>(_007B6563_007D, 0, _007B6563_007D.Length);
	}

	[CompilerGenerated]
	private void _007B6560_007D(WriterExtern _007B6561_007D)
	{
		_007B6561_007D.WriteStruct8bitSize<int>(_007B6564_007D, 0, _007B6564_007D.Length);
	}
}
