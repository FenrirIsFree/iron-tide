namespace Common.Game;

public struct GuildCost
{
	public GSI FortRes;

	public int ConquerBadges;

	public int GoldIngots;

	public GuildCost(GSI _007B4296_007D, int _007B4297_007D, int _007B4298_007D)
	{
		FortRes = _007B4296_007D;
		ConquerBadges = _007B4297_007D;
		GoldIngots = _007B4298_007D;
	}
}
