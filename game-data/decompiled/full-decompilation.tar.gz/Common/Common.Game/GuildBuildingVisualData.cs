using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct GuildBuildingVisualData : IMPSerializable
{
	public string CapturedByGuild;

	public GuildFortStatus FortStatus;

	public byte StatusIcon;

	public bool ShowHpAndAllowDamage;

	public byte[] FlagImage;

	public byte PlaceIDInPort;

	public byte PortID;

	public float AttackTimerMaxDistance;

	public GuildBuildingVisualData(byte[] _007B7114_007D, int _007B7115_007D, int _007B7116_007D, GuildFortStatus _007B7117_007D, int _007B7118_007D, bool _007B7119_007D, float _007B7120_007D, string _007B7121_007D = "")
	{
		FortStatus = _007B7117_007D;
		StatusIcon = (byte)_007B7118_007D;
		CapturedByGuild = _007B7121_007D;
		FlagImage = _007B7114_007D;
		PlaceIDInPort = (byte)_007B7115_007D;
		PortID = (byte)_007B7116_007D;
		ShowHpAndAllowDamage = _007B7119_007D;
		AttackTimerMaxDistance = _007B7120_007D;
	}

	private void _007B7122_007D(WriterExtern _007B7123_007D)
	{
		_007B7123_007D.Write(CapturedByGuild, (Encoding)null);
		_007B7123_007D.WriteByte((byte)FortStatus);
		_007B7123_007D.WriteByte(StatusIcon);
		_007B7123_007D.Write(ShowHpAndAllowDamage);
		_007B7123_007D.WriteBytes32bitSize(FlagImage);
		_007B7123_007D.WriteByte(PlaceIDInPort);
		_007B7123_007D.WriteByte(PortID);
		_007B7123_007D.WriteStruct<float>(AttackTimerMaxDistance);
	}

	private void _007B7124_007D(WriterExtern _007B7125_007D)
	{
		_007B7125_007D.ReadString(ref CapturedByGuild, (Encoding)null);
		FortStatus = (GuildFortStatus)_007B7125_007D.ReadByte();
		StatusIcon = _007B7125_007D.ReadByte();
		_007B7125_007D.ReadBoolean(ref ShowHpAndAllowDamage);
		_007B7125_007D.ReadBytes32bitSize(ref FlagImage);
		PlaceIDInPort = _007B7125_007D.ReadByte();
		PortID = _007B7125_007D.ReadByte();
		_007B7125_007D.ReadStruct<float>(ref AttackTimerMaxDistance);
	}

	public override bool Equals(object _007B7126_007D)
	{
		GuildBuildingVisualData guildBuildingVisualData = (GuildBuildingVisualData)_007B7126_007D;
		return guildBuildingVisualData.CapturedByGuild == CapturedByGuild && guildBuildingVisualData.FortStatus == FortStatus && guildBuildingVisualData.StatusIcon == StatusIcon && guildBuildingVisualData.ShowHpAndAllowDamage == ShowHpAndAllowDamage && ((guildBuildingVisualData.FlagImage == null && FlagImage == null) || FlagImage.Length == FlagImage.Length) && guildBuildingVisualData.PortID == PortID && guildBuildingVisualData.PlaceIDInPort == PlaceIDInPort && guildBuildingVisualData.AttackTimerMaxDistance == AttackTimerMaxDistance;
	}
}
