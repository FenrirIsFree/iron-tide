using CommonDataTypes;

namespace Common.Game;

public class GuildTitle
{
	public readonly int Id;

	public readonly FractionID Fraction;

	public readonly GuildTitlePlace Place;

	public readonly string IconName;

	public readonly int WinnerRewardMint;

	private readonly string _007B6655_007D;

	public string Name => Local.Current(_007B6655_007D);

	public GuildTitle(int _007B6653_007D, GuildTitleToken _007B6654_007D)
	{
		Id = _007B6653_007D;
		Fraction = _007B6654_007D.Fraction;
		Place = _007B6654_007D.Place;
		_007B6655_007D = _007B6654_007D.Name;
		IconName = $"{Fraction}_{Place}";
		WinnerRewardMint = _007B6654_007D.WinnerRewardMint;
	}
}
