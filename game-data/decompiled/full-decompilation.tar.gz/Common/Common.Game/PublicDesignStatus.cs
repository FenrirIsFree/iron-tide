namespace Common.Game;

public enum PublicDesignStatus
{
	Unapproved,
	Normal
}
