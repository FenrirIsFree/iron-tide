namespace Common.Game;

public enum DropModel : byte
{
	SmallDebris,
	SmallBox,
	Fishing,
	ShipDebris,
	DebrisWithBox,
	IsleFarming,
	RuinsFarming,
	UnitOnRaft,
	FishingShip,
	IsleTreasures,
	RealShipLoot,
	PlayerThrowBox,
	SpecialBox,
	Whale,
	WorldFortLoot,
	Pumkin,
	GiftBox,
	EmpireUnderwaterBox
}
