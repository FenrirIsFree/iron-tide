using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Text;
using Common.Account;
using Common.Resources;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;

namespace Common.Game;

public struct GlobalMapOnlineEvent : IMPSerializable
{
	public record PlayerAdvert
	{
		public bool allowPick
		{
			[CompilerGenerated]
			get
			{
				return _007B5752_007D;
			}
			[CompilerGenerated]
			init
			{
				_007B5752_007D = value;
			}
		}

		public bool pvpMode
		{
			[CompilerGenerated]
			get
			{
				return _007B5753_007D;
			}
			[CompilerGenerated]
			init
			{
				_007B5753_007D = value;
			}
		}

		public Func<string> text
		{
			[CompilerGenerated]
			get
			{
				return _007B5754_007D;
			}
			[CompilerGenerated]
			init
			{
				_007B5754_007D = value;
			}
		}

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private readonly bool _007B5752_007D;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private readonly bool _007B5753_007D;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private readonly Func<string> _007B5754_007D;

		public PlayerAdvert(bool _007B5735_007D, bool _007B5736_007D, Func<string> _007B5737_007D)
		{
			_007B5752_007D = _007B5735_007D;
			_007B5753_007D = _007B5736_007D;
			_007B5754_007D = _007B5737_007D;
			base._002Ector();
		}

		[CompilerGenerated]
		protected virtual bool PrintMembers(StringBuilder _007B5741_007D)
		{
			RuntimeHelpers.EnsureSufficientExecutionStack();
			_007B5741_007D.Append("allowPick = ");
			_007B5741_007D.Append(allowPick.ToString());
			_007B5741_007D.Append(", pvpMode = ");
			_007B5741_007D.Append(pvpMode.ToString());
			_007B5741_007D.Append(", text = ");
			_007B5741_007D.Append(text);
			return true;
		}

		[CompilerGenerated]
		public void Deconstruct(out bool _007B5749_007D, out bool _007B5750_007D, out Func<string> _007B5751_007D)
		{
			_007B5749_007D = allowPick;
			_007B5750_007D = pvpMode;
			_007B5751_007D = text;
		}
	}

	public static readonly float PlayerAdvertDurationSec = 600f;

	public static readonly float PlayerAdvertCooldownSec = 1800f;

	public static readonly PlayerAdvert[] PlayerAdvertOptions = new PlayerAdvert[4]
	{
		new PlayerAdvert(_007B5735_007D: true, _007B5736_007D: false, () => Local.mapAdvert_text1),
		new PlayerAdvert(_007B5735_007D: true, _007B5736_007D: false, () => Local.mapAdvert_text2),
		new PlayerAdvert(_007B5735_007D: true, _007B5736_007D: true, () => Local.mapAdvert_text3),
		new PlayerAdvert(_007B5735_007D: false, _007B5736_007D: true, () => Local.mapAdvert_text4)
	};

	public GlobalEventMarkerType Type;

	public CompressedPosition Position;

	public int Argument;

	public bool IsFlickering;

	public string PlayerAdvertNickname;

	public uint PlayerAdvertSID;

	public bool AlwaysVisibleOnMap
	{
		get
		{
			GlobalEventMarkerType type = Type;
			bool flag = type - 1 <= GlobalEventMarkerType.PlayerVisible;
			return flag || (Type == GlobalEventMarkerType.NpcEvent && Gameplay.NpcsInfo[Argument].Descritpion == NpcType.Empire_Legendary3l);
		}
	}

	public bool SilhouetteInFogOfWar => Type == GlobalEventMarkerType.RareTreasures || (Type == GlobalEventMarkerType.NpcEvent && Gameplay.NpcsInfo[Argument].Descritpion == NpcType.Empire_Legendary3l);

	public string GetDescription()
	{
		switch (Type)
		{
		case GlobalEventMarkerType.NpcEvent:
		{
			NpcInfo npcInfo = Gameplay.NpcsInfo.FromID(Argument);
			if (npcInfo.Extras.IsPirateFr1)
			{
				return Local.worldMapEvent_pirate_fleet;
			}
			if (npcInfo.Extras.IsPirateFr2)
			{
				return Local.worldMapEvent_orden_fleet;
			}
			if (npcInfo.Descritpion == NpcType.Trader_Ferryman)
			{
				return Local.worldMapEvent_ferryman;
			}
			if (npcInfo.Descritpion == NpcType.Empire_Legendary2l)
			{
				return Local.npc_Empire_Legendary_2lvl;
			}
			if (npcInfo.Descritpion == NpcType.Empire_Legendary3l)
			{
				return Local.npc_Empire_Legendary_3lvl;
			}
			return Local.worldMapEvent_legendary(npcInfo.NpcName);
		}
		case GlobalEventMarkerType.PlayerVisible:
			return (Argument == 6) ? Local.worldMapEvent_wanted_no_fr : Local.worldMapEvent_wanted(((FractionID)Argument).GetName());
		case GlobalEventMarkerType.RareTreasures:
			return Local.worldMapEvent_treasures;
		case GlobalEventMarkerType.PlayerAdvert:
			return Local.WorldMapUi_advert + ": " + PlayerAdvertOptions[Argument].text();
		default:
			throw new NotSupportedException();
		}
	}

	public GlobalMapOnlineEvent(GlobalEventMarkerType _007B5722_007D, Vector2 _007B5723_007D, int _007B5724_007D, bool _007B5725_007D = false, PlayerAccount? _007B5726_007D = null)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		PlayerAdvertNickname = null;
		PlayerAdvertSID = 0u;
		Type = _007B5722_007D;
		Position = new CompressedPosition(_007B5723_007D);
		Argument = _007B5724_007D;
		IsFlickering = _007B5725_007D;
		if (_007B5722_007D == GlobalEventMarkerType.PlayerAdvert)
		{
			PlayerAdvertSID = _007B5726_007D.SID;
			PlayerAdvertNickname = _007B5726_007D.PlayerName;
		}
	}

	private void _007B5727_007D(WriterExtern _007B5728_007D)
	{
		_007B5728_007D.WriteByte((byte)Type);
		_007B5728_007D.WriteStruct<CompressedPosition>(ref Position);
		_007B5728_007D.WriteStruct<int>(Argument);
		_007B5728_007D.Write(IsFlickering);
		if (Type == GlobalEventMarkerType.PlayerAdvert)
		{
			_007B5728_007D.Write(PlayerAdvertNickname, Encoding.UTF8);
			_007B5728_007D.WriteStruct<uint>(PlayerAdvertSID);
		}
	}

	private void _007B5729_007D(WriterExtern _007B5730_007D)
	{
		Type = (GlobalEventMarkerType)_007B5730_007D.ReadByte();
		_007B5730_007D.ReadStruct<CompressedPosition>(ref Position);
		_007B5730_007D.ReadStruct<int>(ref Argument);
		_007B5730_007D.ReadBoolean(ref IsFlickering);
		if (Type == GlobalEventMarkerType.PlayerAdvert)
		{
			_007B5730_007D.ReadString(ref PlayerAdvertNickname, Encoding.UTF8);
			_007B5730_007D.ReadStruct<uint>(ref PlayerAdvertSID);
		}
	}
}
