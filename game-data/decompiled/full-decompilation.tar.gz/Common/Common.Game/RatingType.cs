namespace Common.Game;

public enum RatingType
{
	AchievementRating,
	PvPRangRating,
	ArenaTournamentHigh,
	PrevArenaTournamentHigh,
	ArenaRating,
	PrevArenaRating
}
