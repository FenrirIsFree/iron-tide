namespace Common.Game;

public struct GSILocalEnumerablePair<TFinish>
{
	public readonly TFinish Info;

	public readonly int Count;

	public GSILocalEnumerablePair(TFinish _007B5422_007D, int _007B5423_007D)
	{
		Info = _007B5422_007D;
		Count = _007B5423_007D;
	}

	public override string ToString()
	{
		return Info.GetType().Name + "x " + Count;
	}
}
