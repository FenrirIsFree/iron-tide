using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;

namespace Common.Game;

public struct CommonShotInfo : IMPSerializable
{
	public int UID;

	public byte SenderCannonSectionUID;

	public Vector3 StartNormalMultiplySpeed;

	public float FinalDistance;

	public float FinalCurve;

	public CannonBallExtraEffects Effects;

	public Vector3 ServerPosition;

	private void _007B4596_007D(WriterExtern _007B4597_007D)
	{
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		_007B4597_007D.WriteStruct<int>(ref UID);
		_007B4597_007D.WriteByte(SenderCannonSectionUID);
		_007B4597_007D.WriteStruct<Vector3>(ref StartNormalMultiplySpeed);
		_007B4597_007D.WriteStruct<float>(ref FinalDistance);
		_007B4597_007D.WriteStruct<float>(ref FinalCurve);
		_007B4597_007D.WriteByte((byte)Effects);
		if (SenderCannonSectionUID == byte.MaxValue)
		{
			_007B4597_007D.WriteStruct<Vector3>(ServerPosition);
		}
	}

	private void _007B4598_007D(WriterExtern _007B4599_007D)
	{
		_007B4599_007D.ReadStruct<int>(ref UID);
		SenderCannonSectionUID = _007B4599_007D.ReadByte();
		_007B4599_007D.ReadStruct<Vector3>(ref StartNormalMultiplySpeed);
		_007B4599_007D.ReadStruct<float>(ref FinalDistance);
		_007B4599_007D.ReadStruct<float>(ref FinalCurve);
		Effects = (CannonBallExtraEffects)_007B4599_007D.ReadByte();
		if (SenderCannonSectionUID == byte.MaxValue)
		{
			_007B4599_007D.ReadStruct<Vector3>(ref ServerPosition);
		}
	}
}
