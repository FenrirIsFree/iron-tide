using System;
using System.Linq;
using Common.Account;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class PlayerReputations : IMPSerializable
{
	public struct ChangeReputation : IMPSerializable
	{
		public FractionID Fraction;

		public float Amount;

		public float DamageModifier;

		public bool MirrorOnOthers;

		public ChangeReputation(FractionID _007B8672_007D, float _007B8673_007D, bool _007B8674_007D = true)
		{
			Fraction = _007B8672_007D;
			Amount = _007B8673_007D;
			DamageModifier = 1f;
			MirrorOnOthers = _007B8674_007D;
		}

		public void Boxing(WriterExtern _007B8675_007D)
		{
			_007B8675_007D.WriteByte((byte)Fraction);
			_007B8675_007D.WriteStruct<float>(Amount);
			_007B8675_007D.WriteStruct<float>(DamageModifier);
			_007B8675_007D.Write(MirrorOnOthers);
		}

		public void Unboxing(WriterExtern _007B8676_007D)
		{
			Fraction = (FractionID)_007B8676_007D.ReadByte();
			_007B8676_007D.ReadStruct<float>(ref Amount);
			_007B8676_007D.ReadStruct<float>(ref DamageModifier);
			_007B8676_007D.ReadBoolean(ref MirrorOnOthers);
		}
	}

	public const float Min = -100f;

	public const float Max = 100f;

	private float[] _007B8668_007D;

	public FractionID PrimaryFraction
	{
		get
		{
			FractionID result = FractionID.None;
			float num = 33f;
			for (int i = 0; i < _007B8668_007D.Length; i++)
			{
				if (_007B8668_007D[i] > num)
				{
					result = FractionDecorator.Nations[i];
					num = _007B8668_007D[i];
				}
			}
			return result;
		}
	}

	public float MinReputation => _007B8668_007D.Min();

	public float MaxReputation => _007B8668_007D.Max();

	public float AverageRound => MathF.Round(_007B8668_007D.Average());

	public float this[FractionID _007B8650_007D]
	{
		get
		{
			int num = FractionDecorator.Nations.IndexOf(in _007B8650_007D);
			return (num == -1) ? 0f : _007B8668_007D[num];
		}
	}

	public void Set(FractionID _007B8651_007D, float _007B8652_007D, PlayerAccount _007B8653_007D, GuildCommon? _007B8654_007D)
	{
		int num = FractionDecorator.Nations.IndexOf(in _007B8651_007D);
		if (num != -1)
		{
			_007B8668_007D[num] = Math.Clamp(FractionAPI.ValidateReputation(_007B8651_007D, _007B8652_007D, _007B8653_007D, _007B8654_007D), -100f, 100f);
		}
	}

	public float Change(ChangeReputation _007B8655_007D, PlayerAccount _007B8656_007D, GuildCommon? _007B8657_007D)
	{
		_007B8655_007D.Amount *= _007B8655_007D.DamageModifier;
		_007B8655_007D.Amount = MathF.Ceiling(Math.Abs(_007B8655_007D.Amount)) * (float)MathF.Sign(_007B8655_007D.Amount);
		float num = 0f;
		if (_007B8655_007D.Amount < 0f && (_007B8655_007D.Fraction == _007B8657_007D?.Fraction || (_007B8655_007D.Fraction == FractionID.TradeUnion && (_007B8657_007D == null || _007B8657_007D.Fraction != FractionID.Pirate)) || (_007B8657_007D != null && _007B8657_007D.Fraction == FractionID.TradeUnion)))
		{
			num = 0f - MathF.Round(_007B8656_007D.ReputationFine);
			num *= _007B8655_007D.DamageModifier;
			num = MathF.Floor(Math.Abs(num)) * (float)MathF.Sign(num);
			_007B8656_007D.ReputationFine = Math.Min(20f, _007B8656_007D.ReputationFine + _007B8655_007D.DamageModifier);
		}
		if (_007B8655_007D.Fraction == FractionID.TradeUnion)
		{
			for (int i = 0; i < _007B8668_007D.Length; i++)
			{
				Set(FractionDecorator.Nations[i], _007B8668_007D[i] + _007B8655_007D.Amount + num, _007B8656_007D, _007B8657_007D);
			}
		}
		else
		{
			int num2 = FractionDecorator.Nations.IndexOf(in _007B8655_007D.Fraction);
			if (num2 != -1)
			{
				Set(_007B8655_007D.Fraction, _007B8668_007D[num2] + _007B8655_007D.Amount + num, _007B8656_007D, _007B8657_007D);
				if (_007B8655_007D.MirrorOnOthers)
				{
					_007B8655_007D.Amount /= (float)FractionDecorator.Nations.Size - 1f;
					for (int j = 0; j < FractionDecorator.Nations.Size; j++)
					{
						if (j != num2)
						{
							Set(FractionDecorator.Nations[j], _007B8668_007D[j] - _007B8655_007D.Amount, _007B8656_007D, _007B8657_007D);
						}
					}
				}
			}
		}
		return _007B8655_007D.Amount + num;
	}

	public void ChangeAfterExitOfGuild(PlayerAccount _007B8658_007D, GuildCommon _007B8659_007D, bool _007B8660_007D)
	{
		if (_007B8659_007D != null)
		{
			throw new InvalidOperationException("Guild is not null");
		}
		if (!_007B8660_007D)
		{
			for (int i = 0; i < _007B8668_007D.Length; i++)
			{
				_007B8668_007D[i] = 0f;
			}
		}
	}

	public void ChangeAfterEnterToGuild(PlayerAccount _007B8661_007D, GuildCommon _007B8662_007D)
	{
		if (_007B8662_007D == null)
		{
			throw new InvalidOperationException("Guild is null");
		}
		if (_007B8662_007D.IsFlotilia)
		{
			return;
		}
		if (_007B8662_007D.Fraction == FractionID.TradeUnion)
		{
			for (int i = 0; i < _007B8668_007D.Length; i++)
			{
				_007B8668_007D[i] = Math.Max(_007B8668_007D[i], 0f);
			}
		}
		else if (_007B8662_007D.Fraction == FractionID.Pirate)
		{
			for (int j = 0; j < _007B8668_007D.Length; j++)
			{
				_007B8668_007D[j] = Math.Min(_007B8668_007D[j], -34f);
			}
		}
		else if (_007B8662_007D.Fraction.IsNation())
		{
			int num = FractionDecorator.Nations.IndexOf(_007B8662_007D.Fraction);
			for (int k = 0; k < _007B8668_007D.Length; k++)
			{
				if (k == num)
				{
					_007B8668_007D[k] = Math.Max(_007B8668_007D[k], 44f);
				}
				else
				{
					_007B8668_007D[k] = Math.Min(_007B8668_007D[k], -34f);
				}
			}
		}
		for (int l = 0; l < _007B8668_007D.Length; l++)
		{
			_007B8668_007D[l] = FractionAPI.ValidateReputation(FractionDecorator.Nations[l], _007B8668_007D[l], _007B8661_007D, _007B8662_007D);
		}
	}

	public bool ShouldKickByReputation(GuildCommon _007B8663_007D, PortCaputreStatusList _007B8664_007D, float _007B8665_007D = 0f)
	{
		if (_007B8663_007D.IsFlotilia)
		{
			return false;
		}
		if (_007B8663_007D.Fraction == FractionID.TradeUnion)
		{
			for (int i = 0; i < FractionDecorator.Nations.Size; i++)
			{
				if (this[FractionDecorator.Nations[i]] + _007B8665_007D <= -33f)
				{
					return true;
				}
			}
			return false;
		}
		if (_007B8663_007D.Fraction.IsNation() && _007B8664_007D != null)
		{
			float num = 33f;
			if (_007B8664_007D.FractionBonusHelper(_007B8663_007D.Fraction))
			{
				num = -33f;
			}
			if (this[_007B8663_007D.Fraction] + _007B8665_007D < num)
			{
				return true;
			}
		}
		return false;
	}

	public PlayerReputations()
	{
		_007B8668_007D = new float[FractionDecorator.Nations.Size];
	}

	public void Boxing(WriterExtern _007B8666_007D)
	{
		_007B8666_007D.WriteStruct8bitSize<float>(_007B8668_007D, 0, _007B8668_007D.Length);
	}

	public void Unboxing(WriterExtern _007B8667_007D)
	{
		_007B8667_007D.ReadStruct8bitSize<float>(ref _007B8668_007D);
	}
}
