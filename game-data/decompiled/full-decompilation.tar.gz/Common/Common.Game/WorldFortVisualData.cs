using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct WorldFortVisualData : IMPSerializable
{
	public GSI NowReward;

	public bool IsDestroyed;

	public WorldFortVisualData(GSI _007B7138_007D, bool _007B7139_007D)
	{
		NowReward = _007B7138_007D.Clone();
		IsDestroyed = _007B7139_007D;
	}

	private void _007B7140_007D(WriterExtern _007B7141_007D)
	{
		_007B7141_007D.WriteNoNull<GSI>(NowReward);
		_007B7141_007D.Write(IsDestroyed);
	}

	private void _007B7142_007D(WriterExtern _007B7143_007D)
	{
		_007B7143_007D.ReadIMPSNoNull<GSI>(ref NowReward);
		_007B7143_007D.ReadBoolean(ref IsDestroyed);
	}

	public override bool Equals(object _007B7144_007D)
	{
		WorldFortVisualData worldFortVisualData = (WorldFortVisualData)_007B7144_007D;
		return worldFortVisualData.NowReward.Equals(NowReward) && worldFortVisualData.IsDestroyed == IsDestroyed;
	}
}
