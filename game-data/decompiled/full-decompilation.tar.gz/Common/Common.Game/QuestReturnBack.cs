namespace Common.Game;

public class QuestReturnBack : QuestStepHeader
{
	public override int ProgressComparand => -1;

	public QuestReturnBack(string _007B7677_007D)
		: base(_007B7677_007D)
	{
	}
}
