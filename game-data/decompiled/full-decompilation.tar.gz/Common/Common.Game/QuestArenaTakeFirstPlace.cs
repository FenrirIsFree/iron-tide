namespace Common.Game;

public class QuestArenaTakeFirstPlace : QuestStepHeader
{
	public readonly int Count;

	public readonly ArenaMode[] Modes;

	public override int ProgressComparand => Count;

	public QuestArenaTakeFirstPlace(string _007B7541_007D, int _007B7542_007D, params ArenaMode[] _007B7543_007D)
		: base(_007B7541_007D)
	{
		Modes = _007B7543_007D;
		Count = _007B7542_007D;
	}
}
