using System;
using Microsoft.Xna.Framework;

namespace Common.Game;

public struct CompressedPosition
{
	private int _007B5212_007D;

	public Vector2 Position
	{
		get
		{
			//IL_001e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0028: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_0037: Unknown result type (might be due to invalid IL or missing references)
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			short num = (short)(_007B5212_007D >> 16);
			short num2 = (short)(_007B5212_007D & 0xFFFF);
			return new Vector2((float)num, (float)num2) / 32767f * Gameplay.WorldMapSizeXY;
		}
	}

	public CompressedPosition(Vector2 _007B5211_007D)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		_007B5211_007D = _007B5211_007D / Gameplay.WorldMapSizeXY * 32767f;
		short num = (short)Math.Max(-32768.0, Math.Min(Math.Round(_007B5211_007D.X), 32767.0));
		short num2 = (short)Math.Max(-32768.0, Math.Min(Math.Round(_007B5211_007D.Y), 32767.0));
		_007B5212_007D = (num << 16) | (ushort)num2;
	}
}
