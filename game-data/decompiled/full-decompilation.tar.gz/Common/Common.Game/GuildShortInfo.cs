using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct GuildShortInfo : IMPSerializable
{
	public string Tag;

	public FractionID Fraction;

	public readonly bool IsFlotilia => CommonSupport.IsGuildFlotilia(Fraction);

	public bool IsNull => string.IsNullOrEmpty(Tag);

	public GuildShortInfo(string _007B6643_007D, FractionID _007B6644_007D)
	{
		Tag = _007B6643_007D;
		Fraction = _007B6644_007D;
	}

	public GuildShortInfo(GuildCommon? _007B6645_007D)
	{
		if (_007B6645_007D == null)
		{
			Tag = string.Empty;
			Fraction = FractionID.Empire;
		}
		else
		{
			Tag = _007B6645_007D.Tag;
			Fraction = _007B6645_007D.Fraction;
		}
	}

	private void _007B6646_007D(WriterExtern _007B6647_007D)
	{
		_007B6647_007D.Write(Tag, (Encoding)null);
		_007B6647_007D.WriteByte((byte)Fraction);
	}

	private void _007B6648_007D(WriterExtern _007B6649_007D)
	{
		_007B6649_007D.ReadString(ref Tag, (Encoding)null);
		Fraction = (FractionID)_007B6649_007D.ReadByte();
	}

	public override bool Equals(object _007B6650_007D)
	{
		if (_007B6650_007D is GuildShortInfo guildShortInfo)
		{
			return guildShortInfo.Tag == Tag && guildShortInfo.Fraction == Fraction;
		}
		return false;
	}
}
