namespace Common.Game;

public enum PbCaptureMode : byte
{
	Capture,
	Reset,
	Colonize,
	Server_Nothing
}
