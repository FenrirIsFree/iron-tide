using Common.Account;
using TheraEngine.Collections;

namespace Common.Game;

public class QuestEducationFlag : QuestStepHeader
{
	public struct Item
	{
		public readonly EducationOnboarding Marker;

		public readonly string HeaderText;

		public Item(EducationOnboarding _007B7598_007D, string _007B7599_007D)
		{
			Marker = _007B7598_007D;
			HeaderText = _007B7599_007D;
		}
	}

	public readonly Tlist<Item> Conditions;

	public readonly EducationOnboardingStore Mask;

	public override int ProgressComparand => -1;

	public QuestEducationFlag(string _007B7594_007D, params Item[] _007B7595_007D)
		: base(_007B7594_007D)
	{
		Conditions = new Tlist<Item>(_007B7595_007D);
		Mask = default(EducationOnboardingStore);
		for (int i = 0; i < _007B7595_007D.Length; i++)
		{
			Item item = _007B7595_007D[i];
			Mask.Append(item.Marker);
		}
	}
}
