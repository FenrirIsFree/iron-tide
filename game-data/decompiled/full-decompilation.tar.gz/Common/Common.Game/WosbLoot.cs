using System;
using System.Linq;
using Common.Resources;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using TheraEngine.Helpers;

namespace Common.Game;

public static class WosbLoot
{
	public readonly struct GoodsGenerator
	{
		public readonly float Probability;

		public readonly DropModel Model;

		public readonly NDropInteropMethod Method;

		public readonly DropServerEffect Effect;

		public readonly Func<Vector2, int, DropBonusInfo> Generate;

		public readonly Func<bool> Enabled;

		public GoodsGenerator(float _007B4001_007D, DropModel _007B4002_007D, NDropInteropMethod _007B4003_007D, DropServerEffect _007B4004_007D, Func<Vector2, int, DropBonusInfo> _007B4005_007D, Func<bool> _007B4006_007D = null)
		{
			Probability = _007B4001_007D;
			Model = _007B4002_007D;
			Method = _007B4003_007D;
			Effect = _007B4004_007D;
			Generate = _007B4005_007D;
			Enabled = _007B4006_007D;
		}
	}

	private static GoodsGenerator[] Goods2 = new GoodsGenerator[14]
	{
		new GoodsGenerator(20f, DropModel.GiftBox, NDropInteropMethod.PickUp, DropServerEffect.None, delegate
		{
			float num = Rand.Range(0f, 100f);
			DropBonusInfo result = new DropBonusInfo(0, new GSI(), new GSI());
			float num2 = 0f;
			if (num < (num2 += 56f))
			{
				result.Ammo.Exs(5, Rand.RangeInt(90, 176));
			}
			else if (num < (num2 += 36f))
			{
				result.Ammo.Exs(18, 30);
			}
			else if (num < (num2 += 3.5f))
			{
				result.Resources.Exs(15, 10);
			}
			else if (num < (num2 += 3f))
			{
				result.Resources.Exs(38, 5);
			}
			else if (num < (num2 += 1f))
			{
				result.Resources.Exs(33, 1);
			}
			else if (num < (num2 += 0.3f))
			{
				result.Resources.Exs(40, 1);
			}
			else
			{
				result.Resources.Exs(67, 1);
			}
			result.Ammo.Exs(21, Rand.RangeInt(150, 301));
			return result;
		}, () => CalendarEvents.IsNewYear),
		new GoodsGenerator(20f, DropModel.Pumkin, NDropInteropMethod.PickUp, DropServerEffect.None, delegate
		{
			float num = Rand.Range(0f, 100f);
			DropBonusInfo result = new DropBonusInfo(0, new GSI(), new GSI());
			if (Rand.Chanse(14f))
			{
				result.MineTrapInside = true;
			}
			else if (num < 60f)
			{
				int _007B5449_007D = Rand.RangeInt(90, 175);
				result.Ammo.Exs(5, _007B5449_007D);
			}
			else if (num < 85f)
			{
				result.PowderKegs.Exs(5, 1);
			}
			else if (num < 91f)
			{
				result.Resources.Exs(15, 10);
			}
			else if (num < 97f)
			{
				result.Resources.Exs(38, 5);
			}
			else if (num < 99.2f)
			{
				result.Resources.Exs(33, 1);
			}
			else if (num < 99.7f)
			{
				result.Resources.Exs(40, 1);
			}
			else
			{
				result.Resources.Exs(67, 1);
			}
			return result;
		}, () => CalendarEvents.PumpkinLootEnabled),
		new GoodsGenerator(8f, DropModel.Whale, NDropInteropMethod.Looting, DropServerEffect.None, delegate(Vector2 _007B4011_007D, int _007B4012_007D)
		{
			(float, float) tuple = ZoneAmountHelper(_007B4012_007D);
			float num = MathF.Round(Rand.Pick<float>(0.7f, 0.7f, 0.7f, 1f, 1f, 1.2f, 2f, 2.2f) * (tuple.Item1 - 0.25f) * 10f) * 20f;
			float num2 = num * 2f + 75f;
			if (Rand.Chanse(7f) && (Gameplay.IsInHazardZone(in _007B4011_007D) || Gameplay.WorldMap.OutsideSeamLevel(in _007B4011_007D) > 0f))
			{
				num *= 10f;
				num2 *= 8f;
			}
			else if (CalendarEvents.PumpkinLootEnabled)
			{
				num *= 7f;
				num2 *= 6f;
			}
			GSI _007B5624_007D = new GSI().Exs(70, Rand.Round(0.6f * num2 / (float)Gameplay.ItemsInfo.FromID(70).MediumCost.Value)).Exs(21, Rand.Round(0.4f * num2 / (float)Gameplay.ItemsInfo.FromID(21).MediumCost.Value)).Exs(69, (int)Math.Max(1.0, Math.Round(num / 1400f)));
			return new DropBonusInfo(0, new GSI(), _007B5624_007D)
			{
				BonusXp = (int)(num2 * Gameplay.BasicXpInGold),
				Server_WhaleHealth = (int)(num * 0.7f)
			};
		}),
		new GoodsGenerator(22f, DropModel.Fishing, NDropInteropMethod.Looting, DropServerEffect.SpawnFar, delegate(Vector2 _007B4013_007D, int _007B4014_007D)
		{
			(float, float) tuple = ZoneAmountHelper(_007B4014_007D);
			float num = Rand.Pick<float>(0.3f, 0.3f, 0.3f, 0.46f, 0.46f, 0.46f, 0.6f, 0.6f, 1f, 1f);
			float num2 = 400f * tuple.Item1 / (float)Gameplay.ItemsInfo.FromID(34).MediumCost.Value;
			float _007B14491_007D = num2 * num;
			int _007B5448_007D = Rand.Pick<int>(30, 17, 35, 53, 20);
			int _007B5448_007D2 = Rand.Pick<int>(38, 37, 24, 35);
			GSI gSI = new GSI().Exs(34, Rand.Round(_007B14491_007D));
			if (Rand.Chanse(30f))
			{
				gSI.Exs(_007B5448_007D, 1);
			}
			if (Rand.Chanse(7f))
			{
				gSI.Exs(_007B5448_007D2, 1);
			}
			else if (Rand.Chanse(0.5f))
			{
				gSI.Exs(67, 1);
			}
			if (CalendarEvents.GoldFishingEnabled)
			{
				gSI[69] = (Rand.Chanse(50f) ? 1 : 0);
			}
			return new DropBonusInfo(0, new GSI(), gSI)
			{
				DisplayOnly_InitialBonusItemsTotalCount = num2,
				BonusXp = (int)(150f * tuple.Item2 * Gameplay.BasicXpInGold)
			};
		}),
		new GoodsGenerator(16f, DropModel.SmallDebris, NDropInteropMethod.PickUp, DropServerEffect.None, delegate(Vector2 _007B4015_007D, int _007B4016_007D)
		{
			(float, float) tuple = ZoneAmountHelper(_007B4016_007D);
			(float, float) tuple2 = ZoneAmountHelper(_007B4016_007D);
			GSI gSI = new GSI();
			gSI.Exs(1, Rand.Round(34.800003f * tuple.Item2));
			gSI.Exs(20, Rand.Round(8.400001f * tuple.Item2));
			if (Rand.Chanse(66f))
			{
				gSI.Exs(3, Rand.Round(10f * tuple2.Item2));
			}
			return new DropBonusInfo(0, new GSI(), gSI);
		}),
		new GoodsGenerator(15f, DropModel.SmallBox, NDropInteropMethod.PickUp, DropServerEffect.CanHavePowderKegs, delegate(Vector2 _007B4017_007D, int _007B4018_007D)
		{
			GSI gSI = new GSI();
			(float, float) tuple = ZoneAmountHelper(_007B4018_007D);
			gSI.AddOrRemove(20, Rand.Round(5f * tuple.Item2));
			float _007B14491_007D = 10f + 25f * tuple.Item2;
			if (Rand.Chanse(6f))
			{
				gSI.AddOrRemove(24, 1);
				_007B14491_007D = 0f;
			}
			GSI gSI2 = new GSI();
			if (CalendarEvents.IceBallsDropEnabled && Rand.Chanse(50f))
			{
				gSI2[5] += Rand.Round(30f * tuple.Item2);
			}
			return new DropBonusInfo(Rand.Round(_007B14491_007D), gSI2, gSI);
		}),
		new GoodsGenerator(14f, DropModel.ShipDebris, NDropInteropMethod.LongWatching, DropServerEffect.CanHavePirateTrap | DropServerEffect.SpawnNearIsles, delegate(Vector2 _007B4019_007D, int _007B4020_007D)
		{
			int num = Rand.Pick<int>(4, 11, 13, 30);
			int num2 = Rand.Pick<int>(4, 11, 13, 13, 30);
			(float, float) tuple = ZoneAmountHelper(_007B4020_007D);
			float _007B14491_007D = 110f * tuple.Item2 / (float)Gameplay.ItemsInfo.FromID(num).MediumCost.Value;
			float _007B14491_007D2 = 80f * tuple.Item2 / (float)Gameplay.ItemsInfo.FromID(num2).MediumCost.Value;
			CannonGameInfo cannonGameInfo = Gameplay.CannonsGameInfo.Rand((CannonGameInfo _007B4021_007D) => _007B4021_007D.CraftingType == ShipCannonCrafting.NotAvailable && _007B4021_007D.Class != CannonClass.Mortar);
			int _007B5449_007D = (Rand.Chanse(8f) ? 1 : 0);
			return new DropBonusInfo(0, new GSI(), new GSI().Exs(num, Rand.Round(_007B14491_007D)).Exs(num2, Rand.Round(_007B14491_007D2)))
			{
				Cannons = new GSI().Exs(cannonGameInfo.ID, _007B5449_007D)
			};
		}),
		new GoodsGenerator(10f, DropModel.DebrisWithBox, NDropInteropMethod.LongWatching, DropServerEffect.CanHavePowderKegs | DropServerEffect.SpawnNearIsles, delegate(Vector2 _007B4022_007D, int _007B4023_007D)
		{
			(float, float) tuple = ZoneAmountHelper(_007B4023_007D);
			float _007B14491_007D = 45f * tuple.Item2;
			int _007B5448_007D = Rand.Pick<int>(2, 1, 7);
			GSI gSI = new GSI().Exs(_007B5448_007D, Rand.Round(_007B14491_007D));
			if (Rand.Chanse(50f))
			{
				gSI.Exs(16, 1);
			}
			byte powerupItemIDindex = (byte)bonusGainsPassing[Rand.RangeInt(0, bonusGainsPassing.Length)];
			if (Rand.Chanse(20f))
			{
				powerupItemIDindex = 41;
			}
			float _007B14491_007D2 = 25f * tuple.Item2;
			return new DropBonusInfo(0, gSI, new GSI().Exs(1, Rand.Round(_007B14491_007D2)))
			{
				PowerupItemIDindex = powerupItemIDindex,
				PowderKegs = new GSI().Exs(Rand.Pick<int>(2, 3), 1)
			};
		}),
		new GoodsGenerator(10f, DropModel.IsleFarming, NDropInteropMethod.MiningByCrew, DropServerEffect.SpawnOnIsles, delegate(Vector2 _007B4024_007D, int _007B4025_007D)
		{
			(float, float) tuple = ZoneAmountHelper(_007B4025_007D);
			float num = tuple.Item2 * 500f;
			num *= 0.75f;
			ResourceInfo resourceInfo = Gameplay.ItemsInfo.FromID(Rand.Pick<int>(1, 31, 32, 12));
			ResourceInfo resourceInfo2 = Gameplay.ItemsInfo.FromID(Rand.Pick<int>(22, 2, 9));
			EconomyRegion nearRegion = Gameplay.GetNearWorldRegion(in _007B4024_007D).ItemsEconomyReigion;
			ResourceInfo[] array = Gameplay.ItemsInfo.Where((ResourceInfo _007B4037_007D) => _007B4037_007D.IsTradingItem && _007B4037_007D.TradingItemShouldBeOnIsle && _007B4037_007D.TradingItemEconomyRegion == nearRegion).ToArray();
			if (array.Length != 0)
			{
				resourceInfo2 = array[Rand.RangeInt(0, array.Length)];
			}
			GSI gSI = new GSI
			{
				[resourceInfo.ID] = Rand.Round(Math.Max(1f, num / (float)resourceInfo.MediumCost.Value * 0.45f)),
				[resourceInfo2.ID] = Rand.Round(Math.Max(1f, num / (float)resourceInfo2.MediumCost.Value * 0.45f)),
				[9] = Rand.Round(num * 0.7f / (float)Gameplay.ItemsInfo.FromID(9).MediumCost.Value),
				[23] = Rand.Round(num * 0.5f / (float)Gameplay.ItemsInfo[23].MediumCost.Value)
			};
			if (Rand.Chanse(2f))
			{
				gSI[24]++;
			}
			return new DropBonusInfo(0, new GSI(), gSI)
			{
				BonusXp = (int)(90f * tuple.Item2 * Gameplay.BasicXpInGold)
			};
		}),
		new GoodsGenerator(1.2f, DropModel.RuinsFarming, NDropInteropMethod.LongWatching, DropServerEffect.CanHavePirateTrap | DropServerEffect.SpawnOnIsles, delegate(Vector2 _007B4026_007D, int _007B4027_007D)
		{
			(float, float) tuple = ZoneAmountHelper(_007B4027_007D);
			GSI gSI = new GSI();
			int _007B5448_007D = Rand.Pick<int>(38, 43, 24, 24);
			gSI.Exs(_007B5448_007D, 1);
			gSI.Exs(23, Rand.Round(tuple.Item2 * 300f / (float)Gameplay.ItemsInfo.FromID(23).MediumCost.Value));
			return new DropBonusInfo(0, new GSI(), gSI);
		}),
		new GoodsGenerator(1f, DropModel.EmpireUnderwaterBox, NDropInteropMethod.PickUp, DropServerEffect.SpawnFar, delegate(Vector2 _007B4028_007D, int _007B4029_007D)
		{
			(float, float) tuple = ZoneAmountHelper(_007B4029_007D);
			GSI gSI = new GSI();
			(int, int) tuple2 = Rand.PickWeighted<(int, int)>(((24, Rand.RangeInt(15, 26)), 35f), ((15, Rand.RangeInt(2, 4)), 35f), ((67, 1), 20f), ((43, 1), 10f));
			gSI[tuple2.Item1] += tuple2.Item2;
			return new DropBonusInfo(0, new GSI(), gSI);
		}),
		new GoodsGenerator(3.5f, DropModel.UnitOnRaft, NDropInteropMethod.PickUp, DropServerEffect.SpawnCloseToShipDebris, (Vector2 _007B4030_007D, int _007B4031_007D) => new DropBonusInfo(0, new GSI(), new GSI().Exs(35, 1))
		{
			Crew = new GSI().Exs(WosbCrew.GetSpecialUnitOnRaft().ID, 1)
		}),
		new GoodsGenerator(20f, DropModel.FishingShip, NDropInteropMethod.LongWatching, DropServerEffect.CanHavePirateTrap | DropServerEffect.SpawnNearIsles, delegate(Vector2 _007B4032_007D, int _007B4033_007D)
		{
			(float, float) tuple = ZoneAmountHelper(_007B4033_007D);
			GSI gSI = new GSI();
			UnitInfo unitInfo = Rand.Pick(Gameplay.UnitsInfo.Where((UnitInfo _007B4034_007D) => _007B4034_007D.Type == UnitType.Sailor || _007B4034_007D.Type == UnitType.Boarding).ToArray());
			fromPrice(gSI, 34, 60f * tuple.Item2, 1);
			return new DropBonusInfo(0, new GSI(), gSI.Exs(36, Rand.Round(Math.Clamp(3f * tuple.Item2, 2f, 7f))))
			{
				Crew = new GSI().Exs(unitInfo.ID, Rand.Round(4.8f * (0.4f + 0.6f * tuple.Item1 / 1.5f)))
			};
		}),
		new GoodsGenerator(0.2f, DropModel.IsleTreasures, NDropInteropMethod.LongWatching, DropServerEffect.SpawnOnIsles | DropServerEffect.GlobalMapEvent, delegate(Vector2 _007B4035_007D, int _007B4036_007D)
		{
			(float, float) tuple = ZoneAmountHelper(_007B4036_007D);
			float num = 20000f * Rand.Range(0.75f, 1.5f);
			GSI gSI = new GSI();
			if (Rand.Chanse(30f))
			{
				gSI[38]++;
			}
			else if (Rand.Chanse(10f))
			{
				gSI[43]++;
				num /= 2f;
			}
			fromPrice(gSI, 24, num, 1);
			return new DropBonusInfo(0, new GSI(), gSI);
		})
	};

	private static int[] bonusGainsArena = new int[3] { 11, 1, 27 };

	private static int[] bonusGainsPassing = new int[7] { 35, 37, 38, 39, 40, 41, 17 };

	private static (float max, float random) ZoneAmountHelper(int _007B3982_007D)
	{
		float num = Rand.Range(0.5f, 1.5f);
		float num2 = 1f + (float)_007B3982_007D * 0.15f * 9f / 7f;
		return (max: num2 * 1.5f, random: num2 * num);
	}

	public static (Vector2, DropBonusInfo, NDropInteropMethod, DropModel, DropServerEffect) GenerateWorldMapGoods(Func<DropModel, DropServerEffect, Vector2?> _007B3983_007D, params DropModel[] _007B3984_007D)
	{
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		float _007B14474_007D = Goods2.Sum((GoodsGenerator _007B4038_007D) => (_007B3984_007D.Contains(_007B4038_007D.Model) || (_007B4038_007D.Enabled != null && !_007B4038_007D.Enabled())) ? 0f : _007B4038_007D.Probability);
		float num = Rand.Range(0f, _007B14474_007D);
		float num2 = 0f;
		GoodsGenerator[] goods = Goods2;
		for (int num3 = 0; num3 < goods.Length; num3++)
		{
			GoodsGenerator goodsGenerator = goods[num3];
			if (_007B3984_007D.Contains(goodsGenerator.Model) || (goodsGenerator.Enabled != null && !goodsGenerator.Enabled()))
			{
				continue;
			}
			num2 += goodsGenerator.Probability;
			if (num2 >= num)
			{
				Vector2? val = _007B3983_007D(goodsGenerator.Model, goodsGenerator.Effect);
				if (val.HasValue)
				{
					DropBonusInfo item = goodsGenerator.Generate(val.Value, Gameplay.GetNearWorldRegion(val.Value).LevelInt);
					return (val.Value, item, goodsGenerator.Method, goodsGenerator.Model, goodsGenerator.Effect);
				}
				return (Vector2.Zero, default(DropBonusInfo), NDropInteropMethod.PickUp, DropModel.Fishing, DropServerEffect.None);
			}
		}
		throw new NotSupportedException();
	}

	public static DropBonusInfo GenerateSpecificGoodsContent(DropModel _007B3985_007D, Vector2 _007B3986_007D)
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		return Goods2.First((GoodsGenerator _007B4039_007D) => _007B4039_007D.Model == _007B3985_007D).Generate(_007B3986_007D, Gameplay.GetNearWorldRegion(in _007B3986_007D).LevelInt);
	}

	public static DropBonusInfo GenerateArenaDrop(int _007B3987_007D)
	{
		DropBonusInfo result = new DropBonusInfo(0, new GSI(), new GSI());
		result.PowerupItemIDindex = (byte)bonusGainsArena[_007B3987_007D % bonusGainsArena.Length];
		return result;
	}

	public static DropBonusInfo GenerateArenaDropWithDebris(float _007B3988_007D)
	{
		DropBonusInfo result = new DropBonusInfo(0, new GSI(), new GSI());
		result.Ammo = new GSI().Exs(Rand.Pick<int>(1, 2, 7, 3), (int)Rand.Range(50f * _007B3988_007D, 100f * _007B3988_007D));
		return result;
	}

	public static DropBonusInfo GeneratePassingMapDrop(MapForPassingInfo _007B3989_007D)
	{
		float num = Math.Max(1f, (float)(6 - (_007B3989_007D.RangRitriction.Item1 + _007B3989_007D.RangRitriction.Item2) / 2) / 3f);
		if (Rand.Chanse(30f))
		{
			DropBonusInfo result = new DropBonusInfo(0, new GSI(), new GSI());
			result.PowerupItemIDindex = (byte)bonusGainsPassing[Rand.RangeInt(0, bonusGainsPassing.Length)];
			return result;
		}
		if (Rand.Chanse(50f))
		{
			int _007B5449_007D = Rand.Round(50f * num);
			GSI gSI = new GSI();
			gSI.Exs(1, _007B5449_007D);
			if (Rand.Chanse(50f))
			{
				gSI.Exs(3, _007B5449_007D);
			}
			else
			{
				gSI.Exs(2, _007B5449_007D);
			}
			return new DropBonusInfo(0, gSI, new GSI());
		}
		float num2 = num * 40f;
		GSI gSI2 = new GSI();
		gSI2.Exs(1, Rand.Round(num2));
		if (Rand.Chanse(50f))
		{
			gSI2.Exs(3, Rand.Round(num2 * 0.7f));
		}
		return new DropBonusInfo(0, new GSI(), gSI2);
	}

	public static DropBonusInfo[] PassingMapTowerDestroyDrop(MapForPassingInfo _007B3990_007D)
	{
		int item = _007B3990_007D.RangRitriction.Item1;
		float num = Math.Max(1f, (float)(6 - item) / 3f);
		float num2 = num * 40f;
		GSI gSI = new GSI();
		gSI.Exs(1, Rand.Round(num2));
		gSI.Exs(3, Rand.Round(num2 * 0.4f));
		GSI gSI2 = new GSI();
		DropBonusInfo dropBonusInfo = new DropBonusInfo(0, gSI2, gSI);
		dropBonusInfo.PowerupItemIDindex = (byte)bonusGainsPassing[Rand.RangeInt(0, bonusGainsPassing.Length)];
		DropBonusInfo dropBonusInfo2 = dropBonusInfo;
		DropBonusInfo dropBonusInfo3 = new DropBonusInfo(0, gSI2.Clone(), gSI.Clone());
		DropBonusInfo dropBonusInfo4 = new DropBonusInfo(0, gSI2.Clone(), gSI.Clone());
		return new DropBonusInfo[3] { dropBonusInfo2, dropBonusInfo3, dropBonusInfo4 };
	}

	private static void fromPrice(GSI _007B3991_007D, int _007B3992_007D, float _007B3993_007D, int _007B3994_007D = 0)
	{
		float num = _007B3993_007D / (float)Gameplay.ItemsInfo.FromID(_007B3992_007D).MediumCost.Value;
		switch (_007B3994_007D)
		{
		case 0:
			_007B3991_007D.Exs(_007B3992_007D, (int)Math.Round(num));
			break;
		case 1:
			_007B3991_007D.Exs(_007B3992_007D, Rand.Round(num));
			break;
		case 2:
			_007B3991_007D.Exs(_007B3992_007D, Gameplay.roundHelper(num));
			break;
		default:
			throw new NotSupportedException();
		}
	}
}
