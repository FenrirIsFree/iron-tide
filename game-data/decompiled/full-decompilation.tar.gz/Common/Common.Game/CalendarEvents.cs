using System;
using Common.Account;
using Common.Resources;
using TheraEngine;

namespace Common.Game;

public static class CalendarEvents
{
	public const int MinimalRank = 7;

	public static readonly RTI SkipQuestPriceInMonets = 89;

	public static TraderOffer SkipQuestOffer => new TraderOffer(SkipQuestPriceInMonets.Value, null, 0, 0, -1, -1, _007B6857_007D: true, _007B6858_007D: true);

	public static bool IsActive => CurrentEvent.IsActive;

	public static bool IsActiveExtended => CurrentEvent.IsActiveExtended;

	public static bool GoldFishingEnabled => IsActive && CurrentEvent.GoldFishingEnabled;

	public static bool IceBallsDropEnabled => IsActive && CurrentEvent.IceBallsDropEnabled;

	public static float DiscountAllShips => IsActive ? CurrentEvent.DiscountAllShips : 0f;

	public static bool PumpkinLootEnabled => IsActive && CurrentEvent.PumpkinLootEnabled;

	public static bool AltartGoldFishEnabled => IsActive && CurrentEvent.AltarGoldFishEnabled;

	public static bool IsHalloween => IsActiveInternal(CalendarEvent.Halloween);

	public static bool IsNewYear => IsActiveInternal(CalendarEvent.NewYear);

	public static bool IsNewYearExtended => IsActiveInternal(CalendarEvent.NewYear, _007B6093_007D: true);

	public static Action<string>? OnLogbookMessage { get; set; }

	public static CalendarEventInfo CurrentEvent { get; } = NewYearCalendarEvent.Create();

	public static bool HasTrader => IsActiveExtended && CurrentEvent.GoldfishTrader.Count > 0;

	public static void GiveGoldFish(int _007B6082_007D, PlayerAccount _007B6083_007D)
	{
		ResourceInfo _007B2739_007D = Gameplay.ItemsInfo.FromID(69);
		_007B6083_007D.Shipyard.CurrentRealShip.AddOrRemoveItemsInHold(_007B2739_007D, _007B6082_007D);
		SendLogbookMessage(Local.goldfish_received(_007B6082_007D));
	}

	public static void GivePremiumOrMonets(PlayerAccount _007B6084_007D, int _007B6085_007D, int _007B6086_007D)
	{
		if (_007B6084_007D.IsPremium && (_007B6084_007D.PremiumEnds.ToDateTime - DateTime.Now).TotalDays >= 30.0)
		{
			SendLogbookMessage(Local.premium_received_alt($"{_007B6086_007D} {Local.monets}"));
			_007B6084_007D.Monets.Value += _007B6086_007D;
		}
		else
		{
			SendLogbookMessage(Local.premium_received(_007B6084_007D.ServerAddPremiumDays = _007B6085_007D));
		}
	}

	public static void GiveDesign(PlayerAccount _007B6087_007D, int _007B6088_007D)
	{
		_007B6087_007D.DesingElementsAtStorage[_007B6088_007D]++;
		SendLogbookMessage(Local.received(Gameplay.DesignsInfo[_007B6088_007D].Name));
	}

	public static void GiveMonets(PlayerAccount _007B6089_007D, int _007B6090_007D)
	{
		_007B6089_007D.Monets.Value += _007B6090_007D;
		SendLogbookMessage(Local.received($"{_007B6090_007D} {Local.monets}"));
	}

	public static void SendLogbookMessage(string _007B6091_007D)
	{
		OnLogbookMessage?.Invoke(_007B6091_007D);
	}

	private static bool IsActiveInternal(CalendarEvent _007B6092_007D, bool _007B6093_007D = false)
	{
		if (_007B6092_007D != CurrentEvent.Type)
		{
			return false;
		}
		if (CurrentEvent.SyncedFromServer)
		{
			return _007B6093_007D ? IsActiveExtended : IsActive;
		}
		DateTime now = DateTime.Now;
		DateTime startDate = CurrentEvent.StartDate;
		DateTime dateTime = CurrentEvent.StartDate + new TimeSpan((CurrentEvent.Duration + (_007B6093_007D ? 6 : 0)) * 24, 0, 0);
		return startDate < now && now < dateTime;
	}
}
