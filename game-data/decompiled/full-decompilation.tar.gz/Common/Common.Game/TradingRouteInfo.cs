using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using Common.Account;
using Common.Resources;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using TheraEngine.Collections;
using TheraEngine.Helpers;

namespace Common.Game;

public class TradingRouteInfo
{
	private static readonly float maxSquaredDistanceToObject = 250000f;

	private static readonly float centralRouteDistance = 6000f;

	public readonly int Id;

	public readonly Vector2[] Nodes;

	public readonly Tlist<Vector2> NodesTlist;

	public readonly bool IsCycled;

	public readonly TradingRouteType Type;

	public readonly float TotalDistance;

	public readonly ResourceInfo[] ResourceInfos;

	internal readonly float AverageLevel;

	internal readonly int MinShallowRank;

	internal readonly Tlist<int> IntersectedLevelsInt = new Tlist<int>();

	public IslePortInfo? StartPort;

	public IslePortInfo? EndPort;

	public static float KillsToReduceRoute => 6f;

	public static float ReducedRouteTimeToRestoreFullRoute => 3600f;

	public static float MinDistancePerShip => 300f;

	public TradingRouteInfo(int _007B5762_007D, List<Vector2> _007B5763_007D)
	{
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		if (_007B5763_007D.Count <= 2)
		{
			throw new InvalidOperationException("Some trading route in TradingRoutesInfo.json is not valid: has 2 or less points");
		}
		Id = _007B5762_007D;
		Nodes = _007B5763_007D.ToArray();
		NodesTlist = new Tlist<Vector2>(_007B5763_007D);
		IsCycled = Vector2.Distance(Nodes.First(), Nodes.Last()) < 100f;
		AverageLevel = 0f;
		MinShallowRank = 0;
		for (int i = 0; i < Nodes.Length; i++)
		{
			int item = Gameplay.GetNearWorldRegion(in Nodes[i]).LevelInt;
			AverageLevel += item;
			IntersectedLevelsInt.AddIfNotContains(in item);
			byte val = Gameplay.WorldMap.Shallows.Get(in Nodes[i]);
			MinShallowRank = Math.Max(MinShallowRank, val);
			if (i > 0)
			{
				float num = Vector2.Distance(Nodes[i], Nodes[i - 1]);
				if (num < 15f)
				{
					throw new InvalidOperationException("Route distance error");
				}
				TotalDistance += num;
			}
		}
		AverageLevel /= Nodes.Length;
		Type = _007B5793_007D();
		if (Type == TradingRouteType.None)
		{
			throw new InvalidOperationException();
		}
		StartPort = GetStartNearestPort();
		EndPort = GetEndNearestPort();
		ResourceInfos = _007B5764_007D();
	}

	private ResourceInfo[] _007B5764_007D()
	{
		TradingRouteType type = Type;
		if (1 == 0)
		{
		}
		ResourceInfo[] result = type switch
		{
			TradingRouteType.Supply => _007B5765_007D(), 
			TradingRouteType.Main => _007B5766_007D(), 
			TradingRouteType.Coastal => _007B5767_007D(), 
			TradingRouteType.Central => Array.Empty<ResourceInfo>(), 
			_ => Array.Empty<ResourceInfo>(), 
		};
		if (1 == 0)
		{
		}
		return result;
	}

	private ResourceInfo[] _007B5765_007D()
	{
		HashSet<ResourceInfo> resources = new HashSet<ResourceInfo>();
		AddRes(_007B5774_007D(0, out var _007B5776_007D));
		AddRes(_007B5774_007D(^1, out _007B5776_007D));
		return resources.ToArray();
		void AddRes(FactoryPlaceIsleInfo? _007B5794_007D)
		{
			if (_007B5794_007D != null && _007B5794_007D.Predefines != null && _007B5794_007D.Predefines.Size != 0)
			{
				FactoryType key = _007B5794_007D.Predefines.First();
				if (WosbCrafting.FactoriesInfo.TryGetValue(key, out FactoryGameInfo value))
				{
					resources.Add(value.Levels[0].DisplayOutputRes);
				}
			}
		}
	}

	private ResourceInfo[] _007B5766_007D()
	{
		HashSet<ResourceInfo> hashSet = new HashSet<ResourceInfo>();
		if (StartPort?.PbsManufacture != null)
		{
			hashSet.Add(StartPort.PbsManufacture);
		}
		if (EndPort?.PbsManufacture != null)
		{
			hashSet.Add(EndPort.PbsManufacture);
		}
		return hashSet.ToArray();
	}

	private ResourceInfo[] _007B5767_007D()
	{
		GSI resources = new GSI();
		AddTraderRes(_007B5771_007D(0, out var _007B5773_007D));
		AddTraderRes(_007B5771_007D(^1, out _007B5773_007D));
		return (from _007B5800_007D in resources.RandItemsId(2, _007B5478_007D: false)
			select Gameplay.ItemsInfo[_007B5800_007D]).ToArray();
		void AddTraderRes(TraderInSeaPlaceInfo? _007B5796_007D)
		{
			if (_007B5796_007D != null)
			{
				resources.Add(_007B5796_007D.NearPort.LiveTrading);
			}
		}
	}

	public IslePortInfo? GetStartNearestPort()
	{
		float _007B5770_007D;
		return _007B5768_007D(0, out _007B5770_007D);
	}

	public IslePortInfo? GetEndNearestPort()
	{
		float _007B5770_007D;
		return _007B5768_007D(^1, out _007B5770_007D);
	}

	private IslePortInfo? _007B5768_007D(Index _007B5769_007D, out float _007B5770_007D)
	{
		return GetNodeNearestObject(_007B5769_007D, (Vector2 _007B5801_007D) => Gameplay.WorldMap.GetNearPort(in _007B5801_007D), (IslePortInfo _007B5802_007D) => _007B5802_007D.EntryPos, out _007B5770_007D);
	}

	private TraderInSeaPlaceInfo? _007B5771_007D(Index _007B5772_007D, out float _007B5773_007D)
	{
		return GetNodeNearestObject(_007B5772_007D, (Vector2 _007B5803_007D) => Gameplay.WorldMap.GetNearTraderInSea(in _007B5803_007D), (TraderInSeaPlaceInfo _007B5804_007D) => _007B5804_007D.Position, out _007B5773_007D);
	}

	private FactoryPlaceIsleInfo? _007B5774_007D(Index _007B5775_007D, out float _007B5776_007D)
	{
		return GetNodeNearestObject(_007B5775_007D, (Vector2 _007B5805_007D) => Gameplay.WorldMap.GetNearFactory(_007B5805_007D), (FactoryPlaceIsleInfo _007B5806_007D) => _007B5806_007D.GlobalPosition, out _007B5776_007D);
	}

	private T? GetNodeNearestObject<T>(Index _007B5777_007D, Func<Vector2, T> _007B5778_007D, Func<T, Vector2> _007B5779_007D, out float _007B5780_007D) where T : class
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		T val = _007B5778_007D(Nodes[_007B5777_007D]);
		_007B5780_007D = Vector2.DistanceSquared(Nodes[_007B5777_007D], _007B5779_007D(val));
		T val2 = ((_007B5780_007D > maxSquaredDistanceToObject) ? null : val);
		if (val2 == null)
		{
			_007B5780_007D = float.MaxValue;
		}
		return val2;
	}

	public Vector2 RandPosition(bool _007B5781_007D = false)
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		float num = (_007B5781_007D ? Rand.Range(TotalDistance * 0.25f, TotalDistance * 0.75f) : Rand.Range(0f, TotalDistance));
		for (int i = 0; i < Nodes.Length - 1; i++)
		{
			Vector2 val = Nodes[i];
			Vector2 val2 = Nodes[i + 1];
			float num2 = Vector2.Distance(val, val2);
			if (num <= num2)
			{
				float num3 = num / num2;
				return Vector2.Lerp(val, val2, num3);
			}
			num -= num2;
		}
		return Nodes[0];
	}

	public Vector2 GetPreferredNextPoint(Vector2 _007B5782_007D)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		Vector2 near = NodesTlist.FindNear(_007B5782_007D, (Vector2 _007B5807_007D) => _007B5807_007D);
		if (Vector2.DistanceSquared(near, _007B5782_007D) > 2500f)
		{
			return near;
		}
		return NodesTlist.FindNear(_007B5782_007D, (Vector2 _007B5809_007D) => (Vector2)((_007B5809_007D == near) ? new Vector2(10000000f, 0f) : _007B5809_007D));
	}

	private ShipPositionInfo _007B5783_007D(Index _007B5784_007D)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = Nodes[_007B5784_007D];
		Vector2 val2 = ((_007B5784_007D.Value == 0) ? Nodes[1] : Nodes[^2]);
		float _007B5192_007D = MathF.Atan2(val2.Y - val.Y, val2.X - val.X);
		return new ShipPositionInfo(val, _007B5192_007D);
	}

	public ShipPositionInfo RandPoisitonForSpawn(float _007B5785_007D = 50f)
	{
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		if (Rand.Chanse(_007B5785_007D) && (StartPort != null || EndPort != null))
		{
			if (StartPort != null && EndPort != null)
			{
				return Rand.Pick<ShipPositionInfo>(_007B5783_007D(0), _007B5783_007D(^1));
			}
			return (StartPort != null) ? _007B5783_007D(0) : _007B5783_007D(^1);
		}
		Vector2 val = RandPosition(_007B5781_007D: true);
		Vector2 preferredNextPoint = GetPreferredNextPoint(val);
		float _007B5192_007D = MathF.Atan2(preferredNextPoint.Y - val.Y, preferredNextPoint.X - val.X);
		return new ShipPositionInfo(val, _007B5192_007D);
	}

	public static TradingRouteInfo? PickRoute(NpcInfo _007B5786_007D, Func<TradingRouteInfo[], TradingRouteInfo?>? _007B5787_007D)
	{
		TradingRouteInfo[] array = Gameplay.TradingRoutesInfo.Where((TradingRouteInfo _007B5810_007D) => _007B5810_007D._007B5788_007D(_007B5786_007D)).ToArray();
		if (array.Length == 0)
		{
			return null;
		}
		if (_007B5787_007D != null)
		{
			TradingRouteInfo tradingRouteInfo = _007B5787_007D(array);
			if (tradingRouteInfo != null)
			{
				return tradingRouteInfo;
			}
		}
		return Rand.PickWeighted((TradingRouteInfo _007B5808_007D) => _007B5808_007D.TotalDistance, array);
	}

	private bool _007B5788_007D(NpcInfo _007B5789_007D)
	{
		if (MinShallowRank != 0)
		{
			if (_007B5789_007D.BasedOn.Rank < MinShallowRank)
			{
				return false;
			}
			if (_007B5789_007D.BasedOn.Rank == MinShallowRank)
			{
				return true;
			}
		}
		if (!(AverageLevel > 0.25f) || !(AverageLevel < 0.75f))
		{
			return (int)MathF.Round(AverageLevel) == _007B5789_007D.Location.HzLevel;
		}
		return Rand.Round(AverageLevel) == _007B5789_007D.Location.HzLevel;
	}

	public float GetRevertChanse()
	{
		return (TotalDistance > 1500f && (StartPort != null || EndPort != null)) ? 66 : 0;
	}

	public float Distance(Vector2 _007B5790_007D)
	{
		return MathF.Sqrt(Geometry.DistanceSquaredToLineSegments(ref _007B5790_007D, Nodes));
	}

	public bool IsVisible(PlayerAccount _007B5791_007D)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < Nodes.Length; i++)
		{
			if (_007B5791_007D.FogOfWar.IsOpened(Nodes[i], 0) && _007B5791_007D.OpenedTradingRoutes[Id])
			{
				return true;
			}
		}
		return false;
	}

	public float GetMapTransparancy(Vector2 _007B5792_007D)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		float num = Distance(_007B5792_007D);
		float num2 = 1f - Geometry.InverseLerp(1000f, 4000f, num);
		if (num2 < 0.5f)
		{
			return 0.3f;
		}
		return num2;
	}

	[CompilerGenerated]
	private TradingRouteType _007B5793_007D()
	{
		if (TotalDistance >= centralRouteDistance)
		{
			return TradingRouteType.Central;
		}
		float _007B5770_007D;
		IslePortInfo islePortInfo = _007B5768_007D(0, out _007B5770_007D);
		float _007B5770_007D2;
		IslePortInfo islePortInfo2 = _007B5768_007D(^1, out _007B5770_007D2);
		_007B5771_007D(0, out var _007B5773_007D);
		_007B5771_007D(^1, out var _007B5773_007D2);
		_007B5774_007D(0, out var _007B5776_007D);
		_007B5774_007D(^1, out var _007B5776_007D2);
		TradingRouteType item = new List<(TradingRouteType, float)>
		{
			(TradingRouteType.Main, _007B5770_007D),
			(TradingRouteType.Coastal, _007B5773_007D),
			(TradingRouteType.Supply, _007B5776_007D),
			(TradingRouteType.None, float.MaxValue)
		}.MinBy<(TradingRouteType, float), float>(((TradingRouteType type, float dist) _007B5798_007D) => _007B5798_007D.dist).Item1;
		TradingRouteType item2 = new List<(TradingRouteType, float)>
		{
			(TradingRouteType.Main, _007B5770_007D2),
			(TradingRouteType.Coastal, _007B5773_007D2),
			(TradingRouteType.Supply, _007B5776_007D2),
			(TradingRouteType.None, float.MaxValue)
		}.MinBy<(TradingRouteType, float), float>(((TradingRouteType type, float dist) _007B5799_007D) => _007B5799_007D.dist).Item1;
		if (item == TradingRouteType.Main && item2 == TradingRouteType.Main)
		{
			if ((islePortInfo != null && islePortInfo.Type == PortType.PirateBay) || (islePortInfo2 != null && islePortInfo2.Type == PortType.PirateBay))
			{
				return TradingRouteType.Smuggling;
			}
			return TradingRouteType.Main;
		}
		if (item == TradingRouteType.Supply || item2 == TradingRouteType.Supply)
		{
			return TradingRouteType.Supply;
		}
		if (item == TradingRouteType.Coastal || item2 == TradingRouteType.Coastal)
		{
			return TradingRouteType.Coastal;
		}
		return TradingRouteType.None;
	}
}
