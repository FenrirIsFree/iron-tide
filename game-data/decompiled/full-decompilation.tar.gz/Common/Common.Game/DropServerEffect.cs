using System;

namespace Common.Game;

[Flags]
public enum DropServerEffect
{
	None = 0,
	CanHavePowderKegs = 1,
	CanHaveFireBurning = 2,
	CanHavePirateTrap = 4,
	SpawnOnIsles = 8,
	SpawnNearIsles = 0x10,
	SpawnCloseToShipDebris = 0x20,
	SpawnFar = 0x40,
	GlobalMapEvent = 0x80
}
