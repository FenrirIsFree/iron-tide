using System;

namespace Common.Game;

public class QuestIndividualLoot : QuestStepHeader
{
	public readonly DropModel Model;

	public readonly Func<ComplexBonus> ProceduralServerBonus;

	public override int ProgressComparand => -1;

	public QuestIndividualLoot(string _007B7625_007D, DropModel _007B7626_007D, Func<ComplexBonus> _007B7627_007D)
		: base(_007B7625_007D)
	{
		Model = _007B7626_007D;
		ProceduralServerBonus = _007B7627_007D;
	}
}
