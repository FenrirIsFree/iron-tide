using TheraEngine;

namespace Common.Game;

public class StorageLevelInfo
{
	public readonly RTI Capacity = new RTI(_007B4302_007D);

	public readonly RTI GoldBuildCost = new RTI(_007B4303_007D);

	public readonly GSI ItemsBuildCost;

	public StorageLevelInfo(int _007B4302_007D, int _007B4303_007D, GSI _007B4304_007D)
	{
		ItemsBuildCost = _007B4304_007D;
		base._002Ector();
	}
}
