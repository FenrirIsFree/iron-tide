using System;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine;
using World_Of_Sea_Battle.Constants;

namespace Common.Game;

public struct AuctionOrderPrice : IMPSerializable
{
	public bool IsGold;

	private RTIf _007B6742_007D;

	public float CostPerUnit
	{
		get
		{
			return _007B6742_007D.Value;
		}
		set
		{
			if (_007B6742_007D.IsInitialized)
			{
				_007B6742_007D.Value = value;
			}
			else
			{
				_007B6742_007D = new RTIf(value);
			}
		}
	}

	public int SortingCost => (int)(IsGold ? CostPerUnit : (1000000f + CostPerUnit));

	public AuctionOrderPrice(bool _007B6733_007D, float _007B6734_007D)
	{
		_007B6742_007D = default(RTIf);
		IsGold = _007B6733_007D;
		CostPerUnit = _007B6734_007D;
	}

	public int TotalCostConvertedToMonets(int _007B6735_007D)
	{
		return IsGold ? ((int)MathF.Ceiling(Math.Max(10f, (float)_007B6735_007D * CostPerUnit / 1000f))) : ((int)MathF.Ceiling(CostPerUnit * (float)_007B6735_007D));
	}

	public string ToString(int _007B6736_007D, bool _007B6737_007D = false)
	{
		return (!IsGold) ? $"{(float)_007B6736_007D * CostPerUnit} {Local.monets}" : (_007B6737_007D ? $"{TotalCostConvertedToMonets(_007B6736_007D)} {Local.monets}" : (StringHelper.BigValueHelper((int)((float)_007B6736_007D * CostPerUnit)) + " " + Local.gold2));
	}

	public string StringAddPrefix(int _007B6738_007D, bool _007B6739_007D = false)
	{
		return (!IsGold) ? $"{_007B6738_007D} {Local.monets}" : (_007B6739_007D ? $"{_007B6738_007D} {Local.monets}" : (StringHelper.BigValueHelper(_007B6738_007D) + " " + Local.gold2));
	}

	public void Boxing(WriterExtern _007B6740_007D)
	{
		_007B6740_007D.Write(IsGold);
		_007B6740_007D.WriteStruct<float>(CostPerUnit);
	}

	public void Unboxing(WriterExtern _007B6741_007D)
	{
		_007B6741_007D.ReadBoolean(ref IsGold);
		float costPerUnit = default(float);
		_007B6741_007D.ReadStruct<float>(ref costPerUnit);
		CostPerUnit = costPerUnit;
	}
}
