using System;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Helpers;
using TheraEngine.PacketValues;

namespace Common.Game;

public struct CapturedShipShortInfo : IMPSerializable
{
	public byte PickedAmmoId;

	public byte RepairsCount;

	public ushort AmmoInHold;

	public ushort MortarShotsAmmoInHold;

	public float HoldLoadWeight;

	public Bits8 Flags;

	public byte NotHavingCrewCount;

	public int TargetUID;

	public CapturedShipIntance.NpcMode BehaviorMode;

	public bool FlagsForgotten
	{
		get
		{
			return Flags[0];
		}
		set
		{
			Flags[0] = value;
		}
	}

	public bool FlagsOverload
	{
		get
		{
			return Flags[1];
		}
		set
		{
			Flags[1] = value;
		}
	}

	public bool FlagsAlmostForgotten
	{
		get
		{
			return Flags[2];
		}
		set
		{
			Flags[2] = value;
		}
	}

	public CapturedShipShortInfo(byte _007B8038_007D, byte _007B8039_007D, int _007B8040_007D, int _007B8041_007D, float _007B8042_007D, Npc _007B8043_007D, CapturedShipIntance.NpcMode _007B8044_007D)
	{
		TargetUID = -1;
		PickedAmmoId = _007B8038_007D;
		RepairsCount = _007B8039_007D;
		AmmoInHold = (ushort)Math.Min(65535, _007B8040_007D);
		MortarShotsAmmoInHold = (ushort)Math.Min(65535, _007B8041_007D);
		HoldLoadWeight = _007B8042_007D;
		Flags = default(Bits8);
		if (_007B8043_007D != null)
		{
			NotHavingCrewCount = Geometry.SaturateByte(_007B8043_007D.UsedShip.CrewPlaces - _007B8043_007D.UsedShip.Crew.Count);
		}
		else
		{
			NotHavingCrewCount = 0;
		}
		BehaviorMode = _007B8044_007D;
	}

	public void Boxing(WriterExtern _007B8045_007D)
	{
		_007B8045_007D.WriteByte(PickedAmmoId);
		_007B8045_007D.WriteByte(RepairsCount);
		_007B8045_007D.WriteStruct<ushort>(AmmoInHold);
		_007B8045_007D.WriteStruct<ushort>(MortarShotsAmmoInHold);
		_007B8045_007D.WriteByte(Flags.Value);
		_007B8045_007D.WriteStruct<float>(HoldLoadWeight);
		_007B8045_007D.WriteByte(NotHavingCrewCount);
		_007B8045_007D.WriteStruct<int>(TargetUID);
		_007B8045_007D.WriteByte((byte)BehaviorMode);
	}

	public void Unboxing(WriterExtern _007B8046_007D)
	{
		PickedAmmoId = _007B8046_007D.ReadByte();
		RepairsCount = _007B8046_007D.ReadByte();
		_007B8046_007D.ReadStruct<ushort>(ref AmmoInHold);
		_007B8046_007D.ReadStruct<ushort>(ref MortarShotsAmmoInHold);
		Flags = new Bits8
		{
			Value = _007B8046_007D.ReadByte()
		};
		_007B8046_007D.ReadStruct<float>(ref HoldLoadWeight);
		NotHavingCrewCount = _007B8046_007D.ReadByte();
		_007B8046_007D.ReadStruct<int>(ref TargetUID);
		BehaviorMode = (CapturedShipIntance.NpcMode)_007B8046_007D.ReadByte();
	}
}
