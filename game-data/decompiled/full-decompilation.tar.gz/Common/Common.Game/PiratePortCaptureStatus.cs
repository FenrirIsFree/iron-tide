namespace Common.Game;

public class PiratePortCaptureStatus : PortCaptureStatus
{
	public PiratePortCaptureStatus()
	{
	}

	public PiratePortCaptureStatus(int _007B7878_007D)
		: base(_007B7878_007D)
	{
	}

	public virtual void SetStatusToCaptured(GuildCommon _007B7879_007D)
	{
		if (_007B7879_007D == null)
		{
			CapturedBy = string.Empty;
			CapturerFraction = FractionID.Empire;
		}
		else
		{
			CapturedBy = _007B7879_007D.Tag;
			CapturerFraction = _007B7879_007D.Fraction;
		}
	}
}
