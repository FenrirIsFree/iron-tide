using System;
using Common.Account;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine;

namespace Common.Game;

public struct Bonus : IMPSerializable
{
	private RTI _007B5290_007D;

	private RTI _007B5291_007D;

	private bool _007B5292_007D;

	public int GoldBonus
	{
		get
		{
			if (!_007B5292_007D)
			{
				_007B5281_007D();
			}
			return _007B5290_007D.Value;
		}
		set
		{
			if (!_007B5292_007D)
			{
				_007B5281_007D();
			}
			_007B5290_007D.Value = value;
		}
	}

	public int XpBonus
	{
		get
		{
			if (!_007B5292_007D)
			{
				_007B5281_007D();
			}
			return _007B5291_007D.Value;
		}
		set
		{
			if (!_007B5292_007D)
			{
				_007B5281_007D();
			}
			_007B5291_007D.Value = value;
		}
	}

	public bool IsEmpty => GoldBonus == 0 && XpBonus == 0;

	public Bonus(float _007B5279_007D, int _007B5280_007D)
	{
		_007B5290_007D = (int)_007B5279_007D;
		_007B5291_007D = _007B5280_007D;
		_007B5292_007D = true;
	}

	private void _007B5281_007D()
	{
		_007B5290_007D = 0;
		_007B5291_007D = 0;
		_007B5292_007D = true;
	}

	public static Bonus Multiply(Bonus _007B5282_007D, float _007B5283_007D)
	{
		return new Bonus(Step((float)_007B5282_007D.GoldBonus * _007B5283_007D), Step((float)_007B5282_007D.XpBonus * _007B5283_007D));
	}

	public void Apply(PlayerAccount _007B5284_007D)
	{
		_007B5284_007D.AddXp(XpBonus);
		_007B5284_007D.Gold += GoldBonus;
	}

	public static int Step(float _007B5285_007D)
	{
		if (_007B5285_007D - (float)(int)_007B5285_007D == 0f)
		{
			return (int)_007B5285_007D;
		}
		double num = Math.Floor(_007B5285_007D);
		double num2 = Math.Ceiling(_007B5285_007D);
		double num3 = (double)_007B5285_007D - num;
		if (num3 <= 0.20000000298023224)
		{
			return (int)num;
		}
		return (int)num2;
	}

	public override string ToString()
	{
		return Local.bonus_xp + XpBonus + ", " + Local.bonus_gold + GoldBonus;
	}

	private void _007B5286_007D(WriterExtern _007B5287_007D)
	{
		_007B5287_007D.WriteStruct<int>(XpBonus);
		_007B5287_007D.WriteStruct<int>(GoldBonus);
	}

	private void _007B5288_007D(WriterExtern _007B5289_007D)
	{
		int num = default(int);
		_007B5289_007D.ReadStruct<int>(ref num);
		_007B5291_007D = num;
		int num2 = default(int);
		_007B5289_007D.ReadStruct<int>(ref num2);
		_007B5290_007D = num2;
		_007B5292_007D = true;
	}
}
