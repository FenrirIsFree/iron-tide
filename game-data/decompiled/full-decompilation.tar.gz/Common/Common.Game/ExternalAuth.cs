using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class ExternalAuth : IMPSerializable
{
	public AuthType AuthType;

	public string UserId;

	public string Token;

	public bool IsActive => AuthType != AuthType.Direct;

	public void Boxing(WriterExtern _007B5254_007D)
	{
		_007B5254_007D.WriteEnum((object)AuthType);
		_007B5254_007D.Write(UserId, (Encoding)null);
		_007B5254_007D.Write(Token, (Encoding)null);
	}

	public void Unboxing(WriterExtern _007B5255_007D)
	{
		_007B5255_007D.ReadEnum<AuthType>(ref AuthType);
		_007B5255_007D.ReadString(ref UserId, (Encoding)null);
		_007B5255_007D.ReadString(ref Token, (Encoding)null);
	}

	public override string ToString()
	{
		return $"{AuthType} {UserId}";
	}
}
