using System;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Game;

public class QuestRunningProgress : IMPSerializable
{
	public int QuestID;

	public int ProgressInStep;

	public byte ProgressStepIndex;

	public Tlist<QuestAdditionalLimit>? FailedLimitsOrNull;

	public QuestRuntimeParameter? RuntimeParameter;

	public float TimeSecLeft;

	public QuestStepHeader CurrentStep => Info.Steps.Array[ProgressStepIndex];

	public QuestInfo Info => Gameplay.QuestsInfo.FromID(QuestID);

	internal void Upgrade(QuestRunningUpgrade _007B7458_007D)
	{
		if (_007B7458_007D.QuestID != QuestID)
		{
			throw new InvalidOperationException("required " + QuestID + " questId, but received " + _007B7458_007D.QuestID);
		}
		ProgressStepIndex = _007B7458_007D.NewStep;
		ProgressInStep = _007B7458_007D.NewProgressInStep;
	}

	public QuestRunningProgress()
	{
	}

	public QuestRunningProgress(int _007B7459_007D, QuestRuntimeParameter? _007B7460_007D)
	{
		QuestID = _007B7459_007D;
		ProgressInStep = 0;
		ProgressStepIndex = 0;
		QuestInfo questInfo = Gameplay.QuestsInfo.FromID(_007B7459_007D);
		TimeSecLeft = ((questInfo.LimitedTimeMinutes == -1) ? 0f : ((float)questInfo.LimitedTimeMinutes * 60f));
		RuntimeParameter = _007B7460_007D;
	}

	private void _007B7461_007D(WriterExtern _007B7462_007D)
	{
		_007B7462_007D.WriteStruct<int>(ref QuestID);
		_007B7462_007D.WriteStruct<int>(ref ProgressInStep);
		_007B7462_007D.WriteByte(ProgressStepIndex);
		_007B7462_007D.WriteStruct<float>(ref TimeSecLeft);
		if (FailedLimitsOrNull == null)
		{
			_007B7462_007D.WriteByte((byte)0);
		}
		else
		{
			_007B7462_007D.WriteByte((byte)FailedLimitsOrNull.Size);
			for (int i = 0; i < FailedLimitsOrNull.Size; i++)
			{
				_007B7462_007D.WriteByte((byte)FailedLimitsOrNull.Array[i]);
			}
		}
		_007B7462_007D.Write<QuestRuntimeParameter>(RuntimeParameter);
	}

	private void _007B7463_007D(WriterExtern _007B7464_007D)
	{
		_007B7464_007D.ReadStruct<int>(ref QuestID);
		_007B7464_007D.ReadStruct<int>(ref ProgressInStep);
		ProgressStepIndex = _007B7464_007D.ReadByte();
		_007B7464_007D.ReadStruct<float>(ref TimeSecLeft);
		byte b = _007B7464_007D.ReadByte();
		if (b > 0)
		{
			FailedLimitsOrNull = new Tlist<QuestAdditionalLimit>(b);
			for (int i = 0; i < b; i++)
			{
				FailedLimitsOrNull.Add((QuestAdditionalLimit)_007B7464_007D.ReadByte());
			}
		}
		_007B7464_007D.ReadIMPS<QuestRuntimeParameter>(ref RuntimeParameter);
	}
}
