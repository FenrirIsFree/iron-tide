using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct FriendStatus : IMPSerializable
{
	public string CachedName;

	public byte Flags;

	public FriendStatus(string _007B8394_007D, byte _007B8395_007D)
	{
		CachedName = _007B8394_007D;
		Flags = _007B8395_007D;
	}

	public void Boxing(WriterExtern _007B8396_007D)
	{
		_007B8396_007D.Write(CachedName, (Encoding)null);
		_007B8396_007D.WriteByte(Flags);
	}

	public void Unboxing(WriterExtern _007B8397_007D)
	{
		_007B8397_007D.ReadString(ref CachedName, (Encoding)null);
		Flags = _007B8397_007D.ReadByte();
	}
}
