namespace Common.Game;

public enum GuildFortStatus
{
	Default,
	AllowRobbingFirstTime,
	AllowRobbingSecoundTime,
	AllowCapturing
}
