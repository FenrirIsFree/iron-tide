using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct PlayerContact : IMPSerializable
{
	public uint SID;

	public string Name;

	public PlayerContact(uint _007B6409_007D, string _007B6410_007D)
	{
		SID = _007B6409_007D;
		Name = _007B6410_007D;
	}

	private void _007B6411_007D(WriterExtern _007B6412_007D)
	{
		_007B6412_007D.WriteStruct<uint>(SID);
		_007B6412_007D.Write(Name, (Encoding)null);
	}

	private void _007B6413_007D(WriterExtern _007B6414_007D)
	{
		_007B6414_007D.ReadStruct<uint>(ref SID);
		_007B6414_007D.ReadString(ref Name, (Encoding)null);
	}
}
