using System.Text;
using Common.Resources;
using CommonDataTypes;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class PublicDesignInfo : IMPSerializable
{
	public int ID;

	public ShipDesignCategory Type;

	public PublicDesignStatus Status;

	public uint OwnerPlayerSID;

	public string OwnerGuildTag;

	public bool IsFlag
	{
		get
		{
			ShipDesignCategory type = Type;
			if (type == ShipDesignCategory.Flag || type == ShipDesignCategory.Flag2)
			{
				return true;
			}
			return false;
		}
	}

	public PublicDesignInfo()
	{
	}

	public PublicDesignInfo(int _007B5564_007D, ShipDesignCategory _007B5565_007D, PublicDesignStatus _007B5566_007D, uint _007B5567_007D, string _007B5568_007D)
	{
		ID = _007B5564_007D;
		Type = _007B5565_007D;
		Status = _007B5566_007D;
		OwnerPlayerSID = _007B5567_007D;
		OwnerGuildTag = _007B5568_007D;
	}

	private void _007B5569_007D(WriterExtern _007B5570_007D)
	{
		_007B5570_007D.WriteStruct<int>(ID);
		_007B5570_007D.WriteByte((byte)Type);
		_007B5570_007D.WriteByte((byte)Status);
		_007B5570_007D.WriteStruct<uint>(OwnerPlayerSID);
		_007B5570_007D.Write(OwnerGuildTag, (Encoding)null);
	}

	private void _007B5571_007D(WriterExtern _007B5572_007D)
	{
		_007B5572_007D.ReadStruct<int>(ref ID);
		Type = (ShipDesignCategory)_007B5572_007D.ReadByte();
		Status = (PublicDesignStatus)_007B5572_007D.ReadByte();
		_007B5572_007D.ReadStruct<uint>(ref OwnerPlayerSID);
		_007B5572_007D.ReadString(ref OwnerGuildTag, (Encoding)null);
	}

	public string GetFileName()
	{
		return $"{ShipDesignInfo.ServerIdParam}_{(IsFlag ? "flag_" : "sail_")}{ID}.png";
	}
}
