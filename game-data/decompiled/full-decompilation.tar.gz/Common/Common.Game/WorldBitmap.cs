using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using TheraEngine;
using TheraEngine.Collections;

namespace Common.Game;

public class WorldBitmap
{
	protected byte[] bytes;

	protected readonly int gridSize;

	protected readonly Vector2 mapSize;

	private readonly Vector2[] _007B5945_007D;

	public byte[] Data => bytes;

	public WorldBitmap(int _007B5921_007D, Vector2 _007B5922_007D, byte[] _007B5923_007D = null)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		gridSize = _007B5921_007D;
		mapSize = _007B5922_007D;
		if (_007B5923_007D != null)
		{
			if (_007B5921_007D * _007B5921_007D != _007B5923_007D.Length)
			{
				throw new ArgumentException("initialData not matching required size");
			}
			bytes = _007B5923_007D;
		}
		else
		{
			bytes = new byte[_007B5921_007D * _007B5921_007D];
		}
		Vector2 val = _007B5922_007D / (float)_007B5921_007D;
		_007B5945_007D = (Vector2[])(object)new Vector2[8]
		{
			new Vector2(val.X, 0f),
			new Vector2(0f - val.X, 0f),
			new Vector2(0f, val.Y),
			new Vector2(0f, 0f - val.Y),
			-val,
			val,
			new Vector2(0f - val.X, val.Y),
			new Vector2(val.X, 0f - val.Y)
		};
	}

	public void ParseFrom(Texture2D _007B5924_007D, Color _007B5925_007D)
	{
		if (_007B5924_007D.Width != gridSize && _007B5924_007D.Height != gridSize)
		{
			throw new ArgumentException("srcTexture has not valid size");
		}
		Color[] array = (Color[])(object)new Color[gridSize * gridSize];
		_007B5924_007D.GetData<Color>(array);
		int num = ((((Color)(ref _007B5925_007D)).A > 0) ? 1 : 0);
		int num2 = ((((Color)(ref _007B5925_007D)).R > 0) ? 1 : 0);
		int num3 = ((((Color)(ref _007B5925_007D)).G > 0) ? 1 : 0);
		int num4 = ((((Color)(ref _007B5925_007D)).B > 0) ? 1 : 0);
		if (num + num2 + num3 + num4 != 1)
		{
			throw new ArgumentException("Incorrect channelMask");
		}
		for (int i = 0; i < array.Length; i++)
		{
			bytes[i] = (byte)(((Color)(ref array[i])).A * num + ((Color)(ref array[i])).R * num2 + ((Color)(ref array[i])).G * num3 + ((Color)(ref array[i])).B * num4);
		}
	}

	public unsafe void ParseFrom2(Texture2D _007B5926_007D, params (Color mask, byte value)[] _007B5927_007D)
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		if (_007B5926_007D.Width != gridSize && _007B5926_007D.Height != gridSize)
		{
			throw new ArgumentException("srcTexture has not valid size");
		}
		Color[] array = (Color[])(object)new Color[gridSize * gridSize];
		_007B5926_007D.GetData<Color>(array);
		for (int i = 0; i < array.Length; i++)
		{
			bool flag = false;
			for (int j = 0; j < _007B5927_007D.Length; j++)
			{
				if (array[i] == _007B5927_007D[j].mask)
				{
					bytes[i] = _007B5927_007D[j].value;
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				Color val = array[i];
				throw new InvalidOperationException("There's no key for color " + ((object)(*(Color*)(&val))/*cast due to .constrained prefix*/).ToString());
			}
		}
	}

	public ScoreDictionary<byte> MacthArea(params (Color mask, byte value)[] _007B5928_007D)
	{
		ScoreDictionary<byte> scoreDictionary = new ScoreDictionary<byte>();
		for (int i = 0; i < bytes.Length; i++)
		{
			scoreDictionary.AddScore(bytes[i], 1f);
		}
		return scoreDictionary;
	}

	public Dictionary<byte, Vector2> MacthCentersApproximate(params (Color mask, byte value)[] _007B5929_007D)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = Gameplay.WorldMapSizeXY / (float)gridSize * 2f;
		Dictionary<byte, ValueCounter> dictionary = new Dictionary<byte, ValueCounter>();
		Dictionary<byte, ValueCounter> dictionary2 = new Dictionary<byte, ValueCounter>();
		for (int i = 0; i < _007B5929_007D.Length; i++)
		{
			(Color, byte) tuple = _007B5929_007D[i];
			dictionary.Add(tuple.Item2, new ValueCounter());
			dictionary2.Add(tuple.Item2, new ValueCounter());
		}
		Vector2 _007B5936_007D = default(Vector2);
		for (float num = -7073.2417f; num < 7073.2417f; num += val.X)
		{
			for (float num2 = -7073.2417f; num2 < 7073.2417f; num2 += val.Y)
			{
				((Vector2)(ref _007B5936_007D))._002Ector(num, num2);
				byte key = Get(in _007B5936_007D);
				dictionary[key].Push(_007B5936_007D.X);
				dictionary2[key].Push(_007B5936_007D.Y);
			}
		}
		Dictionary<byte, Vector2> dictionary3 = new Dictionary<byte, Vector2>();
		for (int j = 0; j < _007B5929_007D.Length; j++)
		{
			(Color, byte) tuple2 = _007B5929_007D[j];
			dictionary3.Add(tuple2.Item2, new Vector2(dictionary[tuple2.Item2].Avg, dictionary2[tuple2.Item2].Avg));
		}
		return dictionary3;
	}

	public int PositionToIndex(in Vector2 _007B5930_007D)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return Index2Index(PositionToIndex2(in _007B5930_007D));
	}

	public int Index2Index(in Point _007B5931_007D)
	{
		return Math.Min(gridSize - 1, Math.Max(0, _007B5931_007D.X)) * gridSize + Math.Min(gridSize - 1, Math.Max(0, _007B5931_007D.Y));
	}

	public Point PositionToIndex2(in Vector2 _007B5932_007D)
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		int num = (int)((_007B5932_007D.X / mapSize.X + 0.5f) * (float)gridSize);
		int num2 = (int)((_007B5932_007D.Y / mapSize.Y + 0.5f) * (float)gridSize);
		return new Point(num, num2);
	}

	private Vector2 _007B5933_007D(in Point _007B5934_007D)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		Vector2 result = default(Vector2);
		result.X = _007B5934_007D.X;
		result.Y = _007B5934_007D.Y;
		return result;
	}

	public void Clean()
	{
		Array.Clear(bytes, 0, bytes.Length);
	}

	public void EnumerateBlocks(Action<Point, byte> _007B5935_007D)
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < gridSize * gridSize; i++)
		{
			if (bytes[i] > 0)
			{
				_007B5935_007D(new Point(i / gridSize, i % gridSize), bytes[i]);
			}
		}
	}

	public byte Get(in Vector2 _007B5936_007D)
	{
		return bytes[PositionToIndex(in _007B5936_007D)];
	}

	public float GetBilinear(in Vector2 _007B5937_007D, Func<byte, float> _007B5938_007D)
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		float num = (_007B5937_007D.X / mapSize.X + 0.5f) * (float)gridSize;
		float num2 = (_007B5937_007D.Y / mapSize.Y + 0.5f) * (float)gridSize;
		int num3 = (int)num;
		int num4 = (int)num2;
		float num5 = _007B5938_007D(bytes[Index2Index(new Point(num3, num4))]);
		float num6 = _007B5938_007D(bytes[Index2Index(new Point(num3 + 1, num4))]);
		float num7 = _007B5938_007D(bytes[Index2Index(new Point(num3, num4 + 1))]);
		float num8 = _007B5938_007D(bytes[Index2Index(new Point(num3 + 1, num4 + 1))]);
		Vector2 val = Vector2.Lerp(new Vector2(num5, num6), new Vector2(num7, num8), num2 - (float)num4);
		return MathHelper.Lerp(val.X, val.Y, num - (float)num3);
	}

	public float GetBilinearCmp(in Vector2 _007B5939_007D, int _007B5940_007D)
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		float num = (_007B5939_007D.X / mapSize.X + 0.5f) * (float)gridSize;
		float num2 = (_007B5939_007D.Y / mapSize.Y + 0.5f) * (float)gridSize;
		int num3 = (int)num;
		int num4 = (int)num2;
		float num5 = ((bytes[Index2Index(new Point(num3, num4))] > _007B5940_007D) ? 1f : 0f);
		float num6 = ((bytes[Index2Index(new Point(num3 + 1, num4))] > _007B5940_007D) ? 1f : 0f);
		float num7 = ((bytes[Index2Index(new Point(num3, num4 + 1))] > _007B5940_007D) ? 1f : 0f);
		float num8 = ((bytes[Index2Index(new Point(num3 + 1, num4 + 1))] > _007B5940_007D) ? 1f : 0f);
		Vector2 val = Vector2.Lerp(new Vector2(num5, num6), new Vector2(num7, num8), num2 - (float)num4);
		return MathHelper.Lerp(val.X, val.Y, num - (float)num3);
	}

	public Vector2 FindGradient(in Vector2 _007B5941_007D, Func<byte, float> _007B5942_007D)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		for (int i = 0; i < _007B5945_007D.Length; i++)
		{
			Vector2 val2 = _007B5945_007D[i];
			((Vector2)(ref val2)).Normalize();
			val += (_007B5942_007D(bytes[PositionToIndex(_007B5941_007D + _007B5945_007D[i])]) + _007B5942_007D(bytes[PositionToIndex(_007B5941_007D + _007B5945_007D[i] * 2f)])) * val2;
		}
		return val / (2f * (float)_007B5945_007D.Length);
	}

	public bool Collision(Vector2 _007B5943_007D, Vector2 _007B5944_007D)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = _007B5933_007D(PositionToIndex2(in _007B5943_007D));
		Vector2 val2 = _007B5933_007D(PositionToIndex2(in _007B5944_007D));
		Vector2 val3 = (val - val2) / mapSize;
		float num = 1f + ((Vector2)(ref val3)).Length() * (float)gridSize;
		float num2 = 0f;
		while (true)
		{
			Vector2 _007B5930_007D = Vector2.Lerp(val, val2, num2);
			if (bytes[PositionToIndex(in _007B5930_007D)] > 0)
			{
				return true;
			}
			if (num2 == 1f)
			{
				break;
			}
			num2 = Math.Min(num2, 1f / num);
		}
		return false;
	}
}
