using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct ArenaShipStats : IMPSerializable
{
	public float SendDamage;

	public float SendDamageBuldings;

	public int Kills;

	public float ReceivedDamage;

	public float SendDamageAlly;

	public float SendDamageEquip;

	public int Death;

	public int CargoPoints;

	public int LootedCargoPoints;

	private void _007B6984_007D(WriterExtern _007B6985_007D)
	{
		_007B6985_007D.WriteStruct<float>(SendDamage);
		_007B6985_007D.WriteStruct<float>(SendDamageBuldings);
		_007B6985_007D.WriteStruct<int>(Kills);
		_007B6985_007D.WriteStruct<float>(ReceivedDamage);
		_007B6985_007D.WriteStruct<float>(SendDamageAlly);
		_007B6985_007D.WriteStruct<float>(SendDamageEquip);
		_007B6985_007D.WriteStruct<int>(Death);
		_007B6985_007D.WriteStruct<int>(CargoPoints);
		_007B6985_007D.WriteStruct<int>(LootedCargoPoints);
	}

	private void _007B6986_007D(WriterExtern _007B6987_007D)
	{
		_007B6987_007D.ReadStruct<float>(ref SendDamage);
		_007B6987_007D.ReadStruct<float>(ref SendDamageBuldings);
		_007B6987_007D.ReadStruct<int>(ref Kills);
		_007B6987_007D.ReadStruct<float>(ref ReceivedDamage);
		_007B6987_007D.ReadStruct<float>(ref SendDamageAlly);
		_007B6987_007D.ReadStruct<float>(ref SendDamageEquip);
		_007B6987_007D.ReadStruct<int>(ref Death);
		_007B6987_007D.ReadStruct<int>(ref CargoPoints);
		_007B6987_007D.ReadStruct<int>(ref LootedCargoPoints);
	}
}
