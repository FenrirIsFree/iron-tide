using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class GuildInvite : IMPSerializable
{
	public uint SID;

	public string CachedName;

	public string InviteMessage;

	public double TimeoutSec;

	public GuildInvite()
	{
	}

	public GuildInvite(uint _007B6512_007D, string _007B6513_007D, double _007B6514_007D, string _007B6515_007D)
	{
		SID = _007B6512_007D;
		CachedName = _007B6513_007D;
		TimeoutSec = _007B6514_007D;
		InviteMessage = _007B6515_007D;
	}

	private void _007B6516_007D(WriterExtern _007B6517_007D)
	{
		_007B6517_007D.WriteStruct<uint>(ref SID);
		_007B6517_007D.Write(CachedName, (Encoding)null);
		_007B6517_007D.WriteStruct<double>(ref TimeoutSec);
		_007B6517_007D.Write(InviteMessage, (Encoding)null);
	}

	private void _007B6518_007D(WriterExtern _007B6519_007D)
	{
		_007B6519_007D.ReadStruct<uint>(ref SID);
		_007B6519_007D.ReadString(ref CachedName, (Encoding)null);
		_007B6519_007D.ReadStruct<double>(ref TimeoutSec);
		_007B6519_007D.ReadString(ref InviteMessage, (Encoding)null);
	}
}
