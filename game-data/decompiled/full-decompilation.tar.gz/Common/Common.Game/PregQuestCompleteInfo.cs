using TheraEngine.Collections;

namespace Common.Game;

public class PregQuestCompleteInfo : Tlist<QuestStepHeader>
{
	public PregQuestCompleteInfo(QuestStepHeader _007B7246_007D)
	{
		Add(in _007B7246_007D);
	}

	public PregQuestCompleteInfo(params QuestStepHeader[] _007B7247_007D)
	{
		for (int i = 0; i < _007B7247_007D.Length; i++)
		{
			QuestStepHeader item = _007B7247_007D[i];
			Add(in item);
		}
	}
}
