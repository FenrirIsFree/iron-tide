using System;
using System.Linq;
using TheraEngine.Collections;

namespace Common.Game;

public static class FractionDecorator
{
	public static Tlist<FractionID> Nations = new Tlist<FractionID>((from _007B8645_007D in Enum.GetValues<FractionID>()
		where _007B8645_007D.IsNation()
		select _007B8645_007D).ToArray());

	public static Tlist<FractionID> AvailableFractions = new Tlist<FractionID>(Enum.GetValues<FractionID>().Except(new FractionID[2]
	{
		FractionID.Empire,
		FractionID.None
	}).ToArray());

	public static bool IsNation(this FractionID _007B8639_007D)
	{
		return _007B8639_007D == FractionID.Antilia || _007B8639_007D == FractionID.Espaniol || _007B8639_007D == FractionID.KaiAndSeveria;
	}

	public static bool CanCapturePorts(this FractionID _007B8640_007D)
	{
		return _007B8640_007D != FractionID.TradeUnion && _007B8640_007D != FractionID.None;
	}

	public static bool CanProtectPortsWithTrusted(this FractionID _007B8641_007D)
	{
		return true;
	}

	public static string GetName(this FractionID _007B8642_007D)
	{
		return _007B8642_007D switch
		{
			FractionID.Empire => Local.fraction_Empire, 
			FractionID.None => Local.fraction_None, 
			FractionID.KaiAndSeveria => Local.fraction_KaiAndSeveria, 
			FractionID.TradeUnion => Local.fraction_TradeUnion, 
			FractionID.Antilia => Local.fraction_Antilia, 
			FractionID.Espaniol => Local.fraction_Espaniol, 
			FractionID.Pirate => Local.fraction_Pirate, 
			_ => throw new NotSupportedException(), 
		};
	}

	public static string GetContactDescription(this FractionID _007B8643_007D)
	{
		return _007B8643_007D switch
		{
			FractionID.Empire => Local.fraction_Empire_Desc, 
			FractionID.None => Local.fraction_None_Desc, 
			FractionID.KaiAndSeveria => Local.fraction_KaiAndSeveria_Desc, 
			FractionID.TradeUnion => Local.fraction_TradeUnion_Desc, 
			FractionID.Antilia => Local.fraction_Antilia_Desc, 
			FractionID.Espaniol => Local.fraction_Espaniol_Desc, 
			FractionID.Pirate => Local.fraction_Pirate_Desc, 
			_ => throw new NotSupportedException(), 
		};
	}

	public static string GetShortDescription(this FractionID _007B8644_007D)
	{
		return _007B8644_007D switch
		{
			FractionID.Empire => Local.fraction_Empire_Desc, 
			FractionID.None => Local.fraction_None_Desc, 
			FractionID.KaiAndSeveria => Local.fraction_KaiAndSeveria_Desc_Short, 
			FractionID.TradeUnion => Local.fraction_TradeUnion_Desc_Short, 
			FractionID.Antilia => Local.fraction_Antilia_Desc_Short, 
			FractionID.Espaniol => Local.fraction_Espaniol_Desc_Short, 
			FractionID.Pirate => Local.fraction_Pirate_Desc_Short, 
			_ => throw new NotSupportedException(), 
		};
	}
}
