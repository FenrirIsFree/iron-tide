using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Resources;
using CommonDataTypes;
using TheraEngine;
using TheraEngine.Collections;

namespace Common.Game;

public static class ArenaRatingGameplay
{
	[CompilerGenerated]
	private sealed class _003CGetArenaRewards_003Ed__8 : IEnumerable<ArenaPlaceReward>, IEnumerable, IEnumerator<ArenaPlaceReward>, IEnumerator, IDisposable
	{
		private int _007B7035_007D;

		private ArenaPlaceReward _007B7036_007D;

		private int _007B7037_007D;

		private int _007B7038_007D;

		public int _003C_003E3__rating;

		private int _007B7039_007D;

		public int _003C_003E3__playersCount;

		private int _007B7040_007D;

		private int _007B7041_007D;

		private int _007B7042_007D;

		ArenaPlaceReward IEnumerator<ArenaPlaceReward>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B7036_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B7036_007D;
			}
		}

		[DebuggerHidden]
		public _003CGetArenaRewards_003Ed__8(int _007B7030_007D)
		{
			_007B7035_007D = _007B7030_007D;
			_007B7037_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B7031_007D()
		{
			_007B7035_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7031}
			this._007B7031_007D();
		}

		private bool _007B7032_007D()
		{
			switch (_007B7035_007D)
			{
			default:
				return false;
			case 0:
				_007B7035_007D = -1;
				_007B7040_007D = (int)MathF.Ceiling(40f * Math.Min(1f, (float)_007B7039_007D / 1000f));
				_007B7041_007D = (int)MathF.Ceiling(80f * Math.Min(1f, (float)_007B7039_007D / 1000f));
				_007B7042_007D = (int)MathF.Ceiling(160f * Math.Min(1f, (float)_007B7039_007D / 1000f));
				_007B7036_007D = new ArenaPlaceReward(0, _007B7040_007D - 1, GetGoldReward(_007B7038_007D), RatingRewardId.Gold);
				_007B7035_007D = 1;
				return true;
			case 1:
				_007B7035_007D = -1;
				_007B7036_007D = new ArenaPlaceReward(_007B7040_007D, _007B7040_007D + _007B7041_007D - 1, GetSilverReward(_007B7038_007D), RatingRewardId.Silver);
				_007B7035_007D = 2;
				return true;
			case 2:
				_007B7035_007D = -1;
				_007B7036_007D = new ArenaPlaceReward(_007B7040_007D + _007B7041_007D, _007B7040_007D + _007B7041_007D + _007B7042_007D - 1, GetBronzeReward(_007B7038_007D), RatingRewardId.Bronze);
				_007B7035_007D = 3;
				return true;
			case 3:
				_007B7035_007D = -1;
				return false;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7032}
			return this._007B7032_007D();
		}

		[DebuggerHidden]
		private void _007B7033_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7033}
			this._007B7033_007D();
		}

		[DebuggerHidden]
		IEnumerator<ArenaPlaceReward> IEnumerable<ArenaPlaceReward>.GetEnumerator()
		{
			_003CGetArenaRewards_003Ed__8 _003CGetArenaRewards_003Ed__;
			if (_007B7035_007D == -2 && _007B7037_007D == Environment.CurrentManagedThreadId)
			{
				_007B7035_007D = 0;
				_003CGetArenaRewards_003Ed__ = this;
			}
			else
			{
				_003CGetArenaRewards_003Ed__ = new _003CGetArenaRewards_003Ed__8(0);
			}
			_003CGetArenaRewards_003Ed__._007B7038_007D = _003C_003E3__rating;
			_003CGetArenaRewards_003Ed__._007B7039_007D = _003C_003E3__playersCount;
			return _003CGetArenaRewards_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B7034_007D()
		{
			return ((IEnumerable<ArenaPlaceReward>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7034}
			return this._007B7034_007D();
		}
	}

	public const int ATPointsInitial = 0;

	public const int GoldCount = 40;

	public const int SilverCount = 80;

	public const int BronzeCount = 160;

	private static readonly ComplexBonus goldRewardTemplate;

	private static readonly ComplexBonus silverRewardTemplate;

	private static readonly ComplexBonus bronzeRewardTemplate;

	static ArenaRatingGameplay()
	{
		goldRewardTemplate = new ComplexBonus
		{
			LegendaryFlagDays = 90,
			Items = new GSI().Exs(43, 100).Exs(37, 10000),
			DesignElements = ArenaRewardsHelper.Wrap(Gameplay.DesignsInfo.Where((ShipDesignInfo _007B7026_007D) => _007B7026_007D.Category == ShipDesignCategory.Satellite), 3),
			RandomDesign = true,
			AchievementsServer = new Tlist<AchievementEnum>().AddFirst(AchievementEnum.ArenaRatingGold)
		};
		silverRewardTemplate = new ComplexBonus
		{
			LegendaryFlagDays = 60,
			Items = new GSI().Exs(43, 70).Exs(37, 7000),
			DesignElements = ArenaRewardsHelper.Wrap(Gameplay.DesignsInfo.Where((ShipDesignInfo _007B7027_007D) => _007B7027_007D.Category == ShipDesignCategory.Satellite), 2),
			RandomDesign = true,
			AchievementsServer = new Tlist<AchievementEnum>().AddFirst(AchievementEnum.ArenaRatingSilver)
		};
		bronzeRewardTemplate = new ComplexBonus
		{
			LegendaryFlagDays = 30,
			Items = new GSI().Exs(43, 30).Exs(37, 3000),
			DesignElements = ArenaRewardsHelper.Wrap(Gameplay.DesignsInfo.Where((ShipDesignInfo _007B7028_007D) => _007B7028_007D.Category == ShipDesignCategory.Satellite), 1),
			RandomDesign = true,
			AchievementsServer = new Tlist<AchievementEnum>().AddFirst(AchievementEnum.ArenaRatingBronze)
		};
	}

	[IteratorStateMachine(typeof(_003CGetArenaRewards_003Ed__8))]
	public static IEnumerable<ArenaPlaceReward> GetArenaRewards(int _007B7019_007D, int _007B7020_007D)
	{
		//yield-return decompiler failed: Method not found
		return new _003CGetArenaRewards_003Ed__8(-2)
		{
			_003C_003E3__rating = _007B7019_007D,
			_003C_003E3__playersCount = _007B7020_007D
		};
	}

	public static ComplexBonus GetReward(RatingRewardId _007B7021_007D, int _007B7022_007D)
	{
		if (1 == 0)
		{
		}
		ComplexBonus result = _007B7021_007D switch
		{
			RatingRewardId.Gold => GetGoldReward(_007B7022_007D), 
			RatingRewardId.Silver => GetSilverReward(_007B7022_007D), 
			RatingRewardId.Bronze => GetBronzeReward(_007B7022_007D), 
			_ => throw new NotSupportedException(), 
		};
		if (1 == 0)
		{
		}
		return result;
	}

	public static ComplexBonus GetGoldReward(int _007B7023_007D)
	{
		ComplexBonus complexBonus = goldRewardTemplate.ShallowCopy();
		complexBonus.ArenaCurrency = new RTI(_007B7023_007D / 2);
		return complexBonus;
	}

	public static ComplexBonus GetSilverReward(int _007B7024_007D)
	{
		ComplexBonus complexBonus = silverRewardTemplate.ShallowCopy();
		complexBonus.ArenaCurrency = new RTI(_007B7024_007D / 2);
		return complexBonus;
	}

	public static ComplexBonus GetBronzeReward(int _007B7025_007D)
	{
		ComplexBonus complexBonus = bronzeRewardTemplate.ShallowCopy();
		complexBonus.ArenaCurrency = new RTI(_007B7025_007D / 2);
		return complexBonus;
	}
}
