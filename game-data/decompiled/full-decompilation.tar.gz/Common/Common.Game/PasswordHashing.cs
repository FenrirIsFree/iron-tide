using System;
using System.Security.Cryptography;
using System.Text;

namespace Common.Game;

public static class PasswordHashing
{
	public static string Hash(string _007B5267_007D)
	{
		if (string.IsNullOrEmpty(_007B5267_007D))
		{
			return string.Empty;
		}
		byte[] array = SHA256.HashData(Encoding.UTF8.GetBytes(_007B5267_007D));
		return BitConverter.ToString(array).Replace("-", "").ToLower();
	}
}
