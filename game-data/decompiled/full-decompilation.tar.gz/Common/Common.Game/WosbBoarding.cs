using System;
using Common.Resources;
using Microsoft.Xna.Framework;
using TheraEngine.Helpers;

namespace Common.Game;

public static class WosbBoarding
{
	public const bool AllCrewCanBeDestroyed = false;

	public const float PreparationTime = 4100f;

	public static float? Editor_DurationMs;

	public static float? Editor_UpdateIntervalMs;

	public static float? Editor_UnitInProtectionDamageIn;

	public static float? Editor_UnitInProtectionDamageOut;

	private const float durationMs = 30000f;

	private const float updateIntervalMs = 3000f;

	private const float unitInProtectionDamageIn = 0.2f;

	private const float unitInProtectionDamageOut = 0.2f;

	public const float DurationMin = 7000f;

	public const float TimeForActionBoardingMs = 14000f;

	public const float PreponderancetoWin = 1.5f;

	public static readonly bool BoardingTestingMode;

	public static float DurationMs => Editor_DurationMs ?? 30000f;

	public static float UpdateIntervalMs => Editor_UpdateIntervalMs ?? 3000f;

	public static float UnitInProtectionDamageIn => Editor_UnitInProtectionDamageIn ?? 0.2f;

	public static float UnitInProtectionDamageOut => Editor_UnitInProtectionDamageOut ?? 0.2f;

	public static BoardingAvailability CheckFor(Ship _007B3875_007D, Ship _007B3876_007D, bool _007B3877_007D, bool _007B3878_007D, bool _007B3879_007D)
	{
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		if (_007B3876_007D is Player)
		{
			if (_007B3877_007D)
			{
				return BoardingAvailability.DisallowGameRights;
			}
			if (_007B3878_007D && _007B3876_007D.IsStatic)
			{
				return BoardingAvailability.DisallowGameRights;
			}
		}
		if (_007B3876_007D is Npc npc)
		{
			if (npc.UsedShip.StaticInfo.ID == 1)
			{
				return BoardingAvailability.DisallowGameRights;
			}
			NpcType descritpion = npc.UsedShipNpc.Information.Descritpion;
		}
		if (_007B3879_007D && !CommonGlobal.IsServer)
		{
			Vector2 val = _007B3875_007D.Position - _007B3876_007D.Position;
			((Vector2)(ref val)).Normalize();
			float value = Vector2.Dot(_007B3875_007D.FastNormal, _007B3876_007D.FastNormal);
			if (Math.Abs(Vector2.Dot(_007B3875_007D.FastNormal, val)) > 0.8f || Math.Abs(Vector2.Dot(_007B3876_007D.FastNormal, val)) > 0.8f || Math.Abs(value) < 0.8f)
			{
				return BoardingAvailability.DisallowGameRights;
			}
		}
		float num = Vector2.Distance(_007B3875_007D.Position, _007B3876_007D.Position);
		if (_007B3879_007D && num > _007B3875_007D.UsedShip.BoardingFailureDisatnce(_007B3875_007D, _007B3876_007D, _007B3878_007D))
		{
			return BoardingAvailability.DisallowGameRights;
		}
		if (_007B3875_007D.IsStatic || _007B3876_007D.IsStatic || _007B3875_007D.UsedShip.firstHP.FloodingFactor > 0f || _007B3876_007D.UsedShip.firstHP.FloodingFactor > 0f || _007B3875_007D.UsedShip.firstHP.burningDuration != 0f || _007B3876_007D.UsedShip.firstHP.burningDuration != 0f)
		{
			return BoardingAvailability.DisallowGameRights;
		}
		if (_007B3876_007D.UsedShip.firstHP.Summary > _007B3876_007D.UsedShip.MaxHp / 2f && _007B3878_007D && !BoardingTestingMode)
		{
			return BoardingAvailability.DisallowHp;
		}
		return BoardingAvailability.Allow;
	}

	public static int XpBonus(Ship _007B3880_007D)
	{
		return (int)(_007B3880_007D.UsedShip.MaxHp / 10f);
	}

	public static float PlayerStealCannonBoardingChanse(Player _007B3881_007D)
	{
		if (_007B3881_007D.AccountConnection.Rang < 15)
		{
			return 0f;
		}
		return MathHelper.Lerp(25f, 10f, Geometry.Saturate((float)(_007B3881_007D.UsedShipPlayer.CraftFrom.Rank - 1) / 6f));
	}
}
