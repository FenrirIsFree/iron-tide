using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Account;

namespace Common.Game;

public class DayInfo(int _007B6095_007D)
{
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly int _007B6099_007D = _007B6095_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly bool _007B6100_007D = false;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly Action<PlayerAccount, CalendarEventInfo>? _007B6101_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly QuestStepHeader[] _007B6102_007D = Array.Empty<QuestStepHeader>();

	public int DayNumber
	{
		[CompilerGenerated]
		get
		{
			return _007B6095_007D;
		}
	}

	public bool AlwaysVisible
	{
		[CompilerGenerated]
		get
		{
			return _007B6100_007D;
		}
		[CompilerGenerated]
		init
		{
			_007B6100_007D = value;
		}
	}

	public Action<PlayerAccount, CalendarEventInfo>? OnDayRewardApply
	{
		[CompilerGenerated]
		get
		{
			return _007B6101_007D;
		}
		[CompilerGenerated]
		init
		{
			_007B6101_007D = value;
		}
	}

	public QuestStepHeader[] Quest
	{
		[CompilerGenerated]
		get
		{
			return _007B6102_007D;
		}
		[CompilerGenerated]
		init
		{
			_007B6102_007D = value;
		}
	}
}
