using System;

namespace Common.Game;

public class QuestCollectItemsByKilling : QuestStepHeader
{
	public GSI Required;

	public override int ProgressComparand => Required.GetTotalItemsCount();

	public QuestCollectItemsByKilling(string _007B7579_007D, GSI _007B7580_007D, TargetShipForQuest? _007B7581_007D)
		: base(_007B7579_007D, _007B7581_007D)
	{
		if (_007B7580_007D.NamesCount > 1 || _007B7580_007D.IsEmpty)
		{
			throw new ArgumentException("required has wrong amount of items");
		}
		Required = _007B7580_007D;
	}
}
