namespace Common.Game;

public enum DamageID
{
	Other,
	Burning,
	CannonBall,
	Collision,
	PowderKeg,
	MortarShot,
	FireArea,
	FalkonetBall
}
