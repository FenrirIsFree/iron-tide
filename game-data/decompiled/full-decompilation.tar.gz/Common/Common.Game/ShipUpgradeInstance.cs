using System;
using Common.Resources;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct ShipUpgradeInstance : IMPSerializable
{
	public byte ID;

	public float Strength;

	public bool IsNull => ID == 0;

	public ShipUpgradeInfo Info => (ID == 0) ? null : Gameplay.ShipUpgradesInfo.FromID(ID);

	public ShipUpgradeInstance(byte _007B4754_007D, float _007B4755_007D)
	{
		ID = _007B4754_007D;
		Strength = _007B4755_007D;
	}

	public ShipUpgradeInstance(ShipUpgradeInfo _007B4756_007D)
		: this((byte)_007B4756_007D.ID, _007B4756_007D.WearAmount.Value)
	{
	}

	private void _007B4757_007D(WriterExtern _007B4758_007D)
	{
		_007B4758_007D.WriteByte(ID);
		if (ID != 0)
		{
			_007B4758_007D.WriteStruct<float>(Strength);
			_007B4758_007D.WriteByte((byte)1);
		}
	}

	private void _007B4759_007D(WriterExtern _007B4760_007D)
	{
		ID = _007B4760_007D.ReadByte();
		if (ID != 0)
		{
			_007B4760_007D.ReadStruct<float>(ref Strength);
			Strength = Math.Min(Strength, Gameplay.ShipUpgradesInfo.FromID(ID).WearAmount.Value);
			byte b = _007B4760_007D.ReadByte();
			if (_007B4760_007D.PeekByte() == 253)
			{
				_007B4760_007D.ReadByte();
				ushort num = default(ushort);
				_007B4760_007D.ReadStruct<ushort>(ref num);
			}
			else if (b == 0)
			{
				ushort num2 = default(ushort);
				_007B4760_007D.ReadStruct<ushort>(ref num2);
			}
		}
	}

	public override bool Equals(object _007B4761_007D)
	{
		return _007B4761_007D is ShipUpgradeInstance shipUpgradeInstance && shipUpgradeInstance.ID == ID;
	}

	public override int GetHashCode()
	{
		return ID;
	}
}
