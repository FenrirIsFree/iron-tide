using System;
using System.Collections;
using System.Collections.Generic;

namespace Common.Game;

public struct GSILocalEnumerable<TFinish> : IEnumerable<GSILocalEnumerablePair<TFinish>>, IEnumerable, IDisposable
{
	private struct LocalEnumenator : IEnumerator<GSILocalEnumerablePair<TFinish>>, IEnumerator, IDisposable
	{
		private GSI source;

		private int currentIndex;

		private Func<int, TFinish> factory;

		public GSILocalEnumerablePair<TFinish> Current => new GSILocalEnumerablePair<TFinish>(factory(source.items.Array[currentIndex].ID), source.items.Array[currentIndex].Count);

		object IEnumerator.Current => Current;

		public LocalEnumenator(GSI _007B5434_007D, Func<int, TFinish> _007B5435_007D)
		{
			currentIndex = -1;
			source = _007B5434_007D;
			factory = _007B5435_007D;
		}

		public void Dispose()
		{
			source = null;
			factory = null;
		}

		public bool MoveNext()
		{
			currentIndex++;
			return currentIndex < source.items.Size;
		}

		public void Reset()
		{
			currentIndex = 0;
		}
	}

	private GSI source;

	private Func<int, TFinish> factory;

	public GSILocalEnumerable(GSI _007B5430_007D, Func<int, TFinish> _007B5431_007D)
	{
		_007B5430_007D.CheckProtection();
		source = _007B5430_007D;
		factory = _007B5431_007D;
	}

	public void Dispose()
	{
		source = null;
		factory = null;
	}

	IEnumerator<GSILocalEnumerablePair<TFinish>> IEnumerable<GSILocalEnumerablePair<TFinish>>.GetEnumerator()
	{
		return new LocalEnumenator(source, factory);
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return new LocalEnumenator(source, factory);
	}
}
