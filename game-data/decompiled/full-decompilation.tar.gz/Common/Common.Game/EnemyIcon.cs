namespace Common.Game;

public enum EnemyIcon
{
	ShipPlayer,
	QuestNpc,
	QuestPoint,
	ArenaEnemyLoot
}
