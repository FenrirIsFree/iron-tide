namespace Common.Game;

internal struct ShipOperatingParameters
{
	public Idea_Ship Ship;

	public float CurrentMaxSpeed;

	public float CurrentMobility;
}
