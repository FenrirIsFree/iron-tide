namespace Common.Game;

public enum OceanStateEnum
{
	Calm,
	Restless,
	Storm,
	DangedStorm
}
