using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Text;
using Common.Account;
using Common.Data;
using CommonDataTypes;
using TheraEngine;

namespace Common.Game;

public readonly struct TraderOffer
{
	public readonly struct Resource : IEquatable<Resource>
	{
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private readonly RTI _007B6901_007D;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private readonly RTI _007B6902_007D;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private readonly StorageAssetEnum _007B6903_007D;

		public RTI Id
		{
			[CompilerGenerated]
			get
			{
				return _007B6901_007D;
			}
			[CompilerGenerated]
			init
			{
				_007B6901_007D = value;
			}
		}

		public RTI Count
		{
			[CompilerGenerated]
			get
			{
				return _007B6902_007D;
			}
			[CompilerGenerated]
			init
			{
				_007B6902_007D = value;
			}
		}

		public StorageAssetEnum Type
		{
			[CompilerGenerated]
			get
			{
				return _007B6903_007D;
			}
			[CompilerGenerated]
			init
			{
				_007B6903_007D = value;
			}
		}

		public Resource(RTI _007B6884_007D, RTI _007B6885_007D, StorageAssetEnum _007B6886_007D = StorageAssetEnum.SimpleItem)
		{
			_007B6901_007D = _007B6884_007D;
			_007B6902_007D = _007B6885_007D;
			_007B6903_007D = _007B6886_007D;
		}

		[CompilerGenerated]
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("Resource");
			stringBuilder.Append(" { ");
			if (_007B6890_007D(stringBuilder))
			{
				stringBuilder.Append(' ');
			}
			stringBuilder.Append('}');
			return stringBuilder.ToString();
		}

		[CompilerGenerated]
		private bool _007B6890_007D(StringBuilder _007B6891_007D)
		{
			_007B6891_007D.Append("Id = ");
			_007B6891_007D.Append(Id.ToString());
			_007B6891_007D.Append(", Count = ");
			_007B6891_007D.Append(Count.ToString());
			_007B6891_007D.Append(", Type = ");
			_007B6891_007D.Append(Type.ToString());
			return true;
		}

		[CompilerGenerated]
		public static bool operator !=(Resource _007B6892_007D, Resource _007B6893_007D)
		{
			return !(_007B6892_007D == _007B6893_007D);
		}

		[CompilerGenerated]
		public static bool operator ==(Resource _007B6894_007D, Resource _007B6895_007D)
		{
			return _007B6894_007D.Equals(_007B6895_007D);
		}

		[CompilerGenerated]
		public override int GetHashCode()
		{
			return (EqualityComparer<RTI>.Default.GetHashCode(_007B6901_007D) * -1521134295 + EqualityComparer<RTI>.Default.GetHashCode(_007B6902_007D)) * -1521134295 + EqualityComparer<StorageAssetEnum>.Default.GetHashCode(_007B6903_007D);
		}

		[CompilerGenerated]
		public override bool Equals(object _007B6896_007D)
		{
			return _007B6896_007D is Resource && Equals((Resource)_007B6896_007D);
		}

		[CompilerGenerated]
		public bool Equals(Resource _007B6897_007D)
		{
			return EqualityComparer<RTI>.Default.Equals(_007B6901_007D, _007B6897_007D._007B6901_007D) && EqualityComparer<RTI>.Default.Equals(_007B6902_007D, _007B6897_007D._007B6902_007D) && EqualityComparer<StorageAssetEnum>.Default.Equals(_007B6903_007D, _007B6897_007D._007B6903_007D);
		}

		[CompilerGenerated]
		public void Deconstruct(out RTI _007B6898_007D, out RTI _007B6899_007D, out StorageAssetEnum _007B6900_007D)
		{
			_007B6898_007D = Id;
			_007B6899_007D = Count;
			_007B6900_007D = Type;
		}
	}

	public enum Action
	{
		None,
		SkipQuest
	}

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly RTI _007B6868_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly Resource? _007B6869_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly RTI _007B6870_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly RTI _007B6871_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly int _007B6872_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly int _007B6873_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly bool _007B6874_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly bool _007B6875_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly int _007B6876_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly RTI _007B6877_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly RTI _007B6878_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly short _007B6879_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly int _007B6880_007D;

	public RTI Price
	{
		[CompilerGenerated]
		get
		{
			return _007B6868_007D;
		}
	}

	public Resource? Res
	{
		[CompilerGenerated]
		get
		{
			return _007B6869_007D;
		}
	}

	public RTI Gold
	{
		[CompilerGenerated]
		get
		{
			return _007B6870_007D;
		}
	}

	public RTI Monets
	{
		[CompilerGenerated]
		get
		{
			return _007B6871_007D;
		}
	}

	public int DesignId
	{
		[CompilerGenerated]
		get
		{
			return _007B6872_007D;
		}
	}

	public int CannonId
	{
		[CompilerGenerated]
		get
		{
			return _007B6873_007D;
		}
	}

	public bool PriceInMonets
	{
		[CompilerGenerated]
		get
		{
			return _007B6874_007D;
		}
	}

	public bool PaidSkipQuest
	{
		[CompilerGenerated]
		get
		{
			return _007B6875_007D;
		}
	}

	public int PremiumDays
	{
		[CompilerGenerated]
		get
		{
			return _007B6876_007D;
		}
	}

	public RTI AllShipsXp
	{
		[CompilerGenerated]
		get
		{
			return _007B6877_007D;
		}
	}

	public RTI LegendaryFlagDays
	{
		[CompilerGenerated]
		get
		{
			return _007B6878_007D;
		}
	}

	public short BuyCooldownID
	{
		[CompilerGenerated]
		get
		{
			return _007B6879_007D;
		}
	}

	public int BuyCooldownDays
	{
		[CompilerGenerated]
		get
		{
			return _007B6880_007D;
		}
	}

	public TraderOffer(int _007B6851_007D, Resource? _007B6852_007D = null, int _007B6853_007D = 0, int _007B6854_007D = 0, int _007B6855_007D = -1, int _007B6856_007D = -1, bool _007B6857_007D = false, bool _007B6858_007D = false, int _007B6859_007D = 0, int _007B6860_007D = 0, int _007B6861_007D = 0, int _007B6862_007D = 0)
	{
		_007B6868_007D = _007B6851_007D;
		_007B6869_007D = _007B6852_007D;
		_007B6870_007D = _007B6853_007D;
		_007B6871_007D = _007B6854_007D;
		_007B6872_007D = _007B6855_007D;
		_007B6873_007D = _007B6856_007D;
		_007B6875_007D = _007B6857_007D;
		_007B6874_007D = _007B6858_007D;
		_007B6880_007D = _007B6862_007D;
		_007B6879_007D = (short)(_007B6851_007D + _007B6862_007D);
		_007B6876_007D = _007B6859_007D;
		_007B6877_007D = _007B6860_007D;
		_007B6878_007D = _007B6861_007D;
	}

	public string GetName(int _007B6863_007D = 1)
	{
		if (Res.HasValue && Res.Value.Type == StorageAssetEnum.Powerup_DisplayOnly)
		{
			return $"{Gameplay.PowerupItems[Res.Value.Id.Value].Name} x{Res.Value.Count.Value * _007B6863_007D}";
		}
		if (Res.HasValue)
		{
			IStorageAsset resource = Gameplay.GetResource(Res.Value.Id.Value, Res.Value.Type);
			return $"{resource.getName} x{Res.Value.Count.Value * _007B6863_007D}";
		}
		if (Gold.Value != 0)
		{
			return Gold.Value * _007B6863_007D + " " + Local.gold2;
		}
		if (Monets.Value != 0)
		{
			return Monets.Value * _007B6863_007D + " " + Local.monets;
		}
		if (DesignId != -1)
		{
			return (Gameplay.DesignsInfo[DesignId].Category == ShipDesignCategory.ShipFullDesign) ? (Local.trade_offer_full_design + " " + Gameplay.DesignsInfo[DesignId].Name) : Gameplay.DesignsInfo[DesignId].Name;
		}
		if (CannonId != -1)
		{
			return Gameplay.CannonsGameInfo[CannonId].Name;
		}
		if (PaidSkipQuest)
		{
			return Local.paid_skip_quest;
		}
		if (PremiumDays > 0)
		{
			return $"{PremiumDays * _007B6863_007D} {Local.premium_days}";
		}
		if (AllShipsXp.Value > 0)
		{
			return $"{Local.ships_xp} +{AllShipsXp.Value}";
		}
		if (LegendaryFlagDays.Value > 0)
		{
			return $"{Local.StringConstants_27} +{LegendaryFlagDays.Value * _007B6863_007D} {Local.days}";
		}
		return "unknown";
	}

	public (string name, int count, int premiumDays, int legendaryFlagDays) Apply(PlayerAccount _007B6864_007D, bool _007B6865_007D, int _007B6866_007D, int? _007B6867_007D)
	{
		if (BuyCooldownDays != 0)
		{
			_007B6864_007D.ArenaShopCooldowns.Add(new TraderOfferCooldown(BuyCooldownID, BuyCooldownDays * 86400));
		}
		if (_007B6865_007D)
		{
			if (Price.Value * _007B6866_007D > _007B6864_007D.ArenaCurrency.Value)
			{
				return default((string, int, int, int));
			}
			_007B6864_007D.ArenaCurrency.Value -= Price.Value * _007B6866_007D;
		}
		else
		{
			if (!_007B6867_007D.HasValue)
			{
				throw new ArgumentNullException();
			}
			GSI _007B5455_007D = new GSI().Exs(_007B6867_007D.Value, Price.Value * _007B6866_007D);
			if (!_007B6864_007D.NearPortStorage.TryRemove(_007B5455_007D) && !_007B6864_007D.TreasuryMaps.TryRemove(_007B5455_007D))
			{
				return default((string, int, int, int));
			}
		}
		string item = "";
		int num = 0;
		if (Res.HasValue)
		{
			if (Res.Value.Type == StorageAssetEnum.Powerup_DisplayOnly)
			{
				item = Gameplay.PowerupItems[Res.Value.Id.Value].Name;
				num = Res.Value.Count.Value * _007B6866_007D;
				_007B6864_007D.PowerupItemsAtStorage[Res.Value.Id.Value] += num;
			}
			else
			{
				item = Gameplay.GetResource(Res.Value.Id.Value, Res.Value.Type).getName;
				num = Res.Value.Count.Value * _007B6866_007D;
				if (Res.Value.Type == StorageAssetEnum.SimpleItem)
				{
					_007B6864_007D.NearPortStorage.AddOrRemove(Res.Value.Id.Value, num);
				}
				else if (Res.Value.Type == StorageAssetEnum.Ammo)
				{
					_007B6864_007D.CBallsAtStorage.AddOrRemove(Res.Value.Id.Value, num);
				}
			}
		}
		else if (Gold.Value != 0)
		{
			item = Local.gold2;
			num = Gold.Value * _007B6866_007D;
			_007B6864_007D.Gold += num;
		}
		else if (Monets.Value != 0)
		{
			item = Local.monets;
			num = Monets.Value * _007B6866_007D;
			_007B6864_007D.Monets.Value += num;
		}
		else if (CannonId != -1)
		{
			item = Gameplay.CannonsGameInfo[CannonId].Name;
			num = _007B6866_007D;
			_007B6864_007D.CannonsAtStorage.AddOrRemove(CannonId, num);
		}
		else if (DesignId != -1)
		{
			item = Gameplay.DesignsInfo[DesignId].Name;
			num = _007B6866_007D;
			_007B6864_007D.DesingElementsAtStorage.AddOrRemove(DesignId, num);
		}
		else if (PremiumDays > 0)
		{
			item = Local.premium;
			num = PremiumDays;
		}
		else if (AllShipsXp.Value > 0)
		{
			item = Local.ships_xp;
			num = AllShipsXp.Value * _007B6866_007D;
			_007B6864_007D.Shipyard.AddXpAllShips(num, _007B2062_007D: true);
		}
		else if (LegendaryFlagDays.Value > 0)
		{
			item = GetName();
			num = 1;
			_007B6864_007D.LegendaryFlagDaysLeft += (ushort)LegendaryFlagDays.Value;
		}
		WosbTreasuryMaps.DetachMaps(_007B6864_007D);
		return (name: item, count: num, premiumDays: PremiumDays, legendaryFlagDays: LegendaryFlagDays.Value);
	}
}
