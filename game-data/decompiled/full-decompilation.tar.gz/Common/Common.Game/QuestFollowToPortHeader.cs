using Common.Resources;

namespace Common.Game;

public class QuestFollowToPortHeader : QuestStepHeader
{
	public readonly IslePortInfo? DeliverTo;

	public bool ToMyHomePort;

	public override int ProgressComparand => -1;

	public QuestFollowToPortHeader(string _007B7613_007D, IslePortInfo? _007B7614_007D, bool _007B7615_007D)
		: base(_007B7613_007D)
	{
		DeliverTo = _007B7614_007D;
		ToMyHomePort = _007B7615_007D;
	}
}
