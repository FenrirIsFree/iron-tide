using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using Common.Resources;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Assets.Sea;
using TheraEngine.Collections;
using TheraEngine.Components.Architecture;
using TheraEngine.Helpers;

namespace Common.Game;

public class WeatherEngine : IUpdateableObject
{
	public const float windChangeToNextTimeSec = 20f;

	public const float weatherChangeToNextTimeSec = 60f;

	public const float StormAreaExternalRadius = 5092.734f;

	public const float StormAreaInternalRadius = 2263.4373f;

	public const float timeForWalkCrossWorldSec = 1400f;

	private const float minDeepnessHeightMul = 0.6f;

	private const float maxDeepnessHeightMul = 2.0615f;

	private const float c_fixedSpeed = 2.352f;

	public static readonly Dictionary<OceanStateEnum, (float wavesHeight, float wavesSpeed)> SeaStates = new Dictionary<OceanStateEnum, (float, float)>
	{
		[OceanStateEnum.Calm] = (0.3f, 2.184f),
		[OceanStateEnum.Restless] = (0.7f, 2.352f),
		[OceanStateEnum.Storm] = (1.1f, 2.352f),
		[OceanStateEnum.DangedStorm] = (3.5f, 2.352f)
	};

	public static readonly Dictionary<OceanStateEnum, float> WindPower = new Dictionary<OceanStateEnum, float>
	{
		[OceanStateEnum.Calm] = 0.15f,
		[OceanStateEnum.Restless] = 0.4f,
		[OceanStateEnum.Storm] = 0.7f,
		[OceanStateEnum.DangedStorm] = 1f
	};

	public static readonly Dictionary<WaterStateEnum, (float cloudyLevel, float fogLevel)> SkydomeStates = new Dictionary<WaterStateEnum, (float, float)>
	{
		[WaterStateEnum.Sunny] = (0f, 0f),
		[WaterStateEnum.Cloudy] = (0.3f, 0.1f),
		[WaterStateEnum.Rain] = (0.7f, 0.4f),
		[WaterStateEnum.HeavyRain] = (1f, 0.6f)
	};

	public static readonly float MaxWaveHeightDangerStorm = SeaStates[OceanStateEnum.DangedStorm].wavesHeight;

	private static readonly (float, float) sunnySkydomeState = SkydomeStates[WaterStateEnum.Sunny];

	private static readonly (float, float) stormSkydomeState = SkydomeStates[WaterStateEnum.HeavyRain];

	private WeatherEngineState _007B5874_007D;

	private OceanWaveManager _007B5875_007D;

	private Vector3 _007B5876_007D;

	private Vector2 _007B5877_007D;

	private float _007B5878_007D;

	private float _007B5879_007D;

	private float _007B5880_007D;

	private float _007B5881_007D;

	private float _007B5882_007D;

	private bool _007B5883_007D;

	private bool _007B5884_007D;

	private Vector2? _007B5885_007D;

	private float _007B5886_007D;

	private float _007B5887_007D;

	private WeatherArea[] _007B5888_007D;

	private bool _007B5889_007D;

	public float EducationMapStormLimit = 800f;

	public float ClientWindPowerEffect => _007B5887_007D;

	public Vector2 WavesPoisiton => _007B5874_007D.wavePoisition;

	public Vector3 WindDirection => _007B5876_007D;

	public Vector2 WindXZNormal => _007B5877_007D;

	public float UniqueSimulationTime => _007B5874_007D.wavePoisition.X / 1.2936001f;

	public Tlist<WeatherArea> StormAreas => _007B5874_007D.stormAreas;

	public string DebugString => "from " + _007B5874_007D.commonOceanInitState.ToString() + " to " + _007B5874_007D.commonOceanNextState.ToString() + " lerp " + _007B5874_007D.commonOceanAndSkyStateLerp;

	public float RainingLevelClient => _007B5880_007D;

	public float FogLevelClientOfExtra => _007B5882_007D;

	public float FogLevelClient => _007B5881_007D;

	public float WavesHeightClient => _007B5879_007D;

	private static (float, float) lerp2d((float, float) _007B5825_007D, (float, float) _007B5826_007D, float _007B5827_007D)
	{
		return (MathHelper.Lerp(_007B5825_007D.Item1, _007B5826_007D.Item1, _007B5827_007D), MathHelper.Lerp(_007B5825_007D.Item2, _007B5826_007D.Item2, _007B5827_007D));
	}

	public WeatherEngine(bool _007B5828_007D, bool _007B5829_007D)
	{
		_007B5883_007D = _007B5828_007D;
		_007B5884_007D = _007B5829_007D;
		_007B5875_007D = new OceanWaveManager();
		_007B5874_007D = default(WeatherEngineState);
		_007B5874_007D.stormAreas = new Tlist<WeatherArea>(8);
		_007B5888_007D = new WeatherArea[0];
	}

	public void SetFullInitialState(Vector3 _007B5830_007D, OceanStateEnum _007B5831_007D, WaterStateEnum _007B5832_007D)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		if (_007B5883_007D)
		{
			_007B5874_007D.stormAreas.Clear();
			_007B5888_007D = new WeatherArea[0];
		}
		ServerChangeWeather(_007B5831_007D, _007B5832_007D);
		ServerChangeWeather(_007B5831_007D, _007B5832_007D);
		ServerRewind(_007B5830_007D);
		ServerRewind(_007B5830_007D);
		_007B5889_007D = false;
	}

	public void EvaluteCustomState(OceanStateEnum _007B5833_007D, WaterStateEnum _007B5834_007D)
	{
		ServerChangeWeather(_007B5833_007D, _007B5834_007D);
	}

	public void CreateCustomStormApproachingCenter()
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		_007B5874_007D.stormAreas.Clear();
		_007B5888_007D = new WeatherArea[0];
		float _007B5903_007D = 1584.406f;
		float _007B5904_007D = 3564.9136f;
		Vector2 _007B5901_007D = default(Vector2);
		((Vector2)(ref _007B5901_007D))._002Ector(4992.734f, 0f);
		_007B5874_007D.stormAreas.Add(new WeatherArea(_007B5901_007D, new Vector2(-1f, 0f), _007B5903_007D, _007B5904_007D, WeatherAreaType.Storm));
		_007B5888_007D = _007B5874_007D.stormAreas.ToArray();
		_007B5874_007D.serializationBits.Value = 0;
		_007B5874_007D.serializationBits[2] = true;
		_007B5889_007D = true;
	}

	public void Update(ref FrameTime _007B5835_007D)
	{
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		_007B5874_007D.windDirectionLerp = Math.Min(1f, _007B5874_007D.windDirectionLerp + _007B5835_007D.secElapsed / 20f);
		_007B5874_007D.commonOceanAndSkyStateLerp = Math.Min(1f, _007B5874_007D.commonOceanAndSkyStateLerp + _007B5835_007D.secElapsed / 60f);
		if (_007B5883_007D)
		{
			for (int i = 0; i < _007B5874_007D.stormAreas.Size; i++)
			{
				WeatherArea obj = _007B5874_007D.stormAreas.Array[i];
				obj.CurrentPosition += _007B5874_007D.stormAreas.Array[i].VelocityDirection * 14146.483f * _007B5835_007D.secElapsed / 1400f * ((_007B5874_007D.stormAreas.Array[i].Type == WeatherAreaType.Fog) ? 0.5f : 1f) * (float)((!_007B5889_007D) ? 1 : 3);
				if (Math.Abs(_007B5874_007D.stormAreas.Array[i].CurrentPosition.X) - 7073.2417f > _007B5874_007D.stormAreas.Array[i].WExternalRadius || Math.Abs(_007B5874_007D.stormAreas.Array[i].CurrentPosition.Y) - 8645.06f > _007B5874_007D.stormAreas.Array[i].WExternalRadius)
				{
					_007B5874_007D.stormAreas.FastRemoveAt(i);
					i--;
				}
				if (_007B5889_007D)
				{
					_007B5874_007D.stormAreas.Array[i].CurrentPosition.X = Math.Max(EducationMapStormLimit, _007B5874_007D.stormAreas.Array[i].CurrentPosition.X);
				}
			}
			_007B5836_007D(2.352f, ref _007B5835_007D);
		}
		else
		{
			_007B5836_007D(_007B5878_007D, ref _007B5835_007D);
		}
		_007B5846_007D();
	}

	private void _007B5836_007D(float _007B5837_007D, ref FrameTime _007B5838_007D)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		if (_007B5885_007D.HasValue)
		{
			Vector2 value = _007B5885_007D.Value;
			if (Vector2.DistanceSquared(_007B5874_007D.wavePoisition, value) < 0.1f)
			{
				_007B5885_007D = null;
			}
			else
			{
				value.X += _007B5837_007D * _007B5838_007D.secElapsed * 0.55f;
				value.Y += _007B5837_007D * _007B5838_007D.secElapsed * 0.3f;
				Geometry.Evalute(ref _007B5874_007D.wavePoisition.X, value.X, 4f * _007B5838_007D.secElapsed);
				Geometry.Evalute(ref _007B5874_007D.wavePoisition.Y, value.Y, 4f * _007B5838_007D.secElapsed);
				_007B5885_007D = value;
			}
		}
		_007B5874_007D.wavePoisition.X += _007B5837_007D * _007B5838_007D.secElapsed * 0.55f;
		_007B5874_007D.wavePoisition.Y += _007B5837_007D * _007B5838_007D.secElapsed * 0.3f;
		if (_007B5874_007D.wavePoisition.X > 10000f)
		{
			_007B5874_007D.wavePoisition.X = -10000f;
		}
		if (_007B5874_007D.wavePoisition.Y > 10000f)
		{
			_007B5874_007D.wavePoisition.Y = -10000f;
		}
	}

	public void ClientSetState(WeatherEngineState _007B5839_007D)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		_007B5839_007D.PartialMerge(ref _007B5874_007D);
		CorrectWavesPosition(_007B5839_007D.wavePoisition);
		_007B5846_007D();
	}

	public void CorrectWavesPosition(Vector2 _007B5840_007D)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		float num = Vector2.Distance(_007B5840_007D, _007B5874_007D.wavePoisition);
		if (num < 4f)
		{
			_007B5885_007D = _007B5840_007D;
			return;
		}
		_007B5885_007D = null;
		_007B5874_007D.wavePoisition = _007B5840_007D;
	}

	public void ClientSetInitialState(WeatherEngineState _007B5841_007D)
	{
		_007B5874_007D = _007B5841_007D;
		_007B5846_007D();
	}

	public WeatherEngineState ServerRewind(Vector3 _007B5842_007D)
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		if (_007B5884_007D)
		{
			_007B5842_007D = ExtensionMethods.Normal(new Vector3(1f, 0f, 1f));
		}
		_007B5874_007D.initWindDirection = _007B5874_007D.nextWindDirection;
		_007B5874_007D.nextWindDirection = _007B5842_007D;
		_007B5874_007D.windDirectionLerp = 0f;
		_007B5846_007D();
		_007B5874_007D.serializationBits.Value = 0;
		_007B5874_007D.serializationBits[0] = true;
		return _007B5874_007D;
	}

	public WeatherEngineState ServerChangeWeather(OceanStateEnum _007B5843_007D, WaterStateEnum _007B5844_007D)
	{
		_007B5874_007D.commonOceanInitState = _007B5874_007D.commonOceanNextState;
		_007B5874_007D.commonSkydomeInitState = _007B5874_007D.commonSkydomeNextState;
		_007B5874_007D.commonOceanNextState = _007B5843_007D;
		_007B5874_007D.commonSkydomeNextState = _007B5844_007D;
		_007B5874_007D.commonOceanAndSkyStateLerp = 0f;
		_007B5846_007D();
		_007B5874_007D.serializationBits.Value = 0;
		_007B5874_007D.serializationBits[1] = true;
		return _007B5874_007D;
	}

	public WeatherEngineState? ServerTryCreateArea(WeatherAreaType _007B5845_007D)
	{
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		if (_007B5874_007D.stormAreas.Count((WeatherArea _007B5890_007D) => _007B5890_007D.Type == _007B5845_007D) >= ((_007B5845_007D == WeatherAreaType.Storm) ? 1 : 2))
		{
			return null;
		}
		float num = Rand.Range(0.7f, 1.1f);
		float num2 = Rand.Range(-0.4f, 0.4f);
		float num3 = 2263.4373f * num;
		float num4 = 5092.734f * num;
		if (_007B5845_007D == WeatherAreaType.Fog)
		{
			num3 *= 0.4f;
			num4 *= 0.4f;
		}
		Vector2 val = Gameplay.WorldMapSizeXY * 0.5f + new Vector2(num4 - 10f);
		Vector2 val2 = -Geometry.RotateVector2(_007B5877_007D, num2) * val;
		val2.X = (float)Math.Sign(val2.X) * Math.Min(Math.Abs(val2.X), val.X);
		val2.Y = (float)Math.Sign(val2.Y) * Math.Min(Math.Abs(val2.Y), val.Y);
		foreach (WeatherArea item in (IEnumerable<WeatherArea>)_007B5874_007D.stormAreas)
		{
			if (Vector2.Distance(item.CurrentPosition, val2) < item.WExternalRadius + num4 + 1000f)
			{
				return null;
			}
		}
		_007B5874_007D.stormAreas.Add(new WeatherArea(val2, _007B5877_007D, num3, num4, _007B5845_007D));
		_007B5888_007D = _007B5874_007D.stormAreas.ToArray();
		_007B5874_007D.serializationBits.Value = 0;
		_007B5874_007D.serializationBits[2] = true;
		return _007B5874_007D;
	}

	public WeatherEngineState ServerGetFullState()
	{
		_007B5874_007D.serializationBits.Value = byte.MaxValue;
		return _007B5874_007D;
	}

	private void _007B5846_007D()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		_007B5888_007D = _007B5874_007D.stormAreas.ToArray();
		_007B5876_007D = Vector3.Lerp(_007B5874_007D.initWindDirection, _007B5874_007D.nextWindDirection, _007B5874_007D.windDirectionLerp);
		_007B5877_007D = _007B5876_007D.XZNormal();
		_007B5886_007D = MathHelper.Lerp(SeaStates[_007B5874_007D.commonOceanInitState].wavesHeight, SeaStates[_007B5874_007D.commonOceanNextState].wavesHeight, _007B5874_007D.commonOceanAndSkyStateLerp);
		_007B5875_007D.WavePosition.X = _007B5874_007D.wavePoisition.X;
		_007B5875_007D.WavePosition.Y = _007B5874_007D.wavePoisition.Y;
		if (!_007B5883_007D)
		{
			(float, float) tuple = lerp2d(SeaStates[_007B5874_007D.commonOceanInitState], SeaStates[_007B5874_007D.commonOceanNextState], _007B5874_007D.commonOceanAndSkyStateLerp);
			_007B5879_007D = tuple.Item1;
			_007B5878_007D = tuple.Item2;
			tuple = lerp2d(SkydomeStates[_007B5874_007D.commonSkydomeInitState], SkydomeStates[_007B5874_007D.commonSkydomeNextState], _007B5874_007D.commonOceanAndSkyStateLerp);
			_007B5880_007D = tuple.Item1;
			_007B5881_007D = tuple.Item2;
			_007B5887_007D = MathHelper.Lerp(WindPower[_007B5874_007D.commonOceanInitState], WindPower[_007B5874_007D.commonOceanNextState], _007B5874_007D.commonOceanAndSkyStateLerp);
		}
	}

	public void ClientUpdatePointedMode(Player _007B5847_007D)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		if (CommonGlobal.IsServer)
		{
			throw new InvalidOperationException();
		}
		_007B5879_007D = WavesHeightIntrenal(_007B5847_007D.MapInfo, _007B5847_007D.Position);
		float num = _007B5849_007D(_007B5847_007D.Position);
		_007B5880_007D = MathHelper.Lerp(sunnySkydomeState.Item1, stormSkydomeState.Item1, num);
		_007B5881_007D = MathHelper.Lerp(sunnySkydomeState.Item2, stormSkydomeState.Item2, num);
		_007B5887_007D = 0.17f + 0.83f * _007B5880_007D;
		_007B5880_007D = Math.Max(_007B5880_007D, Math.Min(SkydomeStates[_007B5874_007D.commonSkydomeNextState].cloudyLevel, SkydomeStates[WaterStateEnum.Cloudy].cloudyLevel));
		_007B5881_007D = Math.Max(_007B5881_007D, Math.Min(SkydomeStates[_007B5874_007D.commonSkydomeNextState].fogLevel, SkydomeStates[WaterStateEnum.Cloudy].cloudyLevel));
		_007B5882_007D = ExtraFogEffect(_007B5847_007D.Position, _007B5847_007D.MapInfo.IsWorldmap, out var _);
		_007B5881_007D = Math.Max(_007B5881_007D, _007B5882_007D * 0.9f);
	}

	public float RainingLevel(in Vector2 _007B5848_007D)
	{
		if (_007B5883_007D)
		{
			if (_007B5889_007D)
			{
				return 0f;
			}
			return _007B5849_007D(in _007B5848_007D);
		}
		return _007B5880_007D;
	}

	private float _007B5849_007D(in Vector2 _007B5850_007D)
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		float num = 0f;
		WeatherArea[] array = _007B5888_007D;
		for (int i = 0; i < array.Length; i++)
		{
			num = ((i != 0) ? Math.Max(num, array[i].IntensityRaining(_007B5850_007D)) : array[i].IntensityRaining(_007B5850_007D));
		}
		num = Math.Max(Gameplay.WorldMap.OutsideSeamLevelWithStep(in _007B5850_007D) * 2f, num);
		return MathHelper.Lerp(sunnySkydomeState.Item1, stormSkydomeState.Item1, num);
	}

	public float ExtraWindSpeedEffect(in Vector2 _007B5851_007D)
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		if (_007B5883_007D)
		{
			float num = 0f;
			WeatherArea[] array = _007B5888_007D;
			for (int i = 0; i < array.Length; i++)
			{
				num = ((i != 0) ? Math.Max(num, array[i].IntensityWind(_007B5851_007D)) : array[i].IntensityWind(_007B5851_007D));
			}
			return Math.Max(Gameplay.WorldMap.OutsideSeamLevelWithStep(in _007B5851_007D), num);
		}
		return 0f;
	}

	public float ExtraFogEffect(in Vector2 _007B5852_007D, bool _007B5853_007D, out float _007B5854_007D)
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		_007B5854_007D = 0f;
		if (_007B5883_007D)
		{
			float num = 0f;
			WeatherArea[] array = _007B5888_007D;
			for (int i = 0; i < array.Length; i++)
			{
				num = ((i != 0) ? Math.Max(num, array[i].IntensityFog(_007B5852_007D)) : array[i].IntensityFog(_007B5852_007D));
			}
			if (_007B5853_007D)
			{
				float num2 = Vector2.Distance(Gameplay.WorldHazardZones.First().XY(), _007B5852_007D);
				_007B5854_007D = Geometry.Saturate((1400f - num2) / 700f);
				num = Math.Max(num, _007B5854_007D);
			}
			return num;
		}
		return 0f;
	}

	public float WavesHeight(WorldMapInfo _007B5855_007D, in Vector2 _007B5856_007D)
	{
		if (!CommonGlobal.IsServer)
		{
			return _007B5879_007D;
		}
		if (_007B5883_007D)
		{
			return WavesHeightIntrenal(_007B5855_007D, in _007B5856_007D);
		}
		return _007B5879_007D;
	}

	[MethodImpl(MethodImplOptions.AggressiveOptimization)]
	public float WavesHeightIntrenal(WorldMapInfo _007B5857_007D, in Vector2 _007B5858_007D)
	{
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		float num = 0f;
		float num2 = 0f;
		WeatherArea[] array = _007B5888_007D;
		for (int i = 0; i < array.Length; i++)
		{
			if (i == 0)
			{
				num = array[i].IntensityRaining(_007B5858_007D);
				num2 = array[i].IntensityFog(_007B5858_007D);
			}
			else
			{
				num = Math.Max(num, array[i].IntensityRaining(_007B5858_007D));
				num2 = Math.Max(num2, array[i].IntensityFog(_007B5858_007D));
			}
		}
		num = Math.Max(Math.Min(1.5f, Gameplay.WorldMap.OutsideSeamLevelWithStep(in _007B5858_007D) * 2f), num);
		float deepnessLevel = _007B5857_007D.GetDeepnessLevel(_007B5858_007D);
		deepnessLevel *= 1f - num2;
		return MathHelper.Lerp(MathHelper.Lerp(_007B5886_007D * 0.6f, _007B5886_007D * 2.0615f, deepnessLevel), MaxWaveHeightDangerStorm, num);
	}

	public float HeightOnlyFast(float _007B5859_007D, float _007B5860_007D, float _007B5861_007D)
	{
		return _007B5875_007D.OnlyHeight(_007B5859_007D, _007B5860_007D, _007B5861_007D);
	}

	public float HeightOnlyHelper(WorldMapInfo _007B5862_007D, float _007B5863_007D, float _007B5864_007D)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		return _007B5875_007D.OnlyHeight(WavesHeight(_007B5862_007D, new Vector2(_007B5863_007D, _007B5864_007D)), _007B5863_007D, _007B5864_007D);
	}

	public Vector3 NormalOnlyHelper(WorldMapInfo _007B5865_007D, float _007B5866_007D, float _007B5867_007D)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		return _007B5875_007D.NormalOnly(WavesHeight(_007B5865_007D, new Vector2(_007B5866_007D, _007B5867_007D)), _007B5866_007D, _007B5867_007D);
	}

	public void NormalAndHeightHelper(WorldMapInfo _007B5868_007D, float _007B5869_007D, float _007B5870_007D, out Vector3 _007B5871_007D, out float _007B5872_007D)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		_007B5875_007D.GetSimpleStatement(WavesHeight(_007B5868_007D, new Vector2(_007B5869_007D, _007B5870_007D)), _007B5869_007D, _007B5870_007D, out _007B5871_007D, out _007B5872_007D);
	}

	public Vector3 StormDirection(in Vector2 _007B5873_007D)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		WeatherArea[] array = _007B5888_007D;
		Vector2 zero = Vector2.Zero;
		float num = 0f;
		float val = 0f;
		float num2 = Gameplay.WorldMap.OutsideSeamLevelWithStep(in _007B5873_007D);
		num += num2;
		val = Math.Max(val, num2);
		zero += -_007B5873_007D.Normal() * num2;
		for (int i = 0; i < array.Length; i++)
		{
			float num3 = array[i].IntensityExternalRadius(_007B5873_007D);
			num += num3;
			val = Math.Max(val, num3);
			zero += (_007B5873_007D - array[i].CurrentPosition).Normal() * num3;
		}
		if (num == 0f)
		{
			return Vector3.Up;
		}
		zero /= num;
		return ExtensionMethods.Normal(new Vector3(zero.X, 0f, zero.Y));
	}
}
