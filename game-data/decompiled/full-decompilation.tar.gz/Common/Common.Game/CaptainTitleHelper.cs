using Common.Account;
using Common.Resources;
using CommonDataTypes;

namespace Common.Game;

public static class CaptainTitleHelper
{
	private static int AchievementRequiredCount(AchievementEnum _007B5293_007D)
	{
		return _007B5293_007D switch
		{
			AchievementEnum.Board3Players => 10, 
			AchievementEnum.PbTopParticipant => 3, 
			_ => 1, 
		};
	}

	public static bool IsAvailable(this CaptainTitle _007B5294_007D, PlayerAccount _007B5295_007D)
	{
		if (_007B5294_007D == CaptainTitle.None)
		{
			return true;
		}
		switch (_007B5294_007D)
		{
		case CaptainTitle.None:
			return true;
		case CaptainTitle.HaveRank30:
			return _007B5295_007D.Rang >= 30;
		case CaptainTitle.Have30Ships:
			return _007B5295_007D.Shipyard.List.Count >= 30;
		case CaptainTitle.Have2PersonalIsles:
			return _007B5295_007D.PersonalIsles.Data.Size >= 2;
		default:
			return _007B5295_007D.Achievements.Count((AchievementEnum)_007B5294_007D) >= AchievementRequiredCount((AchievementEnum)_007B5294_007D);
		}
	}

	public static string ConditionString(this CaptainTitle _007B5296_007D, out string _007B5297_007D)
	{
		_007B5297_007D = string.Empty;
		switch (_007B5296_007D)
		{
		case CaptainTitle.None:
			return Local.title_no;
		case CaptainTitle.HaveRank30:
			return Local.title_30rank;
		case CaptainTitle.Have30Ships:
			return Local.title_30ships;
		case CaptainTitle.Have2PersonalIsles:
			return Local.title_2isles;
		default:
		{
			AchievementDisplayInfo achievementDisplayInfo = Gameplay.AchievementsByEnum[(AchievementEnum)_007B5296_007D];
			_007B5297_007D = achievementDisplayInfo.Description;
			int num = AchievementRequiredCount(achievementDisplayInfo.AchievementEnum);
			return (num == 1) ? Local.title_achiev(achievementDisplayInfo.Name) : Local.title_achiev_q(num, achievementDisplayInfo.Name);
		}
		}
	}
}
