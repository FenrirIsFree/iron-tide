using System;
using System.Collections.Generic;
using System.Linq;
using Common.Account;
using Common.Data;
using Common.Resources;
using TheraEngine;

namespace Common.Game;

public static class WosbCrafting
{
	public class Recepie
	{
		internal readonly RTI outputItemId;

		internal StorageAssetEnum outputType = StorageAssetEnum.SimpleItem;

		public GSI ExtraOutputRes = new GSI();

		public GSI OutputRes = new GSI();

		public CraftingRecipe Craft;

		public readonly RTI OutputItemCount;

		public readonly RTIf CraftHours;

		public string uiCatKey;

		internal string annoKey;

		public bool HideInLowRank;

		public FactoryType? NeedsFactoryInPort;

		public IStorageAsset Output
		{
			get
			{
				object result;
				if (!OutputIsGold)
				{
					if (outputType != StorageAssetEnum.Ammo)
					{
						if (outputType != StorageAssetEnum.PowderKeg)
						{
							IStorageAsset storageAsset = Gameplay.ItemsInfo.FromID(outputItemId.Value);
							result = storageAsset;
						}
						else
						{
							IStorageAsset storageAsset = Gameplay.PowderKegsInfo.FromID(outputItemId.Value);
							result = storageAsset;
						}
					}
					else
					{
						IStorageAsset storageAsset = Gameplay.BallsInfo.FromID(outputItemId.Value);
						result = storageAsset;
					}
				}
				else
				{
					result = null;
				}
				return (IStorageAsset)result;
			}
		}

		public string uiCat => Local.Current(uiCatKey);

		public bool OutputIsGold => outputItemId.Value == 255;

		public string Annotation => string.IsNullOrEmpty(annoKey) ? "" : Local.Current(annoKey);

		public Recepie(float _007B3915_007D, string _007B3916_007D, int _007B3917_007D, int _007B3918_007D, int _007B3919_007D, int _007B3920_007D, int _007B3921_007D)
			: this(_007B3915_007D, _007B3916_007D, _007B3918_007D, _007B3919_007D, _007B3920_007D, _007B3921_007D)
		{
			Craft = new CraftingRecipe(_007B3917_007D, _007B3918_007D, _007B3919_007D);
		}

		public Recepie(float _007B3922_007D, string _007B3923_007D, int _007B3924_007D, int _007B3925_007D, int _007B3926_007D, int _007B3927_007D)
		{
			CraftHours = new RTIf(_007B3922_007D);
			uiCatKey = _007B3923_007D;
			Craft = new CraftingRecipe(_007B3924_007D, _007B3925_007D);
			outputItemId = new RTI(_007B3926_007D);
			OutputItemCount = new RTI(_007B3927_007D);
		}

		public Recepie(float _007B3928_007D, string _007B3929_007D, int[] _007B3930_007D, int[] _007B3931_007D, int _007B3932_007D, int _007B3933_007D)
		{
			CraftHours = new RTIf(_007B3928_007D);
			uiCatKey = _007B3929_007D;
			Craft = new CraftingRecipe(_007B3930_007D, _007B3931_007D, _007B3932_007D);
			outputItemId = new RTI(_007B3932_007D);
			OutputItemCount = new RTI(_007B3933_007D);
		}

		public Recepie(float _007B3934_007D, string _007B3935_007D, GSI _007B3936_007D, GSI _007B3937_007D, int _007B3938_007D = 0)
		{
			CraftHours = new RTIf(_007B3934_007D);
			uiCatKey = _007B3935_007D;
			Craft = new CraftingRecipe(_007B3936_007D, _007B3938_007D);
			GSILocalPair gSILocalPair = _007B3937_007D.items.Array.First();
			outputItemId = gSILocalPair.ID;
			OutputItemCount = gSILocalPair.Count;
			OutputRes = _007B3937_007D;
		}
	}

	private static readonly string craftmaterials = "craft_comp";

	private static readonly string prod = "craft_prod";

	private static readonly string change = "craft_sev";

	public static Recepie[] Furnace = new Recepie[3]
	{
		new Recepie(1f, "", new GSI().Exs(31, 270).Exs(12, 27), new GSI().Exs(4, 270)),
		new Recepie(1f, "", new GSI().Exs(32, 27).Exs(12, 27), new GSI().Exs(11, 27)),
		new Recepie(1f, "", new GSI().Exs(23, 20).Exs(12, 20), new GSI().Exs(4, 520))
	};

	public static Recepie[] Workshop = new Recepie[21]
	{
		new Recepie(5f, craftmaterials, new GSI().Exs(1, 100).Exs(4, 5), new GSI().Exs(27, 1))
		{
			NeedsFactoryInPort = FactoryType.PortBulks
		},
		new Recepie(6f, craftmaterials, new GSI().Exs(4, 20).Exs(11, 10).Exs(12, 1), new GSI().Exs(14, 1))
		{
			NeedsFactoryInPort = FactoryType.PortBronze
		},
		new Recepie(6f, craftmaterials, new GSI().Exs(12, 15).Exs(13, 4).Exs(4, 30), new GSI().Exs(16, 1))
		{
			NeedsFactoryInPort = FactoryType.PortBlocks
		},
		new Recepie(3f, craftmaterials, new GSI().Exs(3, 10).Exs(13, 1), new GSI().Exs(17, 1))
		{
			NeedsFactoryInPort = FactoryType.PortSailcloth
		},
		new Recepie(5f, craftmaterials, new GSI().Exs(13, 1).Exs(4, 70), new GSI().Exs(29, 1))
		{
			NeedsFactoryInPort = FactoryType.PortIronBulks
		},
		new Recepie(1f, prod, new GSI().Exs(31, 10).Exs(12, 1), new GSI().Exs(4, 10)),
		new Recepie(2f, prod, new GSI().Exs(32, 1).Exs(12, 1), new GSI().Exs(11, 1)),
		new Recepie(0.5f, prod, new GSI().Exs(20, 2), new GSI().Exs(12, 1))
		{
			annoKey = "anno_coal"
		},
		new Recepie(1f, prod, new GSI().Exs(22, 1), new GSI().Exs(21, 3))
		{
			annoKey = "anno_meat"
		},
		new Recepie(20f, prod, new GSI().Exs(22, 10), new GSI().Exs(3, 50))
		{
			annoKey = "anno_meat",
			ExtraOutputRes = new GSI().Exs(59, 1)
		},
		new Recepie(0.5f, change, 500, 0, 0, 24, 1)
		{
			HideInLowRank = true
		},
		new Recepie(200f, change, 100000, 67, 100, 68, 1)
		{
			HideInLowRank = true,
			annoKey = "Ragpicker"
		},
		new Recepie(0f, change, 0, 68, 1, 67, 75)
		{
			HideInLowRank = true,
			annoKey = "Ragpicker"
		},
		new Recepie(0f, change, new GSI().Exs(24, 1), new GSI().Exs(255, 490))
		{
			HideInLowRank = true
		},
		new Recepie(2f, change, new GSI().Exs(2, 1).Exs(9, 2).Exs(21, 3), new GSI().Exs(39, 1))
		{
			HideInLowRank = true
		},
		new Recepie(1f, change, new GSI().Exs(1, 5).Exs(4, 1), new GSI().Exs(36, 1)),
		new Recepie(1f, change, new GSI().Exs(4, 8), new GSI().Exs(1, 100))
		{
			HideInLowRank = true,
			outputType = StorageAssetEnum.Ammo,
			NeedsFactoryInPort = FactoryType.PortTopWeapons
		},
		new Recepie(1f, change, new GSI().Exs(4, 5).Exs(70, 2), new GSI().Exs(2, 100))
		{
			HideInLowRank = true,
			outputType = StorageAssetEnum.Ammo,
			NeedsFactoryInPort = FactoryType.PortTopWeapons
		},
		new Recepie(1f, change, new GSI().Exs(11, 1).Exs(4, 5), new GSI().Exs(8, 3))
		{
			HideInLowRank = true,
			outputType = StorageAssetEnum.Ammo,
			NeedsFactoryInPort = FactoryType.PortTopWeapons
		},
		new Recepie(1f, change, new GSI().Exs(1, 100).Exs(70, 10), new GSI().Exs(2, 10))
		{
			HideInLowRank = true,
			outputType = StorageAssetEnum.PowderKeg
		},
		new Recepie(1f, change, new GSI().Exs(13, 20).Exs(4, 200), new GSI().Exs(6, 10))
		{
			HideInLowRank = true,
			outputType = StorageAssetEnum.PowderKeg,
			NeedsFactoryInPort = FactoryType.PortTopWeapons
		}
	};

	public static readonly float PersonalIsleWorkshopDiscount = 0.2f;

	public static Recepie[] PersonalIsleWorkshops = (from _007B3940_007D in Workshop.Where((Recepie _007B3939_007D) => _007B3939_007D.NeedsFactoryInPort.HasValue && _007B3939_007D.outputType == StorageAssetEnum.SimpleItem).Concat(new Recepie[1]
		{
			new Recepie(2f, change, new int[3] { 2, 9, 21 }, new int[3] { 1, 2, 3 }, 39, 1)
			{
				NeedsFactoryInPort = FactoryType.PI_ProvisionWorkshop
			}
		})
		select new Recepie(_007B3940_007D.CraftHours.Value / 20f, string.Empty, _007B3940_007D.Craft.InputItems, new GSI().Exs(_007B3940_007D.Output.ID, _007B3940_007D.OutputItemCount.Value))
		{
			NeedsFactoryInPort = _007B3940_007D.NeedsFactoryInPort
		}).ToArray();

	public static float BondmanFactoryBoostAmount = 3f;

	public static float BondmanFactoryUsagePerHour = 2f;

	public static Dictionary<FactoryType, FactoryGameInfo> FactoriesInfo;

	private static readonly RTI[] goldCost_Factory = new RTI[4]
	{
		new RTI(500),
		new RTI(3000),
		new RTI(9000),
		new RTI(0)
	};

	private static readonly GSI[] resCost_Factory = new GSI[4]
	{
		new GSI(),
		new GSI(),
		new GSI(),
		new GSI().Exs(29, 20).Exs(16, 20).Exs(5, 1000)
	};

	public static int OpenFactoryPriceGold => goldCost_Factory[0].Value;

	public static (int gold, int craftTime) FactoryInPortBuildPrice(IslePortInfo _007B3882_007D, PlayerAccount _007B3883_007D, FactoryType _007B3884_007D)
	{
		(int, int) result = ((_007B3883_007D.Rang < 10) ? 500 : ((_007B3883_007D.Rang < 15) ? 1500 : ((_007B3883_007D.Rang < 20) ? 4000 : ((_007B3883_007D.Rang < 25) ? 6000 : 10000))), _007B3883_007D.CraftTimeLimitWithoutDonate / 3);
		if (_007B3884_007D == FactoryType.PortTopWeapons)
		{
			result.Item1 += 10000;
		}
		return result;
	}

	internal static (int timeLimit, int timeUpdate) WorkshopLevelInfo(int _007B3885_007D)
	{
		return _007B3885_007D switch
		{
			0 => (timeLimit: 300, timeUpdate: 30), 
			1 => (timeLimit: 600, timeUpdate: 40), 
			2 => (timeLimit: 1000, timeUpdate: 50), 
			_ => throw new NotSupportedException(), 
		};
	}

	internal static void InitFactories()
	{
		Dictionary<FactoryType, FactoryGameInfo> dictionary = new Dictionary<FactoryType, FactoryGameInfo>();
		dictionary[FactoryType.NWoodcutter] = new FactoryGameInfo(FactoryType.NWoodcutter, new FactoryMineLivelInfo(new GSI(), new GSI().Exs(1, 20), 820f), new FactoryMineLivelInfo(new GSI(), new GSI().Exs(1, 30), 1440f), new FactoryMineLivelInfo(new GSI().Exs(39, 1), new GSI().Exs(1, 70), 3920f), new FactoryMineLivelInfo(new GSI().Exs(39, 2), new GSI().Exs(1, 110), 7150f));
		dictionary[FactoryType.NIronMine] = new FactoryGameInfo(FactoryType.NIronMine, new FactoryMineLivelInfo(new GSI(), new GSI().Exs(31, 15), 615f), new FactoryMineLivelInfo(new GSI(), new GSI().Exs(31, 22), 1080f), new FactoryMineLivelInfo(new GSI().Exs(39, 1), new GSI().Exs(31, 52), 2940f), new FactoryMineLivelInfo(new GSI().Exs(39, 2), new GSI().Exs(31, 82), 5362f));
		dictionary[FactoryType.NCopperMine] = new FactoryGameInfo(FactoryType.NCopperMine, new FactoryMineLivelInfo(new GSI(), new GSI().Exs(32, 2), 82f), new FactoryMineLivelInfo(new GSI(), new GSI().Exs(32, 3), 144f), new FactoryMineLivelInfo(new GSI().Exs(39, 1), new GSI().Exs(32, 6), 392f), new FactoryMineLivelInfo(new GSI().Exs(39, 2), new GSI().Exs(32, 10), 715f));
		dictionary[FactoryType.NResinFactory] = new FactoryGameInfo(FactoryType.NResinFactory, new FactoryMineLivelInfo(new GSI(), new GSI().Exs(13, 2), 82f), new FactoryMineLivelInfo(new GSI(), new GSI().Exs(13, 3), 144f), new FactoryMineLivelInfo(new GSI().Exs(39, 1), new GSI().Exs(13, 6), 336f), new FactoryMineLivelInfo(new GSI().Exs(39, 2), new GSI().Exs(13, 9), 585f));
		dictionary[FactoryType.NRumFactory] = new FactoryGameInfo(FactoryType.NRumFactory, new FactoryMineLivelInfo(new GSI(), new GSI().Exs(2, 5), 205f), new FactoryMineLivelInfo(new GSI().Exs(6, 1), new GSI().Exs(2, 12), 576f), new FactoryMineLivelInfo(new GSI().Exs(6, 2), new GSI().Exs(2, 19), 1064f), new FactoryMineLivelInfo(new GSI().Exs(6, 3), new GSI().Exs(2, 26), 1690f));
		dictionary[FactoryType.NFarm] = new FactoryGameInfo(FactoryType.NFarm, new FactoryMineLivelInfo(new GSI().Exs(10, 3), new GSI().Exs(22, 12), 200f), new FactoryMineLivelInfo(new GSI().Exs(10, 3), new GSI().Exs(22, 12), 400f), new FactoryMineLivelInfo(new GSI().Exs(10, 4), new GSI().Exs(22, 16), 600f), new FactoryMineLivelInfo(new GSI().Exs(10, 5), new GSI().Exs(22, 20), 750f));
		dictionary[FactoryType.NIceFactory] = new FactoryGameInfo(FactoryType.NIceFactory, new FactoryMineLivelInfo(new GSI(), new GSI().Exs(5, 20), 820f), new FactoryMineLivelInfo(new GSI().Exs(12, 2), new GSI().Exs(5, 40), 1920f), new FactoryMineLivelInfo(new GSI().Exs(12, 5), new GSI().Exs(5, 70), 3920f), new FactoryMineLivelInfo(new GSI().Exs(12, 10), new GSI().Exs(5, 110), 7150f));
		dictionary[FactoryType.NCoalMine] = new FactoryGameInfo(FactoryType.NCoalMine, new FactoryMineLivelInfo(new GSI(), new GSI().Exs(12, 4), 164f), new FactoryMineLivelInfo(new GSI(), new GSI().Exs(12, 6), 288f), new FactoryMineLivelInfo(new GSI().Exs(39, 1), new GSI().Exs(12, 14), 784f), new FactoryMineLivelInfo(new GSI().Exs(39, 2), new GSI().Exs(12, 22), 1430f));
		dictionary[FactoryType.NUnderground] = new FactoryGameInfo(FactoryType.NUnderground, new FactoryMineLivelInfo(new GSI(), new GSI().Exs(37, 1), 40f), new FactoryMineLivelInfo(new GSI().Exs(39, 2), new GSI().Exs(37, 2), 90f), new FactoryMineLivelInfo(new GSI().Exs(39, 3), new GSI().Exs(37, 3), 120f), new FactoryMineLivelInfo(new GSI().Exs(39, 4), new GSI().Exs(37, 4), 140f));
		dictionary[FactoryType.Temp_PersonalIsle] = new FactoryGameInfo(FactoryType.Temp_PersonalIsle, new FactoryMineLivelInfo(new GSI(), new GSI().Exs(1, 1), 0f));
		dictionary[FactoryType.IsleBeerFactory] = new FactoryGameInfo(FactoryType.IsleBeerFactory, new FactoryMineLivelInfo(new GSI(), new GSI().Exs(7, 84), float.MaxValue));
		dictionary[FactoryType.IsleCornFactory] = new FactoryGameInfo(FactoryType.IsleCornFactory, new FactoryMineLivelInfo(new GSI(), new GSI().Exs(10, 56), float.MaxValue));
		dictionary[FactoryType.IsleFruitsFactory] = new FactoryGameInfo(FactoryType.IsleFruitsFactory, new FactoryMineLivelInfo(new GSI(), new GSI().Exs(9, 28), float.MaxValue));
		dictionary[FactoryType.IsleSugarFactory] = new FactoryGameInfo(FactoryType.IsleSugarFactory, new FactoryMineLivelInfo(new GSI(), new GSI().Exs(6, 14), float.MaxValue));
		dictionary[FactoryType.IsleVulkanoOreFactory] = new FactoryGameInfo(FactoryType.IsleVulkanoOreFactory, new FactoryMineLivelInfo(new GSI(), new GSI().Exs(23, 10), float.MaxValue));
		FactoriesInfo = dictionary;
	}

	internal static (int, GSI) FactoryBuildCostGold(int _007B3886_007D, FactoryType _007B3887_007D)
	{
		return (goldCost_Factory[_007B3886_007D].Value, resCost_Factory[_007B3886_007D]);
	}

	private static FactoryMineLivelInfo mineHelper(int _007B3888_007D, GSI _007B3889_007D, int _007B3890_007D)
	{
		double num = Math.Round((float)_007B3890_007D / 24f / (float)Gameplay.ItemsInfo.FromID(_007B3888_007D).MediumCost.Value);
		double num2 = (double)(60f - (float)_007B3890_007D / 24f / 400f) * num;
		return new FactoryMineLivelInfo(_007B3889_007D, new GSI().Exs(_007B3888_007D, Gameplay.roundHelper((float)num)), Gameplay.roundHelper((float)num2));
	}
}
