using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct ArenaPersonalResults : IMPSerializable
{
	public Bonus Bonus;

	public ArenaBattleResult Result;

	public int ArenaRatingChange;

	public int GamemodeRatingChange;

	public float AddArenaPenltyTime;

	public bool LossTournamentLive;

	public byte RemainLives;

	private void _007B6955_007D(WriterExtern _007B6956_007D)
	{
		_007B6956_007D.Write<Bonus>(ref Bonus);
		_007B6956_007D.WriteEnum((object)Result);
		_007B6956_007D.WriteStruct<int>(ref ArenaRatingChange);
		_007B6956_007D.WriteStruct<int>(ref GamemodeRatingChange);
		_007B6956_007D.WriteStruct<float>(AddArenaPenltyTime);
		_007B6956_007D.Write(LossTournamentLive);
		_007B6956_007D.WriteByte(RemainLives);
	}

	private void _007B6957_007D(WriterExtern _007B6958_007D)
	{
		_007B6958_007D.ReadIMPS_struct<Bonus>(ref Bonus);
		_007B6958_007D.ReadEnum<ArenaBattleResult>(ref Result);
		_007B6958_007D.ReadStruct<int>(ref ArenaRatingChange);
		_007B6958_007D.ReadStruct<int>(ref GamemodeRatingChange);
		_007B6958_007D.ReadStruct<float>(ref AddArenaPenltyTime);
		_007B6958_007D.ReadBoolean(ref LossTournamentLive);
		RemainLives = _007B6958_007D.ReadByte();
	}
}
