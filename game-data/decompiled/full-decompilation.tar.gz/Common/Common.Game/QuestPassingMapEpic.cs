namespace Common.Game;

public class QuestPassingMapEpic : QuestStepHeader
{
	public override int ProgressComparand => -1;

	public QuestPassingMapEpic(string _007B7675_007D)
		: base(_007B7675_007D)
	{
	}
}
