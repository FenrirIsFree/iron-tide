using Common.Resources;
using TheraEngine;

namespace Common.Game;

public class QuestGetResFromBoarding : QuestStepHeader
{
	public readonly int NeededResID;

	public readonly RTI Count;

	public ResourceInfo NeededResInfo => Gameplay.ItemsInfo[NeededResID];

	public override int ProgressComparand => Count.Value;

	public QuestGetResFromBoarding(string _007B7619_007D, int _007B7620_007D, int _007B7621_007D)
		: base(_007B7619_007D)
	{
		NeededResID = _007B7620_007D;
		Count = new RTI(_007B7621_007D);
	}
}
