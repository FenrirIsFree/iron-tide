namespace Common.Game;

public enum EconomyRegion
{
	None,
	South,
	North,
	Arab,
	Center
}
