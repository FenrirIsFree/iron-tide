namespace Common.Game;

internal class TiltDesctructionBehavior
{
}
