namespace Common.Game;

public enum GlobalEventMarkerType : byte
{
	NpcEvent,
	PlayerVisible,
	RareTreasures,
	PlayerAdvert
}
