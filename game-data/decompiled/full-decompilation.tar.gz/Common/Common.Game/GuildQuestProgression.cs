namespace Common.Game;

public enum GuildQuestProgression
{
	FractionMakeEnemyDamage,
	TradersGoldTurnover,
	TradersBuildTopShips,
	TradersSellPearl,
	TradersUseCraftTime,
	PirateKills,
	PirateTraderBoardings,
	AnyGainExperience,
	AnyMakeQuests,
	AnyGrowRanks,
	AnyGiveAchievements,
	SupplyMission
}
