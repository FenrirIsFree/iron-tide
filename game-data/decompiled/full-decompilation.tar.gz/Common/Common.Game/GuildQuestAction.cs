namespace Common.Game;

public enum GuildQuestAction
{
	CaptureCity,
	ProtectCity,
	HoldPort,
	FailedAttack,
	CooperatePb,
	ColonizeCity,
	HoldOpenedPort
}
