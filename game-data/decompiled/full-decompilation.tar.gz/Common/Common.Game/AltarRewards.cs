using System;
using Common.Account;
using Common.Resources;
using TheraEngine;

namespace Common.Game;

internal static class AltarRewards
{
	private static readonly RTI r_7 = new RTI(7);

	private static readonly RTI r_10 = new RTI(10);

	private static readonly RTI r_15 = new RTI(15);

	private static readonly RTI r_30 = new RTI(30);

	private static readonly RTI r_500 = new RTI(500);

	private static readonly RTI r_3000 = new RTI(3000);

	public static readonly ChestRewardInfo[] Elements = new ChestRewardInfo[15]
	{
		new ChestRewardInfo(40f, delegate(PlayerAccount _007B8058_007D, int _007B8059_007D, DateTime _007B8060_007D)
		{
			_007B8058_007D.TreasuryMaps[35] += 2;
			return new LocalizedString(string.Empty, "+2x ", new LocalizedString(Gameplay.ItemsInfo.FromID(35).nameKey));
		}, _007B8265_007D: false),
		new ChestRewardInfo(30f, delegate(PlayerAccount _007B8061_007D, int _007B8062_007D, DateTime _007B8063_007D)
		{
			_007B8061_007D.TreasuryMaps[35] += 4;
			return new LocalizedString(string.Empty, "+4x ", new LocalizedString(Gameplay.ItemsInfo.FromID(35).nameKey));
		}, _007B8265_007D: false),
		new ChestRewardInfo(60f, delegate(PlayerAccount _007B8064_007D, int _007B8065_007D, DateTime _007B8066_007D)
		{
			_007B8064_007D.Shipyard.CurrentRealShip.PrivateResourcesOfHold.AddOrRemove(37, r_15.Value);
			return new LocalizedString(string.Empty, "+15x ", new LocalizedString(Gameplay.ItemsInfo.FromID(37).nameKey));
		}, _007B8265_007D: false),
		new ChestRewardInfo(10f, delegate(PlayerAccount _007B8067_007D, int _007B8068_007D, DateTime _007B8069_007D)
		{
			_007B8067_007D.Shipyard.CurrentRealShip.PrivateResourcesOfHold.AddOrRemove(37, r_30.Value);
			return new LocalizedString(string.Empty, "+30x ", new LocalizedString(Gameplay.ItemsInfo.FromID(37).nameKey));
		}, _007B8265_007D: false),
		new ChestRewardInfo(50f, delegate(PlayerAccount _007B8070_007D, int _007B8071_007D, DateTime _007B8072_007D)
		{
			_007B8070_007D.Shipyard.CurrentRealShip.PrivateResourcesOfHold.AddOrRemove(38, 1);
			return new LocalizedString(string.Empty, "+1x ", new LocalizedString(Gameplay.ItemsInfo.FromID(38).nameKey));
		}, _007B8265_007D: false),
		new ChestRewardInfo(10f, delegate(PlayerAccount _007B8073_007D, int _007B8074_007D, DateTime _007B8075_007D)
		{
			_007B8073_007D.Shipyard.CurrentRealShip.PrivateResourcesOfHold.AddOrRemove(38, 3);
			return new LocalizedString(string.Empty, "+3x ", new LocalizedString(Gameplay.ItemsInfo.FromID(38).nameKey));
		}, _007B8265_007D: false),
		new ChestRewardInfo(50f, delegate(PlayerAccount _007B8076_007D, int _007B8077_007D, DateTime _007B8078_007D)
		{
			_007B8076_007D.Gold += r_500.Value;
			return new LocalizedString(string.Empty, "500 ", new LocalizedString("gold2"));
		}, _007B8265_007D: false),
		new ChestRewardInfo(10f, delegate(PlayerAccount _007B8079_007D, int _007B8080_007D, DateTime _007B8081_007D)
		{
			if (_007B8079_007D != null)
			{
				_007B8079_007D.Gold += r_3000.Value;
			}
			return new LocalizedString(string.Empty, "3000 ", new LocalizedString("gold2"));
		}, _007B8265_007D: false),
		new ChestRewardInfo(30f, delegate(PlayerAccount _007B8082_007D, int _007B8083_007D, DateTime _007B8084_007D)
		{
			PowerupItemInfo powerupItemInfo = Gameplay.PowerupItems.Array[17];
			_007B8082_007D.PowerupItemsAtStorage.AddOrRemove(powerupItemInfo.Index, 1);
			return new LocalizedString(string.Empty, "1х ", new LocalizedString(powerupItemInfo.nameKey));
		}, _007B8265_007D: false),
		new ChestRewardInfo(30f, delegate(PlayerAccount _007B8085_007D, int _007B8086_007D, DateTime _007B8087_007D)
		{
			PowerupItemInfo powerupItemInfo = Gameplay.PowerupItems.Array[40];
			_007B8085_007D.PowerupItemsAtStorage.AddOrRemove(powerupItemInfo.Index, 2);
			return new LocalizedString(string.Empty, "2х ", new LocalizedString(powerupItemInfo.nameKey));
		}, _007B8265_007D: false),
		new ChestRewardInfo(15f, delegate(PlayerAccount _007B8088_007D, int _007B8089_007D, DateTime _007B8090_007D)
		{
			_007B8088_007D.Shipyard.CurrentRealShip.BallsOfHold.AddOrRemove(18, r_30.Value);
			return new LocalizedString(string.Empty, "30x ", new LocalizedString(Gameplay.BallsInfo.FromID(18).nameKey));
		}, _007B8265_007D: false),
		new ChestRewardInfo(15f, delegate(PlayerAccount _007B8091_007D, int _007B8092_007D, DateTime _007B8093_007D)
		{
			_007B8091_007D?.Shipyard.CurrentRealShip.PrivateResourcesOfHold.AddOrRemove(39, r_10.Value);
			return new LocalizedString(string.Empty, "+10x ", new LocalizedString(Gameplay.ItemsInfo.FromID(39).nameKey));
		}, _007B8265_007D: false),
		new ChestRewardInfo(5f, delegate(PlayerAccount _007B8094_007D, int _007B8095_007D, DateTime _007B8096_007D)
		{
			_007B8094_007D?.Shipyard.CurrentRealShip.PrivateResourcesOfHold.AddOrRemove(69, r_7.Value);
			return new LocalizedString(string.Empty, "+7x ", new LocalizedString(Gameplay.ItemsInfo.FromID(69).nameKey));
		}, _007B8265_007D: false, "GoldFish"),
		new ChestRewardInfo(2f, delegate(PlayerAccount _007B8097_007D, int _007B8098_007D, DateTime _007B8099_007D)
		{
			_007B8097_007D.Shipyard.CurrentRealShip.PrivateResourcesOfHold.AddOrRemove(43, 1);
			return new LocalizedString(string.Empty, "+1x ", new LocalizedString(Gameplay.ItemsInfo.FromID(43).nameKey));
		}, _007B8265_007D: false),
		new ChestRewardInfo(0.75f, delegate(PlayerAccount _007B8100_007D, int _007B8101_007D, DateTime _007B8102_007D)
		{
			ShipDesignInfo shipDesignInfo = Gameplay.RandomDesignsForAltar.Array[_007B8101_007D % Gameplay.RandomDesignsForAltar.Size];
			_007B8100_007D.DesingElementsAtStorage.AddOrRemove(shipDesignInfo.ID, 1);
			return new LocalizedString(shipDesignInfo.nameKey);
		}, _007B8265_007D: false)
	};
}
