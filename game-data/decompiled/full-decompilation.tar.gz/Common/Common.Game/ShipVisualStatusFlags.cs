namespace Common.Game;

public enum ShipVisualStatusFlags : byte
{
	SmugglingQuest = 1,
	EnemyByDispute = 2,
	EngageInPb = 4,
	PFDisallowedByWar = 8,
	HavingWantedLevel = 0x10,
	TensityMode = 0x20
}
