using TheraEngine;

namespace Common.Game;

internal interface IBehavior
{
	void Update(ref FrameTime _007B5213_007D, ref ShipOperatingParameters _007B5214_007D);
}
