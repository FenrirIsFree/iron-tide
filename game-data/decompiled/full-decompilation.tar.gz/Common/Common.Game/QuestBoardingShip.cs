namespace Common.Game;

public class QuestBoardingShip : QuestStepHeader
{
	public readonly int Count;

	public override int ProgressComparand => Count;

	public QuestBoardingShip(string _007B7547_007D, int _007B7548_007D, TargetShipForQuest _007B7549_007D)
		: base(_007B7547_007D, _007B7549_007D)
	{
		Count = _007B7548_007D;
	}
}
