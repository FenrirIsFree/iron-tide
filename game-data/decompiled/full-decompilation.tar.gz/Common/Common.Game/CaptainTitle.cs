namespace Common.Game;

public enum CaptainTitle : byte
{
	None = 0,
	HaveRank30 = 250,
	Have30Ships = 251,
	Have2PersonalIsles = 252,
	Achievement1 = 51,
	Achievement2 = 6,
	Achievement3 = 43,
	Achievement4 = 35,
	Achievement5 = 55
}
