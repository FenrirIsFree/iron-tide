namespace Common.Game;

public static class ArenaModeSettingsEx
{
	public static ArenaModeSettings GetInfo(this ArenaMode _007B6919_007D)
	{
		return ArenaModeSettings.ByEnum[_007B6919_007D];
	}
}
