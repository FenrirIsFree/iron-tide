namespace Common.Game;

public enum QuestCompany
{
	Trading,
	Battle,
	Coastal,
	War,
	Education,
	Daily
}
