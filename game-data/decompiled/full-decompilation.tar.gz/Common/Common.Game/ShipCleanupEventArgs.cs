namespace Common.Game;

public readonly struct ShipCleanupEventArgs
{
	public readonly Ship Source;

	public readonly bool IsDestroyOnly;

	public ShipCleanupEventArgs(Ship _007B5030_007D, bool _007B5031_007D)
	{
		Source = _007B5030_007D;
		IsDestroyOnly = _007B5031_007D;
	}
}
