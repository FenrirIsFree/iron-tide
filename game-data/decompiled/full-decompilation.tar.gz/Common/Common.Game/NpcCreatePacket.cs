using System.Text;
using Common.Account;
using Common.Resources;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Game;

public class NpcCreatePacket : ShipCreatePacket
{
	public byte ControllerState;

	public short NpcInfoID;

	public bool NpcInfoIDPassingMap;

	public int UidPlayerForCaper;

	public Tlist<int> InstalleUdpgrades;

	public Tlist<CannonSerializedInfo> BrokenCannons;

	public short InitialPlacesForUnits;

	public int FirebrandTargetUID;

	public float FirebrandTimeoutMs;

	public float EmpireNpcLevel;

	public NpcAgression AgressionToPlayer;

	public int AgressionTargetUID;

	public short SailDesignId;

	public OpenWorldFlag OwnerFlags;

	public string OwnerName;

	public bool DisasterMode;

	public short TradingRouteId;

	public bool IsShieldActive;

	public NpcCreatePacket()
	{
	}

	public NpcCreatePacket(Npc _007B4877_007D, GSI _007B4878_007D, GuildCommon _007B4879_007D, bool _007B4880_007D, int _007B4881_007D, float _007B4882_007D, float _007B4883_007D, NpcAgression _007B4884_007D, int _007B4885_007D, OpenWorldFlag _007B4886_007D, string _007B4887_007D, bool _007B4888_007D, Tlist<PublicDesignInfo> _007B4889_007D, FractionID? _007B4890_007D, short _007B4891_007D, bool _007B4892_007D)
		: base(_007B4877_007D, _007B4890_007D.HasValue ? new GuildShortInfo(string.Empty, _007B4890_007D.Value) : ((_007B4879_007D != null) ? new GuildShortInfo(_007B4879_007D.Tag, _007B4879_007D.Fraction) : (_007B4880_007D ? new GuildShortInfo("--- ", FractionID.Empire) : new GuildShortInfo(string.Empty, FractionID.None))), _007B4889_007D)
	{
		NpcInfo information = _007B4877_007D.UsedShipNpc.Information;
		NpcInfoID = information.ID;
		NpcInfoIDPassingMap = _007B4877_007D.UsedShipNpc.Information.NpcInfoIDPassingMap;
		ControllerState = _007B4877_007D.FirstController.GetCode;
		UidPlayerForCaper = _007B4877_007D.UidPlayerForCaper;
		InstalleUdpgrades = _007B4877_007D.UsedShipNpc.Upgrades;
		InitialPlacesForUnits = (short)_007B4877_007D.UsedShipNpc.InitialPlacesForUnits;
		BrokenCannons = _007B4877_007D.UsedShip.Cannons.BrokenItems;
		FirebrandTargetUID = _007B4881_007D;
		FirebrandTimeoutMs = _007B4882_007D;
		EmpireNpcLevel = _007B4883_007D;
		AgressionToPlayer = _007B4884_007D;
		AgressionTargetUID = _007B4885_007D;
		OwnerFlags = _007B4886_007D;
		OwnerName = ((_007B4877_007D.UidPlayerForCaper == -1) ? string.Empty : _007B4887_007D);
		DisasterMode = _007B4888_007D;
		TradingRouteId = _007B4891_007D;
		IsShieldActive = _007B4892_007D;
		ItemsInHoldExemplary = _007B4878_007D;
	}

	public override void Boxing(WriterExtern _007B4893_007D)
	{
		base.Boxing(_007B4893_007D);
		_007B4893_007D.WriteByte(ControllerState);
		_007B4893_007D.WriteStruct<short>(ref NpcInfoID);
		_007B4893_007D.Write(NpcInfoIDPassingMap);
		_007B4893_007D.WriteStruct<int>(UidPlayerForCaper);
		_007B4893_007D.WriteTlist(InstalleUdpgrades);
		_007B4893_007D.WriteStruct<short>(InitialPlacesForUnits);
		_007B4893_007D.WriteTlistStruct<CannonSerializedInfo>(BrokenCannons);
		_007B4893_007D.WriteStruct<int>(FirebrandTargetUID);
		if (FirebrandTargetUID != 0)
		{
			_007B4893_007D.WriteStruct<float>(FirebrandTimeoutMs);
		}
		_007B4893_007D.WriteStruct<float>(EmpireNpcLevel);
		_007B4893_007D.WriteByte((byte)AgressionToPlayer);
		_007B4893_007D.WriteByte((byte)OwnerFlags);
		_007B4893_007D.Write(OwnerName, (Encoding)null);
		_007B4893_007D.Write(DisasterMode);
		_007B4893_007D.WriteStruct<int>(AgressionTargetUID);
		_007B4893_007D.WriteStruct<short>(TradingRouteId);
		_007B4893_007D.Write(IsShieldActive);
	}

	public override void Unboxing(WriterExtern _007B4894_007D)
	{
		base.Unboxing(_007B4894_007D);
		ControllerState = _007B4894_007D.ReadByte();
		_007B4894_007D.ReadStruct<short>(ref NpcInfoID);
		_007B4894_007D.ReadBoolean(ref NpcInfoIDPassingMap);
		_007B4894_007D.ReadStruct<int>(ref UidPlayerForCaper);
		_007B4894_007D.ReadTlist(out InstalleUdpgrades);
		_007B4894_007D.ReadStruct<short>(ref InitialPlacesForUnits);
		_007B4894_007D.ReadTlistStruct<CannonSerializedInfo>(out BrokenCannons);
		_007B4894_007D.ReadStruct<int>(ref FirebrandTargetUID);
		if (FirebrandTargetUID != 0)
		{
			_007B4894_007D.ReadStruct<float>(ref FirebrandTimeoutMs);
		}
		_007B4894_007D.ReadStruct<float>(ref EmpireNpcLevel);
		AgressionToPlayer = (NpcAgression)_007B4894_007D.ReadByte();
		OwnerFlags = (OpenWorldFlag)_007B4894_007D.ReadByte();
		_007B4894_007D.ReadString(ref OwnerName, (Encoding)null);
		_007B4894_007D.ReadBoolean(ref DisasterMode);
		_007B4894_007D.ReadStruct<int>(ref AgressionTargetUID);
		_007B4894_007D.ReadStruct<short>(ref TradingRouteId);
		_007B4894_007D.ReadBoolean(ref IsShieldActive);
	}
}
