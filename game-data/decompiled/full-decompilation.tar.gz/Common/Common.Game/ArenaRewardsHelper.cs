using System.Collections.Generic;
using System.Linq;
using Common.Resources;
using TheraEngine.Helpers;

namespace Common.Game;

public static class ArenaRewardsHelper
{
	public static GSI Wrap(IEnumerable<ShipDesignInfo> _007B7043_007D)
	{
		GSI gSI = new GSI();
		foreach (ShipDesignInfo item in _007B7043_007D)
		{
			gSI.AddOrRemove(item.ID, 1);
		}
		return gSI;
	}

	public static GSI Wrap(IEnumerable<ShipDesignInfo> _007B7044_007D, int _007B7045_007D)
	{
		IEnumerable<ShipDesignInfo> enumerable = Rand.PickMany(_007B7045_007D, _007B7044_007D.ToArray());
		GSI gSI = new GSI();
		foreach (ShipDesignInfo item in enumerable)
		{
			gSI.AddOrRemove(item.ID, 1);
		}
		return gSI;
	}
}
