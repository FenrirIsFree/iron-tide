using System;
using System.Linq;
using Common.Resources;
using TheraEngine.Helpers;

namespace Common.Game;

public class BoardingCombatVisualGroup
{
	public readonly byte VisualGroupIndex;

	internal float hRandomSpeed;

	public GSI IncludingLiveUnits;

	public int InitialUnitsCount;

	public float TotalDamage;

	public float SummaryHp;

	public float InitialSummaryHp;

	public float MiddleDamageIntervalSec;

	public float TimeToNextDamageLoopSec;

	public float HealthFactor => SummaryHp / InitialSummaryHp;

	public float DamageFactor => MathF.Pow(HealthFactor, 0.7f);

	public float ReloadFactor => 1f - TimeToNextDamageLoopSec / MiddleDamageIntervalSec;

	public BoardingCombatVisualGroup(int _007B7944_007D, GSI _007B7945_007D)
	{
		VisualGroupIndex = (byte)_007B7944_007D;
		IncludingLiveUnits = _007B7945_007D;
		InitialUnitsCount = _007B7945_007D.GetTotalItemsCount();
		GSILocalEnumerablePair<UnitInfo>[] source = _007B7945_007D.UnitInfo.ToArray();
		TotalDamage = source.Sum((GSILocalEnumerablePair<UnitInfo> _007B7948_007D) => _007B7948_007D.Info.SampleDamage * (float)_007B7948_007D.Count);
		SummaryHp = source.Sum((GSILocalEnumerablePair<UnitInfo> _007B7949_007D) => _007B7949_007D.Info.Health * _007B7949_007D.Count);
		InitialSummaryHp = SummaryHp;
		MiddleDamageIntervalSec = WosbBoarding.UpdateIntervalMs / 1000f;
		hRandomSpeed = 1f + 0.1f * (HashHelper.greater(_007B7944_007D) - 0.5f);
		TimeToNextDamageLoopSec = MiddleDamageIntervalSec * hRandomSpeed;
	}

	public GSI MatchDamage(int _007B7946_007D, float _007B7947_007D)
	{
		if (SummaryHp <= 0f)
		{
			return GSI.Empty;
		}
		SummaryHp -= _007B7947_007D;
		if (SummaryHp <= 0f)
		{
			SummaryHp = 0f;
			GSI result = IncludingLiveUnits.Clone();
			IncludingLiveUnits.Clean();
			return result;
		}
		float _007B5485_007D = (float)InitialUnitsCount * _007B7947_007D / InitialSummaryHp;
		GSI gSI = IncludingLiveUnits.RandomCut(_007B5485_007D, _007B7946_007D);
		if (IncludingLiveUnits.IsEmpty && SummaryHp > 0f)
		{
			GSI _007B5460_007D = gSI.RandomCut(1f, _007B7946_007D);
			IncludingLiveUnits.Add(_007B5460_007D);
		}
		return gSI;
	}
}
