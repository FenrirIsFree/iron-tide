namespace Common.Game;

public enum PowerupItemServerEffect
{
	NoEffect,
	CaptureNearNpc,
	RunMortar,
	HealHurtedCrew
}
