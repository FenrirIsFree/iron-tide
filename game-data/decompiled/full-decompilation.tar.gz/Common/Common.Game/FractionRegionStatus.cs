using System.Collections.Generic;
using Common.Resources;

namespace Common.Game;

public static class FractionRegionStatus
{
	public static FractionID? GetRegionStatus(this WorldMapRegionInfo _007B8646_007D, IEnumerable<PbsStatus> _007B8647_007D)
	{
		FractionID? fractionID = null;
		bool flag = false;
		foreach (PbsStatus item in _007B8647_007D)
		{
			if (item.PortInstance.NearRegion.ID == _007B8646_007D.ID)
			{
				flag = true;
				FractionID valueOrDefault = fractionID.GetValueOrDefault();
				if (!fractionID.HasValue)
				{
					valueOrDefault = item.CapturerFraction;
					fractionID = valueOrDefault;
				}
				if (fractionID != item.CapturerFraction)
				{
					return null;
				}
			}
		}
		if (!flag)
		{
			return FractionID.None;
		}
		return fractionID;
	}

	public static float GetCapturedPercent(this FractionID _007B8648_007D, IEnumerable<PortCaptureStatus> _007B8649_007D)
	{
		float num = 0f;
		float num2 = 0f;
		foreach (PortCaptureStatus item in _007B8649_007D)
		{
			if (item.IsCapturedByGuild && item.CapturerFraction == _007B8648_007D)
			{
				num += 1f;
			}
			num2 += 1f;
		}
		if (num2 == 0f)
		{
			return 0f;
		}
		return num / num2;
	}
}
