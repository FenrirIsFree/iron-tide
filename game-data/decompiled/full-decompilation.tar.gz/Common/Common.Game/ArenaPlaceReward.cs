namespace Common.Game;

public struct ArenaPlaceReward
{
	public int StartPlaceIndex;

	public int EndPlaceIndexInclusive;

	public ComplexBonus Reward;

	public RatingRewardId RewardId;

	public ArenaPlaceReward(int _007B6963_007D, int _007B6964_007D, ComplexBonus _007B6965_007D, RatingRewardId _007B6966_007D)
	{
		StartPlaceIndex = _007B6963_007D;
		EndPlaceIndexInclusive = _007B6964_007D;
		Reward = _007B6965_007D;
		RewardId = _007B6966_007D;
	}
}
