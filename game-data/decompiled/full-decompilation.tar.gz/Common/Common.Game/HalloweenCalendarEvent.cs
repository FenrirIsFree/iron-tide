using System;
using System.Collections.Generic;
using Common.Account;
using Common.Data;

namespace Common.Game;

public static class HalloweenCalendarEvent
{
	public static CalendarEventInfo Create()
	{
		CalendarEventInfo calendarEventInfo = new CalendarEventInfo(CalendarEvent.Halloween);
		calendarEventInfo.StartDate = new DateTime(2025, 10, 31);
		calendarEventInfo.GoldFishingEnabled = true;
		calendarEventInfo.PumpkinLootEnabled = true;
		calendarEventInfo.RandomizedQuestDays = true;
		calendarEventInfo.OnFirstOpenAction = delegate(PlayerAccount _007B6106_007D)
		{
			_007B6106_007D.EnvDecorElementsAtStorage[45]++;
			_007B6106_007D.DesingElementsAtStorage[519]++;
			CalendarEvents.SendLogbookMessage(Local.halloween_firstOpen);
		};
		calendarEventInfo.Days = new DayInfo[14]
		{
			new DayInfo(1)
			{
				Quest = QuestPresets.KillAnyNpc(15)
			},
			new DayInfo(2)
			{
				Quest = QuestPresets.KillAnyNpcByMortar(10)
			},
			new DayInfo(3)
			{
				Quest = QuestPresets.BoardingAnyNpc(5)
			},
			new DayInfo(4)
			{
				Quest = QuestPresets.BuyAndSell(100, new EconomyRegion[2]
				{
					EconomyRegion.South,
					EconomyRegion.Arab
				}, new EconomyRegion[1] { EconomyRegion.North })
			},
			new DayInfo(5)
			{
				Quest = QuestPresets.KillEmpireNpcInSeamlessSea(5)
			},
			new DayInfo(6)
			{
				Quest = QuestPresets.CollectAndSellFish(1200)
			},
			new DayInfo(7)
			{
				Quest = QuestPresets.CollectKeys(3)
			},
			new DayInfo(8)
			{
				Quest = QuestPresets.ArenaNotDuel(10)
			},
			new DayInfo(9)
			{
				Quest = QuestPresets.FortDamage(3000)
			},
			new DayInfo(10)
			{
				Quest = QuestPresets.PassingMapEpic()
			},
			new DayInfo(11)
			{
				Quest = QuestPresets.KillWhale(1)
			},
			new DayInfo(12)
			{
				Quest = QuestPresets.FalkonetDamage(2000)
			},
			new DayInfo(13)
			{
				Quest = QuestPresets.FireAreaDamage(10000)
			},
			new DayInfo(14)
			{
				Quest = QuestPresets.ArenaNotDuel(10)
			}
		};
		calendarEventInfo.OnDayClosed = delegate(PlayerAccount _007B6107_007D, int _007B6108_007D)
		{
			CalendarEvents.GiveGoldFish(40, _007B6107_007D);
			switch (_007B6108_007D)
			{
			case 3:
				CalendarEvents.GiveMonets(_007B6107_007D, 150);
				break;
			case 5:
				CalendarEvents.GiveDesign(_007B6107_007D, 520);
				break;
			case 9:
				CalendarEvents.GivePremiumOrMonets(_007B6107_007D, 14, 200);
				break;
			case 12:
				CalendarEvents.GiveGoldFish(400, _007B6107_007D);
				break;
			}
		};
		calendarEventInfo.GoldfishTrader = new List<TraderOffer>(19)
		{
			new TraderOffer(1750, null, 0, 0, 404),
			new TraderOffer(1500, new TraderOffer.Resource(72, 75000)),
			new TraderOffer(1000, null, 0, 0, 523),
			new TraderOffer(800, null, 0, 0, 522),
			new TraderOffer(420, new TraderOffer.Resource(68, 1)),
			new TraderOffer(300, new TraderOffer.Resource(72, 12000)),
			new TraderOffer(250, null, 0, 125),
			new TraderOffer(200, null, 0, 0, 521),
			new TraderOffer(150, new TraderOffer.Resource(23, 3000)),
			new TraderOffer(100, new TraderOffer.Resource(37, 1500)),
			new TraderOffer(100, new TraderOffer.Resource(15, 150)),
			new TraderOffer(40, new TraderOffer.Resource(5, 6000, StorageAssetEnum.Ammo)),
			new TraderOffer(20, new TraderOffer.Resource(7, 8000, StorageAssetEnum.Ammo)),
			new TraderOffer(10, null, 75000),
			new TraderOffer(5, new TraderOffer.Resource(43, 1)),
			new TraderOffer(1, new TraderOffer.Resource(15, 1)),
			new TraderOffer(1, new TraderOffer.Resource(72, 30)),
			new TraderOffer(1, new TraderOffer.Resource(37, 5)),
			CalendarEvents.SkipQuestOffer
		};
		return calendarEventInfo;
	}
}
