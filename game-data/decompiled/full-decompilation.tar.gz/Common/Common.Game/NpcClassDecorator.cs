using Common.Account;
using Common.Resources;
using CommonDataTypes;
using TheraEngine.Helpers;

namespace Common.Game;

public readonly struct NpcClassDecorator
{
	private readonly NpcType _007B4046_007D;

	public bool IsBonusMap
	{
		get
		{
			NpcType npcType = _007B4046_007D;
			if ((uint)(npcType - 15) <= 1u)
			{
				return true;
			}
			return false;
		}
	}

	public bool CreateLootByDroppingChests => _007B4046_007D == NpcType.Empire_Legendary3l;

	public bool IsReinforcedType
	{
		get
		{
			switch (_007B4046_007D)
			{
			case NpcType.PirateFraction1_Reinforced:
			case NpcType.PirateFraction1_Fleet:
			case NpcType.PirateFraction2_Reinforced:
			case NpcType.PirateFraction2_Fleet:
			case NpcType.Trader_Ferryman:
			case NpcType.BonusMapBoss:
				return true;
			default:
				return false;
			}
		}
	}

	public bool IsPirate
	{
		get
		{
			NpcType npcType = _007B4046_007D;
			if ((uint)(npcType - 1) <= 5u)
			{
				return true;
			}
			return false;
		}
	}

	public bool IsPirateFr1
	{
		get
		{
			NpcType npcType = _007B4046_007D;
			if ((uint)(npcType - 1) <= 2u)
			{
				return true;
			}
			return false;
		}
	}

	public bool IsPirateFr2
	{
		get
		{
			NpcType npcType = _007B4046_007D;
			if ((uint)(npcType - 4) <= 2u)
			{
				return true;
			}
			return false;
		}
	}

	public bool IsTrader
	{
		get
		{
			NpcType npcType = _007B4046_007D;
			if ((uint)(npcType - 7) <= 1u)
			{
				return true;
			}
			return false;
		}
	}

	public bool IsEmpire
	{
		get
		{
			NpcType npcType = _007B4046_007D;
			if ((uint)(npcType - 10) <= 3u)
			{
				return true;
			}
			return false;
		}
	}

	public NpcIcon Icon
	{
		get
		{
			if (_007B4046_007D == NpcType.NyEventNpc)
			{
				return NpcIcon.Star;
			}
			NpcIcon result;
			if (_007B4046_007D == NpcType.HeadHunter)
			{
				result = NpcIcon.Skull;
			}
			else
			{
				NpcIcon npcIcon;
				if (_007B4046_007D == NpcType.Empire_Legendary3l)
				{
					npcIcon = NpcIcon.Legendary3l;
				}
				else
				{
					NpcIcon npcIcon2;
					if (_007B4046_007D == NpcType.Empire_Legendary2l)
					{
						npcIcon2 = NpcIcon.Legendary2l;
					}
					else
					{
						NpcIcon npcIcon3;
						if (IsReinforcedType)
						{
							npcIcon3 = NpcIcon.Star;
						}
						else
						{
							NpcType npcType = _007B4046_007D;
							bool flag = ((npcType == NpcType.PortPatrol || npcType == NpcType.Empire_Invasion) ? true : false);
							npcIcon3 = (flag ? NpcIcon.Blades : NpcIcon.None);
						}
						npcIcon2 = npcIcon3;
					}
					npcIcon = npcIcon2;
				}
				result = npcIcon;
			}
			return result;
		}
	}

	public bool ShowOnWorldMap
	{
		get
		{
			switch (_007B4046_007D)
			{
			case NpcType.PirateFraction1_Fleet:
			case NpcType.PirateFraction2_Fleet:
			case NpcType.Trader_Ferryman:
			case NpcType.Empire_Legendary2l:
			case NpcType.Empire_Legendary3l:
				return true;
			default:
				return false;
			}
		}
	}

	internal bool MoreRandomUpgrades
	{
		get
		{
			bool isReinforcedType = IsReinforcedType;
			bool flag = isReinforcedType;
			if (!flag)
			{
				NpcType npcType = _007B4046_007D;
				bool flag2 = (((uint)(npcType - 12) <= 1u || npcType == NpcType.HeadHunter) ? true : false);
				flag = flag2;
			}
			return flag;
		}
	}

	public float ReinforceCanonAngle => (MoreRandomUpgrades || IsReinforcedType) ? 10 : 0;

	public OpenWorldFlag Flags => (IsPirate || _007B4046_007D == NpcType.Fanatics) ? OpenWorldFlag.Pirate : (IsTrader ? OpenWorldFlag.Trader : ((_007B4046_007D == NpcType.PortPatrol) ? OpenWorldFlag.War : OpenWorldFlag.NoFlag));

	public bool WeakBehavior => (!MoreRandomUpgrades && _007B4046_007D != NpcType.PortPatrol && _007B4046_007D != NpcType.Fanatics) || _007B4046_007D == NpcType.Seafarer;

	public bool CanAttackNextPlayer => !IsTrader && _007B4046_007D != NpcType.SpecialNoReward && _007B4046_007D != NpcType.Seafarer && _007B4046_007D != NpcType.HeadHunter;

	public bool CanBeAgressiveToPeacePlayers
	{
		get
		{
			NpcType npcType = _007B4046_007D;
			if ((uint)(npcType - 1) <= 1u || (uint)(npcType - 4) <= 1u)
			{
				return true;
			}
			return false;
		}
	}

	public bool CanAttackTraderNpcs => IsPirate && IsReinforcedType;

	public bool CanTriggerWithQuestsAndLooting => CanBeAgressiveToPeacePlayers;

	public bool AlwaysAttackPlayersWithWantedLevel
	{
		get
		{
			NpcType npcType = _007B4046_007D;
			if (npcType == NpcType.PirateFraction1_Reinforced || npcType == NpcType.PirateFraction2_Reinforced)
			{
				return true;
			}
			return false;
		}
	}

	public bool CanRestoreBurning
	{
		get
		{
			NpcType npcType = _007B4046_007D;
			if ((uint)(npcType - 12) <= 2u)
			{
				return true;
			}
			return false;
		}
	}

	public bool ImprovedPresecutionDistance => IsReinforcedType || _007B4046_007D == NpcType.HeadHunter;

	public bool AlwaysReduceCollisionDamage
	{
		get
		{
			NpcType npcType = _007B4046_007D;
			if ((uint)(npcType - 12) <= 2u)
			{
				return true;
			}
			return false;
		}
	}

	public bool HideMaxCrewCount => _007B4046_007D == NpcType.Empire_Legendary3l;

	public float TtlsSec => (_007B4046_007D == NpcType.HeadHunter) ? 300f : (IsTrader ? (10800f * Rand.Range(0.8f, 1.2f)) : 0f);

	public float PowerupItemApplyChanse
	{
		get
		{
			if (_007B4046_007D == NpcType.Fanatics)
			{
				return 100f;
			}
			NpcType npcType = _007B4046_007D;
			bool flag = (uint)(npcType - 12) <= 1u;
			return flag ? 49.500004f : (IsReinforcedType ? 39.600002f : 0f);
		}
	}

	public int GetNextPowderKegId
	{
		get
		{
			NpcType npcType = _007B4046_007D;
			bool flag = (((uint)(npcType - 12) <= 1u || npcType == NpcType.BonusMapBoss) ? true : false);
			return flag ? Rand.Pick<int>(3, 2, 1) : (WeakBehavior ? 1 : Rand.Pick<int>(1, 2));
		}
	}

	public byte FreeFloatingSpeed
	{
		get
		{
			if (_007B4046_007D == NpcType.Trader_Ferryman)
			{
				return 1;
			}
			NpcType npcType = _007B4046_007D;
			bool flag = (uint)(npcType - 12) <= 1u;
			return (byte)(flag ? 3 : 2);
		}
	}

	public bool AllowCapture(WorldMapInfo? _007B4041_007D)
	{
		return !IsEmpire && _007B4046_007D != NpcType.PortPatrol && (_007B4041_007D == null || !_007B4041_007D.IsEnableArenaUi) && _007B4046_007D != NpcType.BonusMapBoss && _007B4046_007D != NpcType.NyEventNpc;
	}

	public float ExtraPortRadius(PortType _007B4042_007D, bool _007B4043_007D)
	{
		NpcType npcType = _007B4046_007D;
		if ((npcType == NpcType.PirateFraction1_Fleet || npcType == NpcType.PirateFraction2_Fleet) ? true : false)
		{
			return 500f;
		}
		if (IsReinforcedType)
		{
			return _007B4043_007D ? 500 : 400;
		}
		npcType = _007B4046_007D;
		if ((uint)(npcType - 12) <= 1u)
		{
			return 800f;
		}
		if (_007B4042_007D == PortType.PirateBay && IsTrader)
		{
			return 250f;
		}
		if (_007B4042_007D != PortType.PirateBay && IsPirate)
		{
			return 200f;
		}
		return 0f;
	}

	public string Description(FractionID? _007B4044_007D = null)
	{
		return (_007B4046_007D == NpcType.Empire_Legendary2l) ? Local.npc_Empire_Legendary_2lvl : ((_007B4046_007D == NpcType.Empire_Legendary3l) ? Local.npc_Empire_Legendary_3lvl : ((_007B4046_007D == NpcType.Empire_Regular) ? Local.npc_Empire_Regular : ((_007B4046_007D == NpcType.Empire_Invasion) ? Local.npc_Empire_Invasion : ((_007B4046_007D == NpcType.PirateFraction1_Regular) ? Local.npc_PirateFraction1_Regular : ((_007B4046_007D == NpcType.PirateFraction1_Reinforced) ? Local.npc_PirateFraction1_Reinforced : ((_007B4046_007D == NpcType.PirateFraction1_Fleet) ? Local.npc_PirateFraction1_Fleet : ((_007B4046_007D == NpcType.PirateFraction2_Regular) ? Local.npc_PirateFraction2_Regular : ((_007B4046_007D == NpcType.PirateFraction2_Reinforced) ? Local.npc_PirateFraction2_Reinforced : ((_007B4046_007D == NpcType.PirateFraction2_Fleet) ? Local.npc_PirateFraction2_Fleet : ((_007B4046_007D == NpcType.Trader_Regular) ? Local.npc_Trader_Regular : ((_007B4046_007D == NpcType.Trader_Ferryman) ? Local.npc_Trader_Ferryman : ((_007B4046_007D == NpcType.PortPatrol) ? Local.npc_PortPatrol(_007B4044_007D.GetValueOrDefault().GetName()) : ((_007B4046_007D == NpcType.Fanatics) ? Local.npc_Fanatics : ((_007B4046_007D == NpcType.Seafarer) ? Local.npc_Seafarer : ((_007B4046_007D == NpcType.HeadHunter) ? Local.npc_Headhunter : "")))))))))))))));
	}

	public NpcClassDecorator(NpcType _007B4045_007D)
	{
		_007B4046_007D = _007B4045_007D;
	}
}
