using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Resources;

namespace Common.Game;

public struct PbsTensityEffects
{
	[CompilerGenerated]
	private sealed class _003CGetAllEffectDescription_003Ed__13 : IEnumerable<string>, IEnumerable, IEnumerator<string>, IEnumerator, IDisposable
	{
		private int _007B7938_007D;

		private string _007B7939_007D;

		private int _007B7940_007D;

		private IslePortInfo _007B7941_007D;

		public IslePortInfo _003C_003E3__port;

		public PbsTensityEffects _003C_003E4__this;

		public PbsTensityEffects _003C_003E3___003C_003E4__this;

		string IEnumerator<string>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B7939_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B7939_007D;
			}
		}

		[DebuggerHidden]
		public _003CGetAllEffectDescription_003Ed__13(int _007B7933_007D)
		{
			_007B7938_007D = _007B7933_007D;
			_007B7940_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B7934_007D()
		{
			_007B7938_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7934}
			this._007B7934_007D();
		}

		private bool _007B7935_007D()
		{
			switch (_007B7938_007D)
			{
			default:
				return false;
			case 0:
				_007B7938_007D = -1;
				if (_003C_003E4__this.BlockFortWindowActions)
				{
					_007B7939_007D = Local.tensity_blockFort;
					_007B7938_007D = 1;
					return true;
				}
				goto IL_0067;
			case 1:
				_007B7938_007D = -1;
				goto IL_0067;
			case 2:
				_007B7938_007D = -1;
				goto IL_0091;
			case 3:
				_007B7938_007D = -1;
				goto IL_00bb;
			case 4:
				{
					_007B7938_007D = -1;
					break;
				}
				IL_0067:
				if (_003C_003E4__this.ReduceFactorySpeed)
				{
					_007B7939_007D = Local.tensity_facotrySpeedReduce;
					_007B7938_007D = 2;
					return true;
				}
				goto IL_0091;
				IL_00bb:
				if (_003C_003E4__this.DisableMooringCharge)
				{
					_007B7939_007D = Local.tensity_noMooring;
					_007B7938_007D = 4;
					return true;
				}
				break;
				IL_0091:
				if (_003C_003E4__this.DisableMonetization)
				{
					_007B7939_007D = Local.tensity_noMoney;
					_007B7938_007D = 3;
					return true;
				}
				goto IL_00bb;
			}
			return false;
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7935}
			return this._007B7935_007D();
		}

		[DebuggerHidden]
		private void _007B7936_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7936}
			this._007B7936_007D();
		}

		[DebuggerHidden]
		IEnumerator<string> IEnumerable<string>.GetEnumerator()
		{
			_003CGetAllEffectDescription_003Ed__13 _003CGetAllEffectDescription_003Ed__;
			if (_007B7938_007D == -2 && _007B7940_007D == Environment.CurrentManagedThreadId)
			{
				_007B7938_007D = 0;
				_003CGetAllEffectDescription_003Ed__ = this;
			}
			else
			{
				_003CGetAllEffectDescription_003Ed__ = new _003CGetAllEffectDescription_003Ed__13(0);
			}
			_003CGetAllEffectDescription_003Ed__._003C_003E4__this = _003C_003E3___003C_003E4__this;
			_003CGetAllEffectDescription_003Ed__._007B7941_007D = _003C_003E3__port;
			return _003CGetAllEffectDescription_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B7937_007D()
		{
			return ((IEnumerable<string>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7937}
			return this._007B7937_007D();
		}
	}

	public const float TensityToOpenHq = 0.45f;

	public readonly float Tensity;

	public bool BlockFortWindowActions => Tensity > 0.15f;

	public bool ReduceFactorySpeed => Tensity > 0.3f;

	public bool CanHqBeOpened => Tensity > 0.45f;

	public bool DisableMonetization => Tensity > 0.5f;

	public bool DisableMooringCharge => Tensity > 0.6f;

	public PbsTensityEffects(float _007B7930_007D)
	{
		Tensity = _007B7930_007D;
	}

	[IteratorStateMachine(typeof(_003CGetAllEffectDescription_003Ed__13))]
	public IEnumerable<string> GetAllEffectDescription(IslePortInfo _007B7931_007D)
	{
		//yield-return decompiler failed: Method not found
		return new _003CGetAllEffectDescription_003Ed__13(-2)
		{
			_003C_003E3___003C_003E4__this = this,
			_003C_003E3__port = _007B7931_007D
		};
	}
}
