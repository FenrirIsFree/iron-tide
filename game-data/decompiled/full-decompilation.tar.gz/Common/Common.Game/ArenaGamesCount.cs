using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct ArenaGamesCount : IMPSerializable
{
	public byte Format;

	public byte[] Data;

	public int TotalCountRunGames
	{
		get
		{
			if (Format == 0)
			{
				return 0;
			}
			if (Format == 2)
			{
				return Data[0];
			}
			int num = Data.Length / 2;
			int num2 = 0;
			for (int i = 0; i < num; i++)
			{
				num2 += Data[i];
			}
			return num2;
		}
	}

	public int TotalCountWaitGames
	{
		get
		{
			if (Format == 0)
			{
				return 0;
			}
			if (Format == 2)
			{
				return Data[1];
			}
			int num = Data.Length / 2;
			int num2 = 0;
			for (int i = num; i < Data.Length; i++)
			{
				num2 += Data[i];
			}
			return num2;
		}
	}

	public ArenaGamesCount()
	{
		Format = 0;
		Data = Array.Empty<byte>();
	}

	public ArenaGamesCount(int _007B6908_007D, int _007B6909_007D)
	{
		Format = 2;
		Data = new byte[2]
		{
			(byte)_007B6909_007D,
			(byte)_007B6908_007D
		};
	}

	public ArenaGamesCount(int[] _007B6910_007D, int[] _007B6911_007D)
	{
		Format = (byte)(_007B6910_007D.Length + _007B6911_007D.Length);
		Data = new byte[Format];
		int num = Format / 2;
		for (int i = 0; i < Format; i++)
		{
			if (i < num)
			{
				Data[i] = (byte)_007B6910_007D[i];
			}
			else
			{
				Data[i] = (byte)_007B6911_007D[i - num];
			}
		}
	}

	public int CountRunGames(int _007B6912_007D)
	{
		return (Format != 0 && _007B6912_007D < Data.Length) ? Data[_007B6912_007D] : 0;
	}

	public int CountWaitGames(int _007B6913_007D)
	{
		return (Format != 0 && _007B6913_007D + Format / 2 < Data.Length) ? Data[_007B6913_007D + Format / 2] : 0;
	}

	private void _007B6914_007D(WriterExtern _007B6915_007D)
	{
		_007B6915_007D.WriteByte(Format);
		_007B6915_007D.WriteByteConstSize(Data);
	}

	private void _007B6916_007D(WriterExtern _007B6917_007D)
	{
		Format = _007B6917_007D.ReadByte();
		_007B6917_007D.ReadByte(ref Data, (int)Format);
	}

	public override bool Equals([NotNullWhen(true)] object? _007B6918_007D)
	{
		if (_007B6918_007D is ArenaGamesCount arenaGamesCount)
		{
			return arenaGamesCount.Format == Format && arenaGamesCount.Data.Length == Data.Length && arenaGamesCount.Data.SequenceEqual(Data);
		}
		return false;
	}
}
