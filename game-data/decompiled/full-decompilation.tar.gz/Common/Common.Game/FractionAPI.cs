using System;
using Common.Account;
using Common.Packets;
using Common.Resources;
using CommonDataTypes;
using Microsoft.Xna.Framework.Graphics;

namespace Common.Game;

public static class FractionAPI
{
	public const float RelationReputationThreshold = 33f;

	public const float KickAlertReputationThreshold = 10f;

	private const string pathToIcons = "_lzcommon\\Items\\Fractions\\fraction_icon_";

	private static Texture2D?[] fractionIcons;

	private static Texture2D?[] fractionIconsWithBack;

	public static bool IgnoreMembersCountRestriction { get; set; }

	public static int ChangeAgainRestrictionDays(FractionID _007B8571_007D, FractionID _007B8572_007D)
	{
		if (_007B8572_007D == FractionID.None)
		{
			return 10;
		}
		if ((_007B8571_007D == FractionID.Pirate && _007B8572_007D == FractionID.TradeUnion) || (_007B8571_007D == FractionID.TradeUnion && _007B8572_007D == FractionID.Pirate))
		{
			return 20;
		}
		if (_007B8571_007D.IsNation())
		{
			return 20;
		}
		return 1;
	}

	public static bool CanChangeFraction(this GuildCommon _007B8573_007D, PortCaputreStatusList _007B8574_007D, FractionID _007B8575_007D, out string _007B8576_007D)
	{
		if (_007B8573_007D.Fraction.IsNation() && _007B8575_007D.IsNation() && _007B8573_007D.Treasury < 5000)
		{
			_007B8576_007D = $"{Local.gold_ingots_not_enough} ({_007B8573_007D.Treasury}/{5000})";
			return false;
		}
		if (_007B8575_007D.IsNation())
		{
			if (_007B8573_007D.ConquerBadges < 25)
			{
				_007B8576_007D = $"{Local.conquer_badges_not_enough} ({_007B8573_007D.ConquerBadges}/{25})";
				return false;
			}
			int num = GuildCommon.MinMembersForNation(_007B8574_007D.FractionBonusHelper(_007B8575_007D));
			if (!IgnoreMembersCountRestriction && _007B8573_007D.Members.Size < num)
			{
				_007B8576_007D = $"{Local.members_not_enough} ({_007B8573_007D.Members.Size}/{num})";
				return false;
			}
		}
		_007B8576_007D = "";
		return !_007B8573_007D.IsFlotilia;
	}

	public static Relation GeneralStatusWith(in Decorator _007B8577_007D, GuildShortInfo _007B8578_007D, PlayerReputations _007B8579_007D)
	{
		if (_007B8577_007D.guild == null || _007B8577_007D.guild.IsFlotilia)
		{
			if (_007B8578_007D.IsNull || _007B8578_007D.IsFlotilia)
			{
				return _007B8577_007D.account.Reputations.NeutralStatusWith(_007B8579_007D);
			}
			if (_007B8578_007D.Fraction == FractionID.Pirate)
			{
				return Relation.Enemy;
			}
			return _007B8577_007D.account.Reputations.NeutralStatusWith(_007B8578_007D.Fraction);
		}
		if (_007B8578_007D.IsNull || _007B8578_007D.IsFlotilia)
		{
			return _007B8579_007D.NeutralStatusWith(_007B8577_007D.guild.Fraction);
		}
		return StatusWith(_007B8577_007D.guild, _007B8578_007D);
	}

	public static Relation StatusWith(GuildCommon? _007B8580_007D, GuildCommon? _007B8581_007D, Relation _007B8582_007D = Relation.Neutral)
	{
		if (_007B8580_007D == null || _007B8581_007D == null)
		{
			return _007B8582_007D;
		}
		if (_007B8580_007D.IsFlotilia || _007B8581_007D.IsFlotilia)
		{
			return Relation.Neutral;
		}
		return (!(_007B8580_007D.Tag == _007B8581_007D.Tag) && (!_007B8580_007D.IsTrusted(_007B8581_007D.Tag) || !_007B8581_007D.IsTrusted(_007B8580_007D.Tag))) ? StatusWith(_007B8580_007D.Fraction, _007B8581_007D.Fraction) : Relation.Ally;
	}

	public static Relation StatusWith(GuildCommon _007B8583_007D, GuildShortInfo _007B8584_007D)
	{
		if (_007B8583_007D.IsFlotilia || _007B8584_007D.IsFlotilia)
		{
			return Relation.Neutral;
		}
		return (!_007B8583_007D.IsTrusted(_007B8584_007D.Tag) && !(_007B8583_007D.Tag == _007B8584_007D.Tag)) ? StatusWith(_007B8583_007D.Fraction, _007B8584_007D.Fraction) : Relation.Ally;
	}

	public static Relation StatusWith(FractionID _007B8585_007D, FractionID _007B8586_007D)
	{
		if (_007B8585_007D == FractionID.None || _007B8586_007D == FractionID.None)
		{
			return Relation.Neutral;
		}
		if (_007B8585_007D == FractionID.TradeUnion && _007B8586_007D == FractionID.TradeUnion)
		{
			return Relation.Ally;
		}
		if (_007B8585_007D == FractionID.Pirate || _007B8586_007D == FractionID.Pirate)
		{
			return Relation.Enemy;
		}
		if (_007B8585_007D == FractionID.Empire || _007B8586_007D == FractionID.Empire)
		{
			return (_007B8585_007D != _007B8586_007D) ? Relation.Enemy : Relation.Ally;
		}
		bool flag = FractionDecorator.Nations.Contains(_007B8585_007D);
		bool flag2 = FractionDecorator.Nations.Contains(_007B8586_007D);
		if (flag)
		{
			return NationNonNationTest(_007B8585_007D, _007B8586_007D);
		}
		if (flag2)
		{
			return NationNonNationTest(_007B8586_007D, _007B8585_007D);
		}
		return Relation.Neutral;
	}

	public static Texture2D? GetFractionIcon(FractionID _007B8587_007D)
	{
		return fractionIcons[(int)_007B8587_007D];
	}

	public static Texture2D? GetFractionIconWithBack(FractionID _007B8588_007D)
	{
		return fractionIconsWithBack[(int)_007B8588_007D];
	}

	public static void LoadIcons()
	{
		Array values = Enum.GetValues(typeof(FractionID));
		fractionIcons = (Texture2D?[])(object)new Texture2D[values.Length];
		fractionIconsWithBack = (Texture2D?[])(object)new Texture2D[values.Length];
		foreach (int item in values)
		{
			FractionID fractionID = (FractionID)item;
			if (fractionID == FractionID.None)
			{
				fractionIcons[item] = null;
				continue;
			}
			Texture2D val = CommonGlobal.CommonDataContent.Load<Texture2D>($"{"_lzcommon\\Items\\Fractions\\fraction_icon_"}{fractionID}");
			fractionIcons[item] = val;
			Texture2D val2 = CommonGlobal.CommonDataContent.Load<Texture2D>($"{"_lzcommon\\Items\\Fractions\\fraction_icon_"}{fractionID}_withBack");
			fractionIconsWithBack[item] = val2;
		}
	}

	private static Relation NationNonNationTest(FractionID _007B8589_007D, FractionID _007B8590_007D)
	{
		switch (_007B8590_007D)
		{
		case FractionID.TradeUnion:
			return Relation.Neutral;
		default:
			if (_007B8590_007D != FractionID.Empire)
			{
				return (_007B8589_007D != _007B8590_007D) ? Relation.Enemy : Relation.Ally;
			}
			goto case FractionID.Pirate;
		case FractionID.Pirate:
			return Relation.Enemy;
		}
	}

	public static PlayerReputations.ChangeReputation GetReputationChangeForQuest(Decorator _007B8591_007D, QuestInfo _007B8592_007D)
	{
		if (_007B8592_007D.LocationPort == null || _007B8592_007D.DisableReputation || (_007B8591_007D.MapMyFraction ?? FractionID.Antilia) == FractionID.Pirate)
		{
			return default(PlayerReputations.ChangeReputation);
		}
		if (_007B8592_007D.LocationPort != null && _007B8592_007D.LocationPort.Type == PortType.NeutralBay)
		{
			return new PlayerReputations.ChangeReputation(FractionID.None, 1f, _007B8674_007D: false);
		}
		FractionID capturerFraction = _007B8591_007D.SafeGetPortStatus(_007B8592_007D.LocationPort.PortID).CapturerFraction;
		QuestCompany company = _007B8592_007D.Company;
		bool flag = (uint)company <= 2u;
		if (flag && capturerFraction.IsNation())
		{
			return new PlayerReputations.ChangeReputation(capturerFraction, 1f, _007B8674_007D: false);
		}
		return default(PlayerReputations.ChangeReputation);
	}

	public static void ChangeReputationWhenQuestComplete(Decorator _007B8593_007D, QuestInfo _007B8594_007D)
	{
		PlayerReputations.ChangeReputation reputationChangeForQuest = GetReputationChangeForQuest(_007B8593_007D, _007B8594_007D);
		FractionID fractionID = ((reputationChangeForQuest.Fraction == FractionID.None) ? _007B8593_007D.account.FractionToRepChange : reputationChangeForQuest.Fraction);
		if (reputationChangeForQuest.Amount != 0f && fractionID != FractionID.None)
		{
			_007B8593_007D.account.Reputations.Change(new PlayerReputations.ChangeReputation(fractionID, reputationChangeForQuest.Amount, reputationChangeForQuest.MirrorOnOthers), _007B8593_007D.account, _007B8593_007D.guild);
		}
	}

	public static Relation NeutralStatusWith(this PlayerReputations _007B8595_007D, FractionID _007B8596_007D)
	{
		if (_007B8596_007D == FractionID.Pirate || _007B8596_007D == FractionID.TradeUnion)
		{
			return Relation.Neutral;
		}
		if (_007B8596_007D.IsNation())
		{
			return (!(_007B8595_007D[_007B8596_007D] >= 33f)) ? ((_007B8595_007D[_007B8596_007D] <= -33f) ? Relation.Enemy : Relation.Neutral) : Relation.Ally;
		}
		return Relation.Neutral;
	}

	public static Relation NeutralStatusWith(this PlayerReputations _007B8597_007D, PlayerReputations _007B8598_007D)
	{
		return Relation.Neutral;
	}

	internal static float ValidateReputation(FractionID _007B8599_007D, float _007B8600_007D, PlayerAccount _007B8601_007D, GuildCommon? _007B8602_007D)
	{
		if (_007B8601_007D.Rang <= 10)
		{
			_007B8600_007D = Math.Max(-32f, _007B8600_007D);
		}
		if (_007B8602_007D != null)
		{
			if (_007B8602_007D.Fraction == FractionID.Pirate)
			{
				_007B8600_007D = Math.Min(_007B8600_007D, -34f);
			}
			else if (_007B8602_007D.Fraction.IsNation() && _007B8599_007D.IsNation() && _007B8599_007D != _007B8602_007D.Fraction)
			{
				_007B8600_007D = -100f;
			}
		}
		return _007B8600_007D;
	}

	public static PlayerReputations.ChangeReputation GetKillReputation(Decorator _007B8603_007D, Ship _007B8604_007D, GuildCommon _007B8605_007D, bool _007B8606_007D)
	{
		if (_007B8603_007D.ship.MirrorEngageInPortBattlePortID != -1 || _007B8604_007D is Player { MirrorEngageInPortBattlePortID: not -1 } || _007B8604_007D.IsOutsideSeam)
		{
			return default(PlayerReputations.ChangeReputation);
		}
		if (_007B8606_007D)
		{
			return default(PlayerReputations.ChangeReputation);
		}
		if (_007B8604_007D is Npc npc && _007B8604_007D.NearAquatoria != null && npc.UsedShipNpc.Information.Descritpion == NpcType.PortPatrol && FractionDecorator.Nations.Contains(_007B8603_007D.NearPortGuild.Fraction))
		{
			return new PlayerReputations.ChangeReputation(_007B8603_007D.NearPortGuild.Fraction, -1f);
		}
		if (_007B8604_007D is Player player2)
		{
			if (player2.AccountConnection.WorldFlag.HideNicknameAndGuild(player2))
			{
				return default(PlayerReputations.ChangeReputation);
			}
			int num = (int)Math.Floor(player2.ResourcesOfHold.ComputeMass<ResourceInfo>() / 12500f);
			if (_007B8605_007D != null && !_007B8605_007D.IsFlotilia)
			{
				if (_007B8605_007D.Fraction == FractionID.TradeUnion)
				{
					return new PlayerReputations.ChangeReputation(FractionID.TradeUnion, -(1 + num), _007B8674_007D: false);
				}
				if (_007B8605_007D.Fraction.IsNation())
				{
					if (_007B8605_007D.Fraction == _007B8603_007D.guild?.Fraction)
					{
						num++;
					}
					return new PlayerReputations.ChangeReputation(_007B8605_007D.Fraction, -(3 + num));
				}
				if (_007B8605_007D.Fraction == FractionID.Pirate)
				{
					if (_007B8603_007D.guild != null && _007B8603_007D.guild.Fraction.IsNation())
					{
						return new PlayerReputations.ChangeReputation(_007B8603_007D.guild.Fraction, 1f, _007B8674_007D: false);
					}
					return new PlayerReputations.ChangeReputation(FractionID.TradeUnion, 1f, _007B8674_007D: false);
				}
			}
			else
			{
				if (_007B8603_007D.guild == null || _007B8603_007D.guild.IsFlotilia)
				{
					return default(PlayerReputations.ChangeReputation);
				}
				switch (player2.AccountConnection.Reputations.NeutralStatusWith(_007B8603_007D.guild.Fraction))
				{
				case Relation.Ally:
					return new PlayerReputations.ChangeReputation(_007B8603_007D.guild.Fraction, -(3 + num));
				case Relation.Neutral:
					return new PlayerReputations.ChangeReputation(FractionID.TradeUnion, -(1 + num));
				}
			}
		}
		return default(PlayerReputations.ChangeReputation);
	}

	public static KillCase WillGetBlackMark(in Decorator _007B8607_007D, Relation _007B8608_007D, Player _007B8609_007D, OpenWorldFlag _007B8610_007D, bool _007B8611_007D, bool _007B8612_007D, bool _007B8613_007D, bool _007B8614_007D, out bool _007B8615_007D, out bool _007B8616_007D, out bool _007B8617_007D)
	{
		_007B8615_007D = false;
		_007B8616_007D = false;
		_007B8617_007D = false;
		if (_007B8608_007D == Relation.Ally)
		{
			return KillCase.PlayerAlly;
		}
		if (_007B8607_007D.ship.MirrorEngageInPortBattlePortID != -1 || _007B8609_007D.MirrorEngageInPortBattlePortID != -1)
		{
			_007B8615_007D = true;
			return KillCase.Player;
		}
		if (_007B8610_007D.IsPeaceMode() || _007B8607_007D.ship.IsOutsideSeam || _007B8609_007D.IsOutsideSeam)
		{
			_007B8615_007D = true;
			_007B8616_007D = true;
			return KillCase.Player;
		}
		if (_007B8614_007D)
		{
			_007B8615_007D = true;
			_007B8616_007D = true;
			return KillCase.Player;
		}
		int rank = _007B8607_007D.account.Shipyard.CurrentRealShip.CraftFrom.Rank;
		int num = _007B8609_007D.CraftFrom.Rank;
		if (num > rank && _007B8609_007D.CraftFrom.Coolness == PlayerShipCoolness.Elite)
		{
			num--;
		}
		FractionID? mapMyFraction = _007B8607_007D.MapMyFraction;
		if ((!mapMyFraction.HasValue || mapMyFraction.GetValueOrDefault() == FractionID.Pirate) ? true : false)
		{
			if (num - rank >= 2)
			{
				_007B8617_007D = true;
				return KillCase.PlayerShipDiff;
			}
			if (_007B8611_007D)
			{
				_007B8616_007D = true;
				_007B8615_007D = true;
				_007B8617_007D = true;
				return KillCase.PlayerNeutral;
			}
		}
		else if (_007B8608_007D != Relation.Enemy)
		{
			_007B8616_007D = false;
			_007B8615_007D = false;
			if (num - rank >= 2)
			{
				_007B8617_007D = true;
				return KillCase.PlayerShipDiff;
			}
			return KillCase.Player;
		}
		if (_007B8612_007D && !_007B8613_007D)
		{
			_007B8617_007D = true;
			return KillCase.PlayerEvent;
		}
		_007B8616_007D = true;
		_007B8615_007D = true;
		return KillCase.Player;
	}

	public static KillCase MatchBlackMark(in Decorator _007B8618_007D, in Decorator _007B8619_007D, bool _007B8620_007D, bool _007B8621_007D, bool _007B8622_007D, out bool _007B8623_007D, out bool _007B8624_007D, out bool _007B8625_007D)
	{
		Relation _007B8608_007D = GeneralStatusWith(in _007B8618_007D, new GuildShortInfo(_007B8619_007D.guild), _007B8619_007D.account.Reputations);
		return WillGetBlackMark(in _007B8618_007D, _007B8608_007D, _007B8619_007D.ship, _007B8619_007D.account.WorldFlag, _007B8619_007D.guild == null || _007B8619_007D.guild.IsFlotilia, _007B8620_007D, _007B8621_007D, _007B8622_007D, out _007B8623_007D, out _007B8624_007D, out _007B8625_007D);
	}
}
