using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Common.Account;
using Common.Resources;
using CommonDataTypes;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework.Graphics;
using TheraEngine;
using TheraEngine.Collections;
using World_Of_Sea_Battle.Constants;

namespace Common.Game;

public class ComplexBonus : IMPSerializable
{
	public enum AnnotationKey
	{
		Gold,
		GoldForGuild,
		Item,
		Xp,
		XpForShips,
		LegendaryFlag,
		RandomDesign,
		SpecificDesign,
		Ship,
		Achievement,
		ConquerorBadges,
		EducationFlag,
		Cannon,
		Unit,
		UnknownUnit,
		Monets,
		Ball,
		PowderKeg,
		HoldProtection,
		Rank,
		ArenaCurrency,
		CraftTime
	}

	public struct Annotation
	{
		public int ID;

		public string Text;

		public AnnotationKey Key;

		public Texture2D CustomIcon;

		public Annotation(int _007B5320_007D, string _007B5321_007D, AnnotationKey _007B5322_007D, Texture2D _007B5323_007D)
		{
			ID = _007B5320_007D;
			Text = _007B5321_007D;
			Key = _007B5322_007D;
			CustomIcon = _007B5323_007D;
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _003C_003Ec__DisplayClass32_0
	{
		public ComplexBonus _003C_003E4__this;

		public float useMultiplier;

		public bool takePremium;

		public string s;
	}

	[CompilerGenerated]
	private sealed class _003CDisplayText_003Ed__32 : IEnumerable<Annotation>, IEnumerable, IEnumerator<Annotation>, IEnumerator, IDisposable
	{
		private int _007B5340_007D;

		private Annotation _007B5341_007D;

		private int _007B5342_007D;

		private float _007B5343_007D;

		public float _003C_003E3__useMultiplier;

		private bool _007B5344_007D;

		public bool _003C_003E3__takePremium;

		public ComplexBonus _003C_003E4__this;

		private _003C_003Ec__DisplayClass32_0 _007B5345_007D;

		private IEnumerator<GSILocalEnumerablePair<ResourceInfo>> _007B5346_007D;

		private GSILocalEnumerablePair<ResourceInfo> _007B5347_007D;

		private IEnumerator<GSILocalEnumerablePair<CannonBallInfo>> _007B5348_007D;

		private GSILocalEnumerablePair<CannonBallInfo> _007B5349_007D;

		private IEnumerator<GSILocalEnumerablePair<PowderKegInfo>> _007B5350_007D;

		private GSILocalEnumerablePair<PowderKegInfo> _007B5351_007D;

		private IEnumerator<GSILocalEnumerablePair<CannonGameInfo>> _007B5352_007D;

		private GSILocalEnumerablePair<CannonGameInfo> _007B5353_007D;

		private IEnumerator<GSILocalEnumerablePair<UnitInfo>> _007B5354_007D;

		private GSILocalEnumerablePair<UnitInfo> _007B5355_007D;

		private IEnumerator<UnitInfo> _007B5356_007D;

		private UnitInfo _007B5357_007D;

		private Tlist<ShipDesignCategory> _007B5358_007D;

		private string _007B5359_007D;

		private string _007B5360_007D;

		private IEnumerator<GSILocalEnumerablePair<ShipDesignInfo>> _007B5361_007D;

		private GSILocalEnumerablePair<ShipDesignInfo> _007B5362_007D;

		private IEnumerator<ShipDesignCategory> _007B5363_007D;

		private ShipDesignCategory _007B5364_007D;

		private IEnumerator<GSILocalEnumerablePair<ShipDesignInfo>> _007B5365_007D;

		private GSILocalEnumerablePair<ShipDesignInfo> _007B5366_007D;

		private string _007B5367_007D;

		private IEnumerator<int> _007B5368_007D;

		private int _007B5369_007D;

		private PlayerShipInfo _007B5370_007D;

		private string _007B5371_007D;

		private IEnumerator<AchievementEnum> _007B5372_007D;

		private AchievementEnum _007B5373_007D;

		private AchievementDisplayInfo _007B5374_007D;

		private IEnumerator<GSILocalEnumerablePair<PowerupItemInfo>> _007B5375_007D;

		private GSILocalEnumerablePair<PowerupItemInfo> _007B5376_007D;

		Annotation IEnumerator<Annotation>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B5341_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B5341_007D;
			}
		}

		[DebuggerHidden]
		public _003CDisplayText_003Ed__32(int _007B5325_007D)
		{
			_007B5340_007D = _007B5325_007D;
			_007B5342_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B5326_007D()
		{
			switch (_007B5340_007D)
			{
			case -3:
			case 7:
				try
				{
				}
				finally
				{
					_007B5328_007D();
				}
				break;
			case -4:
			case 8:
				try
				{
				}
				finally
				{
					_007B5329_007D();
				}
				break;
			case -5:
			case 9:
				try
				{
				}
				finally
				{
					_007B5330_007D();
				}
				break;
			case -6:
			case 10:
				try
				{
				}
				finally
				{
					_007B5331_007D();
				}
				break;
			case -7:
			case 11:
				try
				{
				}
				finally
				{
					_007B5332_007D();
				}
				break;
			case -8:
			case 12:
				try
				{
				}
				finally
				{
					_007B5333_007D();
				}
				break;
			case -9:
			case 15:
				try
				{
				}
				finally
				{
					_007B5334_007D();
				}
				break;
			case -10:
			case 16:
				try
				{
				}
				finally
				{
					_007B5335_007D();
				}
				break;
			case -11:
			case 20:
				try
				{
				}
				finally
				{
					_007B5336_007D();
				}
				break;
			case -12:
			case 21:
				try
				{
				}
				finally
				{
					_007B5337_007D();
				}
				break;
			}
			_007B5345_007D = default(_003C_003Ec__DisplayClass32_0);
			_007B5346_007D = null;
			_007B5347_007D = default(GSILocalEnumerablePair<ResourceInfo>);
			_007B5348_007D = null;
			_007B5349_007D = default(GSILocalEnumerablePair<CannonBallInfo>);
			_007B5350_007D = null;
			_007B5351_007D = default(GSILocalEnumerablePair<PowderKegInfo>);
			_007B5352_007D = null;
			_007B5353_007D = default(GSILocalEnumerablePair<CannonGameInfo>);
			_007B5354_007D = null;
			_007B5355_007D = default(GSILocalEnumerablePair<UnitInfo>);
			_007B5356_007D = null;
			_007B5357_007D = null;
			_007B5358_007D = null;
			_007B5359_007D = null;
			_007B5360_007D = null;
			_007B5361_007D = null;
			_007B5362_007D = default(GSILocalEnumerablePair<ShipDesignInfo>);
			_007B5363_007D = null;
			_007B5365_007D = null;
			_007B5366_007D = default(GSILocalEnumerablePair<ShipDesignInfo>);
			_007B5367_007D = null;
			_007B5368_007D = null;
			_007B5370_007D = null;
			_007B5371_007D = null;
			_007B5372_007D = null;
			_007B5374_007D = null;
			_007B5375_007D = null;
			_007B5376_007D = default(GSILocalEnumerablePair<PowerupItemInfo>);
			_007B5340_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {5326}
			this._007B5326_007D();
		}

		private bool _007B5327_007D()
		{
			try
			{
				switch (_007B5340_007D)
				{
				default:
					return false;
				case 0:
					_007B5340_007D = -1;
					_007B5345_007D._003C_003E4__this = _003C_003E4__this;
					_007B5345_007D.useMultiplier = _007B5343_007D;
					_007B5345_007D.takePremium = _007B5344_007D;
					_007B5345_007D.s = GetBonusPostfix(_007B5345_007D.useMultiplier);
					if (_003C_003E4__this.Gold.Value > 0)
					{
						_007B5341_007D = new Annotation(0, "+" + _003C_003E4__this._007B5302_007D(_003C_003E4__this.Gold.Value, Local.complexBonus_gold, _007B5345_007D.useMultiplier, _007B5345_007D.takePremium) + _007B5345_007D.s, AnnotationKey.Gold, null);
						_007B5340_007D = 1;
						return true;
					}
					goto IL_0227;
				case 1:
					_007B5340_007D = -1;
					goto IL_0227;
				case 2:
					_007B5340_007D = -1;
					goto IL_02ad;
				case 3:
					_007B5340_007D = -1;
					goto IL_0308;
				case 4:
					_007B5340_007D = -1;
					goto IL_0394;
				case 5:
					_007B5340_007D = -1;
					goto IL_0420;
				case 6:
					_007B5340_007D = -1;
					goto IL_047c;
				case 7:
					_007B5340_007D = -3;
					_007B5347_007D = default(GSILocalEnumerablePair<ResourceInfo>);
					goto IL_04fd;
				case 8:
					_007B5340_007D = -4;
					_007B5349_007D = default(GSILocalEnumerablePair<CannonBallInfo>);
					goto IL_059a;
				case 9:
					_007B5340_007D = -5;
					_007B5351_007D = default(GSILocalEnumerablePair<PowderKegInfo>);
					goto IL_0638;
				case 10:
					_007B5340_007D = -6;
					_007B5353_007D = default(GSILocalEnumerablePair<CannonGameInfo>);
					goto IL_0716;
				case 11:
					_007B5340_007D = -7;
					_007B5355_007D = default(GSILocalEnumerablePair<UnitInfo>);
					goto IL_07e8;
				case 12:
					_007B5340_007D = -8;
					_007B5357_007D = null;
					goto IL_0899;
				case 13:
					_007B5340_007D = -1;
					goto IL_08ef;
				case 14:
					_007B5340_007D = -1;
					_007B5358_007D = null;
					_007B5359_007D = null;
					_007B5360_007D = null;
					goto IL_0bed;
				case 15:
					_007B5340_007D = -9;
					_007B5367_007D = null;
					_007B5366_007D = default(GSILocalEnumerablePair<ShipDesignInfo>);
					goto IL_0bce;
				case 16:
					_007B5340_007D = -10;
					_007B5370_007D = null;
					_007B5371_007D = null;
					goto IL_0cc5;
				case 17:
					_007B5340_007D = -1;
					goto IL_0d3a;
				case 18:
					_007B5340_007D = -1;
					goto IL_0d99;
				case 19:
					_007B5340_007D = -1;
					goto IL_0df1;
				case 20:
					_007B5340_007D = -11;
					_007B5374_007D = null;
					goto IL_0e8c;
				case 21:
					_007B5340_007D = -12;
					_007B5376_007D = default(GSILocalEnumerablePair<PowerupItemInfo>);
					goto IL_0f86;
				case 22:
					_007B5340_007D = -1;
					goto IL_0fe1;
				case 23:
					_007B5340_007D = -1;
					goto IL_1023;
				case 24:
					_007B5340_007D = -1;
					goto IL_1065;
				case 25:
					_007B5340_007D = -1;
					goto IL_10a7;
				case 26:
					_007B5340_007D = -1;
					goto IL_10e9;
				case 27:
					_007B5340_007D = -1;
					goto IL_112b;
				case 28:
					_007B5340_007D = -1;
					goto IL_117f;
				case 29:
					_007B5340_007D = -1;
					goto IL_11d6;
				case 30:
					_007B5340_007D = -1;
					goto IL_1251;
				case 31:
					_007B5340_007D = -1;
					goto IL_12a9;
				case 32:
					_007B5340_007D = -1;
					goto IL_1355;
				case 33:
					{
						_007B5340_007D = -1;
						break;
					}
					IL_1023:
					if (_003C_003E4__this.SetEducationFlags.Contains(EducationOnboarding.InitialQuest_OpenDaily))
					{
						_007B5341_007D = new Annotation(0, Local.eq_extra_2, AnnotationKey.EducationFlag, null);
						_007B5340_007D = 24;
						return true;
					}
					goto IL_1065;
					IL_0227:
					if (_003C_003E4__this.Monets.Value > 0)
					{
						_007B5341_007D = new Annotation(0, "+" + _003C_003E4__this._007B5302_007D(_003C_003E4__this.Monets.Value, Local.complexBonus_monets, _007B5345_007D.useMultiplier, _007B5345_007D.takePremium) + _007B5345_007D.s, AnnotationKey.Monets, null);
						_007B5340_007D = 2;
						return true;
					}
					goto IL_02ad;
					IL_0bce:
					if (_007B5365_007D.MoveNext())
					{
						_007B5366_007D = _007B5365_007D.Current;
						_007B5367_007D = ((_007B5366_007D.Info.Category == ShipDesignCategory.ShipFullDesign) ? (Local.design + " ") : "");
						_007B5341_007D = new Annotation(_007B5366_007D.Info.ID, _007B5367_007D + _007B5366_007D.Info.Name, AnnotationKey.SpecificDesign, null);
						_007B5340_007D = 15;
						return true;
					}
					_007B5334_007D();
					_007B5365_007D = null;
					goto IL_0bed;
					IL_02ad:
					if (_003C_003E4__this.GoldToGuildServer > 0)
					{
						_007B5341_007D = new Annotation(0, "+" + _003C_003E4__this.GoldToGuildServer + " " + Local.complexBonus_goldGuild, AnnotationKey.GoldForGuild, null);
						_007B5340_007D = 3;
						return true;
					}
					goto IL_0308;
					IL_112b:
					if (_003C_003E4__this.SetEducationFlags.Contains(EducationOnboarding.InitialQuest_DisplayMoreBranchXp))
					{
						_007B5341_007D = new Annotation(0, Local.eq_extra_4((int)(Gameplay.ResearchBonus(1) * 100f)), AnnotationKey.EducationFlag, null);
						_007B5340_007D = 28;
						return true;
					}
					goto IL_117f;
					IL_0308:
					if (_003C_003E4__this.Xp.Value > 0)
					{
						_007B5341_007D = new Annotation(0, "+" + _003C_003E4__this._007B5302_007D(_003C_003E4__this.Xp.Value, Local.xp_2, _007B5345_007D.useMultiplier, _007B5345_007D.takePremium) + " " + _007B5345_007D.s, AnnotationKey.Xp, null);
						_007B5340_007D = 4;
						return true;
					}
					goto IL_0394;
					IL_0bed:
					_007B5368_007D = ((IEnumerable<int>)_003C_003E4__this.ShipIds).GetEnumerator();
					_007B5340_007D = -10;
					goto IL_0cc5;
					IL_0394:
					if (_003C_003E4__this.ShipXp.Value > 0)
					{
						_007B5341_007D = new Annotation(0, "+" + _003C_003E4__this._007B5302_007D(_003C_003E4__this.ShipXp.Value, Local.ships_xp, _007B5345_007D.useMultiplier, _007B5345_007D.takePremium) + " " + _007B5345_007D.s, AnnotationKey.XpForShips, null);
						_007B5340_007D = 5;
						return true;
					}
					goto IL_0420;
					IL_0cc5:
					if (_007B5368_007D.MoveNext())
					{
						_007B5369_007D = _007B5368_007D.Current;
						_007B5370_007D = Gameplay.PlayersInfo.FromID(_007B5369_007D);
						_007B5371_007D = (_007B5370_007D.StaticInfo.IsBalloon ? (Local.subclass_balloon + " ") : Local.ship);
						_007B5341_007D = new Annotation(_007B5370_007D.ID, _007B5371_007D + _007B5370_007D.ShipName, AnnotationKey.Ship, _007B5370_007D.IconTexture);
						_007B5340_007D = 16;
						return true;
					}
					_007B5335_007D();
					_007B5368_007D = null;
					if (_003C_003E4__this.LegendaryFlagDays.Value > 0)
					{
						_007B5341_007D = new Annotation(0, Local.complexBonus_legFlagDays(_003C_003E4__this.LegendaryFlagDays.Value), AnnotationKey.LegendaryFlag, null);
						_007B5340_007D = 17;
						return true;
					}
					goto IL_0d3a;
					IL_0420:
					if (_003C_003E4__this.GuildConquerorBadgesServer > 0)
					{
						_007B5341_007D = new Annotation(0, "+" + _003C_003E4__this.GuildConquerorBadgesServer + Local.pcs + Local.conquer_badges, AnnotationKey.ConquerorBadges, null);
						_007B5340_007D = 6;
						return true;
					}
					goto IL_047c;
					IL_0df1:
					_007B5372_007D = ((IEnumerable<AchievementEnum>)_003C_003E4__this.AchievementsServer).GetEnumerator();
					_007B5340_007D = -11;
					goto IL_0e8c;
					IL_047c:
					_007B5346_007D = ((IEnumerable<GSILocalEnumerablePair<ResourceInfo>>)_003C_003E4__this.Items.ResourceInfo/*cast due to .constrained prefix*/).GetEnumerator();
					_007B5340_007D = -3;
					goto IL_04fd;
					IL_04fd:
					if (_007B5346_007D.MoveNext())
					{
						_007B5347_007D = _007B5346_007D.Current;
						_007B5341_007D = _003C_003E4__this._003CDisplayText_003Eg__GetItemAnnotation_007C32_0(_007B5347_007D, AnnotationKey.Item, ref _007B5345_007D);
						_007B5340_007D = 7;
						return true;
					}
					_007B5328_007D();
					_007B5346_007D = null;
					_007B5348_007D = ((IEnumerable<GSILocalEnumerablePair<CannonBallInfo>>)_003C_003E4__this.Balls.CannonBallInfo/*cast due to .constrained prefix*/).GetEnumerator();
					_007B5340_007D = -4;
					goto IL_059a;
					IL_0d99:
					if (_003C_003E4__this.Rank.Value > 0)
					{
						_007B5341_007D = new Annotation(0, Local.complexBonus_rank(_003C_003E4__this.Rank.Value), AnnotationKey.Rank, null);
						_007B5340_007D = 19;
						return true;
					}
					goto IL_0df1;
					IL_059a:
					if (_007B5348_007D.MoveNext())
					{
						_007B5349_007D = _007B5348_007D.Current;
						_007B5341_007D = _003C_003E4__this._003CDisplayText_003Eg__GetItemAnnotation_007C32_0(_007B5349_007D, AnnotationKey.Ball, ref _007B5345_007D);
						_007B5340_007D = 8;
						return true;
					}
					_007B5329_007D();
					_007B5348_007D = null;
					_007B5350_007D = ((IEnumerable<GSILocalEnumerablePair<PowderKegInfo>>)_003C_003E4__this.Kegs.PowderKegInfo/*cast due to .constrained prefix*/).GetEnumerator();
					_007B5340_007D = -5;
					goto IL_0638;
					IL_0638:
					if (_007B5350_007D.MoveNext())
					{
						_007B5351_007D = _007B5350_007D.Current;
						_007B5341_007D = _003C_003E4__this._003CDisplayText_003Eg__GetItemAnnotation_007C32_0(_007B5351_007D, AnnotationKey.PowderKeg, ref _007B5345_007D);
						_007B5340_007D = 9;
						return true;
					}
					_007B5330_007D();
					_007B5350_007D = null;
					_007B5352_007D = ((IEnumerable<GSILocalEnumerablePair<CannonGameInfo>>)_003C_003E4__this.Cannons.CannonGameInfo/*cast due to .constrained prefix*/).GetEnumerator();
					_007B5340_007D = -6;
					goto IL_0716;
					IL_1355:
					if (_003C_003E4__this.ShipPlaces.Value > 0)
					{
						_007B5341_007D = new Annotation(0, $"+{_003C_003E4__this.ShipPlaces.Value} {Local.PortRealShopPage_105}", AnnotationKey.Ship, null);
						_007B5340_007D = 33;
						return true;
					}
					break;
					IL_0716:
					if (_007B5352_007D.MoveNext())
					{
						_007B5353_007D = _007B5352_007D.Current;
						_007B5341_007D = new Annotation(_007B5353_007D.Info.ID, "+" + _007B5353_007D.Count + Local.pcs + _007B5353_007D.Info.Name, AnnotationKey.Cannon, _007B5353_007D.Info.IconTexture);
						_007B5340_007D = 10;
						return true;
					}
					_007B5331_007D();
					_007B5352_007D = null;
					_007B5354_007D = ((IEnumerable<GSILocalEnumerablePair<UnitInfo>>)_003C_003E4__this.CrewToPort.UnitInfo/*cast due to .constrained prefix*/).GetEnumerator();
					_007B5340_007D = -7;
					goto IL_07e8;
					IL_0e8c:
					if (_007B5372_007D.MoveNext())
					{
						_007B5373_007D = _007B5372_007D.Current;
						_007B5374_007D = Gameplay.AchievementsByEnum[_007B5373_007D];
						_007B5341_007D = new Annotation(_007B5374_007D.ID, Local.achievement + ": " + _007B5374_007D.Name, AnnotationKey.Achievement, null);
						_007B5340_007D = 20;
						return true;
					}
					_007B5336_007D();
					_007B5372_007D = null;
					_007B5375_007D = ((IEnumerable<GSILocalEnumerablePair<PowerupItemInfo>>)_003C_003E4__this.PowerupItems.PowerupItemInfo/*cast due to .constrained prefix*/).GetEnumerator();
					_007B5340_007D = -12;
					goto IL_0f86;
					IL_07e8:
					if (_007B5354_007D.MoveNext())
					{
						_007B5355_007D = _007B5354_007D.Current;
						_007B5341_007D = new Annotation(0, "+" + _007B5355_007D.Count + Local.pcs + _007B5355_007D.Info.Name, AnnotationKey.Unit, _007B5355_007D.Info.Icon);
						_007B5340_007D = 11;
						return true;
					}
					_007B5332_007D();
					_007B5354_007D = null;
					_007B5356_007D = _003C_003E4__this.SpecialUnitsIds.Select(Gameplay.UnitsInfo.FromID).GetEnumerator();
					_007B5340_007D = -8;
					goto IL_0899;
					IL_0f86:
					if (_007B5375_007D.MoveNext())
					{
						_007B5376_007D = _007B5375_007D.Current;
						_007B5341_007D = new Annotation(_007B5376_007D.Info.Index, "+" + _007B5376_007D.Count + " " + Local.pcs + _007B5376_007D.Info.Name, AnnotationKey.Ship, _007B5376_007D.Info.Icon);
						_007B5340_007D = 21;
						return true;
					}
					_007B5337_007D();
					_007B5375_007D = null;
					if (_003C_003E4__this.FreeWorldResTravel > 0)
					{
						_007B5341_007D = new Annotation(0, Local.caravan_in_reward, AnnotationKey.Item, null);
						_007B5340_007D = 22;
						return true;
					}
					goto IL_0fe1;
					IL_0899:
					if (_007B5356_007D.MoveNext())
					{
						_007B5357_007D = _007B5356_007D.Current;
						_007B5341_007D = new Annotation(0, "+" + _007B5357_007D.Name, AnnotationKey.Unit, _007B5357_007D.Icon);
						_007B5340_007D = 12;
						return true;
					}
					_007B5333_007D();
					_007B5356_007D = null;
					if (_003C_003E4__this.RandomSpecialUnit)
					{
						_007B5341_007D = new Annotation(0, Local.complexBonus_randSpecialUnit, AnnotationKey.UnknownUnit, null);
						_007B5340_007D = 13;
						return true;
					}
					goto IL_08ef;
					IL_12a9:
					if (_003C_003E4__this.CraftTimeRecovery.Value > 0)
					{
						_007B5341_007D = new Annotation(0, $"+{MathF.Round((float)_003C_003E4__this.CraftTimeRecovery.Value * Math.Min(1f, _007B5345_007D.useMultiplier))} {Local.craft_time}", AnnotationKey.CraftTime, null);
						_007B5340_007D = 32;
						return true;
					}
					goto IL_1355;
					IL_0d3a:
					if (_003C_003E4__this.HoldProtectionSec.Value > 0)
					{
						_007B5341_007D = new Annotation(0, Local.complexBonus_holdProtection + StringHelper.TimeDHM(_003C_003E4__this.HoldProtectionSec.Value), AnnotationKey.HoldProtection, null);
						_007B5340_007D = 18;
						return true;
					}
					goto IL_0d99;
					IL_08ef:
					if (_003C_003E4__this.RandomDesign && _003C_003E4__this.DesignElements.NamesCount > 1)
					{
						_007B5358_007D = new Tlist<ShipDesignCategory>();
						_007B5361_007D = ((IEnumerable<GSILocalEnumerablePair<ShipDesignInfo>>)_003C_003E4__this.DesignElements.DesignElementInfo/*cast due to .constrained prefix*/).GetEnumerator();
						try
						{
							while (_007B5361_007D.MoveNext())
							{
								_007B5362_007D = _007B5361_007D.Current;
								_007B5358_007D.AddIfNotContains(in _007B5362_007D.Info.Category);
								_007B5362_007D = default(GSILocalEnumerablePair<ShipDesignInfo>);
							}
						}
						finally
						{
							if (_007B5361_007D != null)
							{
								_007B5361_007D.Dispose();
							}
						}
						_007B5361_007D = null;
						_007B5359_007D = "";
						_007B5363_007D = ((IEnumerable<ShipDesignCategory>)_007B5358_007D).GetEnumerator();
						try
						{
							while (_007B5363_007D.MoveNext())
							{
								_007B5364_007D = _007B5363_007D.Current;
								if (_007B5359_007D.Length > 0)
								{
									_007B5359_007D += " / ";
								}
								_007B5359_007D += _007B5364_007D.ToStrLocal();
							}
						}
						finally
						{
							if (_007B5363_007D != null)
							{
								_007B5363_007D.Dispose();
							}
						}
						_007B5363_007D = null;
						_007B5360_007D = ((_007B5358_007D.Size > 1) ? $" x{_007B5358_007D.Size}" : "");
						_007B5341_007D = new Annotation(0, Local.complexBonus_randomItem + _007B5359_007D + _007B5360_007D, AnnotationKey.RandomDesign, null);
						_007B5340_007D = 14;
						return true;
					}
					_007B5365_007D = ((IEnumerable<GSILocalEnumerablePair<ShipDesignInfo>>)_003C_003E4__this.DesignElements.DesignElementInfo/*cast due to .constrained prefix*/).GetEnumerator();
					_007B5340_007D = -9;
					goto IL_0bce;
					IL_1251:
					if (_003C_003E4__this.ArenaCurrency.Value > 0)
					{
						_007B5341_007D = new Annotation(0, Local.arena_currency_increased(_003C_003E4__this.ArenaCurrency.Value), AnnotationKey.ArenaCurrency, null);
						_007B5340_007D = 31;
						return true;
					}
					goto IL_12a9;
					IL_1065:
					if (_003C_003E4__this.SetEducationFlags.Contains(EducationOnboarding.InitialQuest_OpenDaily_2))
					{
						_007B5341_007D = new Annotation(0, Local.eq_extra_2_b, AnnotationKey.EducationFlag, null);
						_007B5340_007D = 25;
						return true;
					}
					goto IL_10a7;
					IL_11d6:
					if (_003C_003E4__this.PointsToGuildQuest.Item2 != 0)
					{
						_007B5341_007D = new Annotation(0, Local.complexBonus_guildMission(GuildQuests.MapQuestSubtype(FractionID.Antilia, _003C_003E4__this.PointsToGuildQuest.Item1).Value.GetName(), StringHelper.BigValueHelper(_003C_003E4__this.PointsToGuildQuest.Item2)), AnnotationKey.Xp, null);
						_007B5340_007D = 30;
						return true;
					}
					goto IL_1251;
					IL_10a7:
					if (_003C_003E4__this.SetEducationFlags.Contains(EducationOnboarding.InitialQuest_DisplayNextStep))
					{
						_007B5341_007D = new Annotation(0, Local.eq_extra_all, AnnotationKey.EducationFlag, null);
						_007B5340_007D = 26;
						return true;
					}
					goto IL_10e9;
					IL_10e9:
					if (_003C_003E4__this.SetEducationFlags.Contains(EducationOnboarding.InitialQuest_OpenTravel))
					{
						_007B5341_007D = new Annotation(0, Local.eq_extra_3, AnnotationKey.EducationFlag, null);
						_007B5340_007D = 27;
						return true;
					}
					goto IL_112b;
					IL_0fe1:
					if (_003C_003E4__this.SetEducationFlags.Contains(EducationOnboarding.InitialQuest_OpenTaverna))
					{
						_007B5341_007D = new Annotation(0, Local.eq_extra_1, AnnotationKey.EducationFlag, null);
						_007B5340_007D = 23;
						return true;
					}
					goto IL_1023;
					IL_117f:
					if (_003C_003E4__this.AllReputations != 0)
					{
						_007B5341_007D = new Annotation(0, Local.all_reputation + " +" + _003C_003E4__this.AllReputations, AnnotationKey.Xp, null);
						_007B5340_007D = 29;
						return true;
					}
					goto IL_11d6;
				}
				return false;
			}
			catch
			{
				//try-fault
				_007B5326_007D();
				throw;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {5327}
			return this._007B5327_007D();
		}

		private void _007B5328_007D()
		{
			_007B5340_007D = -1;
			if (_007B5346_007D != null)
			{
				_007B5346_007D.Dispose();
			}
		}

		private void _007B5329_007D()
		{
			_007B5340_007D = -1;
			if (_007B5348_007D != null)
			{
				_007B5348_007D.Dispose();
			}
		}

		private void _007B5330_007D()
		{
			_007B5340_007D = -1;
			if (_007B5350_007D != null)
			{
				_007B5350_007D.Dispose();
			}
		}

		private void _007B5331_007D()
		{
			_007B5340_007D = -1;
			if (_007B5352_007D != null)
			{
				_007B5352_007D.Dispose();
			}
		}

		private void _007B5332_007D()
		{
			_007B5340_007D = -1;
			if (_007B5354_007D != null)
			{
				_007B5354_007D.Dispose();
			}
		}

		private void _007B5333_007D()
		{
			_007B5340_007D = -1;
			if (_007B5356_007D != null)
			{
				_007B5356_007D.Dispose();
			}
		}

		private void _007B5334_007D()
		{
			_007B5340_007D = -1;
			if (_007B5365_007D != null)
			{
				_007B5365_007D.Dispose();
			}
		}

		private void _007B5335_007D()
		{
			_007B5340_007D = -1;
			if (_007B5368_007D != null)
			{
				_007B5368_007D.Dispose();
			}
		}

		private void _007B5336_007D()
		{
			_007B5340_007D = -1;
			if (_007B5372_007D != null)
			{
				_007B5372_007D.Dispose();
			}
		}

		private void _007B5337_007D()
		{
			_007B5340_007D = -1;
			if (_007B5375_007D != null)
			{
				_007B5375_007D.Dispose();
			}
		}

		[DebuggerHidden]
		private void _007B5338_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {5338}
			this._007B5338_007D();
		}

		[DebuggerHidden]
		IEnumerator<Annotation> IEnumerable<Annotation>.GetEnumerator()
		{
			_003CDisplayText_003Ed__32 _003CDisplayText_003Ed__;
			if (_007B5340_007D == -2 && _007B5342_007D == Environment.CurrentManagedThreadId)
			{
				_007B5340_007D = 0;
				_003CDisplayText_003Ed__ = this;
			}
			else
			{
				_003CDisplayText_003Ed__ = new _003CDisplayText_003Ed__32(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			_003CDisplayText_003Ed__._007B5343_007D = _003C_003E3__useMultiplier;
			_003CDisplayText_003Ed__._007B5344_007D = _003C_003E3__takePremium;
			return _003CDisplayText_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B5339_007D()
		{
			return ((IEnumerable<Annotation>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {5339}
			return this._007B5339_007D();
		}
	}

	public GSI Items = new GSI();

	public GSI Cannons = new GSI();

	public GSI Balls = new GSI();

	public GSI Kegs = new GSI();

	public RTI Xp = 0;

	public RTI ShipXp = 0;

	public RTI Gold = 0;

	public RTI Monets = 0;

	public RTI LegendaryFlagDays = 0;

	public RTI HoldProtectionSec = 0;

	public RTI Rank = 0;

	public GSI DesignElements = new GSI();

	public bool RandomDesign = true;

	public Tlist<int> ShipIds = new Tlist<int>();

	public bool DonationShips = false;

	public Tlist<EducationOnboarding> SetEducationFlags = new Tlist<EducationOnboarding>();

	public GSI CrewToPort = new GSI();

	public Tlist<int> SpecialUnitsIds = new Tlist<int>();

	public bool RandomSpecialUnit = false;

	public GSI PowerupItems = new GSI();

	public bool ForceAddToShip = false;

	public int AllReputations;

	public int FreeWorldResTravel = 0;

	public (GuildQuestScoped, int) PointsToGuildQuest;

	public RTI ArenaCurrency = 0;

	public RTI CraftTimeRecovery = 0;

	public RTI ShipPlaces = 0;

	public int GuildConquerorBadgesServer = 0;

	public Tlist<AchievementEnum> AchievementsServer = new Tlist<AchievementEnum>();

	public int GoldToGuildServer = 0;

	[IteratorStateMachine(typeof(_003CDisplayText_003Ed__32))]
	public IEnumerable<Annotation> DisplayText(float _007B5298_007D = 1f, bool _007B5299_007D = false)
	{
		//yield-return decompiler failed: Method not found
		return new _003CDisplayText_003Ed__32(-2)
		{
			_003C_003E4__this = this,
			_003C_003E3__useMultiplier = _007B5298_007D,
			_003C_003E3__takePremium = _007B5299_007D
		};
	}

	public static string CountWithPremium(int _007B5300_007D, bool _007B5301_007D)
	{
		if (_007B5301_007D)
		{
			return $"{MathF.Round((float)_007B5300_007D * 1.4f)} ({Local.premium.ToLower()})";
		}
		return _007B5300_007D.ToString();
	}

	private string _007B5302_007D(int _007B5303_007D, string _007B5304_007D, float _007B5305_007D, bool _007B5306_007D)
	{
		if (_007B5306_007D)
		{
			_007B5305_007D *= 1.4f;
		}
		_007B5303_007D = (int)MathF.Round((float)_007B5303_007D * _007B5305_007D);
		if (!_007B5306_007D)
		{
			return $"{_007B5303_007D} {_007B5304_007D}";
		}
		return $"{_007B5303_007D} {_007B5304_007D} ({Local.premium.ToLower()})";
	}

	private static string GetBonusPostfix(float _007B5307_007D)
	{
		if (_007B5307_007D == 1f)
		{
			return "";
		}
		int value = (int)Math.Round(_007B5307_007D * 100f - 100f);
		return $" ({value:+#;-#}%)";
	}

	public void Apply(PlayerAccount _007B5308_007D, bool _007B5309_007D, float _007B5310_007D = 1f)
	{
		int num = 5538 + _007B5308_007D.Xp + _007B5308_007D.Rang * 111;
		if (_007B5309_007D)
		{
			PlayerShipDynamicInfo currentRealShip = _007B5308_007D.Shipyard.CurrentRealShip;
			currentRealShip.PrivateResourcesOfHold.Add(Items.Clone(_007B5310_007D, RoundMode.Round));
			currentRealShip.BallsOfHold.Add(Balls.Clone(_007B5310_007D, RoundMode.Round));
			currentRealShip.PowderKegsOfHold.Add(Kegs.Clone(_007B5310_007D, RoundMode.Round));
		}
		else
		{
			_007B5308_007D.NearPortStorage.Add(Items.Clone(_007B5310_007D, RoundMode.Round));
			_007B5308_007D.NearPortStorage.Add(Balls.Clone(_007B5310_007D, RoundMode.Round));
			_007B5308_007D.NearPortStorage.Add(Kegs.Clone(_007B5310_007D, RoundMode.Round));
		}
		WosbTreasuryMaps.DetachMaps(_007B5308_007D);
		_007B5308_007D.Monets.Value += Monets.Value;
		_007B5308_007D.AddXp((int)Math.Round((float)Xp.Value * _007B5310_007D));
		if (ShipXp.Value > 0)
		{
			_007B5308_007D.Shipyard.AddXpAllShips((int)Math.Round((float)ShipXp.Value * _007B5310_007D));
		}
		_007B5308_007D.Gold += (int)Math.Round((float)Gold.Value * _007B5310_007D);
		for (int i = 0; i < Rank.Value; i++)
		{
			if (_007B5308_007D.Rang - 1 < Gameplay.RangsInfo.Count)
			{
				_007B5308_007D.AddXp(_007B5308_007D.XpToNextRang + 1, _007B1621_007D: false);
			}
		}
		_007B5308_007D.HoldProtectionSubscriptionSec += HoldProtectionSec.Value;
		_007B5308_007D.UnitsAtStorage.Add(CrewToPort);
		_007B5308_007D.PowerupItemsAtStorage.Add(PowerupItems);
		_007B5308_007D.TemporaryFreeResTravel.Value += FreeWorldResTravel;
		_007B5308_007D.AvailCraftTime.Value = Math.Min(_007B5308_007D.AvailCraftTime.Value + MathF.Round((float)CraftTimeRecovery.Value * Math.Min(1f, _007B5310_007D)), _007B5308_007D.CraftTimeLimit);
		if (RandomSpecialUnit)
		{
			UnitInfo unitInfo = Gameplay.AllSpecialUnits.Array[num % Gameplay.AllSpecialUnits.Size];
			_007B5308_007D.SpecialUnitsAtStorage.Add(new SpecialUnitInstance(unitInfo.ID));
		}
		foreach (int item in (IEnumerable<int>)SpecialUnitsIds)
		{
			_007B5308_007D.SpecialUnitsAtStorage.Add(new SpecialUnitInstance(item));
		}
		_007B5308_007D.CannonsAtStorage.Add(Cannons);
		_007B5308_007D.LegendaryFlagDaysLeft = (ushort)Math.Min(65535, _007B5308_007D.LegendaryFlagDaysLeft + LegendaryFlagDays.Value);
		if (!DesignElements.IsEmpty)
		{
			if (RandomDesign)
			{
				_007B5308_007D.DesingElementsAtStorage.AddOrRemove(DesignElements.SelectRandomNameByHash(num), 1);
			}
			else
			{
				_007B5308_007D.DesingElementsAtStorage.Add(DesignElements);
			}
		}
		foreach (int item2 in (IEnumerable<int>)ShipIds)
		{
			PlayerShipInfo playerShipInfo = Gameplay.PlayersInfo.FromID(item2);
			if (DonationShips)
			{
				int value = CommonSupport.DonationShipCannonsId[playerShipInfo.MaxCannonCategory];
				_007B5308_007D.Shipyard.CreateNewShip(playerShipInfo, _007B5308_007D, value, _007B2038_007D: true, _007B2039_007D: true, _007B2040_007D: true);
			}
			else
			{
				_007B5308_007D.Shipyard.CreateNewShip(playerShipInfo, _007B5308_007D);
			}
		}
		foreach (EducationOnboarding item3 in (IEnumerable<EducationOnboarding>)SetEducationFlags)
		{
			_007B5308_007D.EducationQuest.Append(item3);
		}
		if (AllReputations != 0)
		{
			foreach (FractionID item4 in (IEnumerable<FractionID>)FractionDecorator.Nations)
			{
				_007B5308_007D.Reputations.Change(new PlayerReputations.ChangeReputation(item4, AllReputations, _007B8674_007D: false), _007B5308_007D, null);
			}
		}
		if (ArenaCurrency.Value > 0)
		{
			_007B5308_007D.ArenaCurrency.Value += ArenaCurrency.Value;
		}
		if (ShipPlaces.Value > 0)
		{
			_007B5308_007D.MaxShipsCount.Value = Math.Min(_007B5308_007D.HardShipPlacesLimit, _007B5308_007D.MaxShipsCount.Value + ShipPlaces.Value);
		}
	}

	public void Boxing(WriterExtern _007B5311_007D)
	{
		_007B5311_007D.Write<GSI>(Items);
		_007B5311_007D.Write<GSI>(Cannons);
		_007B5311_007D.WriteStruct<int>(Xp.Value);
		_007B5311_007D.WriteStruct<int>(ShipXp.Value);
		_007B5311_007D.WriteStruct<RTI>(Gold);
		_007B5311_007D.WriteStruct<RTI>(Monets);
		_007B5311_007D.WriteStruct<RTI>(LegendaryFlagDays);
		_007B5311_007D.Write<GSI>(DesignElements);
		_007B5311_007D.Write(RandomDesign);
		_007B5311_007D.WriteTlist(ShipIds);
		_007B5311_007D.Write(DonationShips);
		_007B5311_007D.WriteTlist(SetEducationFlags);
		_007B5311_007D.Write<GSI>(CrewToPort);
		_007B5311_007D.WriteTlist(SpecialUnitsIds);
		_007B5311_007D.Write(RandomSpecialUnit);
		_007B5311_007D.Write<GSI>(PowerupItems);
		_007B5311_007D.Write(ForceAddToShip);
		_007B5311_007D.WriteStruct<int>(FreeWorldResTravel);
		_007B5311_007D.Write<GSI>(Balls);
		_007B5311_007D.Write<GSI>(Kegs);
		_007B5311_007D.WriteStruct<int>(Rank.Value);
		_007B5311_007D.WriteStruct<int>(HoldProtectionSec.Value);
		_007B5311_007D.WriteStruct<int>(ArenaCurrency.Value);
		_007B5311_007D.WriteStruct<int>(CraftTimeRecovery.Value);
		_007B5311_007D.WriteByte((byte)ShipPlaces.Value);
	}

	public void Unboxing(WriterExtern _007B5312_007D)
	{
		_007B5312_007D.ReadIMPS<GSI>(ref Items);
		_007B5312_007D.ReadIMPS<GSI>(ref Cannons);
		int value = default(int);
		_007B5312_007D.ReadStruct<int>(ref value);
		Xp.Value = value;
		int value2 = default(int);
		_007B5312_007D.ReadStruct<int>(ref value2);
		ShipXp.Value = value2;
		_007B5312_007D.ReadStruct<RTI>(ref Gold);
		_007B5312_007D.ReadStruct<RTI>(ref Monets);
		_007B5312_007D.ReadStruct<RTI>(ref LegendaryFlagDays);
		_007B5312_007D.ReadIMPS<GSI>(ref DesignElements);
		_007B5312_007D.ReadBoolean(ref RandomDesign);
		_007B5312_007D.ReadTlist(out ShipIds);
		_007B5312_007D.ReadBoolean(ref DonationShips);
		_007B5312_007D.ReadTlist(out SetEducationFlags);
		_007B5312_007D.ReadIMPS<GSI>(ref CrewToPort);
		_007B5312_007D.ReadTlist(out SpecialUnitsIds);
		_007B5312_007D.ReadBoolean(ref RandomSpecialUnit);
		_007B5312_007D.ReadIMPS<GSI>(ref PowerupItems);
		_007B5312_007D.ReadBoolean(ref ForceAddToShip);
		_007B5312_007D.ReadStruct<int>(ref FreeWorldResTravel);
		_007B5312_007D.ReadIMPS<GSI>(ref Balls);
		_007B5312_007D.ReadIMPS<GSI>(ref Kegs);
		int value3 = default(int);
		_007B5312_007D.ReadStruct<int>(ref value3);
		Rank.Value = value3;
		int value4 = default(int);
		_007B5312_007D.ReadStruct<int>(ref value4);
		HoldProtectionSec.Value = value4;
		int _007B11342_007D = default(int);
		_007B5312_007D.ReadStruct<int>(ref _007B11342_007D);
		ArenaCurrency = new RTI(_007B11342_007D);
		int _007B11342_007D2 = default(int);
		_007B5312_007D.ReadStruct<int>(ref _007B11342_007D2);
		CraftTimeRecovery = new RTI(_007B11342_007D2);
		ShipPlaces = new RTI(_007B5312_007D.ReadByte());
	}

	public ComplexBonus ShallowCopy()
	{
		return (ComplexBonus)MemberwiseClone();
	}
}
