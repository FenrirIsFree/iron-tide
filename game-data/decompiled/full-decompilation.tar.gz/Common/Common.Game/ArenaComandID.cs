namespace Common.Game;

public enum ArenaComandID
{
	Team1,
	Team2
}
