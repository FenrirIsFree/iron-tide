using System;
using System.Diagnostics.CodeAnalysis;
using Common.Resources;

namespace Common.Game;

public readonly struct WeakShipReference : IEquatable<WeakShipReference>
{
	public readonly int UID;

	public readonly uint PlayerSID;

	private readonly Ship? _007B5253_007D;

	public Ship? GetShip
	{
		get
		{
			if (_007B5253_007D == null || !_007B5253_007D.InstanceAlive || UID != _007B5253_007D.uID)
			{
				return null;
			}
			return _007B5253_007D;
		}
	}

	public Ship? GetShipNotDestroyed
	{
		get
		{
			Ship getShip = GetShip;
			return (getShip == null || getShip.IsDestroyed) ? null : getShip;
		}
	}

	public WeakShipReference(Ship? _007B5246_007D)
	{
		if (_007B5246_007D == null)
		{
			UID = 0;
			_007B5253_007D = null;
			PlayerSID = 0u;
			return;
		}
		UID = _007B5246_007D.uID;
		_007B5253_007D = _007B5246_007D;
		if (_007B5246_007D is Player player)
		{
			if (CommonGlobal.IsServer || !(player.UsedShipPlayer is RemotePlayerDynamicInfo))
			{
				PlayerSID = player.AccountConnection.SID;
			}
			else
			{
				PlayerSID = ((RemotePlayerDynamicInfo)player.UsedShipPlayer).AccountSID;
			}
		}
		else
		{
			PlayerSID = 0u;
		}
	}

	public override bool Equals([NotNullWhen(true)] object? _007B5247_007D)
	{
		return _007B5247_007D is WeakShipReference weakShipReference && weakShipReference.UID == UID && UID != 0;
	}

	public override int GetHashCode()
	{
		return UID.GetHashCode();
	}

	public override string ToString()
	{
		return UID.ToString();
	}

	public bool Equals(WeakShipReference _007B5248_007D)
	{
		return _007B5248_007D.UID == UID && UID != 0;
	}

	public static bool operator ==(WeakShipReference _007B5249_007D, WeakShipReference _007B5250_007D)
	{
		return _007B5249_007D.Equals(_007B5250_007D);
	}

	public static bool operator !=(WeakShipReference _007B5251_007D, WeakShipReference _007B5252_007D)
	{
		return !_007B5251_007D.Equals(_007B5252_007D);
	}
}
