using System;
using System.Runtime.CompilerServices;
using Common.Account;
using Common.Resources;

namespace Common.Game;

public sealed class TargetShipNpcForQuest : TargetShipForQuest
{
	public NpcType? Class;

	public int? NpcID;

	public WorldMapRegionInfo? NpcClassTargetRegion;

	public bool RequiredPvpFlag;

	public bool MakeFailedWhenKilledWithoutAccepting;

	public Func<NpcShipDynamicInfo, bool>? ExtraRequirement;

	public TargetShipNpcForQuest()
		: this(null, null, null)
	{
	}

	public TargetShipNpcForQuest(Func<NpcShipDynamicInfo, bool>? _007B7735_007D)
		: this(null, null, null, _007B7739_007D: false, _007B7735_007D)
	{
	}

	public TargetShipNpcForQuest(NpcType? _007B7736_007D, int? _007B7737_007D, WorldMapRegionInfo? _007B7738_007D, bool _007B7739_007D = false, Func<NpcShipDynamicInfo, bool>? _007B7740_007D = null)
	{
		Class = _007B7736_007D;
		NpcID = _007B7737_007D;
		NpcClassTargetRegion = _007B7738_007D;
		ExtraRequirement = _007B7740_007D;
		ShowOnMinimap = _007B7739_007D;
	}

	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	public bool ShouldShowOnMinimap(Npc _007B7741_007D, Player _007B7742_007D)
	{
		NpcInfo information = _007B7741_007D.UsedShipNpc.Information;
		return (!NpcID.HasValue && !Class.HasValue) || information.ID == NpcID || (information.Descritpion == Class && (NpcClassTargetRegion == null || information.Location.AsWorldRegion == NpcClassTargetRegion));
	}

	public bool DoesShipFit(Npc _007B7743_007D, Player _007B7744_007D, bool _007B7745_007D = true)
	{
		NpcInfo information = _007B7743_007D.UsedShipNpc.Information;
		return ShouldShowOnMinimap(_007B7743_007D, _007B7744_007D) && (!_007B7745_007D || ExtraRequirement == null || ExtraRequirement(_007B7743_007D.UsedShipNpc)) && (!_007B7745_007D || !RequiredPvpFlag || _007B7744_007D.AccountConnection.WorldFlag.IsPeaceMode());
	}
}
