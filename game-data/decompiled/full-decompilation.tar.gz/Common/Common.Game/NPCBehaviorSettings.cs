using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using Common.Resources;
using CommonDataTypes;
using TheraEngine.Helpers;

namespace Common.Game;

public struct NPCBehaviorSettings
{
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B4235_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B4236_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B4237_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B4238_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B4239_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B4240_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B4241_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private float _007B4242_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B4243_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B4244_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private float _007B4245_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private float _007B4246_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B4247_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B4248_007D;

	public bool MakeUseSpeedAnyHp
	{
		[CompilerGenerated]
		readonly get
		{
			return _007B4235_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B4235_007D = value;
		}
	}

	public bool MakeUseSpeedLowHp
	{
		[CompilerGenerated]
		readonly get
		{
			return _007B4236_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B4236_007D = value;
		}
	}

	public bool UseDistanceAnyHp
	{
		[CompilerGenerated]
		readonly get
		{
			return _007B4237_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B4237_007D = value;
		}
	}

	public bool UseDistanceLowHp
	{
		[CompilerGenerated]
		readonly get
		{
			return _007B4238_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B4238_007D = value;
		}
	}

	public bool UseArmorAnyHp
	{
		[CompilerGenerated]
		readonly get
		{
			return _007B4239_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B4239_007D = value;
		}
	}

	public bool UseArmorLowHp
	{
		[CompilerGenerated]
		readonly get
		{
			return _007B4240_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B4240_007D = value;
		}
	}

	public bool GetCloserLowHp
	{
		[CompilerGenerated]
		readonly get
		{
			return _007B4241_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B4241_007D = value;
		}
	}

	public float ReactionTimeMul
	{
		[CompilerGenerated]
		readonly get
		{
			return _007B4242_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B4242_007D = value;
		}
	}

	public bool TryToAvoidFireareas
	{
		[CompilerGenerated]
		readonly get
		{
			return _007B4243_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B4243_007D = value;
		}
	}

	public bool UseFalkonets
	{
		[CompilerGenerated]
		readonly get
		{
			return _007B4244_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B4244_007D = value;
		}
	}

	public float PowderKegReload
	{
		[CompilerGenerated]
		readonly get
		{
			return _007B4245_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B4245_007D = value;
		}
	}

	public float PowderKegChanse
	{
		[CompilerGenerated]
		readonly get
		{
			return _007B4246_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B4246_007D = value;
		}
	}

	public bool CanFearSometimes
	{
		[CompilerGenerated]
		readonly get
		{
			return _007B4247_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B4247_007D = value;
		}
	}

	public bool CanMending
	{
		[CompilerGenerated]
		readonly get
		{
			return _007B4248_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B4248_007D = value;
		}
	}

	public bool MakeUseSpeed(bool _007B4228_007D)
	{
		return _007B4228_007D ? MakeUseSpeedLowHp : MakeUseSpeedAnyHp;
	}

	public bool UseDistance(bool _007B4229_007D)
	{
		return _007B4229_007D ? UseDistanceLowHp : UseDistanceAnyHp;
	}

	public bool UseArmor(bool _007B4230_007D)
	{
		return _007B4230_007D ? UseArmorLowHp : UseArmorAnyHp;
	}

	public bool GetCloser(bool _007B4231_007D)
	{
		return _007B4231_007D && GetCloserLowHp;
	}

	public NPCBehaviorSettings(NpcShipDynamicInfo _007B4232_007D, WorldMapInfo _007B4233_007D, PassingMapDiffCard[] _007B4234_007D)
	{
		_007B4241_007D = false;
		_007B4242_007D = 0f;
		MakeUseSpeedLowHp = _007B4232_007D.Information.BasedOn.Class == ShipClass.Destroyer;
		MakeUseSpeedAnyHp = false;
		UseDistanceLowHp = _007B4232_007D.Information.AttackDistance > 134f && _007B4232_007D.Information.BasedOn.Class != ShipClass.Battleship;
		UseDistanceAnyHp = _007B4232_007D.Information.AttackDistance > 134f && _007B4232_007D.Information.BasedOn.Class == ShipClass.Destroyer;
		UseArmorLowHp = (_007B4232_007D.Information.BasedOn.Class == ShipClass.Hardship && _007B4232_007D.Information.ShipProperties.Armor >= 3.5f) || _007B4232_007D.Information.ShipProperties.Armor >= 4.5f;
		UseArmorAnyHp = _007B4232_007D.Information.ShipProperties.Armor > 3.5f && _007B4232_007D.upgradesEffects[ShipBonusEffect.PReduceDamageToNose] > 0f;
		PowderKegReload = (_007B4232_007D.Information.Extras.IsEmpire ? 16000 : 26000);
		PowderKegChanse = ((_007B4232_007D.Information.Descritpion == NpcType.NyEventNpc) ? 0f : (_007B4232_007D.Information.Extras.IsTrader ? 0.3f : 0.6f));
		TryToAvoidFireareas = _007B4232_007D.upgradesEffects[ShipBonusEffect.PReduceFireAreaDamage] == 0f;
		UseFalkonets = _007B4232_007D.Information.Descritpion != NpcType.NyEventNpc && !_007B4232_007D.Information.Extras.WeakBehavior;
		CanFearSometimes = _007B4232_007D.Information.Extras.IsPirate && Rand.Chanse(14f) && _007B4232_007D.Information.Location.HzLevel >= 1;
		if (_007B4234_007D != null)
		{
			UseFalkonets = _007B4234_007D.Length >= 1;
			PowderKegChanse = (_007B4234_007D.Contains(PassingMapDiffCard.PowderKegsEverywhere) ? 0.9f : ((_007B4234_007D.Length >= 1) ? 0.5f : 0f));
		}
		if (_007B4233_007D.IsWorldmap && _007B4232_007D.Information.Location.HzLevel >= 5)
		{
			MakeUseSpeedLowHp = true;
			MakeUseSpeedAnyHp = true;
		}
		CanMending = _007B4232_007D.Information.Descritpion == NpcType.PortPatrol || _007B4232_007D.Information.Extras.IsEmpire || _007B4232_007D.Information.Extras.IsReinforcedType;
	}
}
