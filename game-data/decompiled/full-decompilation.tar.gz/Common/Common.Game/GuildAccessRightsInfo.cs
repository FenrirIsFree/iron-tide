using System.Collections.Generic;

namespace Common.Game;

public struct GuildAccessRightsInfo
{
	public int RankId;

	public bool AllowWatchMembersPositions;

	public bool AllowViewFortStorage;

	public bool AllowGiveFortStorage;

	public bool AllowAcceptPlayers;

	public bool AllowRemovePlayersWithRankLower;

	public bool AllowEditPlayers;

	public bool AllowEditGuildAndFortAndTreasury;

	public bool AllowEditPolitics;

	public bool AllowEngageInPortBattle;

	public bool AllowReceiveSalary;

	public bool DisableOnFlotilia;

	public static Dictionary<int, GuildAccessRightsInfo> AllRights = new Dictionary<int, GuildAccessRightsInfo>
	{
		[1] = new GuildAccessRightsInfo(1, _007B6432_007D: false, _007B6433_007D: false, _007B6434_007D: false, _007B6435_007D: false, _007B6436_007D: false, _007B6437_007D: false, _007B6438_007D: false, _007B6439_007D: false, _007B6440_007D: false, _007B6441_007D: false),
		[2] = new GuildAccessRightsInfo(2, _007B6432_007D: false, _007B6433_007D: true, _007B6434_007D: false, _007B6435_007D: false, _007B6436_007D: false, _007B6437_007D: false, _007B6438_007D: false, _007B6439_007D: false, _007B6440_007D: true, _007B6441_007D: true)
		{
			DisableOnFlotilia = true
		},
		[3] = new GuildAccessRightsInfo(3, _007B6432_007D: true, _007B6433_007D: true, _007B6434_007D: true, _007B6435_007D: false, _007B6436_007D: false, _007B6437_007D: false, _007B6438_007D: false, _007B6439_007D: false, _007B6440_007D: true, _007B6441_007D: true),
		[4] = new GuildAccessRightsInfo(4, _007B6432_007D: true, _007B6433_007D: true, _007B6434_007D: true, _007B6435_007D: true, _007B6436_007D: false, _007B6437_007D: false, _007B6438_007D: false, _007B6439_007D: false, _007B6440_007D: true, _007B6441_007D: true)
		{
			DisableOnFlotilia = true
		},
		[5] = new GuildAccessRightsInfo(5, _007B6432_007D: true, _007B6433_007D: true, _007B6434_007D: true, _007B6435_007D: true, _007B6436_007D: true, _007B6437_007D: true, _007B6438_007D: false, _007B6439_007D: false, _007B6440_007D: true, _007B6441_007D: true)
		{
			DisableOnFlotilia = true
		},
		[6] = new GuildAccessRightsInfo(6, _007B6432_007D: true, _007B6433_007D: true, _007B6434_007D: true, _007B6435_007D: true, _007B6436_007D: true, _007B6437_007D: true, _007B6438_007D: true, _007B6439_007D: true, _007B6440_007D: true, _007B6441_007D: true),
		[7] = new GuildAccessRightsInfo(7, _007B6432_007D: true, _007B6433_007D: true, _007B6434_007D: true, _007B6435_007D: true, _007B6436_007D: true, _007B6437_007D: true, _007B6438_007D: true, _007B6439_007D: true, _007B6440_007D: true, _007B6441_007D: true)
	};

	public string DisplayName => Local.Current("guildrights_" + RankId);

	public static GuildAccessRightsInfo FounderRights => AllRights[7];

	public static GuildAccessRightsInfo NewPlayerRights => AllRights[1];

	public GuildAccessRightsInfo(int _007B6431_007D, bool _007B6432_007D, bool _007B6433_007D, bool _007B6434_007D, bool _007B6435_007D, bool _007B6436_007D, bool _007B6437_007D, bool _007B6438_007D, bool _007B6439_007D, bool _007B6440_007D, bool _007B6441_007D)
	{
		RankId = _007B6431_007D;
		AllowWatchMembersPositions = _007B6432_007D;
		AllowViewFortStorage = _007B6433_007D;
		AllowGiveFortStorage = _007B6434_007D;
		AllowAcceptPlayers = _007B6435_007D;
		AllowRemovePlayersWithRankLower = _007B6436_007D;
		AllowEditPlayers = _007B6437_007D;
		AllowEditGuildAndFortAndTreasury = _007B6438_007D;
		AllowEditPolitics = _007B6439_007D;
		AllowEngageInPortBattle = _007B6440_007D;
		AllowReceiveSalary = _007B6441_007D;
		DisableOnFlotilia = false;
	}
}
