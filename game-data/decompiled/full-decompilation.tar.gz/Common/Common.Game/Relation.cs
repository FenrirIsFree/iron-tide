namespace Common.Game;

public enum Relation
{
	Ally,
	Enemy,
	Neutral
}
