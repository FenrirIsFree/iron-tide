using System;
using Common.Account;
using Microsoft.Xna.Framework;

namespace Common.Game;

public abstract class QuestStepHeader
{
	internal string TextWhatToDo;

	public readonly bool RollbackWhenFailed;

	public readonly TargetShipForQuest? Target;

	public abstract int ProgressComparand { get; }

	public QuestStepHeader(string _007B7250_007D, TargetShipForQuest? _007B7251_007D = null)
	{
		TextWhatToDo = _007B7250_007D;
		Target = _007B7251_007D;
	}

	public static string GetTextWhatToDo(Player _007B7252_007D, QuestEducationFlag.Item _007B7253_007D, bool _007B7254_007D)
	{
		string text = _007B7253_007D.HeaderText;
		if (_007B7253_007D.Marker == EducationOnboarding.PlayArena7Games)
		{
			text = text.Replace("$$", $"{Math.Max(1, 7 - _007B7252_007D.AccountConnection.Analytics.TotalArenaGamesCount)}");
		}
		if (_007B7253_007D.Marker == EducationOnboarding.BuyWoodInOtherPort && _007B7254_007D && _007B7252_007D.NearPort.PortID == _007B7252_007D.AccountConnection.StartPortId)
		{
			text = text + " (" + Local.startq_action_8_1.ToLower() + ")";
		}
		return text;
	}

	public string GetTextWhatToDo(Player _007B7255_007D, QuestRunningProgress _007B7256_007D)
	{
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		PlayerAccount account = _007B7255_007D.AccountConnection;
		if (this is QuestEducationFlag questEducationFlag)
		{
			string text = "";
			foreach (QuestEducationFlag.Item item in questEducationFlag.Conditions.Where((QuestEducationFlag.Item _007B7257_007D) => !account.EducationQuest.HasFlag(_007B7257_007D.Marker)))
			{
				if (text.Length > 0)
				{
					text += Environment.NewLine;
				}
				text = text + "⚔ " + GetTextWhatToDo(_007B7255_007D, item, _007B7254_007D: false);
			}
			if (text.Length == 0)
			{
				if (_007B7255_007D.IsPortEntry)
				{
					return Local.onboarding_port10_q;
				}
				return Local.q_returnPort;
			}
			return text;
		}
		string text2 = string.Empty;
		if (this is QuestFindSomething questFindSomething)
		{
			text2 = Math.Ceiling(Vector2.Distance(questFindSomething.LocationPos, _007B7255_007D.Position)).ToString();
		}
		else if (_007B7256_007D.CurrentStep.ProgressComparand != -1)
		{
			text2 = (_007B7256_007D.CurrentStep.ProgressComparand - _007B7256_007D.ProgressInStep).ToString();
		}
		if (this is QuestFollowToPortHeader { ToMyHomePort: not false })
		{
			if (_007B7255_007D.IsPortEntry && _007B7255_007D.NearPort.PortID == account.StartPortId)
			{
				return Local.onboarding_port10_q;
			}
			return TextWhatToDo + " (" + Gameplay.WorldMap.Ports[account.StartPortId].PortNameShort + ")";
		}
		if (this is QuestTransportPassengers questTransportPassengers && _007B7256_007D.Info.Limits.Contains(QuestAdditionalLimit.RDontGetDamage))
		{
			return Local.q_transport_passengers_with_restriction(questTransportPassengers.PassengerCount, questTransportPassengers.TargetPort.PortName, questTransportPassengers.TargetPort.NearRegion.Name, $"{_007B7256_007D.Info.RistrictionKeepShipHealth * 100f:F0}");
		}
		string text3 = ((text2.Length == 0) ? TextWhatToDo : TextWhatToDo.Replace("$$", text2));
		if (this is QuestKillShip { Target: TargetShipNpcForQuest { ShowOnMinimap: not false } })
		{
			text3 = text3 + " " + Local.Current("targets_on_map");
		}
		return text3;
	}
}
