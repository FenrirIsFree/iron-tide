using System;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct QuestDisableInfo : IMPSerializable
{
	public ushort ID;

	public ushort Code;

	internal bool Evalute(int _007B7261_007D)
	{
		if (Code == ushort.MaxValue)
		{
			return false;
		}
		int code = Code;
		code -= _007B7261_007D;
		if (code <= 0)
		{
			return true;
		}
		Code = (ushort)code;
		return false;
	}

	public QuestDisableInfo(QuestInfo _007B7262_007D)
		: this(_007B7262_007D, (_007B7262_007D.RegularInterval == -1) ? ushort.MaxValue : ((ushort)_007B7262_007D.RegularInterval))
	{
	}

	public QuestDisableInfo(QuestInfo _007B7263_007D, int _007B7264_007D)
	{
		if (_007B7264_007D > 65535)
		{
			throw new NotSupportedException(" QuestDisableInfo argument");
		}
		ID = (ushort)_007B7263_007D.ID;
		Code = (ushort)_007B7264_007D;
	}

	private void _007B7265_007D(WriterExtern _007B7266_007D)
	{
		_007B7266_007D.WriteStruct<ushort>(ID);
		_007B7266_007D.WriteStruct<ushort>(Code);
	}

	private void _007B7267_007D(WriterExtern _007B7268_007D)
	{
		_007B7268_007D.ReadStruct<ushort>(ref ID);
		_007B7268_007D.ReadStruct<ushort>(ref Code);
	}
}
