namespace Common.Game;

public class QuestMakeCompanyQuests : QuestStepHeader
{
	public int RequiredCount;

	public override int ProgressComparand => RequiredCount;

	public QuestMakeCompanyQuests(string _007B7650_007D, int _007B7651_007D)
		: base(_007B7650_007D)
	{
		RequiredCount = _007B7651_007D;
	}
}
