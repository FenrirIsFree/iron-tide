namespace Common.Game;

public enum PhysicsLayerHardness
{
	Linear,
	Collision
}
