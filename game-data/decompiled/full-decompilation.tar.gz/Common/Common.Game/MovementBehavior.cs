namespace Common.Game;

internal class MovementBehavior
{
}
