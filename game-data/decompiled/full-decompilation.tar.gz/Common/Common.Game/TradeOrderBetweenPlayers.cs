using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct TradeOrderBetweenPlayers : IMPSerializable
{
	public int SourceUID;

	public int TargetUID;

	public GSI Content;

	public int TotalPrice;

	public int Tax => (int)(WosbTrading.TradingInSeaBetweenPlayersTax() * (float)TotalPrice);

	public TradeOrderBetweenPlayers(int _007B6724_007D, int _007B6725_007D, GSI _007B6726_007D, int _007B6727_007D)
	{
		SourceUID = _007B6724_007D;
		TargetUID = _007B6725_007D;
		Content = _007B6726_007D;
		TotalPrice = _007B6727_007D;
	}

	public void Boxing(WriterExtern _007B6728_007D)
	{
		_007B6728_007D.WriteStruct<int>(SourceUID);
		_007B6728_007D.WriteStruct<int>(TargetUID);
		_007B6728_007D.WriteStruct<int>(TotalPrice);
		_007B6728_007D.WriteNoNull<GSI>(Content);
	}

	public void Unboxing(WriterExtern _007B6729_007D)
	{
		_007B6729_007D.ReadStruct<int>(ref SourceUID);
		_007B6729_007D.ReadStruct<int>(ref TargetUID);
		_007B6729_007D.ReadStruct<int>(ref TotalPrice);
		_007B6729_007D.ReadIMPSNoNull<GSI>(ref Content);
	}
}
