namespace Common.Game;

public enum FractionDisputeType
{
	None,
	Voting,
	Kingship
}
