using System;
using Common.Resources;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct PbsAttackWindow : IMPSerializable
{
	public int StartHour;

	public int EndHour(IslePortInfo _007B7839_007D)
	{
		return (StartHour + (_007B7839_007D?.PbWindowDuration ?? 2)) % 24;
	}

	public PbsAttackWindow(int _007B7840_007D)
	{
		StartHour = _007B7840_007D;
	}

	private void _007B7841_007D(WriterExtern _007B7842_007D)
	{
		_007B7842_007D.WriteByte((byte)StartHour);
	}

	private void _007B7843_007D(WriterExtern _007B7844_007D)
	{
		StartHour = _007B7844_007D.ReadByte();
	}

	public bool IsInInterval(IslePortInfo _007B7845_007D, int _007B7846_007D)
	{
		if (StartHour > EndHour(_007B7845_007D))
		{
			return _007B7846_007D >= StartHour || _007B7846_007D < EndHour(_007B7845_007D);
		}
		return _007B7846_007D >= StartHour && _007B7846_007D < EndHour(_007B7845_007D);
	}

	public override string ToString()
	{
		return StartHour + "+";
	}

	public string ToStringFull(IslePortInfo _007B7847_007D, bool _007B7848_007D)
	{
		int num = StartHour;
		int num2 = EndHour(_007B7847_007D);
		string empty = string.Empty;
		if (_007B7848_007D)
		{
			int hours = (TimeZoneInfo.Local.BaseUtcOffset - LocalizedDateTime.ServerTimeZone).Hours;
			num = (num + hours + 24) % 24;
			num2 = (num2 + hours + 24) % 24;
			int hours2 = TimeZoneInfo.Local.BaseUtcOffset.Hours;
			empty = " (GMT" + ((hours2 > 0) ? "+" : "") + hours2 + ")";
		}
		else
		{
			empty = " " + LocalizedDateTime.ServerTimezonePrefix;
		}
		string text = ((num < 10) ? ("0" + num) : num.ToString());
		string text2 = ((num2 < 10) ? ("0" + num2) : num2.ToString());
		string text3 = text + ".00-" + text2 + ".00";
		return text3 + empty;
	}
}
