using System;
using System.Collections.Generic;
using System.Linq;
using Common.Account;
using Common.Data;
using Common.Resources;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Helpers;

namespace Common.Game;

internal class GeneratedQuests
{
	private enum MakeAutoReward
	{
		No,
		GoldXp,
		WithRes
	}

	private Sequence srandom;

	private int err_limiter = 0;

	private static Tlist<Vector2> temp2 = new Tlist<Vector2>();

	private static Tlist<Vector2> bookedPositions = new Tlist<Vector2>();

	private static float zoneMinDistDefault => 250f;

	private static float zoneMaxDistDefault => 680f;

	public GeneratedQuests()
	{
		srandom = new Sequence(123);
	}

	public int Generate()
	{
		Gameplay.QuestsInfo = new XmlAssetLibrary<QuestInfo>();
		GeneratePortQuests();
		GenerateEducationQuests();
		GenerateDailyQuests();
		GenerateTreasuryMapsQuests();
		Gameplay.QuestsByPort = new LinkedDictionrary<IslePortInfo, QuestInfo>();
		foreach (QuestInfo item in (IEnumerable<QuestInfo>)Gameplay.QuestsInfo)
		{
			if (item.Company == QuestCompany.Daily)
			{
				item.Bonus.ForceAddToShip = true;
				if (!item.CalendarQuestDay.HasValue)
				{
					item.InternalPirateMonetBonus = 60;
				}
			}
			if (item.LocationPort != null)
			{
				Gameplay.QuestsByPort.Add(item.LocationPort, item);
				int num = ((item.Company == QuestCompany.Battle) ? 15 : ((item.Company != QuestCompany.Trading) ? ((item.Company == QuestCompany.Coastal) ? 10 : 0) : ((item.FirstStep is QuestTransferOrder) ? 20 : 10)));
				if (item.HardnessLevel >= 3)
				{
					num += 5;
				}
				item.InternalCraftTimnSkillBonus = num;
			}
		}
		Gameplay.EducationQuestsList = new Tlist<QuestInfo>(Gameplay.QuestsInfo.Where((QuestInfo x) => x.Company == QuestCompany.Education));
		return srandom.RangeInt(0, 1000000);
	}

	private void GeneratePortQuests()
	{
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_06be: Unknown result type (might be due to invalid IL or missing references)
		//IL_0780: Unknown result type (might be due to invalid IL or missing references)
		//IL_0782: Unknown result type (might be due to invalid IL or missing references)
		//IL_08cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_090a: Unknown result type (might be due to invalid IL or missing references)
		//IL_090c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c67: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c6c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0abd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0af9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0afb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d8e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d79: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eb5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eba: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0885: Unknown result type (might be due to invalid IL or missing references)
		//IL_0870: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d93: Unknown result type (might be due to invalid IL or missing references)
		//IL_046f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0471: Unknown result type (might be due to invalid IL or missing references)
		//IL_088a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1006: Unknown result type (might be due to invalid IL or missing references)
		//IL_100b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f31: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f1c: Unknown result type (might be due to invalid IL or missing references)
		//IL_127c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1281: Unknown result type (might be due to invalid IL or missing references)
		//IL_1123: Unknown result type (might be due to invalid IL or missing references)
		//IL_1128: Unknown result type (might be due to invalid IL or missing references)
		//IL_11cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_11d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a77: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a62: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f36: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a7c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1333: Unknown result type (might be due to invalid IL or missing references)
		//IL_131e: Unknown result type (might be due to invalid IL or missing references)
		//IL_10a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_1093: Unknown result type (might be due to invalid IL or missing references)
		//IL_1338: Unknown result type (might be due to invalid IL or missing references)
		//IL_10ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_1443: Unknown result type (might be due to invalid IL or missing references)
		//IL_1448: Unknown result type (might be due to invalid IL or missing references)
		//IL_158c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1591: Unknown result type (might be due to invalid IL or missing references)
		//IL_14cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_14b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_14d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_162b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1616: Unknown result type (might be due to invalid IL or missing references)
		//IL_1725: Unknown result type (might be due to invalid IL or missing references)
		//IL_172a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1630: Unknown result type (might be due to invalid IL or missing references)
		//IL_1797: Unknown result type (might be due to invalid IL or missing references)
		//IL_1782: Unknown result type (might be due to invalid IL or missing references)
		//IL_179c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a14: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a19: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ab3: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ab8: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b6e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b73: Unknown result type (might be due to invalid IL or missing references)
		//IL_18af: Unknown result type (might be due to invalid IL or missing references)
		//IL_18b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_1978: Unknown result type (might be due to invalid IL or missing references)
		//IL_197d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c34: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c1f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c39: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d18: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d1d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f50: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f57: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f80: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f85: Unknown result type (might be due to invalid IL or missing references)
		//IL_067a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0665: Unknown result type (might be due to invalid IL or missing references)
		//IL_063f: Unknown result type (might be due to invalid IL or missing references)
		//IL_062a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1de4: Unknown result type (might be due to invalid IL or missing references)
		//IL_1dcf: Unknown result type (might be due to invalid IL or missing references)
		//IL_067f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0644: Unknown result type (might be due to invalid IL or missing references)
		//IL_1de9: Unknown result type (might be due to invalid IL or missing references)
		foreach (IslePortInfo port in (IEnumerable<IslePortInfo>)Gameplay.WorldMap.Ports)
		{
			IEnumerable<NpcInfo> source = Gameplay.NpcsInfo.Where((NpcInfo x) => x.Location.AsWorldRegion?.ID == port.NearRegion.ID);
			Tlist<NpcInfo> tlist = new Tlist<NpcInfo>(source.Where((NpcInfo x) => x.Extras.IsPirate && !x.Extras.IsReinforcedType));
			Tlist<NpcInfo> tlist2 = new Tlist<NpcInfo>(source.Where((NpcInfo x) => x.Extras.IsPirate && x.Extras.IsReinforcedType && x.Descritpion != NpcType.PirateFraction1_Fleet && x.Descritpion != NpcType.PirateFraction2_Fleet));
			Tlist<NpcInfo> tlist3 = new Tlist<NpcInfo>(source.Where((NpcInfo x) => x.Descritpion == NpcType.Trader_Regular));
			Tlist<NpcInfo> tlist4 = new Tlist<NpcInfo>(source.Where((NpcInfo x) => x.Descritpion == NpcType.Trader_Ferryman));
			Tlist<NpcInfo> tlist5 = new Tlist<NpcInfo>(source.Where((NpcInfo x) => x.Descritpion == NpcType.Empire_Legendary2l));
			bool flag = port.portNameKey != "nport_11";
			int levelInt = port.NearRegion.LevelInt;
			int num = 0;
			for (int num2 = 0; num2 < 20; num2++)
			{
				bool flag2 = srandom.Chanse(40f);
				Vector2 val = (Vector2)(((_003F?)GetPosition(port.EntryPos, 200f, 600f, !flag2, int.MaxValue, int.MaxValue, considerHazardZones: false)) ?? GetPositionWitinPort(port));
				int timeInMinutes;
				int goldBonus;
				int xpBonus;
				QuestTransferOrder questTransferOrder = GenerateTradeTransferQuest(flag2, val, Gameplay.WorldMap, out timeInMinutes, out goldBonus, out xpBonus);
				if (questTransferOrder == null)
				{
					continue;
				}
				string text = "";
				if (questTransferOrder.TargetAsPort == null)
				{
					text = ((!questTransferOrder.IsSmuggling) ? string.Format(Local.Current("transfQ_toTrader" + Rand.RangeInt(1, 6)), questTransferOrder.ResInfo.Name) : string.Format(Local.Current("transfQ_smug" + Rand.RangeInt(1, 6)), questTransferOrder.ResInfo.Name));
					text += Local.transfQ_toTraderAppendix(Gameplay.WorldMap.GetNearPort(in questTransferOrder.TargetPosition).PortName);
				}
				else
				{
					if (questTransferOrder.IsSmuggling)
					{
						throw new NotSupportedException();
					}
					text = string.Format(Local.Current("transfQ_toPort" + Rand.RangeInt(1, 7)), questTransferOrder.ResInfo.Name, questTransferOrder.TargetAsPort.PortName);
				}
				QuestInfo questInfo = MakeQ((questTransferOrder.IsSmuggling ? Local.qname_delivery_smug : Local.qname_delivery) + " " + questTransferOrder.ResInfo.Name, port, text, QuestCompany.Trading);
				string _007B1187_007D = ((questTransferOrder.TargetAsPort != null) ? Local.ToPort(questTransferOrder.TargetAsPort.PortName) : ((!Gameplay.WorldMap.IsInsideMap(in questTransferOrder.TargetPosition)) ? Local.MerchantInTheSeaNearThePort_outside : Local.MerchantInTheSeaNearThePort(Gameplay.WorldMap.GetNearPort(in questTransferOrder.TargetPosition).PortName)));
				string textToolTipOrNull = Local.DeliverResourcesTo(questTransferOrder.ResInfo.Name, _007B1187_007D) + $", {Local.map_distance}: {(int)Vector2.Distance(val, (questTransferOrder.TargetAsPort == null) ? questTransferOrder.TargetPosition : questTransferOrder.TargetAsPort.EntryPos)}" + Environment.NewLine + Local.CargoWeight(questTransferOrder.Mass) + Environment.NewLine + Local.TransferQuestTt;
				questInfo.TextToolTipOrNull = textToolTipOrNull;
				questInfo.Portraits = Tlist<QuestPortrait>.FromParams(QuestPortrait.TraderMale, QuestPortrait.Villager);
				questInfo.Steps = new PregQuestCompleteInfo(questTransferOrder);
				questInfo.LocationPos = val;
				questInfo.Bonus.Gold = goldBonus;
				questInfo.Bonus.Xp.Value = xpBonus;
				if (num2 % 2 == 0 && port.NearRegion.LevelInt >= 2)
				{
					questInfo.LimitedTimeMinutes = timeInMinutes;
					questInfo.FailWhenTimeLeft = false;
				}
				questInfo.RegularInterval = 1;
				questInfo.Bonus.Items.Exs(35, 1);
				if (questTransferOrder.IsSmuggling || (questTransferOrder.TargetAsPort != null && !questTransferOrder.TargetAsPort.FlagsAllowedToEnter.Contains(OpenWorldFlag.Peaceful)))
				{
					questInfo.Limits.Add(QuestAdditionalLimit.RWithoutPeacefulFlag);
				}
				if (questTransferOrder.SailingDistance < 5000f && num <= 1)
				{
					questInfo.Limits.Add(QuestAdditionalLimit.CDontGetDamage);
					num++;
				}
				questInfo.HardnessLevel = Math.Max((!questTransferOrder.IsSmuggling) ? 1 : 2, Math.Min(3, (questTransferOrder.IsSmuggling ? 1 : 0) + ((questTransferOrder.SailingDistance > 2500f) ? 1 : 0) + ((questTransferOrder.SailingDistance > 5000f) ? 1 : 0) + ((questTransferOrder.Mass > 7000f) ? 1 : 0)));
				if (questTransferOrder.ResInfo.DestroyInHold > 0f)
				{
					questInfo.Limits.Add(QuestAdditionalLimit.FHavingHoldUpgradeWarning);
				}
				if (!questTransferOrder.IsSmuggling)
				{
					questInfo.Icon = ((questInfo.HardnessLevel == 3) ? new Rectangle(496, 1084, 92, 92) : new Rectangle(403, 1084, 92, 92));
				}
				else
				{
					questInfo.Icon = ((questInfo.HardnessLevel >= 2) ? new Rectangle(691, 1084, 92, 92) : new Rectangle(598, 1084, 92, 92));
				}
			}
			for (int num3 = 0; num3 < 4; num3++)
			{
				Vector2 val2 = NextQuestPos(srandom, port, onIsle: false, 50f);
				int timeInMinutes2;
				int goldBonus2;
				int xpBonus2;
				QuestTransportPassengers questTransportPassengers = GeneratePassengerTransportQuest(val2, Gameplay.WorldMap, out timeInMinutes2, out goldBonus2, out xpBonus2);
				if (questTransportPassengers != null)
				{
					string dialogText = string.Format(Local.Current("transfQ_passengers_" + num3 % 3), questTransportPassengers.PassengerCount, questTransportPassengers.TargetPort.PortName);
					QuestInfo questInfo2 = MakeQ(Local.qname_passengers, port, dialogText, QuestCompany.Coastal);
					questInfo2.TextToolTipOrNull = Local.TransportPassengersTo(questTransportPassengers.PassengerCount, questTransportPassengers.TargetPort.PortName);
					questInfo2.Portraits = Tlist<QuestPortrait>.FromParams(QuestPortrait.TraderMale, QuestPortrait.Villager);
					questInfo2.Steps = new PregQuestCompleteInfo(questTransportPassengers);
					questInfo2.LocationPos = val2;
					questInfo2.Bonus.Gold = goldBonus2;
					questInfo2.Bonus.Xp.Value = xpBonus2;
					questInfo2.LimitedTimeMinutes = timeInMinutes2;
					questInfo2.FailWhenTimeLeft = false;
					questInfo2.RegularInterval = 1;
					questInfo2.Limits.Add(QuestAdditionalLimit.RDontGetDamage);
					if (num3 == 4)
					{
						questInfo2.Limits.Add(QuestAdditionalLimit.CDontUseCannons);
					}
					questInfo2.RistrictionKeepShipHealth = 0.8f;
					questInfo2.Bonus.Items.Exs(35, 1);
					questInfo2.HardnessLevel = Math.Min(3, 1 + ((questTransportPassengers.SailingDistance > 2500f) ? 1 : 0) + ((questTransportPassengers.SailingDistance > 5000f) ? 1 : 0) + ((num3 == 4) ? 1 : 0));
					questInfo2.Icon = ((questInfo2.HardnessLevel == 3) ? new Rectangle(884, 1084, 92, 92) : new Rectangle(791, 1084, 92, 92));
				}
			}
			if (flag)
			{
				for (int num4 = 0; num4 < 4; num4++)
				{
					Vector2 locationPos = NextQuestPos(srandom, port, onIsle: true);
					string dialogText2 = Local.Current("FindLoot_desc_" + Rand.RangeInt(0, 4));
					QuestInfo questInfo3 = MakeQ(Local.qname_collecting, port, dialogText2, QuestCompany.Coastal);
					questInfo3.LocationPos = locationPos;
					bool flag3 = num4 >= 4;
					int num5 = (int)((float)(140 + levelInt * 80) * (0.75f + 0.4f * srandom.Float()) * (flag3 ? 1.3f : 1f));
					int _007B7564_007D = ((levelInt <= 3) ? 4 : 6) + num4 % 2 + (flag3 ? 2 : 0);
					questInfo3.Portraits = Tlist<QuestPortrait>.FromParams(QuestPortrait.TraderFemale, QuestPortrait.Officier);
					questInfo3.Bonus.Xp.Value = num5;
					questInfo3.Bonus.ShipXp.Value = num5 / 2;
					questInfo3.Steps = new PregQuestCompleteInfo(new QuestCollectDropInSea(Local.q_collect, _007B7564_007D), new QuestReturnBack(Local.q_collect_return));
					questInfo3.HardnessLevel = 1;
					questInfo3.RegularInterval = 1;
					if (flag3)
					{
						questInfo3.Bonus.Gold.Value *= 2;
						questInfo3.Limits.Add(QuestAdditionalLimit.CDontGetDamage);
						questInfo3.LimitedTimeMinutes = 15;
						questInfo3.HardnessLevel = 2;
					}
					questInfo3.DisableReputation = true;
					questInfo3.Icon = ((questInfo3.HardnessLevel >= 2) ? new Rectangle(1076, 1084, 92, 92) : new Rectangle(983, 1084, 92, 92));
				}
			}
			if (flag)
			{
				for (int num6 = 0; num6 < 4; num6++)
				{
					Vector2 locationPos2 = NextQuestPos(srandom, port, onIsle: false, 50f);
					string dialogText3 = Local.Current("PersonFromShip_" + num6 % 2);
					QuestInfo questInfo4 = MakeQ(Local.qname_traderinshallow, port, dialogText3, QuestCompany.Coastal);
					questInfo4.LocationPos = locationPos2;
					int num7 = 240 + 140 * levelInt;
					questInfo4.Bonus.Gold = num7;
					questInfo4.Bonus.Xp.Value = (int)((float)num7 / 2f);
					questInfo4.Steps = new PregQuestCompleteInfo(new QuestFollowToPortHeader(Local.q_escort_crew, null, _007B7615_007D: false));
					questInfo4.Limits.Add(QuestAdditionalLimit.CDontGetDamage);
					questInfo4.RegularInterval = 1;
					questInfo4.Portraits = Tlist<QuestPortrait>.FromParams(QuestPortrait.Officier);
					questInfo4.DisableReputation = true;
					questInfo4.Icon = new Rectangle(597, 986, 92, 92);
				}
			}
			tlist2.Shuffle(srandom);
			for (int num8 = 0; num8 < Math.Min(tlist2.Size, 4); num8++)
			{
				string dialogText4 = Local.Current("QuestRiotAndRevenge_" + num8 % 2);
				QuestInfo questInfo5 = MakeQ(Local.qname_revenge, port, dialogText4, QuestCompany.Battle, MakeAutoReward.WithRes, new QuestBoardingShip(Local.q_boardShip(""), 1, new TargetShipNpcForQuest(tlist2[num8].Descritpion, null, port.NearRegion, _007B7739_007D: true)));
				questInfo5.LocationPos = NextQuestPos(srandom, port, onIsle: false);
				questInfo5.MinimalRank = 7;
				questInfo5.Bonus.Xp.Value += 50;
				questInfo5.Bonus.ShipXp.Value = (int)((float)questInfo5.Bonus.Xp.Value * 0.66f);
				questInfo5.Bonus.Gold.Value += 50;
				if (num8 == 0)
				{
					questInfo5.Limits.Add(QuestAdditionalLimit.RWithoutPeacefulFlag);
					questInfo5.HardnessLevel = 3;
				}
				else
				{
					questInfo5.HardnessLevel = 2;
				}
				if (port.BuildShipRangs >= 3)
				{
					questInfo5.Limits.Add(QuestAdditionalLimit.RShipRankRelyOnPortPlusOne);
				}
				questInfo5.RegularInterval = 1;
				questInfo5.OpenGroupNext = 777;
				questInfo5.Portraits = Tlist<QuestPortrait>.FromParams(QuestPortrait.Officier, QuestPortrait.Filibuster);
				questInfo5.Icon = ((questInfo5.HardnessLevel == 3) ? new Rectangle(498, 985, 92, 92) : new Rectangle(405, 985, 92, 92));
			}
			tlist.Shuffle(srandom);
			for (int num9 = 0; num9 < Math.Min(tlist.Size, 4); num9++)
			{
				float amount = ((levelInt == 0) ? 0.8f : 0.7f);
				string dialogText5 = Local.Current("QuestKillWithSailes_" + num9 % 2, Math.Round(amount * 100f));
				int num10 = 2 + num9 % 2;
				QuestInfo questInfo6 = MakeQ(Local.qname_desrSailes, port, dialogText5, QuestCompany.Battle, MakeAutoReward.GoldXp, new QuestKillShip(Local.q_killWithSailes, num10, new TargetShipNpcForQuest(tlist[num9].Descritpion, null, port.NearRegion, _007B7739_007D: true)
				{
					ExtraRequirement = (NpcShipDynamicInfo npc) => npc.MinAchievedSailStrength <= amount
				}));
				questInfo6.LocationPos = NextQuestPos(srandom, port, onIsle: true);
				questInfo6.MinimalRank = 8;
				questInfo6.HardnessLevel = ((num10 > 2) ? 3 : 2);
				questInfo6.RegularInterval = 1;
				questInfo6.OpenGroupNext = 777;
				questInfo6.Portraits = Tlist<QuestPortrait>.FromParams(QuestPortrait.Officier, QuestPortrait.Filibuster);
				questInfo6.Icon = ((questInfo6.HardnessLevel == 3) ? new Rectangle(884, 986, 92, 92) : new Rectangle(791, 986, 92, 92));
			}
			for (int num11 = 0; num11 < 3; num11++)
			{
				string dialogText6 = Local.Current("QuestDestroyTraders_" + num11 % 3);
				int num12 = ((levelInt == 0) ? srandom.RangeInt(2, 5) : srandom.RangeInt(3, 6));
				QuestInfo questInfo7 = MakeQ(Local.qname_killtrader, port, dialogText6, QuestCompany.Battle, MakeAutoReward.GoldXp, new QuestKillShip(Local.q_killTraders, num12, new TargetShipNpcForQuest(NpcType.Trader_Regular, null, port.NearRegion, _007B7739_007D: true)));
				questInfo7.LocationPos = NextQuestPos(srandom, port, onIsle: true);
				if (num11 % 2 == 0)
				{
					questInfo7.Limits.Add(QuestAdditionalLimit.CDontGetDamage);
				}
				else
				{
					questInfo7.Limits.Add(QuestAdditionalLimit.CDontDeath);
				}
				questInfo7.HardnessLevel = ((num12 <= 3) ? 1 : 2);
				questInfo7.RegularInterval = 1;
				questInfo7.OpenGroupNext = 777;
				questInfo7.Portraits = Tlist<QuestPortrait>.FromParams(default(QuestPortrait));
				questInfo7.Icon = ((questInfo7.HardnessLevel == 3) ? new Rectangle(1267, 986, 92, 92) : new Rectangle(1174, 986, 92, 92));
			}
			if (flag)
			{
				for (int num13 = 0; num13 < 4; num13++)
				{
					string dialogText7 = Local.Current("GrabbingTrader_" + num13 % 3);
					QuestInfo questInfo8 = MakeQ(Local.qname_traderinshallow, port, dialogText7, QuestCompany.Coastal);
					questInfo8.LocationPos = NextQuestPos(srandom, port, onIsle: false);
					int num14 = srandom.Pick<int>(1, 4, 2, 7, 11, 13);
					int num15 = 220 + 130 * levelInt;
					questInfo8.Bonus.Items.Exs(num14, num15 / Gameplay.ItemsInfo.FromID(num14).MediumCost.Value);
					questInfo8.Steps = new PregQuestCompleteInfo(new QuestNothingAction("", QuestNothingAction.SAction.SampleAttackByNearPirates));
					questInfo8.RegularInterval = 1;
					questInfo8.HardnessLevel = 2;
					questInfo8.DisableReputation = true;
					questInfo8.Icon = new Rectangle(597, 986, 92, 92);
				}
			}
			for (int num16 = 0; num16 < 2; num16++)
			{
				string dialogText8 = Local.Current("QuestPowderKeg_" + num16 % 2);
				QuestInfo questInfo9 = MakeQ(Local.qname_diversion, port, dialogText8, QuestCompany.Coastal, MakeAutoReward.WithRes, new QuestMakeSpecificDamage(Local.q_powderKegDestroy, 2, DamageID.PowderKeg, SpecificDamageFlags.None, _007B7663_007D: true, _007B7664_007D: true, new TargetShipNpcForQuest(NpcType.PirateFraction1_Reinforced, null, port.NearRegion, _007B7739_007D: true)));
				questInfo9.LocationPos = NextQuestPos(srandom, port, onIsle: false);
				if (num16 == 0)
				{
					questInfo9.Limits.Add(QuestAdditionalLimit.RDontGetDamage);
					questInfo9.HardnessLevel = 3;
					questInfo9.Bonus.Gold.Value *= 2;
				}
				else
				{
					questInfo9.HardnessLevel = 2;
				}
				questInfo9.RegularInterval = 1;
				questInfo9.OpenGroupNext = 777;
				questInfo9.Portraits = Tlist<QuestPortrait>.FromParams(QuestPortrait.Officier, QuestPortrait.Admiral, QuestPortrait.TraderMale);
				questInfo9.Icon = ((questInfo9.HardnessLevel == 3) ? new Rectangle(1269, 1084, 92, 92) : new Rectangle(1176, 1084, 92, 92));
			}
			NpcType value = (source.Any((NpcInfo x) => x.Descritpion == NpcType.PirateFraction2_Regular) ? NpcType.PirateFraction2_Regular : ((!source.Any((NpcInfo x) => x.Descritpion == NpcType.Fanatics)) ? NpcType.PirateFraction1_Regular : NpcType.Fanatics));
			for (int num17 = 0; num17 < 3; num17++)
			{
				string dialogText9 = Local.Current("QuestDestroyPirates_" + num17 % 4);
				int num18 = srandom.RangeInt(3, 5);
				QuestInfo questInfo10 = MakeQ(Local.qname_killpirate, port, dialogText9, QuestCompany.Battle, MakeAutoReward.GoldXp, new QuestKillShip(Local.q_killPirates, num18, new TargetShipNpcForQuest(value, null, port.NearRegion, _007B7739_007D: true)));
				questInfo10.LocationPos = NextQuestPos(srandom, port, onIsle: false);
				questInfo10.Limits.Add(QuestAdditionalLimit.CDontDeath);
				questInfo10.HardnessLevel = ((num18 < 4) ? 1 : 2);
				questInfo10.RegularInterval = 1;
				questInfo10.OpenGroupNext = 777;
				questInfo10.Portraits = Tlist<QuestPortrait>.FromParams(QuestPortrait.Admiral, QuestPortrait.Officier);
				questInfo10.Icon = ((questInfo10.HardnessLevel == 3) ? new Rectangle(1460, 986, 92, 92) : new Rectangle(1366, 986, 92, 92));
			}
			for (int num19 = 0; num19 < 2; num19++)
			{
				string dialogText10 = Local.Current("QuestDestroyPirates_" + srandom.RangeInt(0, 4));
				int num20 = srandom.RangeInt(3, 6);
				QuestInfo questInfo11 = MakeQ(Local.qname_killpirate2, port, dialogText10, QuestCompany.Battle, MakeAutoReward.GoldXp, new QuestKillShip(Local.q_killPirates2, num20, new TargetShipNpcForQuest(NpcType.PirateFraction1_Regular, null, port.NearRegion, _007B7739_007D: true)));
				questInfo11.LocationPos = NextQuestPos(srandom, port, onIsle: false);
				questInfo11.LimitedTimeMinutes = 25 + num19 * 2;
				questInfo11.FailWhenTimeLeft = false;
				questInfo11.Limits.Add(QuestAdditionalLimit.CDontDeath);
				questInfo11.HardnessLevel = ((num20 >= 4) ? 3 : 2);
				questInfo11.RegularInterval = 1;
				questInfo11.OpenGroupNext = 777;
				questInfo11.Portraits = Tlist<QuestPortrait>.FromParams(QuestPortrait.Admiral, QuestPortrait.Officier);
				questInfo11.Icon = ((questInfo11.HardnessLevel == 3) ? new Rectangle(1076, 986, 92, 92) : new Rectangle(983, 986, 92, 92));
			}
			tlist3.Shuffle(srandom);
			for (int num21 = 0; num21 < Math.Min(4, tlist3.Size); num21++)
			{
				string dialogText11 = Local.Current("QuestKillWithSailes_Caper_" + num21 % 2);
				int _007B7637_007D = 2 + num21 % 2;
				QuestInfo questInfo12 = MakeQ(Local.qname_desrSailes, port, dialogText11, QuestCompany.Battle, MakeAutoReward.GoldXp, new QuestKillShip(Local.q_killTradersWithSailes, _007B7637_007D, new TargetShipNpcForQuest(tlist3[num21].Descritpion, null, port.NearRegion, _007B7739_007D: true)
				{
					ExtraRequirement = (NpcShipDynamicInfo npc) => npc.FirstSailHP <= 0.7f
				}));
				questInfo12.MinimalRank = 12;
				questInfo12.LocationPos = NextQuestPos(srandom, port, onIsle: false);
				questInfo12.HardnessLevel = 2;
				questInfo12.RegularInterval = 1;
				questInfo12.OpenGroupNext = 777;
				questInfo12.Portraits = Tlist<QuestPortrait>.FromParams(QuestPortrait.Officier, QuestPortrait.Admiral, QuestPortrait.TraderMale);
				questInfo12.Icon = ((questInfo12.HardnessLevel == 3) ? new Rectangle(1656, 986, 92, 92) : new Rectangle(1563, 986, 92, 92));
			}
			if (tlist2.Size > 0)
			{
				Tlist<NpcInfo> tlist6 = new Tlist<NpcInfo>(tlist2);
				tlist6.SortTop((NpcInfo x) => x.ShipProperties.MaxHp.Value);
				NpcInfo npcInfo = ((levelInt <= 3) ? tlist6.Last() : tlist6.First());
				string dialogText12 = Local.Current("AgainstLegend_" + srandom.RangeInt(0, 2));
				QuestInfo questInfo13 = MakeQ(Local.qname_pve6, port, dialogText12, QuestCompany.Battle, MakeAutoReward.GoldXp, new QuestBoardingShip(Local.q_killLegendBoard(npcInfo.NpcName), 1, new TargetShipNpcForQuest(null, npcInfo.ID, null, _007B7739_007D: true)
				{
					MakeFailedWhenKilledWithoutAccepting = true
				}));
				questInfo13.LocationPos = NextQuestPos(srandom, port, onIsle: false);
				questInfo13.MinimalRank = 7;
				questInfo13.RegularInterval = 1;
				questInfo13.HardnessLevel = 3;
				questInfo13.Bonus.ShipXp.Value = (int)((float)questInfo13.Bonus.Xp.Value * 0.66f);
				questInfo13.Group = 777;
				questInfo13.Bonus.Gold.Value = Math.Max(questInfo13.Bonus.Gold.Value, 250 + levelInt * 110);
				questInfo13.Limits.Add(QuestAdditionalLimit.CDontDeath);
				questInfo13.Portraits = Tlist<QuestPortrait>.FromParams(QuestPortrait.Governor, QuestPortrait.Admiral);
				questInfo13.Icon = new Rectangle(1366, 1083, 92, 92);
			}
			for (int num22 = 0; num22 < 2; num22++)
			{
				string dialogText13 = Local.Current("Challenge_NoDamage_" + srandom.RangeInt(0, 2));
				QuestInfo questInfo14 = MakeQ(Local.qname_challengepirate, port, dialogText13, QuestCompany.Battle, MakeAutoReward.GoldXp, new QuestKillShip(Local.q_killWithoutDamage, 1, new TargetShipNpcForQuest(NpcType.PirateFraction1_Regular, null, port.NearRegion, _007B7739_007D: true)));
				questInfo14.LocationPos = NextQuestPos(srandom, port, onIsle: false);
				questInfo14.Bonus.Items.Exs(4, questInfo14.Bonus.Gold.Value / 15);
				questInfo14.Bonus.Gold.Value += 750;
				questInfo14.Limits.Add(QuestAdditionalLimit.RDontGetDamageFromTarget);
				questInfo14.HardnessLevel = 3;
				questInfo14.RegularInterval = 1;
				questInfo14.Group = 777;
				questInfo14.Portraits = Tlist<QuestPortrait>.FromParams(default(QuestPortrait));
				questInfo14.Icon = new Rectangle(1461, 1083, 92, 92);
			}
			if (tlist4.Size > 0)
			{
				string dialogText14 = Local.Current("KillFerry_" + srandom.RangeInt(0, 2));
				QuestInfo questInfo15 = MakeQ(Local.qname_killferry, port, dialogText14, QuestCompany.Battle, MakeAutoReward.GoldXp, new QuestKillShip(Local.q_killFerry, 1, new TargetShipNpcForQuest(NpcType.Trader_Ferryman, null, port.NearRegion, _007B7739_007D: true)));
				questInfo15.LocationPos = NextQuestPos(srandom, port, onIsle: false);
				questInfo15.RegularInterval = 1;
				questInfo15.HardnessLevel = 3;
				questInfo15.Bonus.Gold.Value += 100;
				questInfo15.Limits.Add(QuestAdditionalLimit.RWithoutPeacefulFlag);
				questInfo15.Bonus.Gold = (int)((float)questInfo15.Bonus.Gold.Value * 1.2f);
				questInfo15.Group = 777;
				questInfo15.Portraits = Tlist<QuestPortrait>.FromParams(QuestPortrait.TraderMale, QuestPortrait.Officier);
				questInfo15.Icon = ((questInfo15.HardnessLevel == 3) ? new Rectangle(1267, 986, 92, 92) : new Rectangle(1174, 986, 92, 92));
			}
			tlist2.Shuffle(srandom);
			for (int num23 = 0; num23 < Math.Min(4, tlist2.Size); num23++)
			{
				bool flag4 = num23 % 2 == 0;
				string dialogText15 = (flag4 ? Local.CaptureAndDeliverPirate_hard : Local.Current("CaptureAndDeliverPirate_" + num23 % 2));
				NpcInfo npcInfo2 = tlist2[num23];
				QuestInfo questInfo16 = MakeQ(Local.qname_pve4, port, dialogText15, QuestCompany.Battle, MakeAutoReward.WithRes, new QuestCaptureNpc(Local.q_captureShip(npcInfo2.NpcName), new TargetShipNpcForQuest(null, npcInfo2.ID, null, _007B7739_007D: true)), new QuestDeliverNpc(Local.q_escort_ship, npcInfo2.ID, null, _007B7590_007D: false, flag4));
				questInfo16.MinimalRank = 12;
				questInfo16.LocationPos = NextQuestPos(srandom, port, onIsle: false);
				if (port.BuildShipRangs >= 3)
				{
					questInfo16.Limits.Add(QuestAdditionalLimit.RShipRankRelyOnPortPlusOne);
				}
				questInfo16.Bonus.ShipXp.Value = (int)((float)questInfo16.Bonus.Xp.Value * 0.66f);
				questInfo16.HardnessLevel = (flag4 ? 3 : 2);
				questInfo16.RegularInterval = 1;
				questInfo16.Group = 777;
				questInfo16.Portraits = Tlist<QuestPortrait>.FromParams(QuestPortrait.Admiral, QuestPortrait.Officier);
				questInfo16.Icon = ((questInfo16.HardnessLevel == 3) ? new Rectangle(1657, 1083, 92, 92) : new Rectangle(1564, 1083, 92, 92));
			}
			for (int num24 = 0; num24 < 1; num24++)
			{
				int _007B3506_007D = 1;
				ResourceInfo resourceInfo = Gameplay.ItemsInfo.FromID(_007B3506_007D);
				IslePortInfo islePortInfo = Gameplay.WorldMap.FindNearPortBy(in port.EntryPos, (IslePortInfo xx) => xx != port && Vector2.Distance(xx.EntryPos, port.EntryPos) > 2894.1174f);
				int num25 = 30000 / resourceInfo.MediumCost.Value;
				num25 = (int)((float)num25 * port.Leveling);
				int num26 = 40000;
				int goldToGuildServer = 40000;
				QuestInfo questInfo17 = MakeQ(Local.qname_delivery_guild, port, "", QuestCompany.War);
				questInfo17.LimitedTimeMinutes = 45;
				questInfo17.FailWhenTimeLeft = false;
				questInfo17.TextToolTipOrNull = (questInfo17.FinalTextDialog = Local.QuestDeliveryGuild(num25, resourceInfo.Name, islePortInfo.PortName, (float)num25 * resourceInfo.Mass));
				questInfo17.Portraits = Tlist<QuestPortrait>.FromParams(QuestPortrait.TraderMale, QuestPortrait.Villager);
				questInfo17.Steps = new PregQuestCompleteInfo(new QuestTransferOrder(Local.q_guildTransfer(islePortInfo.PortName))
				{
					IsSmuggling = true,
					ResInfo = resourceInfo,
					ResourceCount = num25,
					SailingDistance = Vector2.Distance(port.EntryPos, islePortInfo.EntryPos),
					TargetAsPort = islePortInfo
				});
				questInfo17.LocationPos = port.EntryPos;
				questInfo17.Bonus.Gold = num26;
				questInfo17.ShareRewardWithGoup = true;
				questInfo17.Bonus.GoldToGuildServer = goldToGuildServer;
				questInfo17.Bonus.Xp.Value = (int)((float)num26 * Gameplay.BasicXpInGold * 0.33f);
				questInfo17.Bonus.PointsToGuildQuest = (GuildQuestScoped.SupplyMission, 500000);
				questInfo17.RegularInterval = 0;
				questInfo17.Limits.Add(QuestAdditionalLimit.RWithoutPeacefulFlag);
				questInfo17.HardnessLevel = 3;
			}
		}
	}

	private void GenerateEducationQuests()
	{
		QuestInfo questInfo = MakeQ(Local.education_quest_1_Name, null, Local.education_quest_1_text, QuestCompany.Education);
		questInfo.Bonus.SetEducationFlags.Add(EducationOnboarding.InitialQuest_DisplayNextStep);
		questInfo.Bonus.Gold = 500;
		questInfo.RegularInterval = 0;
		questInfo.OpenGroupNext = 777100;
		questInfo.Portraits.Add(QuestPortrait.StartQuestMan);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.DestroyNpcBlack, Local.startq_action_1_1), new QuestEducationFlag.Item(EducationOnboarding.FalkonetDamage, Local.startq_action_1_2), new QuestEducationFlag.Item(EducationOnboarding.PowderKegDamage, Local.startq_action_1_3)), new QuestFollowToPortHeader(Local.q_returnPort, null, _007B7615_007D: true));
		questInfo = MakeQ(Local.education_quest_2_Name, null, Local.education_quest_2_text, QuestCompany.Education);
		questInfo.Bonus.SetEducationFlags.Add(EducationOnboarding.InitialQuest_DisplayNextStep);
		questInfo.Bonus.Gold = 0;
		questInfo.Bonus.Xp = 100;
		questInfo.RegularInterval = 0;
		questInfo.Group = 777100;
		questInfo.OpenGroupNext = 777101;
		questInfo.Portraits.Add(QuestPortrait.StartQuestMan);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.SellItemsInTrade, Local.startq_action_2_4), new QuestEducationFlag.Item(EducationOnboarding.ShopCannonBalls, Local.startq_action_2_2)), new QuestFollowToPortHeader(Local.q_returnPort, null, _007B7615_007D: true));
		questInfo = MakeQ(Local.education_quest_3_Name, null, Local.education_quest_3_text, QuestCompany.Education);
		questInfo.Bonus.SetEducationFlags.Add(EducationOnboarding.InitialQuest_OpenTaverna);
		questInfo.Bonus.Gold = 250;
		questInfo.RegularInterval = 0;
		questInfo.Group = 777101;
		questInfo.OpenGroupNext = 777102;
		questInfo.Portraits.Add(QuestPortrait.StartQuestMan);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.InstallUpgrade, Local.startq_action_3_1), new QuestEducationFlag.Item(EducationOnboarding.GivePowerupItems, Local.startq_action_3_2)), new QuestFollowToPortHeader(Local.q_returnPort, null, _007B7615_007D: true));
		questInfo = MakeQ(Local.education_quest_4_Name, null, Local.education_quest_4_text, QuestCompany.Education);
		questInfo.Bonus.SetEducationFlags.Add(EducationOnboarding.InitialQuest_DisplayNextStep);
		questInfo.Bonus.Items = new GSI().Exs(4, Gameplay.PlayersInfo.FromID(6).CraftCostDefault[4]);
		questInfo.Bonus.PowerupItems[41] += 3;
		questInfo.RegularInterval = 0;
		questInfo.Group = 777102;
		questInfo.OpenGroupNext = 777103;
		questInfo.Portraits.Add(QuestPortrait.StartQuestMan);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.UsePowerupItemInBattle, Local.startq_action_4_1)), new QuestFollowToPortHeader(Local.q_returnPort, null, _007B7615_007D: true));
		questInfo = MakeQ(Local.education_quest_5_Name, null, Local.education_quest_5_text, QuestCompany.Education);
		questInfo.Bonus.SetEducationFlags.Add(EducationOnboarding.InitialQuest_DisplayNextStep);
		questInfo.Bonus.Gold = 500;
		questInfo.RegularInterval = 0;
		questInfo.Group = 777103;
		questInfo.OpenGroupNext = 777104;
		questInfo.Portraits.Add(QuestPortrait.StartQuestMan);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.BuildNextShip, Local.startq_action_5_1(Gameplay.PlayersInfo[6].ShipName))), new QuestFollowToPortHeader(Local.q_returnPort, null, _007B7615_007D: true));
		questInfo = MakeQ(Local.education_quest_6_Name, null, Local.education_quest_6_text, QuestCompany.Education);
		questInfo.Bonus.SetEducationFlags.Add(EducationOnboarding.InitialQuest_OpenTravel);
		questInfo.Bonus.CrewToPort = new GSI().Exs(4, 5);
		questInfo.Bonus.DesignElements[94] = 1;
		questInfo.Bonus.RandomSpecialUnit = true;
		questInfo.Bonus.Gold = 500;
		questInfo.RegularInterval = 0;
		questInfo.Group = 777104;
		questInfo.OpenGroupNext = 777105;
		questInfo.Portraits.Add(QuestPortrait.StartQuestMan);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.CraftCannon, Local.startq_action_5_2), new QuestEducationFlag.Item(EducationOnboarding.GetCrewToNewShip, Local.startq_action_6_2), new QuestEducationFlag.Item(EducationOnboarding.InstallUpgradeForNonStartShip, Local.startq_action_6_3)), new QuestFollowToPortHeader(Local.q_returnPort, null, _007B7615_007D: true));
		questInfo = MakeQ(Local.education_quest_8_Name, null, Local.education_quest_8_text, QuestCompany.Education);
		questInfo.Bonus.SetEducationFlags.Add(EducationOnboarding.InitialQuest_DisplayNextStep);
		questInfo.Bonus.Xp = 300;
		questInfo.RegularInterval = 0;
		questInfo.Group = 777105;
		questInfo.OpenGroupNext = 777106;
		questInfo.Portraits.Add(QuestPortrait.StartQuestMan);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.WorldTravel, Local.startq_action_8_1), new QuestEducationFlag.Item(EducationOnboarding.BuyWoodInOtherPort, Local.startq_action_8_2), new QuestEducationFlag.Item(EducationOnboarding.ResearchSkillSailingCategory, Local.startq_action_8_3(Local.CaptainSkillsInfoWindow_12))), new QuestFollowToPortHeader(Local.q_returnPort, null, _007B7615_007D: true));
		questInfo = MakeQ(Local.education_quest_7_Name, null, Local.education_quest_7_text, QuestCompany.Education);
		questInfo.Bonus.SetEducationFlags.Add(EducationOnboarding.InitialQuest_OpenDaily);
		questInfo.Bonus.Items = new GSI().Exs(53, 10);
		questInfo.Bonus.AllReputations = 5;
		questInfo.Bonus.Gold = 0;
		questInfo.RegularInterval = 0;
		questInfo.Group = 777106;
		questInfo.OpenGroupNext = 777107;
		questInfo.Portraits.Add(QuestPortrait.StartQuestMan);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.CompleteQuest, Local.startq_action_7_1)));
		questInfo = MakeQ(Local.education_quest_trading, null, Local.education_quest_t1_text, QuestCompany.Education);
		questInfo.Bonus.SetEducationFlags.Add(EducationOnboarding.InitialQuest_DisplayNextStep);
		questInfo.Bonus.Gold = 500;
		questInfo.RegularInterval = 0;
		questInfo.Group = 777107;
		questInfo.OpenGroupNext = 888001;
		questInfo.Portraits.Add(QuestPortrait.TraderMale);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.OpenSpecificWorkshop, Local.startq_action_t1_1), new QuestEducationFlag.Item(EducationOnboarding.MakeBulkByQuest, Local.startq_action_t1_2)));
		questInfo = MakeQ(Local.education_quest_trading, null, Local.education_quest_t2_text, QuestCompany.Education);
		questInfo.Bonus.SetEducationFlags.Add(EducationOnboarding.InitialQuest_DisplayNextStep);
		questInfo.Bonus.Xp = 400;
		questInfo.RegularInterval = 0;
		questInfo.Group = 888001;
		questInfo.OpenGroupNext = 888002;
		questInfo.Portraits.Add(QuestPortrait.TraderMale);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.BuildFactory, Local.startq_action_t2_1(WosbCrafting.OpenFactoryPriceGold)), new QuestEducationFlag.Item(EducationOnboarding.DoFishing, Local.startq_action_t2_2), new QuestEducationFlag.Item(EducationOnboarding.MakeIsleActivity, Local.startq_action_t2_3)));
		questInfo = MakeQ(Local.education_quest_trading, null, Local.education_quest_t3_text, QuestCompany.Education);
		questInfo.Bonus.SetEducationFlags.Add(EducationOnboarding.InitialQuest_DisplayNextStep);
		questInfo.Bonus.Gold = 0;
		questInfo.Bonus.Items[35] += 20;
		questInfo.RegularInterval = 0;
		questInfo.Group = 888002;
		questInfo.OpenGroupNext = 888003;
		questInfo.Portraits.Add(QuestPortrait.TraderMale);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.BuyGoodItemsOnTraderInSea, Local.startq_action_t3_1), new QuestEducationFlag.Item(EducationOnboarding.TradeBetweenPorts, Local.startq_action_t3_2), new QuestEducationFlag.Item(EducationOnboarding.GetItemsFromFactory, Local.startq_action_t3_3)));
		questInfo = MakeQ(Local.education_quest_trading, null, Local.education_quest_t4_text, QuestCompany.Education);
		questInfo.Bonus.SetEducationFlags.Add(EducationOnboarding.InitialQuest_DisplayNextStep);
		questInfo.Bonus.Gold = 0;
		questInfo.Bonus.Items[24]++;
		questInfo.Bonus.FreeWorldResTravel = 1;
		questInfo.RegularInterval = 0;
		questInfo.Group = 888003;
		questInfo.OpenGroupNext = 888004;
		questInfo.Portraits.Add(QuestPortrait.TraderMale);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.AuctionBuyOrder, Local.startq_action_t4_1), new QuestEducationFlag.Item(EducationOnboarding.AuctionCreateOrder, Local.startq_action_t4_2)));
		questInfo = MakeQ(Local.education_quest_trading, null, Local.education_quest_t5_text, QuestCompany.Education);
		questInfo.Bonus.SetEducationFlags.Add(EducationOnboarding.InitialQuest_DisplayNextStep);
		questInfo.Bonus.Items[73] += WosbTreasuryMaps.CountToComplete(73);
		questInfo.Bonus.Gold = 0;
		questInfo.Bonus.RandomSpecialUnit = true;
		questInfo.Bonus.AllReputations = 5;
		questInfo.RegularInterval = 0;
		questInfo.Group = 888004;
		questInfo.Portraits.Add(QuestPortrait.TraderMale);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.BuildStorage, Local.startq_action_t5_1), new QuestEducationFlag.Item(EducationOnboarding.InstallUpgradeForHold, Local.startq_action_t5_2)));
		questInfo = MakeQ(Local.education_quest_battle, null, Local.education_quest_b1_text, QuestCompany.Education);
		questInfo.Bonus.Gold = 0;
		questInfo.Bonus.ShipXp = 200;
		questInfo.RegularInterval = 0;
		questInfo.Group = 777107;
		questInfo.OpenGroupNext = 999001;
		questInfo.Portraits.Add(QuestPortrait.StartQuestMan);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.HireGoodCrew, Local.startq_action_b1_1)));
		questInfo = MakeQ(Local.education_quest_battle, null, Local.education_quest_b2_text, QuestCompany.Education);
		questInfo.Bonus.Gold = 0;
		questInfo.RegularInterval = 0;
		questInfo.Bonus.Items.Exs(37, 50);
		questInfo.Bonus.RandomSpecialUnit = true;
		questInfo.Group = 999001;
		questInfo.OpenGroupNext = 999002;
		questInfo.Portraits.Add(QuestPortrait.StartQuestMan);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.AnticrewDamage, Local.startq_action_b2_1), new QuestEducationFlag.Item(EducationOnboarding.GameTT_CaptureShip, Local.startq_action_b2_2)));
		questInfo = MakeQ(Local.education_quest_battle, null, Local.education_quest_b3_text, QuestCompany.Education);
		questInfo.Bonus.Gold = 0;
		questInfo.Bonus.Xp = 300;
		questInfo.Bonus.AllReputations = 5;
		questInfo.Bonus.PowerupItems[12] += 15;
		questInfo.Bonus.PowerupItems[21] += 10;
		questInfo.Bonus.PowerupItems[41] += 5;
		questInfo.RegularInterval = 0;
		questInfo.Group = 999002;
		questInfo.OpenGroupNext = 999003;
		questInfo.Portraits.Add(QuestPortrait.StartQuestMan);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.KillThroughStern, Local.startq_action_b3_1), new QuestEducationFlag.Item(EducationOnboarding.DestroySailes, Local.startq_action_b3_2)));
		questInfo = MakeQ(Local.education_quest_battle, null, Local.education_quest_b6_text, QuestCompany.Education);
		questInfo.Bonus.Gold = 0;
		questInfo.Bonus.Cannons[9] = 4;
		questInfo.RegularInterval = 0;
		questInfo.Group = 999003;
		questInfo.OpenGroupNext = 999004;
		questInfo.Portraits.Add(QuestPortrait.StartQuestMan);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.BuildOrBuyShipRank5, Local.startq_action_b6_1)));
		questInfo = MakeQ(Local.education_quest_battle, null, Local.education_quest_b7_text, QuestCompany.Education);
		questInfo.Bonus.SetEducationFlags.Add(EducationOnboarding.InitialQuest_OpenDaily_2);
		questInfo.Bonus.Gold = 0;
		questInfo.Bonus.DesignElements[18] = 1;
		questInfo.Bonus.RandomDesign = true;
		questInfo.RegularInterval = 0;
		questInfo.Group = 999004;
		questInfo.OpenGroupNext = 999005;
		questInfo.Portraits.Add(QuestPortrait.StartQuestMan);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.PlayArena7Games, Local.startq_action_b7_2)));
		questInfo = MakeQ(Local.education_quest_battle, null, Local.education_quest_b7_text, QuestCompany.Education);
		questInfo.Bonus.SetEducationFlags.Add(EducationOnboarding.InitialQuest_OpenDaily_2);
		questInfo.Bonus.Gold = 0;
		questInfo.Bonus.Items[37] += 100;
		questInfo.RegularInterval = 0;
		questInfo.Group = 999005;
		questInfo.Portraits.Add(QuestPortrait.StartQuestMan);
		questInfo.Steps = new PregQuestCompleteInfo(new QuestEducationFlag("", new QuestEducationFlag.Item(EducationOnboarding.OpenGuildAndFractions, Local.startq_action_b8_1), new QuestEducationFlag.Item(EducationOnboarding.CreateOrJoinGroup, Local.startq_action_b8_2)));
	}

	private void GenerateDailyQuests()
	{
		QuestInfo questInfo = MakeQ(Local.qname_pvp5, null, Local.DailyChallenge_Pvp5, QuestCompany.Daily);
		questInfo.Bonus.Items = new GSI().Exs(37, 40);
		questInfo.RegularInterval = 1;
		questInfo.Steps = new PregQuestCompleteInfo(new QuestPassDistance(Local.q_passDistance, 8000));
		questInfo = MakeQ(Local.qname_pvp1, null, Local.DailyChallenge_Pvp1, QuestCompany.Daily);
		questInfo.NeedDailyQuestsTier2 = true;
		questInfo.Bonus.Items = new GSI().Exs(37, 50);
		questInfo.RegularInterval = 1;
		questInfo.Steps = new PregQuestCompleteInfo(new QuestKillShip(Local.q_killEnemyPlayers, 3, new TargetShipPlayerForQuest(_007B7753_007D: true, _007B7754_007D: false, 7, _007B7756_007D: true, _007B7757_007D: false, _007B7758_007D: false, _007B7759_007D: true)));
		QuestInfo questInfo2 = MakeQ(Local.qname_pvp4, null, Local.DailyChallenge_Pvp4, QuestCompany.Daily);
		questInfo2.Bonus.Gold = 2000;
		questInfo2.Bonus.Items = new GSI().Exs(38, 3);
		questInfo2.RegularInterval = 1;
		questInfo2.Steps = new PregQuestCompleteInfo(new QuestKillShip(Local.q_killBlackPlayers, 2, new TargetShipPlayerForQuest(_007B7753_007D: true, _007B7754_007D: false, 7, _007B7756_007D: false, _007B7757_007D: false, _007B7758_007D: true)));
		bool flag = false;
		questInfo = MakeQ(Local.qname_pvp2, null, Local.DailyChallenge_Pvp2, QuestCompany.Daily);
		questInfo.Bonus.Items = new GSI().Exs(37, 50);
		questInfo.Bonus.Gold = 5000;
		questInfo.RegularInterval = 1;
		questInfo.Steps = new PregQuestCompleteInfo(new QuestKillShip(Local.q_killTopGuilPlayers, 3, new TargetShipPlayerForQuest(_007B7753_007D: true, _007B7754_007D: false, 7, _007B7756_007D: true, _007B7757_007D: true)));
		questInfo = MakeQ(Local.qname_pvp3, null, Local.DailyChallenge_Pvp3, QuestCompany.Daily);
		questInfo.Bonus.Items = new GSI().Exs(37, 50);
		questInfo.RegularInterval = 1;
		questInfo.Steps = new PregQuestCompleteInfo(new QuestBoardingShip(Local.q_boardPlayers, 3, new TargetShipPlayerForQuest(_007B7753_007D: true, _007B7754_007D: false, 7, _007B7756_007D: false, _007B7757_007D: false, _007B7758_007D: false, _007B7759_007D: true)));
		QuestInfo questInfo3 = MakeQ(Local.q_arena2, null, Local.q_arena2_text, QuestCompany.Daily);
		questInfo3.Bonus.Items = new GSI().Exs(37, 45);
		questInfo3.RegularInterval = 1;
		questInfo3.Steps = new PregQuestCompleteInfo(new QuestArenaKillShip(Local.q_arena2_action, 12, ArenaMode.WallVsWall));
		questInfo3 = MakeQ(Local.q_arena_collecting, null, Local.q_arena_collecting_text, QuestCompany.Daily);
		questInfo3.Bonus.Items = new GSI().Exs(37, 70);
		questInfo3.RegularInterval = 1;
		questInfo3.Steps = new PregQuestCompleteInfo(new QuestArenaCollectLootingMode(Local.q_arena_collecting_action, 40));
		questInfo3 = MakeQ(Local.q_arena_tournament, null, Local.q_arena_tournament_text, QuestCompany.Daily);
		questInfo3.Bonus.Items = new GSI().Exs(37, 85);
		questInfo3.RegularInterval = 1;
		questInfo3.Steps = new PregQuestCompleteInfo(new QuestArenaGames(Local.q_arena_tournament_action, ArenaMode.DuelRating, 4, 500f, false));
		questInfo3 = MakeQ(Local.q_arena_win, null, Local.q_arena_win_text, QuestCompany.Daily);
		questInfo3.Bonus.ArenaCurrency = 250;
		questInfo3.RegularInterval = 1;
		questInfo3.Steps = new PregQuestCompleteInfo(new QuestArenaGames(Local.q_arena_win_action, Enum.GetValues<ArenaMode>(), 8, 0f, true));
		questInfo3 = MakeQ(Local.q_arena_gold, null, Local.q_arena_gold_text, QuestCompany.Daily);
		questInfo3.Bonus.ArenaCurrency = 200;
		questInfo3.RegularInterval = 1;
		questInfo3.Steps = new PregQuestCompleteInfo(new QuestArenaEarnMoneyByFinish(Local.q_arena_gold_action, 60000));
		questInfo3 = MakeQ(Local.q_arena_first_place, null, Local.q_arena_first_place_text, QuestCompany.Daily);
		questInfo3.Bonus.ArenaCurrency = 300;
		questInfo3.RegularInterval = 1;
		questInfo3.Steps = new PregQuestCompleteInfo(new QuestArenaTakeFirstPlace(Local.q_arena_first_place_action, 5, ArenaMode.WallVsWall, ArenaMode.TowerDefence, ArenaMode.Collecting));
		questInfo3 = MakeQ(Local.q_arena3, null, Local.q_arena3_text, QuestCompany.Daily);
		questInfo3.Bonus.Items = new GSI().Exs(37, 30);
		questInfo3.RegularInterval = 1;
		questInfo3.Steps = new PregQuestCompleteInfo(new QuestArenaGames(Local.q_arena3_action, new ArenaMode[1] { ArenaMode.WallVsWall }, 2, 250f, false, 5, 6, 7));
		CalendarEventInfo currentEvent = CalendarEvents.CurrentEvent;
		for (int i = 0; i < currentEvent.Days.Length; i++)
		{
			QuestStepHeader[] quest = currentEvent.Days[i].Quest;
			if (quest != null)
			{
				(string Name, string Desc) questNameAndDesc = currentEvent.GetQuestNameAndDesc(i + 1);
				string item = questNameAndDesc.Name;
				string item2 = questNameAndDesc.Desc;
				QuestInfo questInfo4 = MakeQ(item, null, item2, QuestCompany.Daily);
				questInfo4.Steps = new PregQuestCompleteInfo(quest);
				questInfo4.RegularInterval = -1;
				questInfo4.MinimalRank = 7;
				questInfo4.CalendarQuestDay = i + 1;
			}
		}
	}

	private void GenerateTreasuryMapsQuests()
	{
		QuestInfo questInfo = MakeQ(Local.res_71_name, null, Local.q_treasuryMap, QuestCompany.Daily);
		questInfo.TreasuryMapID = 71;
		questInfo.Steps = new PregQuestCompleteInfo(new QuestIndividualLoot(Local.q_individual_loot, DropModel.IsleTreasures, delegate
		{
			ComplexBonus complexBonus = new ComplexBonus();
			if (CalendarEvents.IsNewYear)
			{
				complexBonus.PowerupItems = new GSI().Exs(45, 50).Exs(46, 50).Exs(47, 50);
				complexBonus.Balls.Exs(21, Rand.RangeInt(100, 201));
			}
			complexBonus.Items.Exs(24, Rand.RangeInt(200, 401));
			switch (Rand.RangeInt(1, 5))
			{
			case 1:
				complexBonus.Monets = 75;
				break;
			case 2:
				complexBonus.Cannons = new GSI().Exs(Rand.Pick<int>(25, 26, 27), 5);
				break;
			case 3:
				complexBonus.Items.Exs(67, 25);
				break;
			case 4:
				complexBonus.Items.Exs(69, Rand.RangeInt(50, 76));
				break;
			}
			return complexBonus;
		}));
		QuestInfo questInfo2 = MakeQ(Local.res_73_name, null, Local.q_treasuryMap, QuestCompany.Daily);
		questInfo2.TreasuryMapID = 73;
		questInfo2.RegularInterval = 0;
		questInfo2.Steps = new PregQuestCompleteInfo(new QuestIndividualLoot(Local.q_individual_loot, DropModel.SpecialBox, delegate
		{
			ComplexBonus complexBonus = new ComplexBonus();
			int currentCost = 0;
			int maxCost = 10000;
			int[] _007B14490_007D = new int[6] { 1, 13, 2, 12, 3, 10 };
			int[] array = Rand.PickMany(2, _007B14490_007D).ToArray();
			AddResToReward(complexBonus, array[0], maxCost, ref currentCost);
			AddResToReward(complexBonus, array[1], maxCost, ref currentCost, addMaxAmount: true);
			return complexBonus;
		}));
		QuestInfo questInfo3 = MakeQ(Local.res_74_name, null, Local.q_treasuryMap, QuestCompany.Daily);
		questInfo3.TreasuryMapID = 74;
		questInfo3.RegularInterval = 0;
		questInfo3.Steps = new PregQuestCompleteInfo(new QuestIndividualLoot(Local.q_individual_loot, DropModel.SpecialBox, delegate
		{
			ComplexBonus complexBonus = new ComplexBonus();
			complexBonus.Items[35] += 7;
			complexBonus.Items.Exs(39, 6000 / Gameplay.ItemsInfo.FromID(39).MediumCost.Value);
			complexBonus.Items.Exs(24, 14000 / Gameplay.ItemsInfo.FromID(24).MediumCost.Value);
			complexBonus.Balls.Exs(Rand.Pick<int>(1, 2, 3), 1000);
			return complexBonus;
		}));
		QuestInfo questInfo4 = MakeQ(Local.res_75_name, null, Local.q_treasuryMap, QuestCompany.Daily);
		questInfo4.TreasuryMapID = 75;
		questInfo4.RegularInterval = 0;
		questInfo4.Steps = new PregQuestCompleteInfo(new QuestIndividualLoot(Local.q_individual_loot, DropModel.SpecialBox, delegate
		{
			ComplexBonus complexBonus = new ComplexBonus();
			complexBonus.Items[8] += 50;
			complexBonus.Items[35] += 10;
			int num = 10000;
			int num2 = 10;
			short[] _007B14485_007D = (from x in Gameplay.ItemsInfo
				where x.IsTradingItem && x.ID != 25
				select x.ID).ToArray();
			int currentCost = 0;
			for (int num3 = 0; num3 < num2; num3++)
			{
				if (currentCost >= num)
				{
					break;
				}
				AddResToReward(complexBonus, Rand.Pick(_007B14485_007D), num, ref currentCost);
			}
			return complexBonus;
		}));
		static void AddResToReward(ComplexBonus reward, int resId, int maxCost, ref int currentCost, bool addMaxAmount = false)
		{
			int value = Gameplay.ItemsInfo.FromID(resId).MediumCost.Value;
			int num = Math.Max(1, Rand.Round((maxCost - currentCost) / value));
			int num2 = (addMaxAmount ? num : Rand.RangeInt(1, num));
			reward.Items.Exs(resId, num2);
			currentCost += value * num2;
		}
	}

	private Vector2 NextQuestPos(Sequence srandom, IslePortInfo forPort, bool onIsle, float islesExtraDist = 0f)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		return (Vector2)(((_003F?)GetPosition(forPort.EntryPos, zoneMinDistDefault, zoneMaxDistDefault, onIsle, int.MaxValue, int.MaxValue, considerHazardZones: false, bookPosition: true, islesExtraDist)) ?? GetPositionWitinPort(forPort));
	}

	private Vector2 TradeQuestPosHelper(IEnumerable<Vector2> allowedPos, float minDist, float maxDist, Vector2 from, int maxLevelsDifference, int maxShallowDifference, bool allowToHazardWaters)
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		int levelInt = Gameplay.GetNearWorldRegion(in from).LevelInt;
		byte b = Gameplay.WorldMap.Shallows.Get(in from);
		bool flag = Gameplay.IsInHazardZone(in from);
		temp2.Clear();
		foreach (Vector2 allowedPo in allowedPos)
		{
			Vector2 _007B3649_007D = allowedPo;
			float num = Vector2.DistanceSquared(_007B3649_007D, from);
			if (num > minDist * minDist && num < maxDist * maxDist && (allowToHazardWaters || flag || !Gameplay.IsInHazardZone(in _007B3649_007D)))
			{
				int levelInt2 = Gameplay.GetNearWorldRegion(in _007B3649_007D).LevelInt;
				byte b2 = Gameplay.WorldMap.Shallows.Get(in _007B3649_007D);
				if (levelInt2 - levelInt <= maxLevelsDifference && b + maxShallowDifference >= b2)
				{
					temp2.Add(in _007B3649_007D);
				}
			}
		}
		if (temp2.Size == 0)
		{
			return default(Vector2);
		}
		return temp2.Rand(srandom);
	}

	private unsafe Vector2 PositionHelperTrader(Vector2 sourcePosition, float maxDist, bool is_far, int maxLevelsDifference, bool canBeOutsideSeam, bool allowToHazardWaters)
	{
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		float minDist = 1800f;
		float num = Math.Min(maxDist / 2f, 3800f);
		if (is_far)
		{
			Vector2 val = TradeQuestPosHelper(from x in Gameplay.WorldMap.TradersInSea
				where (x.Type == TraderInSeaType.TraderInSea || x.Type == TraderInSeaType.SmallVilage) && (canBeOutsideSeam || Gameplay.WorldMap.IsInsideMap(in x.Position))
				select x.Position, num, maxDist, sourcePosition, maxLevelsDifference, 0, allowToHazardWaters);
			if (val.X == 0f && val.Y == 0f)
			{
				if (err_limiter < 10)
				{
					GameLoader current = GameLoader.Current;
					Vector2 val2 = sourcePosition;
					current.AddImportant("Failure in PositionHelperTrader, sourcePosition: " + ((object)(*(Vector2*)(&val2))/*cast due to .constrained prefix*/).ToString());
				}
				err_limiter++;
				return Vector2.Zero;
			}
			return val;
		}
		Vector2 val3 = TradeQuestPosHelper(from x in Gameplay.WorldMap.TradersInSea
			where (x.Type == TraderInSeaType.TraderInSea || x.Type == TraderInSeaType.SmallVilage) && (canBeOutsideSeam || Gameplay.WorldMap.IsInsideMap(in x.Position))
			select x.Position, minDist, num, sourcePosition, maxLevelsDifference, 0, allowToHazardWaters);
		if (val3.X == 0f && val3.Y == 0f)
		{
			return PositionHelperTrader(sourcePosition, maxDist, is_far: true, maxLevelsDifference, canBeOutsideSeam, allowToHazardWaters);
		}
		return val3;
	}

	private IslePortInfo PositionHelperPort(Vector2 sourcePosition, float maxDist, bool is_far, int maxLevelsDifference, bool allowToHazardWaters)
	{
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		float minDist = 1000f;
		float num = Math.Min(maxDist / 2f, 3000f);
		if (is_far)
		{
			Vector2 _007B3051_007D = TradeQuestPosHelper(Gameplay.WorldMap.Ports.Select((IslePortInfo x) => x.EntryPos), num, maxDist, sourcePosition, maxLevelsDifference, 1, allowToHazardWaters);
			if (_007B3051_007D.X == 0f && _007B3051_007D.Y == 0f)
			{
				_007B3051_007D = TradeQuestPosHelper(Gameplay.WorldMap.Ports.Select((IslePortInfo x) => x.EntryPos), num * 0.66f, maxDist, sourcePosition, maxLevelsDifference + 1, 100, allowToHazardWaters);
			}
			if (_007B3051_007D.X == 0f && _007B3051_007D.Y == 0f)
			{
				throw new Exception();
			}
			return Gameplay.WorldMap.GetNearPort(in _007B3051_007D);
		}
		Vector2 _007B3051_007D2 = TradeQuestPosHelper(Gameplay.WorldMap.Ports.Select((IslePortInfo x) => x.EntryPos), minDist, num, sourcePosition, maxLevelsDifference, 1, allowToHazardWaters);
		if (_007B3051_007D2.X == 0f && _007B3051_007D2.Y == 0f)
		{
			return PositionHelperPort(sourcePosition, maxDist, is_far: true, maxLevelsDifference, allowToHazardWaters);
		}
		return Gameplay.WorldMap.GetNearPort(in _007B3051_007D2);
	}

	private static QuestInfo MakeQ(string shortName, IslePortInfo port, string dialogText, QuestCompany company)
	{
		QuestInfo item = new QuestInfo();
		item.QuestShortName = shortName;
		item.LocationPort = port;
		item.ID = Gameplay.QuestsInfo.NextID;
		item.FinalTextDialog = dialogText;
		item.Company = company;
		Gameplay.QuestsInfo.Add(in item);
		return item;
	}

	private static QuestInfo MakeQ(string shortName, IslePortInfo port, string dialogText, QuestCompany company, MakeAutoReward makeAutoReward, params QuestStepHeader[] steps)
	{
		QuestInfo item = new QuestInfo();
		item.QuestShortName = shortName;
		item.LocationPort = port;
		item.ID = Gameplay.QuestsInfo.NextID;
		item.FinalTextDialog = dialogText;
		item.Steps = new PregQuestCompleteInfo(steps);
		item.Company = company;
		Gameplay.QuestsInfo.Add(in item);
		float num = ((makeAutoReward == MakeAutoReward.WithRes) ? 0.1f : 0.2f);
		float num2 = 0.15f;
		float num3 = 2f;
		if (steps.Any((QuestStepHeader x) => x is QuestKillShip { Target: TargetShipNpcForQuest target } && target.ExtraRequirement != null))
		{
			num3 += 1.5f;
		}
		if (makeAutoReward != MakeAutoReward.No)
		{
			for (int num4 = 0; num4 < item.Steps.Size; num4++)
			{
				QuestStepHeader questStepHeader = item.Steps.Array[num4];
				int? num5 = ((questStepHeader.Target is TargetShipNpcForQuest targetShipNpcForQuest) ? targetShipNpcForQuest.NpcID : ((questStepHeader is QuestDeliverNpc questDeliverNpc) ? new int?(questDeliverNpc.CapturedNpcID) : ((int?)null)));
				NpcType? npcType = ((questStepHeader.Target is TargetShipNpcForQuest targetShipNpcForQuest2) ? targetShipNpcForQuest2.Class : ((NpcType?)null));
				float num6 = num3 + (float)((questStepHeader.ProgressComparand == -1) ? 1 : questStepHeader.ProgressComparand);
				if (num5.HasValue)
				{
					NpcInfo npcInfo = Gameplay.NpcsInfo.FromID(num5.Value);
					item.Bonus.Gold.Value += (int)((float)npcInfo.RewardAmount.GoldBonus * num * num6);
					item.Bonus.Xp.Value += (int)((float)npcInfo.RewardAmount.XpBonus * num2 * num6);
				}
				else
				{
					if (!npcType.HasValue)
					{
						continue;
					}
					Bonus bonus = default(Bonus);
					float num7 = 0f;
					foreach (NpcInfo item2 in (IEnumerable<NpcInfo>)Gameplay.NpcsInfo)
					{
						if (item2.Descritpion == npcType.Value && item2.Location.AsWorldRegion == port.NearRegion)
						{
							bonus.GoldBonus += item2.RewardAmount.GoldBonus;
							bonus.XpBonus += item2.RewardAmount.XpBonus;
							num7 += 1f;
						}
					}
					if (num7 == 0f)
					{
						throw new NotSupportedException("computeBonusForKillNpcs");
					}
					item.Bonus.Gold.Value += (int)((float)bonus.GoldBonus / num7 * num * num6);
					item.Bonus.Xp.Value += (int)((float)bonus.XpBonus / num7 * num2 * num6);
				}
			}
			item.Bonus.Gold.Value += 380 + port.NearRegion.LevelInt * 50 / 2;
			item.Bonus.Xp.Value += 340 + port.NearRegion.LevelInt * 40 / 2;
			item.Bonus.Gold.Value = (int)Math.Ceiling((float)item.Bonus.Gold.Value / 10f) * 10;
			item.Bonus.Xp.Value = (int)Math.Ceiling((float)item.Bonus.Xp.Value / 10f) * 10;
			if (makeAutoReward == MakeAutoReward.WithRes)
			{
				item.Bonus.Items.Exs(35, 2);
				if (item.ID % 2 == 0)
				{
					item.Bonus.Items.Exs(12, 2 * (7 + port.NearRegion.LevelInt * 2));
					item.Bonus.Items.Exs(11, 7 + port.NearRegion.LevelInt * 2);
				}
				else
				{
					item.Bonus.Items.Exs(11, 7 + port.NearRegion.LevelInt * 2);
					item.Bonus.Items.Exs(13, 7 + port.NearRegion.LevelInt * 2);
				}
			}
			else
			{
				item.Bonus.Items.Exs(35, 1);
			}
		}
		return item;
	}

	private QuestTransferOrder GenerateTradeTransferQuest(bool isSmuggling, Vector2 approxSourcePosition, WorldMapInfo map, out int timeInMinutes, out int goldBonus, out int xpBonus)
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		int levelInt = Gameplay.GetNearWorldRegion(in approxSourcePosition).LevelInt;
		float num = levelInt switch
		{
			3 => 8000f, 
			2 => 6000f, 
			1 => 4000f, 
			0 => 3000f, 
			_ => 14000f, 
		};
		int maxLevelsDifference = 4;
		QuestTransferOrder questTransferOrder = new QuestTransferOrder("");
		questTransferOrder.IsSmuggling = isSmuggling;
		Vector2 val = default(Vector2);
		if (questTransferOrder.IsSmuggling || srandom.Chanse(25f))
		{
			val = PositionHelperTrader(approxSourcePosition, num, srandom.Boolean(), maxLevelsDifference, questTransferOrder.IsSmuggling, questTransferOrder.IsSmuggling);
			questTransferOrder.TargetAsPort = null;
			questTransferOrder.TargetPosition = val;
		}
		else
		{
			IslePortInfo islePortInfo = (questTransferOrder.TargetAsPort = PositionHelperPort(approxSourcePosition, num, srandom.Boolean(), maxLevelsDifference, questTransferOrder.IsSmuggling));
			questTransferOrder.TargetPosition = default(Vector2);
			val = islePortInfo.EntryPos;
		}
		if (val == Vector2.Zero)
		{
			timeInMinutes = -1;
			goldBonus = -1;
			xpBonus = -1;
			return null;
		}
		float num2 = Vector2.Distance(approxSourcePosition, val);
		float num3 = (float)Gameplay.GetNearWorldRegion(in approxSourcePosition).LevelInt * 0.66f + (float)Gameplay.GetNearWorldRegion(in val).LevelInt * 0.33f;
		float num4 = 300f + num3 * 200f;
		float num5 = num4 * 8f;
		float num6 = 500f + num3 * 300f;
		float num7 = 1500f + num3 * 500f;
		if (questTransferOrder.IsSmuggling)
		{
			num4 += 300f;
			num5 += 500f;
			num6 *= 1.3f;
			num7 *= 1.3f;
		}
		float num8 = num7 * (0.7f + num3 * 0.1f);
		if (questTransferOrder.IsSmuggling)
		{
			num8 = num7 * 0.8f;
		}
		float num12;
		while (true)
		{
			questTransferOrder.ResInfo = Gameplay.ItemsInfo.FromID(WosbTrading.GetResForTransferring(approxSourcePosition, srandom));
			if ((questTransferOrder.ResInfo.ID == 8 && !questTransferOrder.IsSmuggling) || (levelInt < 3 && questTransferOrder.ResInfo.DestroyInHold > 0f))
			{
				continue;
			}
			questTransferOrder.ResourceCount = (int)(srandom.Range(num4, num5) / questTransferOrder.ResInfo.Mass);
			if (!((float)(questTransferOrder.ResInfo.MediumCost.Value * questTransferOrder.ResourceCount.Value) > num8))
			{
				float num9 = num5 / questTransferOrder.ResInfo.Mass;
				float num10 = (float)questTransferOrder.ResourceCount.Value / num9;
				float num11 = num2 / Math.Max(5000f, num);
				num12 = MathHelper.Lerp(num6, num7, num10 * 0.3f + num11 * 0.8f);
				if (!(num12 < num6) && !(num12 > num7))
				{
					break;
				}
			}
		}
		goldBonus = (int)num12;
		goldBonus = (int)((double)goldBonus * Math.Pow(0.8f + num2 / 12000f, 1.2999999523162842));
		if (Geometry.IntersectRayWithSphere(ref approxSourcePosition, ref val, Gameplay.WorldHazardZones[0].X, Gameplay.WorldHazardZones[0].Y, Gameplay.WorldHazardZones[0].Z * 0.8f) && !Gameplay.IsInHazardZone(in approxSourcePosition))
		{
			goldBonus = (int)((float)goldBonus * 1.4f);
		}
		if (questTransferOrder.IsSmuggling || (questTransferOrder.TargetAsPort != null && !questTransferOrder.TargetAsPort.FlagsAllowedToEnter.Contains(OpenWorldFlag.Peaceful)))
		{
			goldBonus = (int)((float)goldBonus * 1.2f);
		}
		xpBonus = (int)(1f + (float)goldBonus * Gameplay.BasicXpInGold * 0.8f);
		float num13 = CommonSupport.MiddleSailingTime(16f, num2);
		timeInMinutes = (int)((num13 * 1.4f + 90f) * (srandom.Float() * 0.39999998f + 0.9f) / 60f) + 2;
		questTransferOrder.SailingDistance = num2;
		questTransferOrder.TextWhatToDo = ((questTransferOrder.TargetAsPort != null) ? Local.q_deliver_1(questTransferOrder.ResourceCount.Value, questTransferOrder.TargetAsPort.PortName, questTransferOrder.TargetAsPort.NearRegion.Name) : Local.q_deliver_2(questTransferOrder.ResourceCount.Value));
		return questTransferOrder;
	}

	private QuestTransportPassengers GeneratePassengerTransportQuest(Vector2 approxSourcePosition, WorldMapInfo map, out int timeInMinutes, out int goldBonus, out int xpBonus)
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		float num = Gameplay.GetNearWorldRegion(in approxSourcePosition).LevelInt switch
		{
			2 => 8000f, 
			1 => 7000f, 
			0 => 5000f, 
			_ => 14000f, 
		};
		int maxLevelsDifference = 4;
		IslePortInfo islePortInfo = PositionHelperPort(approxSourcePosition, num, srandom.Boolean(), maxLevelsDifference, allowToHazardWaters: false);
		Vector2 _007B3640_007D = islePortInfo.EntryPos;
		float num2 = Vector2.Distance(approxSourcePosition, _007B3640_007D);
		float num3 = (float)Gameplay.GetNearWorldRegion(in approxSourcePosition).LevelInt * 0.66f + (float)Gameplay.GetNearWorldRegion(in _007B3640_007D).LevelInt * 0.33f;
		int num4 = 1 + (int)(num3 * 2f);
		int num5 = 5 + (int)(num3 * 3f);
		float num6 = 400f + num3 * 300f;
		float num7 = 1000f + num3 * 500f;
		int num8 = srandom.RangeInt(num4, num5);
		float num9 = (float)(num8 - num4) / (float)(num5 - num4);
		float num10 = num2 / num;
		goldBonus = (int)MathHelper.Lerp(num6, num7, num9 * 0.3f + num10 * 0.8f);
		goldBonus = (int)((double)goldBonus * Math.Pow(0.8f + num2 / 12000f, 1.2999999523162842));
		xpBonus = (int)(1f + (float)goldBonus * Gameplay.BasicXpInGold * 0.8f);
		float num11 = CommonSupport.MiddleSailingTime(16f, num2);
		timeInMinutes = (int)((num11 * 1.4f + 90f) * (srandom.Float() * 0.39999998f + 0.9f) / 60f) + 2;
		return new QuestTransportPassengers(Local.q_transport_passengers(num8, islePortInfo.PortName, islePortInfo.NearRegion.Name))
		{
			PassengerCount = new RTI(num8),
			TargetPosition = _007B3640_007D,
			TargetPort = islePortInfo,
			SailingDistance = num2
		};
	}

	private Vector2 GetPositionWitinPort(IslePortInfo forPort)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = forPort.EntryPos + Geometry.SubstructRotate(forPort.Entry.Rotation, 100f);
		return val + srandom.NextVector2() * 20f;
	}

	private Vector2? GetPosition(Vector2 zoneCenter, float zoneMin, float zoneMax, bool tryFindOnIsle, int maxLevelsDifference, int maxShallowDifference, bool considerHazardZones = true, bool bookPosition = true, float extraDistanceFromIsels = 0f)
	{
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		bool flag = Gameplay.IsInHazardZone(in zoneCenter);
		int levelInt = Gameplay.GetNearWorldRegion(in zoneCenter).LevelInt;
		byte b = Gameplay.WorldMap.Shallows.Get(in zoneCenter);
		if (tryFindOnIsle)
		{
			for (int i = 0; i < 500; i++)
			{
				Vector2 item = Gameplay.WorldMap.PoolQuestPositionsIsles.Rand(srandom);
				float num = Vector2.DistanceSquared(item, zoneCenter);
				if (!(num < zoneMin * zoneMin) && !(num > zoneMax * zoneMax))
				{
					if (bookPosition)
					{
						Gameplay.WorldMap.PoolQuestPositionsIsles.FastRemove(in item);
					}
					return item;
				}
			}
		}
		for (int j = 0; j < 250; j++)
		{
			Vector2 item2 = Gameplay.WorldMap.RandomPosition(new Vector3(zoneCenter, zoneMax), 20f, 0f, srandom);
			float num2 = Vector2.DistanceSquared(item2, zoneCenter);
			if (num2 < zoneMin * zoneMin || num2 > zoneMax * zoneMax || (considerHazardZones && !flag && Gameplay.IsInHazardZone(in item2)) || Gameplay.GetNearWorldRegion(in item2).LevelInt - levelInt > maxLevelsDifference || maxShallowDifference < Gameplay.WorldMap.Shallows.Get(in item2) - b || (extraDistanceFromIsels > 0f && Gameplay.WorldMap.CheckPosition(item2, extraDistanceFromIsels)))
			{
				continue;
			}
			if (bookPosition)
			{
				bool flag2 = false;
				for (int k = 0; k < bookedPositions.Size; k++)
				{
					if (Vector2.DistanceSquared(bookedPositions.Array[k], item2) < 2500f)
					{
						flag2 = true;
						break;
					}
				}
				if (flag2)
				{
					continue;
				}
				bookedPositions.Add(in item2);
			}
			return item2;
		}
		return null;
	}
}
