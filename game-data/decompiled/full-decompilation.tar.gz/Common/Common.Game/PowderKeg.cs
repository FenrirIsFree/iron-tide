using Common.Resources;
using Microsoft.Xna.Framework;
using TheraEngine;

namespace Common.Game;

public class PowderKeg : UIDSceneObject
{
	public const float AnimationTimeMs = 1500f;

	public static readonly int FirebrandTimeoutMs = 25000;

	public Vector2 Position;

	public Vector2 DriftingSpeed;

	public float Ttl;

	public float TtlToEnd;

	public int SourceUID;

	public PowderKegInfo Info;

	public bool ShouldExplodeAfterTimeFinish => !Info.IsInvisibleMine && Ttl < 300000f;

	public float Lifetime => Ttl - TtlToEnd;

	public PowderKegTransferPacket TransferData()
	{
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		PowderKegTransferPacket result = default(PowderKegTransferPacket);
		result.NowPosition = Position;
		result.DriftingSpeed = DriftingSpeed;
		result.Ttl = TtlToEnd;
		result.TtlInit = Ttl;
		result.uID = uID;
		result.SourceUID = SourceUID;
		result.InfoID = (byte)Info.ID;
		return result;
	}

	public PowderKeg()
		: base(0)
	{
	}

	public void Init(Vector2 _007B5677_007D, int _007B5678_007D, int _007B5679_007D, PowderKegInfo _007B5680_007D, Vector2 _007B5681_007D, float _007B5682_007D)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		Info = _007B5680_007D;
		Position = _007B5677_007D;
		DriftingSpeed = _007B5681_007D;
		TtlToEnd = (Ttl = _007B5682_007D);
		SourceUID = _007B5679_007D;
		uID = _007B5678_007D;
	}

	public virtual bool Update(ref FrameTime _007B5683_007D)
	{
		TtlToEnd -= _007B5683_007D.msElapsed;
		Position.X += DriftingSpeed.X * _007B5683_007D.secElapsed;
		Position.Y += DriftingSpeed.Y * _007B5683_007D.secElapsed;
		return TtlToEnd < 0f;
	}
}
