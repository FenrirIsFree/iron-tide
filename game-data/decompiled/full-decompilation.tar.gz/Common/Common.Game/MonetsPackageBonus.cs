using Common.Account;

namespace Common.Game;

public class MonetsPackageBonus
{
	public static int GetExtraMonetsAmount(int _007B8280_007D, PlayerAccount? _007B8281_007D)
	{
		if (_007B8280_007D >= 10000)
		{
			return 15;
		}
		if (_007B8280_007D >= 4000)
		{
			return 7;
		}
		return 0;
	}

	public static int GetExtraMonetsForPayroll(int _007B8282_007D, PlayerAccount? _007B8283_007D)
	{
		int num = 0;
		return num + (int)((float)(_007B8282_007D * GetExtraMonetsAmount(_007B8282_007D, _007B8283_007D)) / 100f);
	}
}
