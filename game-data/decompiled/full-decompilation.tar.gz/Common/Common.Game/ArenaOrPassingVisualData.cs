using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct ArenaOrPassingVisualData : IMPSerializable
{
	public byte StatusIcon;

	public ArenaComandID ArenaTeam;

	public ArenaOrPassingVisualData(int _007B7129_007D, ArenaComandID _007B7130_007D)
	{
		StatusIcon = (byte)_007B7129_007D;
		ArenaTeam = _007B7130_007D;
	}

	private void _007B7131_007D(WriterExtern _007B7132_007D)
	{
		_007B7132_007D.WriteByte(StatusIcon);
		_007B7132_007D.WriteByte((byte)ArenaTeam);
	}

	private void _007B7133_007D(WriterExtern _007B7134_007D)
	{
		StatusIcon = _007B7134_007D.ReadByte();
		ArenaTeam = (ArenaComandID)_007B7134_007D.ReadByte();
	}

	public override bool Equals(object _007B7135_007D)
	{
		ArenaOrPassingVisualData arenaOrPassingVisualData = (ArenaOrPassingVisualData)_007B7135_007D;
		return arenaOrPassingVisualData.StatusIcon == StatusIcon && arenaOrPassingVisualData.ArenaTeam == ArenaTeam;
	}
}
