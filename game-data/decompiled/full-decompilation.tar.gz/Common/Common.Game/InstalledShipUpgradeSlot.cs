namespace Common.Game;

public readonly struct InstalledShipUpgradeSlot
{
	public readonly int SlotIndex;

	public readonly ShipUpgradeInstance Info;

	public InstalledShipUpgradeSlot(int _007B4764_007D, ShipUpgradeInstance _007B4765_007D)
	{
		SlotIndex = _007B4764_007D;
		Info = _007B4765_007D;
	}
}
