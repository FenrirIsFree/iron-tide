using System;
using System.Linq;
using Microsoft.Xna.Framework;
using TheraEngine.Interface.Controls;

namespace Common.Game;

public static class Gcc
{
	public static readonly (int, int) PassLengthLimits = (4, 20);

	public static readonly (int, int) NameLengthLimits = (4, 16);

	public static readonly int MaxEmailLength = 45;

	public const string UnnamedName = "unnamed_";

	public const float MaxSpecialWordsInNickname = 2f / 3f;

	public static readonly (int, int) GuildNameLimits = (3, 23);

	public const int MaxGuildDescLen = 250;

	public const int HoursToDeleteAccountRequest = 72;

	public const float UnflattenWorldScale = 0.82f;

	public const float WorldActivitiesScale = 0.85f;

	public const float IsleProcuderalScale = 1.05f;

	public const float IslesScale = 0.246f;

	public const float HeightScale = 1.0365855f;

	public const float ShipModelsScale = 0.3f;

	public const float SimulationSpeedFactor = 1f;

	public static string ModerateNickname(ref string _007B3798_007D)
	{
		_007B3798_007D = _007B3798_007D.TrimStart(' ');
		_007B3798_007D = _007B3798_007D.Replace(Environment.NewLine, "");
		if (_007B3798_007D.Length == 0)
		{
			return "";
		}
		if (_007B3798_007D.Length < NameLengthLimits.Item1)
		{
			return Local.length_ristriction_min(NameLengthLimits.Item1);
		}
		if (_007B3798_007D.Length > NameLengthLimits.Item2)
		{
			if (_007B3798_007D.Length > NameLengthLimits.Item2 + 2)
			{
				_007B3798_007D = _007B3798_007D.Substring(0, NameLengthLimits.Item2 + 2);
			}
			return Local.length_ristriction_max(NameLengthLimits.Item2);
		}
		if (TextBox.NonLettersAmount(_007B3798_007D) >= 2f / 3f || _007B3798_007D.Count((char _007B3806_007D) => char.IsLetter(_007B3806_007D)) <= 2)
		{
			return Local.EntryScene_27;
		}
		if (!ChatCensure.CheckIsNormal(_007B3798_007D))
		{
			return Local.bad_words_nick;
		}
		return null;
	}

	public static string ModerateLogin(ref string _007B3799_007D)
	{
		if (_007B3799_007D.Length == 0)
		{
			return "";
		}
		if (_007B3799_007D.Length < 3)
		{
			return Local.length_ristriction_min(3);
		}
		if (_007B3799_007D.Length > MaxEmailLength)
		{
			_007B3799_007D = _007B3799_007D.Substring(0, MaxEmailLength);
			return Local.length_ristriction_max(MaxEmailLength);
		}
		return null;
	}

	public static string ModeratePassword(ref string _007B3800_007D)
	{
		if (_007B3800_007D.Length == 0)
		{
			return "";
		}
		if (_007B3800_007D.Length < PassLengthLimits.Item1)
		{
			return Local.length_ristriction_min(PassLengthLimits.Item1);
		}
		if (_007B3800_007D.Length > PassLengthLimits.Item2)
		{
			_007B3800_007D = _007B3800_007D.Substring(0, PassLengthLimits.Item2);
			return Local.length_ristriction_max(PassLengthLimits.Item2);
		}
		return null;
	}

	public static string ModerateLoginEmail(ref string _007B3801_007D)
	{
		if (_007B3801_007D.Length == 0)
		{
			return "";
		}
		if (_007B3801_007D.Length > MaxEmailLength)
		{
			return Local.length_ristriction_max(MaxEmailLength);
		}
		if ((!_007B3801_007D.Contains('@') || !_007B3801_007D.Contains('.')) && _007B3801_007D.Length > 0)
		{
			return Local.EscapeInterface_19;
		}
		return null;
	}

	public static string ModerateText(string _007B3802_007D, int _007B3803_007D, int _007B3804_007D)
	{
		if (_007B3802_007D.Length == 0)
		{
			return "";
		}
		if (_007B3802_007D.Length < _007B3803_007D)
		{
			return Local.length_ristriction_min(_007B3803_007D);
		}
		if (_007B3802_007D.Length > _007B3804_007D)
		{
			return Local.length_ristriction_max(_007B3804_007D);
		}
		if (!ChatCensure.CheckIsNormal(_007B3802_007D))
		{
			return Local.bad_words_nick;
		}
		return null;
	}

	public static Vector3 GetExactIsleScale(string _007B3805_007D)
	{
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		float num = 1.0365855f;
		if (_007B3805_007D.Contains("FortMain") || _007B3805_007D.Contains("port_") || _007B3805_007D.Contains("personal_isle") || _007B3805_007D.Contains("trader_") || _007B3805_007D.Contains("factory_"))
		{
			return new Vector3(0.246f * num);
		}
		return new Vector3(0.246f, 0.246f * num, 0.246f);
	}
}
