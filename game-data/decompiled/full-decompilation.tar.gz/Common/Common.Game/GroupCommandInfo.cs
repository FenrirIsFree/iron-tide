using Microsoft.Xna.Framework;

namespace Common.Game;

public readonly struct GroupCommandInfo
{
	private readonly GroupCommandId _007B5969_007D;

	public string DisplayName => Local.Current("gc_" + _007B5969_007D);

	public bool NpcCommand => _007B5969_007D == GroupCommandId.NpcSetSimple || _007B5969_007D == GroupCommandId.NpcSetAntisail || _007B5969_007D == GroupCommandId.NpcSetAnticrew || _007B5969_007D == GroupCommandId.NpcSetSakson || _007B5969_007D == GroupCommandId.NpcStopFire;

	private bool HasEnemyTarget => _007B5969_007D == GroupCommandId.NpcSetSimple || _007B5969_007D == GroupCommandId.NpcSetAntisail || _007B5969_007D == GroupCommandId.NpcSetAnticrew || _007B5969_007D == GroupCommandId.NpcSetSakson || _007B5969_007D == GroupCommandId.FocusOn;

	public bool HasTarget => HasEnemyTarget || _007B5969_007D == GroupCommandId.InviteGroup;

	public GroupCommandInfo(GroupCommandId _007B5965_007D)
	{
		_007B5969_007D = _007B5965_007D;
	}

	public bool AbleToUse(Player _007B5966_007D)
	{
		if (HasEnemyTarget)
		{
			return !_007B5966_007D.IsStatic;
		}
		return true;
	}

	public bool IsTargetClose(Player _007B5967_007D, Ship _007B5968_007D)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		if (HasEnemyTarget && NpcCommand)
		{
			return Vector2.Distance(_007B5967_007D.Position, _007B5968_007D.Position) < 200f;
		}
		return true;
	}
}
