using System;
using System.Collections.Generic;
using Common.Account;
using Common.Data;
using Common.Resources;
using CommonDataTypes;
using TheraEngine;

namespace Common.Game;

public static class WosbPbs
{
	public class PbsBuildingStats
	{
		public float Strength;

		public int[] AvailableCannonsToSet;

		public int ModelIndex;

		public PbsBuildingStats(int _007B4280_007D, float _007B4281_007D, int[] _007B4282_007D)
		{
			Strength = _007B4281_007D;
			AvailableCannonsToSet = _007B4282_007D;
			ModelIndex = _007B4280_007D;
		}
	}

	public const bool EnableWind = true;

	public const int BasicTeamLimitation = 20;

	public static float PBBattleTimeInitialSec = 1500f;

	public static float PBBattleTimeMaxSec = 5400f;

	public static float PBBattleTimeSec_DestroyTower = 600f;

	public static float PBBattleTimeSec_KillPlayer_Min = 60f;

	public static float PBBattleTimeSec_KillPlayer_Max = 120f;

	public static float PBBattleTimeUnactivity_Sec = 600f;

	public static float StrengthDisablingAttack = 500f;

	public const float AvanpostPermanentSafezoneRadius = 50f;

	public const int AgainEntryBanDurationMinutes = 1000;

	public const int FortBoardingDurationMs = 25000;

	public const int TowerCapturingDurationMs = 30000;

	public static float MendingAmountPerHour = 0.02f;

	public static int ReduceCityLevelAfterDestruction = 1;

	public static readonly (int id, int count) GuildMendingPricePer1k = (id: 16, count: 1);

	public static int FactoryBoostTimeoutDays = 5;

	private const float deg = 0.0174533f;

	public static readonly Dictionary<InitialDynamicBuildingId, PbsTowerDescription> TowerDesription = new Dictionary<InitialDynamicBuildingId, PbsTowerDescription>
	{
		[InitialDynamicBuildingId.FortTowerMortar] = new PbsTowerDescription(120f, 15f, 0f, 50f, 190f),
		[InitialDynamicBuildingId.FortTowerFire] = new PbsTowerDescription(30f, 0.5f, 0.7853985f, 14f, 115f),
		[InitialDynamicBuildingId.FortTowerCannons] = null
	};

	public static PbsBuildingStats[] FortLevelsByPort = new PbsBuildingStats[7]
	{
		new PbsBuildingStats(0, 10000f, new int[2] { 30, 31 }),
		new PbsBuildingStats(0, 12000f, new int[2] { 30, 31 }),
		new PbsBuildingStats(1, 15000f, new int[3] { 30, 31, 32 }),
		new PbsBuildingStats(1, 20000f, new int[3] { 30, 31, 32 }),
		new PbsBuildingStats(2, 25000f, new int[3] { 30, 31, 32 }),
		new PbsBuildingStats(2, 29000f, new int[3] { 30, 31, 32 }),
		new PbsBuildingStats(3, 33000f, new int[3] { 30, 31, 32 })
	};

	internal static PbsBuildingStats[] TowerLevelsByPort = new PbsBuildingStats[7]
	{
		new PbsBuildingStats(0, 6000f, null),
		new PbsBuildingStats(1, 7000f, null),
		new PbsBuildingStats(1, 8000f, null),
		new PbsBuildingStats(1, 9000f, null),
		new PbsBuildingStats(2, 10500f, null),
		new PbsBuildingStats(2, 12000f, null),
		new PbsBuildingStats(2, 12000f, null)
	};

	public const int TradeUnionPortHqDurationDays = 7;

	public const float MaxTensityNotInWindow = 0.5f;

	public const float VassalDurationDays = 5f;

	public static readonly RTI ChageAttackWindowPrice = 50;

	public const int QuickTransferMoneyPriceCC = 10;

	public const int QuickTransferMoneyTimeoutHours = 3;

	public static int ProvidedPortMinLevel => 3;

	public static int GFactoryTempBoostPrice => 15;

	public static int MaxPlayersTrustedGuilds(int _007B4249_007D)
	{
		return (_007B4249_007D == int.MaxValue) ? int.MaxValue : Math.Max(_007B4249_007D, 3);
	}

	public static int MaxCapturableTowersCount(IslePortInfo _007B4250_007D)
	{
		return (int)MathF.Floor((float)(_007B4250_007D.PbSystem.Count - 1) / 2f);
	}

	public static float TimeToStartTowerAttackMs(in Decorator _007B4251_007D, bool _007B4252_007D, PortCaptureStatus _007B4253_007D)
	{
		if (((_007B4251_007D.ship.MirrorEngageInPortBattlePortID == -1) ? _007B4251_007D.ship.IsEntryToPortZoneContains : _007B4251_007D.ship.AllowEnteringPort) || _007B4251_007D.ship.ProtectionSafeZoneTimeout > 0f || _007B4251_007D.ship.UsedShip.IsInvisibilityBonusEnabled)
		{
			return -1f;
		}
		if (_007B4252_007D)
		{
			if (_007B4251_007D.ship.MirrorEngageInPortBattlePortID == _007B4253_007D.PortID)
			{
				return 0f;
			}
			return -1f;
		}
		if (_007B4251_007D.account.WorldFlag.IsPeaceMode() || _007B4251_007D.ship.UsedShip.StaticInfo.IsBalloon || _007B4251_007D.ship.IsStatic)
		{
			return -1f;
		}
		if (!_007B4253_007D.IsCapturedByGuild && !_007B4251_007D.account.TensityMode)
		{
			return -1f;
		}
		if (_007B4251_007D.account.WorldFlag.HideNicknameAndGuild(_007B4251_007D.ship))
		{
			return 40000f;
		}
		if ((_007B4251_007D.guild == null || _007B4251_007D.guild.IsFlotilia) && _007B4251_007D.account.Reputations.NeutralStatusWith(_007B4253_007D.CapturerFraction) != Relation.Enemy)
		{
			return -1f;
		}
		if (_007B4251_007D.guild != null && !_007B4251_007D.guild.IsFlotilia && _007B4253_007D.IsCapturedByGuild && FractionAPI.StatusWith(_007B4251_007D.guild, new GuildShortInfo(_007B4253_007D.CapturedBy, _007B4253_007D.CapturerFraction)) != Relation.Enemy)
		{
			return -1f;
		}
		return 15000f;
	}

	public static int PBTeamMaxRespawns(int _007B4254_007D, bool _007B4255_007D, IslePortInfo _007B4256_007D, bool _007B4257_007D)
	{
		return (int)((25f + (float)Math.Max(0, _007B4254_007D - 1) * 2.5f * (float)PBTeamUseRespawns((_007B4256_007D.ShallowUpperRang == -1) ? 1 : _007B4256_007D.ShallowUpperRang, ShipClass.CargoShip, PlayerShipCoolness.Default)) * ((!_007B4255_007D) ? 0.85f : 1f) * (_007B4257_007D ? 1.07f : 1f));
	}

	public static int PBTeamUseRespawns(int _007B4258_007D, ShipClass _007B4259_007D, PlayerShipCoolness _007B4260_007D)
	{
		int num = ((_007B4258_007D == 1 && _007B4260_007D == PlayerShipCoolness.Empire) ? 15 : (_007B4258_007D switch
		{
			5 => 3, 
			4 => 4, 
			3 => 5, 
			2 => 6, 
			1 => 7, 
			_ => 2, 
		}));
		if (_007B4259_007D == ShipClass.Hardship)
		{
			num += ((_007B4258_007D >= 4) ? 1 : 2);
		}
		if (_007B4259_007D == ShipClass.Battleship || _007B4260_007D == PlayerShipCoolness.Empire)
		{
			num++;
		}
		return num;
	}

	public static int NumBuildingLicensesForRobbing(PbsStatus _007B4261_007D)
	{
		return _007B4261_007D.IsCapturedByGuild ? _007B4261_007D.grownCity : 0;
	}

	public static bool FractionHasPBBonus(FractionID _007B4262_007D, int _007B4263_007D)
	{
		return (!_007B4262_007D.IsNation() || _007B4263_007D > 4) && false;
	}

	public static string TowerNameByIndex(InitialDynamicBuildingId _007B4264_007D)
	{
		return _007B4264_007D switch
		{
			InitialDynamicBuildingId.FortTowerCannons => Local.fort_tower_cannons, 
			InitialDynamicBuildingId.FortTowerMortar => Local.fort_tower_mortar, 
			_ => Local.fort_tower_fire, 
		};
	}

	public static float DamageFactorHelper(IslePortInfo _007B4265_007D)
	{
		return 0.4f + 0.5f * _007B4265_007D.Leveling;
	}

	internal static int UnitsCount(IslePortInfo _007B4266_007D)
	{
		return (int)(_007B4266_007D.Leveling * 130f * 4f);
	}

	public static GSI FortTowerBuildCost()
	{
		GSI gSI = new GSI();
		gSI.Exs(16, 4);
		gSI.Exs(14, 4);
		return gSI;
	}

	public static (int goldIngots, int conquerorBadges) TensityProtectionPrice(int _007B4267_007D, int _007B4268_007D)
	{
		int num = Math.Max(0, _007B4268_007D / 2 - 1);
		int item = (_007B4267_007D + num) * 10;
		int item2 = _007B4267_007D + num;
		return (goldIngots: item, conquerorBadges: item2);
	}

	public static int CalculateBuildingStrength(IslePortInfo _007B4269_007D, int _007B4270_007D, bool _007B4271_007D)
	{
		int num = Math.Max(1, _007B4269_007D.ShallowUpperRang);
		if (1 == 0)
		{
		}
		int num2 = num switch
		{
			1 => _007B4271_007D ? 12100 : 26400, 
			2 => _007B4271_007D ? 10000 : 21700, 
			3 => _007B4271_007D ? 9100 : 20000, 
			4 => _007B4271_007D ? 7700 : 16700, 
			5 => _007B4271_007D ? 6600 : 14500, 
			_ => _007B4271_007D ? 4500 : 10000, 
		};
		if (1 == 0)
		{
		}
		int num3 = num2;
		int portBattleTeamLimitation = _007B4269_007D.PortBattleTeamLimitation;
		if (1 == 0)
		{
		}
		double num4 = portBattleTeamLimitation switch
		{
			40 => 1.15, 
			20 => 1.0, 
			15 => 0.85, 
			10 => 0.7, 
			7 => 0.6, 
			5 => 0.5, 
			_ => 1.0, 
		};
		if (1 == 0)
		{
		}
		double num5 = num4;
		if (1 == 0)
		{
		}
		num4 = _007B4270_007D switch
		{
			1 => 1.0, 
			2 => 1.04, 
			3 => 1.08, 
			4 => 1.12, 
			5 => 1.16, 
			6 => 1.2, 
			7 => 1.24, 
			_ => 1.0, 
		};
		if (1 == 0)
		{
		}
		double num6 = num4;
		double num7 = (double)num3 * num5 * num6;
		return (int)(Math.Round(num7 / 100.0) * 100.0);
	}

	public static int NeedProvidedPortsToCaptureNew(int _007B4272_007D)
	{
		return 0;
	}

	public static ResourceInfo? PortHasDeficit(IslePortInfo _007B4273_007D, GSI _007B4274_007D)
	{
		foreach (GSILocalPair item in (IEnumerable<GSILocalPair>)_007B4273_007D.LiveTrading)
		{
			float num = (float)_007B4274_007D[item.ID] / (float)item.Count;
			if (num < 0.1f)
			{
				return Gameplay.ItemsInfo.FromID(item.ID);
			}
		}
		return null;
	}

	public static (RTI conquerorBadges, RTI goldIngots) GuildOpenHqOrLicensePrice(GuildCommon _007B4275_007D, int _007B4276_007D)
	{
		int[] array = new int[7] { 2, 4, 6, 10, 16, 24, 30 };
		int num = array[_007B4276_007D];
		if (_007B4275_007D.Fraction != FractionID.TradeUnion)
		{
			num /= 2;
		}
		return (conquerorBadges: num, goldIngots: num);
	}
}
