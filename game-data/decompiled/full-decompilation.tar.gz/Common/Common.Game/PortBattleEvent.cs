namespace Common.Game;

public enum PortBattleEvent
{
	NoEvent,
	TensityGrown,
	Defended,
	DefendedAndRobbed,
	Captured,
	WinWithoutCapture,
	WinAndMakeVassal
}
