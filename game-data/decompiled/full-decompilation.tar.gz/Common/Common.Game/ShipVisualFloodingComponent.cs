using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class ShipVisualFloodingComponent : IMPSerializable
{
	public byte ShipStaticInfoID;

	public int ShipUID;

	public bool isNpcShip;

	public ShipVisualFloodingComponent()
	{
	}

	public ShipVisualFloodingComponent(int _007B5588_007D, int _007B5589_007D, bool _007B5590_007D = false)
	{
		ShipStaticInfoID = (byte)_007B5588_007D;
		ShipUID = _007B5589_007D;
		isNpcShip = _007B5590_007D;
	}

	private void _007B5591_007D(WriterExtern _007B5592_007D)
	{
		_007B5592_007D.WriteByte(ShipStaticInfoID);
		_007B5592_007D.WriteStruct<int>(ref ShipUID);
		_007B5592_007D.Write(isNpcShip);
	}

	private void _007B5593_007D(WriterExtern _007B5594_007D)
	{
		ShipStaticInfoID = _007B5594_007D.ReadByte();
		_007B5594_007D.ReadStruct<int>(ref ShipUID);
		_007B5594_007D.ReadBoolean(ref isNpcShip);
	}
}
