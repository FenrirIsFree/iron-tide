using System;
using System.Collections.Generic;
using Common.Account;
using Common.Data;
using Common.Resources;

namespace Common.Game;

public static class NewYearCalendarEvent
{
	public static CalendarEventInfo Create()
	{
		CalendarEventInfo calendarEventInfo = new CalendarEventInfo(CalendarEvent.NewYear);
		calendarEventInfo.StartDate = new DateTime(2025, 12, 23);
		calendarEventInfo.GoldFishingEnabled = true;
		calendarEventInfo.RandomizedQuestDays = true;
		calendarEventInfo.AltarGoldFishEnabled = true;
		calendarEventInfo.OnFirstOpenAction = delegate(PlayerAccount _007B6109_007D)
		{
			CalendarEvents.GiveDesign(_007B6109_007D, 528);
			_007B6109_007D.EnvDecorElementsAtStorage[3]++;
		};
		calendarEventInfo.Days = new DayInfo[14]
		{
			new DayInfo(1)
			{
				Quest = QuestPresets.KillAnyNpc(15)
			},
			new DayInfo(2)
			{
				Quest = QuestPresets.CollectSpecialUnits(3)
			},
			new DayInfo(3)
			{
				Quest = QuestPresets.BoardingAnyNpc(5)
			},
			new DayInfo(4)
			{
				Quest = QuestPresets.CollectEmpireDrop(3)
			},
			new DayInfo(5)
			{
				Quest = QuestPresets.KillEmpireNpcInSeamlessSea(5)
			},
			new DayInfo(6)
			{
				Quest = QuestPresets.KillEmpireLegend(5)
			},
			new DayInfo(7)
			{
				Quest = QuestPresets.CollectKeys(3)
			},
			new DayInfo(8)
			{
				Quest = QuestPresets.ArenaNotTraining(10)
			},
			new DayInfo(9)
			{
				Quest = QuestPresets.FortDamage(3000)
			},
			new DayInfo(10)
			{
				Quest = QuestPresets.PassingMapEpic()
			},
			new DayInfo(11)
			{
				Quest = QuestPresets.KillWhale(10)
			},
			new DayInfo(12)
			{
				Quest = QuestPresets.FalkonetDamage(2000)
			},
			new DayInfo(13)
			{
				Quest = QuestPresets.FireAreaDamage(10000)
			},
			new DayInfo(14)
			{
				Quest = QuestPresets.ArenaNotTraining(10)
			}
		};
		calendarEventInfo.OnDayClosed = delegate(PlayerAccount _007B6110_007D, int _007B6111_007D)
		{
			CalendarEvents.GiveGoldFish(40, _007B6110_007D);
			CannonBallInfo cannonBallInfo = Gameplay.BallsInfo.FromID(21);
			_007B6110_007D.Shipyard.CurrentRealShip.BallsOfHold.AddOrRemove(21, 2000);
			CalendarEvents.SendLogbookMessage(Local.received("+2000 " + cannonBallInfo.Name));
			switch (_007B6111_007D)
			{
			case 3:
				CalendarEvents.GiveMonets(_007B6110_007D, 150);
				break;
			case 5:
				CalendarEvents.GiveDesign(_007B6110_007D, 525);
				break;
			case 6:
				CalendarEvents.GiveDesign(_007B6110_007D, 530);
				break;
			case 9:
				CalendarEvents.GivePremiumOrMonets(_007B6110_007D, 14, 200);
				break;
			case 12:
				CalendarEvents.GiveGoldFish(400, _007B6110_007D);
				break;
			}
		};
		calendarEventInfo.GoldfishTrader = new List<TraderOffer>(27)
		{
			new TraderOffer(2500, null, 0, 0, 468),
			new TraderOffer(2000, null, 0, 0, 537),
			new TraderOffer(1750, null, 0, 0, 404),
			new TraderOffer(1500, new TraderOffer.Resource(72, 75000)),
			new TraderOffer(1250, null, 0, 0, 536),
			new TraderOffer(1000, null, 0, 0, 531),
			new TraderOffer(900, null, 0, 0, 534),
			new TraderOffer(600, null, 0, 0, 535),
			new TraderOffer(600, null, 0, 0, 532),
			new TraderOffer(600, null, 0, 0, 562),
			new TraderOffer(420, new TraderOffer.Resource(68, 1)),
			new TraderOffer(300, new TraderOffer.Resource(72, 12000)),
			new TraderOffer(250, null, 0, 125),
			new TraderOffer(200, null, 0, 0, 524),
			new TraderOffer(150, new TraderOffer.Resource(23, 3000)),
			new TraderOffer(150, null, 0, 0, 529),
			new TraderOffer(100, null, 0, 0, 527),
			new TraderOffer(100, new TraderOffer.Resource(37, 1500)),
			new TraderOffer(100, new TraderOffer.Resource(15, 150)),
			new TraderOffer(40, new TraderOffer.Resource(5, 6000, StorageAssetEnum.Ammo)),
			new TraderOffer(20, new TraderOffer.Resource(7, 8000, StorageAssetEnum.Ammo)),
			new TraderOffer(10, null, 75000),
			new TraderOffer(5, new TraderOffer.Resource(43, 1)),
			new TraderOffer(1, new TraderOffer.Resource(15, 1)),
			new TraderOffer(1, new TraderOffer.Resource(72, 30)),
			new TraderOffer(1, new TraderOffer.Resource(37, 10)),
			CalendarEvents.SkipQuestOffer
		};
		return calendarEventInfo;
	}
}
