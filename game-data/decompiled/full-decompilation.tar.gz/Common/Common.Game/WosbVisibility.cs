using System;

namespace Common.Game;

public static class WosbVisibility
{
	public const float MapDistanceFactoriesTraders = 1832.941f;

	public const float MapDistanceNpsEvents = 1099.7646f;

	public static float MinimapLootVisibleDistance => 130f;

	public static float MinimapIslesAndFishVisibleDistance => ExtraVisibleDistanceMaxForDrop + VisibleDistanceMin;

	public static float VisibleDistanceMin => 190f;

	public static float ExtraVisibleDistanceMaxForShip => 45f;

	public static float ExtraVisibleDistanceMaxForDrop => 250f;

	public static float VisibleDistance(Player _007B4389_007D, float _007B4390_007D, float _007B4391_007D)
	{
		float num = VisibleDistanceMin * _007B4389_007D.UsedShipPlayer.ViewDistanceMultiplier;
		return num + 15f * Math.Min(_007B4390_007D, 1f - _007B4391_007D);
	}

	public static float ExtraVisibleDistanceFor(object _007B4392_007D, Player _007B4393_007D, float _007B4394_007D, float _007B4395_007D)
	{
		if (_007B4392_007D is Ship ship)
		{
			return ExtraVisibleDistanceMaxForShip * (0.5f + 0.5f * Math.Min(_007B4394_007D, 1f - _007B4395_007D)) * (float)(ship.MapInfo.IsWorldmap ? 1 : 0) * _007B4393_007D.UsedShip.ViewDistanceMultiplier;
		}
		if (_007B4392_007D is Drop { LongVisibleDistance: not false })
		{
			return ExtraVisibleDistanceMaxForDrop;
		}
		return 0f;
	}

	public static float SpyglassExtraDistance(Player _007B4396_007D, float _007B4397_007D, float _007B4398_007D)
	{
		float num = (_007B4396_007D.MapInfo.IsReducedFarDistView ? 50f : 100f);
		return num * (Math.Min(_007B4397_007D, 1f - _007B4398_007D) * 0.5f + 0.5f * (0.6f + 0.4f * (1f - _007B4398_007D)));
	}

	public static float ShipSilhouetteDistance(Player _007B4399_007D, float _007B4400_007D, float _007B4401_007D)
	{
		float num = VisibleDistance(_007B4399_007D, _007B4400_007D, _007B4401_007D);
		return num + (float)(_007B4399_007D.MapInfo.IsReducedFarDistView ? 80 : 500) * (1f - Math.Max(_007B4401_007D * 0.7f, (1f - _007B4400_007D) * 0.5f));
	}

	public static float ShipSilhouetteDistanceMinimap(Player _007B4402_007D, float _007B4403_007D, float _007B4404_007D)
	{
		return Math.Min(350f, ShipSilhouetteDistance(_007B4402_007D, _007B4403_007D, _007B4404_007D));
	}

	public static float VisibleDistanceNicknames(Player _007B4405_007D)
	{
		return 270f * (_007B4405_007D?.UsedShipPlayer.ViewDistanceMultiplier ?? 1f);
	}
}
