using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using Common.Account;
using Common.Resources;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using TheraEngine.Collections;

namespace Common.Game;

public readonly struct Decorator
{
	[CompilerGenerated]
	private sealed class _003CGetRegionRecomendation_003Ed__96 : IEnumerable<WorldMapRegionInfo>, IEnumerable, IEnumerator<WorldMapRegionInfo>, IEnumerator, IDisposable
	{
		private int _007B3627_007D;

		private WorldMapRegionInfo _007B3628_007D;

		private int _007B3629_007D;

		public Decorator _003C_003E4__this;

		public Decorator _003C_003E3___003C_003E4__this;

		private int? _007B3630_007D;

		private IEnumerator<WorldMapRegionInfo> _007B3631_007D;

		private WorldMapRegionInfo _007B3632_007D;

		WorldMapRegionInfo IEnumerator<WorldMapRegionInfo>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B3628_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B3628_007D;
			}
		}

		[DebuggerHidden]
		public _003CGetRegionRecomendation_003Ed__96(int _007B3621_007D)
		{
			_007B3627_007D = _007B3621_007D;
			_007B3629_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B3622_007D()
		{
			int num = _007B3627_007D;
			if (num == -3 || num == 1)
			{
				try
				{
				}
				finally
				{
					_007B3624_007D();
				}
			}
			_007B3631_007D = null;
			_007B3632_007D = null;
			_007B3627_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3622}
			this._007B3622_007D();
		}

		private bool _007B3623_007D()
		{
			try
			{
				int num = _007B3627_007D;
				if (num != 0)
				{
					if (num != 1)
					{
						return false;
					}
					_007B3627_007D = -3;
					goto IL_00e3;
				}
				_007B3627_007D = -1;
				_007B3630_007D = _003C_003E4__this.GetRegionLevelRecomendation();
				if (_007B3630_007D.HasValue)
				{
					_007B3631_007D = ((IEnumerable<WorldMapRegionInfo>)Gameplay.WorldMap.RegionsInfo).GetEnumerator();
					_007B3627_007D = -3;
					goto IL_00ea;
				}
				goto IL_0109;
				IL_00e3:
				_007B3632_007D = null;
				goto IL_00ea;
				IL_0109:
				return false;
				IL_00ea:
				if (_007B3631_007D.MoveNext())
				{
					_007B3632_007D = _007B3631_007D.Current;
					if (_007B3632_007D.LevelInt == _007B3630_007D && !Gameplay.IsInHazardZone(in _007B3632_007D.CenterPos))
					{
						_007B3628_007D = _007B3632_007D;
						_007B3627_007D = 1;
						return true;
					}
					goto IL_00e3;
				}
				_007B3624_007D();
				_007B3631_007D = null;
				goto IL_0109;
			}
			catch
			{
				//try-fault
				_007B3622_007D();
				throw;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3623}
			return this._007B3623_007D();
		}

		private void _007B3624_007D()
		{
			_007B3627_007D = -1;
			if (_007B3631_007D != null)
			{
				_007B3631_007D.Dispose();
			}
		}

		[DebuggerHidden]
		private void _007B3625_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3625}
			this._007B3625_007D();
		}

		[DebuggerHidden]
		IEnumerator<WorldMapRegionInfo> IEnumerable<WorldMapRegionInfo>.GetEnumerator()
		{
			_003CGetRegionRecomendation_003Ed__96 _003CGetRegionRecomendation_003Ed__;
			if (_007B3627_007D == -2 && _007B3629_007D == Environment.CurrentManagedThreadId)
			{
				_007B3627_007D = 0;
				_003CGetRegionRecomendation_003Ed__ = this;
			}
			else
			{
				_003CGetRegionRecomendation_003Ed__ = new _003CGetRegionRecomendation_003Ed__96(0);
			}
			_003CGetRegionRecomendation_003Ed__._003C_003E4__this = _003C_003E3___003C_003E4__this;
			return _003CGetRegionRecomendation_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B3626_007D()
		{
			return ((IEnumerable<WorldMapRegionInfo>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {3626}
			return this._007B3626_007D();
		}
	}

	internal readonly Player ship;

	internal readonly PlayerAccount account;

	internal readonly ServerWorldInformation api;

	internal readonly GuildCommon guild;

	public const float ShipAndFortFarmMultiplier = 0.9f;

	public PortCaptureStatus NearPortStatus
	{
		get
		{
			if (!ship.MapInfo.IsWorldmap)
			{
				throw new InvalidOperationException();
			}
			return SafeGetPortStatus(ship.NearPort.PortID);
		}
	}

	public FractionID? MapMyFraction => (guild != null && !guild.IsFlotilia) ? new FractionID?(guild.Fraction) : ((FractionID?)null);

	public GuildShortInfo NearPortGuild => ship.MapInfo.IsWorldmap ? new GuildShortInfo(NearPortStatus.CapturedBy, NearPortStatus.CapturerFraction) : new GuildShortInfo(string.Empty, FractionID.Empire);

	public Relation NearPortRelation
	{
		get
		{
			if (!ship.MapInfo.IsWorldmap)
			{
				return Relation.Neutral;
			}
			bool allowCapturePiratePort = ship.NearPort.AllowCapturePiratePort;
			bool flag = allowCapturePiratePort;
			bool flag2;
			if (flag)
			{
				switch (MapMyFraction)
				{
				case FractionID.Pirate:
				case FractionID.None:
					flag2 = true;
					break;
				default:
					flag2 = false;
					break;
				}
				flag = flag2;
			}
			if (flag)
			{
				return Relation.Neutral;
			}
			bool flag3 = ship.NearPort.AllowCapture && NearPortStatus.CapturerFraction == FractionID.Empire;
			bool flag4 = flag3;
			if (flag4)
			{
				FractionID? mapMyFraction = MapMyFraction;
				if (mapMyFraction.HasValue)
				{
					FractionID valueOrDefault = mapMyFraction.GetValueOrDefault();
					if (valueOrDefault != FractionID.TradeUnion)
					{
						flag2 = false;
						goto IL_00cb;
					}
				}
				flag2 = true;
				goto IL_00cb;
			}
			goto IL_00cf;
			IL_00cb:
			flag4 = flag2;
			goto IL_00cf;
			IL_00cf:
			if (flag4)
			{
				return Relation.Neutral;
			}
			if (ship.NearPort.IsArabPort)
			{
				return (guild == null) ? Relation.Neutral : ((!(guild.Tag == NearPortStatus.CapturedBy) && !guild.IsTrusted(NearPortStatus.CapturedBy)) ? Relation.Neutral : Relation.Ally);
			}
			if (!ship.NearPort.AllowCapture)
			{
				return Relation.Neutral;
			}
			return (guild == null || guild.IsFlotilia) ? account.Reputations.NeutralStatusWith(NearPortStatus.CapturerFraction) : FractionAPI.StatusWith(guild, NearPortGuild);
		}
	}

	public PortCaputreStatusList? WorldPorts => api.WorldPorts ?? new PortCaputreStatusList();

	public int NumCapturedPorts
	{
		get
		{
			GuildCommon t = guild;
			return (t != null && api.WorldPorts != null) ? api.WorldPorts.Count((PortCaptureStatus _007B3615_007D) => _007B3615_007D.CapturedBy == t.Tag) : 0;
		}
	}

	public int NumCapturedPortsMyFraction
	{
		get
		{
			GuildCommon t = guild;
			return (t != null && api.WorldPorts != null) ? api.WorldPorts.Count((PortCaptureStatus _007B3616_007D) => _007B3616_007D.IsCapturedByGuild && _007B3616_007D.CapturerFraction == t.Fraction) : 0;
		}
	}

	public bool CanOpenTradeHqInNearPort
	{
		get
		{
			FractionID? fractionID = guild?.Fraction;
			return fractionID.HasValue && fractionID == FractionID.TradeUnion && ship.NearPort.AllowCapture && !guild.HasHqOrLicense(ship.NearPort.PortID) && NearPortStatus.CapturerFraction.IsNation();
		}
	}

	public bool CanGetHqLicenseInNearPort => NearPortRelation == Relation.Ally && !guild.HasHqOrLicense(ship.NearPort.PortID);

	public bool CanSupplyNearPort => guild != null && !guild.IsFlotilia && NearPortRelation != Relation.Enemy && ship.NearPort.AllowCapture && NearPortStatus.Dev.PortLevel < NearPortStatus.Dev.MaxLevel;

	public bool IsInPortOrIsleWithStorage => ship.MapInfo.IsWorldmap && ship.IsPortEntry && (ship.NearPortType == PortEnteringType.Port || ship.NearPortType == PortEnteringType.PersonalIsle);

	public bool NearPortHasManyPvpShips => api.NearPortHasManyPvpShips;

	public int MaxCountOfWorkshops => 2;

	public int NextArenaUpgradePrice => Gameplay.arenaUpgradePrices[ship.UsedShipPlayer.DynamicBonus.TotalCountArenaUpgrades()].Value;

	public float ShipAndFortLootMultiplier => 1f + ((!ship.MapInfo.IsEnableArenaUi && account.IsPremium) ? 0.4f : 0f) + (ship.MapInfo.IsWorldmap ? (ship.UsedShipPlayer.PlayerXpAndRewardBonusBattle + account.WorldFlag.LootBonus(this) + (float)account.CaptainSkills[PDynamicAccountBonus.PGoldAndResRewards] / 100f + NearPortLootAndXpBonus) : 0f);

	public float KillShipXpMultiplier => KillShipXpMultiplierWithoutPremium + (account.IsPremium ? 0.35999998f : 0f);

	private float RegionRecomendationXpBonus => (Gameplay.GetNearWorldRegion(ship.Position).LevelInt == GetRegionLevelRecomendation()) ? 0.25f : 0f;

	public float KillShipXpMultiplierWithoutPremium => 1f + (ship.MapInfo.IsWorldmap ? (ship.UsedShipPlayer.PlayerXpAndRewardBonusBattle + account.WorldFlag.AllXp(this) + RegionRecomendationXpBonus + NearPortLootAndXpBonus + (float)account.CaptainSkills[PDynamicAccountBonus.PAllXp] / 100f) : 0f) + ship.UsedShip.PlayerXpOnlyBonus;

	public float EmpireDraftAndEscudoMultiplier => (ship.MapInfo.IsWorldmap && account.WorldFlag == OpenWorldFlag.Peaceful) ? 0.5f : 1f;

	public float NearPortLootAndXpBonus => 0f;

	public int MaxConqurrentPpOrders => 2 + account.CaptainSkills[PDynamicAccountBonus.CPpTradeConcurrentOrders] + (int)_007B3584_007D(PortLevelBonusType.AuctionLotLimit, _007B3586_007D: true);

	public int NearPortShipRankAllowToBuild => Math.Max(1, ship.NearPort.BuildShipRangs - (int)_007B3584_007D(PortLevelBonusType.ShipCraftingInLowerRankPort));

	public float NpcDecraftBonus => (float)account.CaptainSkills[PDynamicAccountBonus.PMoreResourcesForDestryingNpc] / 100f + _007B3584_007D(PortLevelBonusType.ShipDecraftEffectiveness);

	public float ShipDecraftBonus => _007B3584_007D(PortLevelBonusType.ShipDecraftEffectiveness);

	public int NearPortCrewHireLimit => (ship.NearPort.Type == PortType.NeutralBay) ? 200 : ((int)_007B3584_007D(PortLevelBonusType.CrewLimit));

	public float CapitalRestoreDiscount => _007B3584_007D(PortLevelBonusType.CapitalRestoreDiscount);

	public float CapitalRestoreDurationBonus => _007B3584_007D(PortLevelBonusType.ShipCraftAndRepairTimeReduction);

	public float PowerupItemCraftDiscount => _007B3584_007D(PortLevelBonusType.PowerupItemsCraftDiscount);

	public float ShipBuildTimeBonus => _007B3584_007D(PortLevelBonusType.ShipCraftAndRepairTimeReduction);

	public bool NearPortAllAuctionOption => _007B3584_007D(PortLevelBonusType.AllPortsAuction) > 0f || _007B3584_007D(PortLevelBonusType.AllPortsAuctionPirate) > 0f;

	public bool NoUseCaptureNpcPowerupItem => _007B3584_007D(PortLevelBonusType.BribeNotConsumedInWaterArea) > 0f && ship.NearAquatoria != null && NearPortRelation != Relation.Enemy;

	public float AllCraftTimeBonus => _007B3584_007D(PortLevelBonusType.AllCraftTimeReduction, _007B3586_007D: true);

	public float RecoveryAfterSinkBonus => _007B3584_007D(PortLevelBonusType.RecoveryTimeAfterSink);

	public bool NearPortAllowBondmanTrade => _007B3584_007D(PortLevelBonusType.BondmanTrade) > 0f;

	public bool CanPickNoFlag => account.Shipyard.List.Any((PlayerShipDynamicInfo _007B3612_007D) => _007B3612_007D.CraftFrom.Rank == 1);

	public bool PatrolCannotInteropMe => ((guild == null || guild.IsFlotilia) && ship.UsedShip.HpFactor >= 1f) || account.WorldFlag.IsPeaceMode();

	public float WeaponCraftDiscount => _007B3584_007D(PortLevelBonusType.WeaponCraftDiscount, _007B3586_007D: true);

	public Decorator(Player _007B3579_007D, PlayerAccount _007B3580_007D, in ServerWorldInformation _007B3581_007D, GuildCommon _007B3582_007D)
	{
		ship = _007B3579_007D;
		account = _007B3580_007D;
		api = _007B3581_007D;
		guild = _007B3582_007D;
	}

	internal PortCaptureStatus SafeGetPortStatus(int _007B3583_007D)
	{
		return api.WorldPorts?.GetByPortId(_007B3583_007D) ?? Gameplay.WorldMap.Ports[_007B3583_007D].FixedLevelBonuses;
	}

	private float _007B3584_007D(PortLevelBonusType _007B3585_007D, bool _007B3586_007D = false)
	{
		if (ship.MapInfo.IsWorldmap)
		{
			if (_007B3586_007D && !ship.IsPortEntry)
			{
				return 0f;
			}
			if (ship.IsPortEntry && ship.NearPortType != PortEnteringType.Port)
			{
				return 0f;
			}
			return NearPortStatus.Dev.GetAvailableBonus(_007B3585_007D, in this, NearPortStatus);
		}
		return 0f;
	}

	public bool CanTravelToPort(IslePortInfo _007B3587_007D)
	{
		PortCaptureStatus portCaptureStatus = api.WorldPorts?.GetByPortId(_007B3587_007D.PortID);
		return portCaptureStatus != null && portCaptureStatus.Dev.GetAvailableBonus(PortLevelBonusType.TargetForTravel, in this, portCaptureStatus) > 0f;
	}

	public bool IsExtraWorkshopAvailable(IslePortInfo _007B3588_007D, bool _007B3589_007D = true, bool _007B3590_007D = true)
	{
		return (_007B3589_007D && account.ResourcesInPorts.GetStorageLevel(_007B3588_007D.PortID) >= WosbStorages.Port.Length - 2) || (_007B3590_007D && Gameplay.IsInHazardZone(in _007B3588_007D.EntryPos) && account.CaptainSkills[PDynamicAccountBonus.CExtraWorkshopsPiratePorts] > 0);
	}

	public float CurrentPortShipCraftDisccount(int _007B3591_007D)
	{
		return _007B3584_007D(PortLevelBonusType.ShipCraftDiscount);
	}

	public bool CanHaveShipCraftFractionFine()
	{
		return _007B3584_007D(PortLevelBonusType.AllFractionShipsCraftNoPenalty) == 0f;
	}

	public bool HasCraftShipFractionFine(FractionID _007B3592_007D)
	{
		return _007B3592_007D.IsNation() && _007B3592_007D != NearPortGuild.Fraction && _007B3584_007D(PortLevelBonusType.AllFractionShipsCraftNoPenalty) == 0f;
	}

	public float FactoryMiningSpeedBonus(Vector2 _007B3593_007D)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		return FactoryMiningSpeedBonusGeneral(_007B3593_007D, account, guild, api.WorldPorts);
	}

	public static float FactoryMiningSpeedBonusGeneral(Vector2 _007B3594_007D, PlayerAccount _007B3595_007D, GuildCommon _007B3596_007D, PortCaputreStatusList? _007B3597_007D)
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		int num = 3000;
		if (Gameplay.WorldMap.IsInsideMap(in _007B3594_007D))
		{
			foreach (IslePortInfo item in (IEnumerable<IslePortInfo>)Gameplay.WorldMap.Ports)
			{
				if (!(Vector2.DistanceSquared(_007B3594_007D, item.EntryPos) < (float)(num * num)))
				{
					continue;
				}
				PortCaptureStatus portCaptureStatus = _007B3597_007D?.GetByPortId(item.PortID);
				if (portCaptureStatus != null)
				{
					PortDevelopment dev = portCaptureStatus.Dev;
					ServerWorldInformation _007B3581_007D = new ServerWorldInformation
					{
						WorldPorts = _007B3597_007D
					};
					float availableBonus = dev.GetAvailableBonus(PortLevelBonusType.FactoriesMiningSpeed, new Decorator(null, _007B3595_007D, in _007B3581_007D, _007B3596_007D), portCaptureStatus);
					if (availableBonus > 0f)
					{
						return availableBonus;
					}
				}
			}
		}
		return 0f;
	}

	public float PortMissionCraftTimeBonus(IslePortInfo? _007B3598_007D)
	{
		if (_007B3598_007D == null)
		{
			return 0f;
		}
		PortCaptureStatus portCaptureStatus = SafeGetPortStatus(_007B3598_007D.PortID);
		return portCaptureStatus.Dev.GetAvailableBonus(PortLevelBonusType.PortMissionsCraftTime, in this, portCaptureStatus);
	}

	public void GetAvailableRespawnMethods(bool _007B3599_007D, out IslePortInfo _007B3600_007D, out IslePortPharosInfo _007B3601_007D, out bool _007B3602_007D, out bool _007B3603_007D, out string _007B3604_007D)
	{
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		_007B3604_007D = null;
		if (!ship.MapInfo.IsWorldmap)
		{
			_007B3602_007D = true;
			_007B3600_007D = null;
			_007B3601_007D = null;
			_007B3603_007D = _007B3599_007D;
			return;
		}
		_007B3603_007D = false;
		_007B3602_007D = false;
		PlayerAccount acc = account;
		ServerWorldInformation a = api;
		GuildCommon g = guild;
		Player s = ship;
		_007B3600_007D = ship.MapInfo.FindNearPortBy(ship.Position, delegate(IslePortInfo _007B3617_007D)
		{
			if (_007B3617_007D.ShallowUpperRang > acc.Shipyard.List.Max((PlayerShipDynamicInfo _007B3613_007D) => _007B3613_007D.CraftFrom.Rank))
			{
				return false;
			}
			if (acc.DisallowEnteringHazardWaters && Gameplay.IsInHazardZone(in _007B3617_007D.EntryPos))
			{
				return false;
			}
			if (_007B3617_007D.MakeLockedForPlayer(acc))
			{
				return false;
			}
			if (acc.WorldFlag == OpenWorldFlag.Peaceful)
			{
				return _007B3617_007D.FlagsAllowedToChoose.Contains(OpenWorldFlag.Peaceful);
			}
			if (s.MirrorEngageInPortBattlePortID != -1)
			{
				return true;
			}
			if (a.NearPortAlwaysRespawn)
			{
				return true;
			}
			if (_007B3617_007D.Type == PortType.PirateBay)
			{
				FractionID? fractionID = g?.Fraction;
				if (fractionID.HasValue && fractionID.GetValueOrDefault() == FractionID.Pirate)
				{
					return true;
				}
			}
			PortCaptureStatus portCaptureStatus = a.WorldPorts?.GetByPortId(_007B3617_007D.PortID);
			if (portCaptureStatus != null)
			{
				Relation relation = ((g == null) ? acc.Reputations.NeutralStatusWith(portCaptureStatus.CapturerFraction) : portCaptureStatus.StatusWith(g));
				return (relation == Relation.Ally || relation == Relation.Neutral) ? true : false;
			}
			if (portCaptureStatus is ArabPortCaptureStatus)
			{
				FractionID? fractionID = g?.Fraction;
				if (fractionID.HasValue && fractionID.GetValueOrDefault() == FractionID.Pirate)
				{
					return false;
				}
			}
			return true;
		});
		if (ship.MirrorEngageInPortBattlePortID != -1)
		{
			_007B3601_007D = new IslePortPharosInfo(Vector2.Zero, new Tlist<ShipPositionInfo>());
		}
		else
		{
			_007B3601_007D = ship.MapInfo.GetNearAvailableRespawnInSea(ship.Position, api.NearPortHasManyPvpShips, account);
		}
		if (account.Shipyard.CurrentRealShip.IntegrityIsDestroyed)
		{
			_007B3601_007D = null;
			_007B3604_007D = Local.has_no_integrity;
		}
	}

	public bool CanEnterNearPortWithFlags(OpenWorldFlag _007B3605_007D, out string _007B3606_007D, IslePortInfo _007B3607_007D = null)
	{
		_007B3606_007D = string.Empty;
		if (_007B3607_007D == null && ship.NearPortType == PortEnteringType.PersonalIsle)
		{
			return true;
		}
		if (!account.IsPeaceActivated && account.PeaceExtraTimeSec == 0f)
		{
			IslePortInfo islePortInfo = _007B3607_007D ?? ship.NearPort;
			OpenWorldFlag openWorldFlag = _007B3605_007D.Mapback();
			if (!islePortInfo.FlagsAllowedToEnter.Contains(openWorldFlag))
			{
				_007B3606_007D = Local.portEnterError_1(openWorldFlag.ToStringLocalShort());
				return false;
			}
		}
		return true;
	}

	public bool CanPickFlagsInNearPort(OpenWorldFlag _007B3608_007D, bool _007B3609_007D, out string _007B3610_007D)
	{
		_007B3610_007D = Local.not_available_in_port;
		if (_007B3608_007D == OpenWorldFlag.Legendary && account.LegendaryFlagDaysLeft == 0)
		{
			return false;
		}
		if (_007B3608_007D == OpenWorldFlag.Peaceful)
		{
			if (ship.UsedShipPlayer.CraftFrom.Rank >= 7 || ship.AccountConnection.IsPeaceActivated || account.PeaceExtraTimeSec > 0f)
			{
				return true;
			}
			if (_007B3609_007D && account.WantedLevelDisallowsPeacefulFlag)
			{
				return false;
			}
			if (MapMyFraction == FractionID.Pirate)
			{
				_007B3610_007D = Local.not_available_pirates;
				return false;
			}
		}
		if (_007B3608_007D == OpenWorldFlag.Trader && _007B3609_007D && account.WantedLevelDisallowsPeacefulFlag)
		{
			return false;
		}
		if (_007B3608_007D == OpenWorldFlag.NoFlag && !CanPickNoFlag)
		{
			_007B3610_007D = Local.flag_caper_no_ship;
			return false;
		}
		if (_007B3608_007D == OpenWorldFlag.War && !MapMyFraction.HasValue)
		{
			_007B3610_007D = Local.available_only_fraction;
			return false;
		}
		if (_007B3608_007D == OpenWorldFlag.Pirate && MapMyFraction.HasValue)
		{
			_007B3610_007D = Local.unavailable_in_fraction;
			return false;
		}
		return ship.NearPortType == PortEnteringType.PersonalIsle || ship.NearPort.FlagsAllowedToChoose.Contains(_007B3608_007D);
	}

	public bool CanTradeInAcution(out string _007B3611_007D)
	{
		if (MapMyFraction == FractionID.Pirate && NearPortGuild.Fraction != FractionID.Pirate && !ship.NearPort.AllowCapturePiratePort)
		{
			_007B3611_007D = Local.auction_disable_pirates;
			return false;
		}
		_007B3611_007D = string.Empty;
		return true;
	}

	public void CheckFlag()
	{
		if (!CanPickFlagsInNearPort(account.WorldFlag, _007B3609_007D: true, out string _007B3610_007D))
		{
			if (CanPickFlagsInNearPort(OpenWorldFlag.Trader, _007B3609_007D: true, out _007B3610_007D))
			{
				account.WorldFlag = OpenWorldFlag.Trader;
			}
			else if (MapMyFraction.HasValue)
			{
				account.WorldFlag = OpenWorldFlag.War;
			}
			else
			{
				account.WorldFlag = OpenWorldFlag.Pirate;
			}
		}
	}

	public int? GetRegionLevelRecomendation()
	{
		if (account.Rang > 22)
		{
			return null;
		}
		if (!account.EducationQuest.HasFlag(EducationOnboarding.InitialQuest_OpenTaverna))
		{
			return null;
		}
		int betterShipRank = account.Shipyard.List.Min((PlayerShipDynamicInfo _007B3614_007D) => _007B3614_007D.CraftFrom.Rank);
		int maxZoneLevel = account.Shipyard.List.Max((PlayerShipDynamicInfo _007B3618_007D) => (_007B3618_007D.CraftFrom.Rank == betterShipRank) ? _007B3618_007D.CraftFrom.AssotiatedHazardZoneLevel : 0);
		maxZoneLevel = Math.Min(maxZoneLevel, Math.Max(1, account.Rang / 4));
		if (maxZoneLevel >= 6 || maxZoneLevel <= 0)
		{
			return null;
		}
		PlayerAccount acc = account;
		if (Gameplay.WorldMap.Ports.All((IslePortInfo _007B3619_007D) => _007B3619_007D.NearRegion.LevelInt != maxZoneLevel || acc.FogOfWar.IsOpened(_007B3619_007D.EntryPos)))
		{
			return null;
		}
		return maxZoneLevel;
	}

	[IteratorStateMachine(typeof(_003CGetRegionRecomendation_003Ed__96))]
	public IEnumerable<WorldMapRegionInfo> GetRegionRecomendation()
	{
		//yield-return decompiler failed: Method not found
		return new _003CGetRegionRecomendation_003Ed__96(-2)
		{
			_003C_003E3___003C_003E4__this = this
		};
	}
}
