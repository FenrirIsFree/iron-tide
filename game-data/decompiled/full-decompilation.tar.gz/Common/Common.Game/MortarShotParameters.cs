using Common.Resources;
using CommonDataTypes;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;

namespace Common.Game;

public struct MortarShotParameters : IMPSerializable
{
	public Vector2 WeaponDistance;

	public Vector3 StartPosition;

	public Vector3 Direction;

	public CannonBallInfo BallInfo;

	public CannonFeature Feature;

	public MortarShotParameters(Vector2 _007B5652_007D, Vector3 _007B5653_007D, Vector3 _007B5654_007D, CannonBallInfo _007B5655_007D, CannonFeature _007B5656_007D)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		WeaponDistance = _007B5652_007D;
		StartPosition = _007B5653_007D;
		Direction = _007B5654_007D;
		BallInfo = _007B5655_007D;
		Feature = _007B5656_007D;
	}

	private void _007B5657_007D(WriterExtern _007B5658_007D)
	{
		_007B5658_007D.WriteStruct<Vector2>(ref WeaponDistance);
		_007B5658_007D.WriteStruct<Vector3>(ref StartPosition);
		_007B5658_007D.WriteStruct<Vector3>(ref Direction);
		_007B5658_007D.WriteByte((byte)BallInfo.ID);
		_007B5658_007D.WriteByte((byte)Feature);
	}

	private void _007B5659_007D(WriterExtern _007B5660_007D)
	{
		_007B5660_007D.ReadStruct<Vector2>(ref WeaponDistance);
		_007B5660_007D.ReadStruct<Vector3>(ref StartPosition);
		_007B5660_007D.ReadStruct<Vector3>(ref Direction);
		BallInfo = Gameplay.BallsInfo.FromID(_007B5660_007D.ReadByte());
		Feature = (CannonFeature)_007B5660_007D.ReadByte();
	}
}
