namespace Common.Game;

public enum NDropInteropMethod : byte
{
	PickUp,
	Looting,
	LongWatching,
	MiningByCrew
}
