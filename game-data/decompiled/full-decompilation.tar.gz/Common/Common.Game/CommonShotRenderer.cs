using System;
using Common.Resources;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Helpers;

namespace Common.Game;

public class CommonShotRenderer<T>
{
	private static int[] timings_linear = mul(new int[18]
	{
		62, 44, 134, 124, 72, 220, 22, 147, 57, 40,
		102, 34, 47, 78, 197, 25, 18, 89
	}, 0.5f);

	public const float VisibilityTimerMaxSec = 2f;

	public object UserObject;

	private CommonCannonGunCallback<T> singleEventhandler;

	private CommonCannonCompleteAttackCallback completeCallback;

	private Action<Ship, T, CannonGunSoundEvent, int> soundEffectCallback;

	private Ship shipSrc;

	private bool enabled;

	private int ballType;

	private float interval;

	private int nextTimingIndex;

	private int nextWeaponIndex;

	private float deckMultipliter;

	private float additionalTimeout;

	private float previewTimeout;

	private bool doublesideMode;

	private CannonLocation currentBoard;

	public float VisibilityTimerSec;

	public Tlist<T> Buckets = new Tlist<T>();

	public CannonsAttackMode Mode;

	public bool ShotIsProcessing => enabled;

	public bool ShotIsProcessingWithoutWait => enabled && nextWeaponIndex != -2;

	private static int[] mul(int[] _007B4620_007D, float _007B4621_007D)
	{
		for (int i = 0; i < _007B4620_007D.Length; i++)
		{
			_007B4620_007D[i] = Math.Max(17, (int)((float)_007B4620_007D[i] * _007B4621_007D));
		}
		return _007B4620_007D;
	}

	public bool CanShotAgain(CannonLocation _007B4622_007D)
	{
		return !enabled || (currentBoard != _007B4622_007D && nextWeaponIndex == -2);
	}

	public CommonShotRenderer(CommonCannonGunCallback<T> _007B4623_007D, CommonCannonCompleteAttackCallback _007B4624_007D)
	{
		singleEventhandler = _007B4623_007D;
		completeCallback = _007B4624_007D;
	}

	public void BeginGunEventCommon(int _007B4625_007D, CannonsAttackMode _007B4626_007D, int _007B4627_007D, Ship _007B4628_007D, CannonLocation _007B4629_007D, Action<Ship, T, CannonGunSoundEvent, int> _007B4630_007D = null)
	{
		Mode = _007B4626_007D;
		currentBoard = _007B4629_007D;
		deckMultipliter = Math.Max(1f, 1f + (float)(_007B4628_007D.UsedShip.StaticInfo.Decks.Size - 1) * 0.14f);
		soundEffectCallback = _007B4630_007D;
		shipSrc = _007B4628_007D;
		switch (_007B4626_007D)
		{
		case CannonsAttackMode.AllRandomized:
		{
			previewTimeout = 100f;
			additionalTimeout = 2200f;
			for (int i = 0; i < Buckets.Size; i++)
			{
				additionalTimeout += (float)timings_linear[i % timings_linear.Length] / deckMultipliter;
			}
			deckMultipliter *= 4f;
			break;
		}
		case CannonsAttackMode.SingleCannon:
			additionalTimeout = _007B4628_007D.UsedShip.StaticInfo.SingleModeShotInterval;
			break;
		default:
			additionalTimeout = 750f * Geometry.Saturate(((float)_007B4628_007D.UsedShip.StaticInfo.LeftSidePorts.Length - 30f) / 35f);
			break;
		}
		if (_007B4625_007D == 12)
		{
			previewTimeout = 0f;
			additionalTimeout = 0f;
		}
		nextTimingIndex = _007B4627_007D % timings_linear.Length;
		nextWeaponIndex = -1;
		ballType = _007B4625_007D;
		enabled = true;
		if (previewTimeout == 0f)
		{
			TryUsingNextCannon();
		}
		if (interval == 0f)
		{
			interval = timings_linear[nextTimingIndex];
		}
		if (VisibilityTimerSec <= 0f)
		{
			VisibilityTimerSec = 2f;
		}
	}

	public void KeepShootingSingleMode(Ship _007B4631_007D)
	{
		additionalTimeout = shipSrc.UsedShip.StaticInfo.SingleModeShotInterval;
		nextWeaponIndex = -1;
		if (VisibilityTimerSec <= 0f)
		{
			VisibilityTimerSec = 2f;
		}
	}

	public void StartDoublesideGun()
	{
		if (!ShotIsProcessing)
		{
			throw new InvalidOperationException();
		}
		doublesideMode = true;
		deckMultipliter *= 2.5f;
		additionalTimeout += 500f;
	}

	public static float TotalShotDurationMs(ShipStaticInfo _007B4632_007D)
	{
		float num = Math.Max(1f, 1f + (float)(_007B4632_007D.Decks.Size - 1) * 0.14f);
		int num2 = _007B4632_007D.LeftSidePorts.Length;
		float num3 = 0f;
		for (int i = 0; i < num2; i++)
		{
			num3 += (float)timings_linear[i % timings_linear.Length] / num;
		}
		return num3 + 750f * Geometry.Saturate(((float)_007B4632_007D.LeftSidePorts.Length - 30f) / 35f);
	}

	public void Update(ref FrameTime _007B4633_007D)
	{
		if (enabled)
		{
			if (previewTimeout > 0f)
			{
				_007B4633_007D.EvaluteTimerMs(ref previewTimeout);
			}
			else if (nextWeaponIndex == -2 && additionalTimeout > 0f)
			{
				_007B4633_007D.EvaluteTimerMs(ref additionalTimeout);
				if (additionalTimeout == 0f)
				{
					nextWeaponIndex = -1;
					enabled = false;
				}
			}
			else
			{
				interval -= _007B4633_007D.msElapsed * deckMultipliter;
				while (interval < 0f)
				{
					interval += timings_linear[nextTimingIndex];
					nextTimingIndex++;
					if (nextTimingIndex == timings_linear.Length)
					{
						nextTimingIndex = 0;
					}
					TryUsingNextCannon();
				}
			}
		}
		_007B4633_007D.EvaluteTimerSec(ref VisibilityTimerSec);
	}

	private void TryUsingNextCannon()
	{
		nextWeaponIndex++;
		if (nextWeaponIndex < Buckets.Size)
		{
			T val = Buckets.Array[nextWeaponIndex];
			singleEventhandler(val, ballType);
			soundEffectCallback?.Invoke(shipSrc, val, CannonGunSoundEvent.ShotSingleCannon, ballType);
			if (doublesideMode && nextWeaponIndex + 1 < Buckets.Size)
			{
				val = Buckets.Array[Buckets.Size - 1];
				singleEventhandler(val, ballType);
				soundEffectCallback?.Invoke(shipSrc, val, CannonGunSoundEvent.ShotSingleCannon, ballType);
				Buckets.RemoveAt(Buckets.Size - 1);
			}
		}
		else
		{
			if (additionalTimeout > 0f)
			{
				nextWeaponIndex = -2;
			}
			else
			{
				nextWeaponIndex = -1;
				enabled = false;
			}
			doublesideMode = false;
			Buckets.Clear();
			completeCallback();
			interval = timings_linear[nextTimingIndex];
		}
	}

	public void Reset()
	{
		nextTimingIndex = 0;
		interval = timings_linear[0];
		nextWeaponIndex = -1;
		Buckets.Clear();
		enabled = false;
		soundEffectCallback = null;
		shipSrc = null;
		deckMultipliter = 1f;
		additionalTimeout = 0f;
		previewTimeout = 0f;
		doublesideMode = false;
		VisibilityTimerSec = 0f;
	}

	public void ChangeRemainBuckets(Func<T, T> _007B4634_007D)
	{
		if (nextWeaponIndex == -2)
		{
			nextWeaponIndex = -1;
		}
		for (int i = nextWeaponIndex + 1; i < Buckets.Size; i++)
		{
			Buckets.Array[i] = _007B4634_007D(Buckets.Array[i]);
		}
	}
}
