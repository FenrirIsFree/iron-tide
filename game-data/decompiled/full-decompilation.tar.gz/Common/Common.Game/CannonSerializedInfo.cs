using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct CannonSerializedInfo : IMPSerializable
{
	public byte Location;

	public byte GameInfoID;

	public CannonSerializedInfo(CannonCommon _007B4477_007D)
	{
		Location = (byte)_007B4477_007D.Location.SectionID;
		GameInfoID = (byte)_007B4477_007D.GameInfo.ID;
	}

	public CannonSerializedInfo(byte _007B4478_007D, byte _007B4479_007D)
	{
		Location = _007B4478_007D;
		GameInfoID = _007B4479_007D;
	}

	private void _007B4480_007D(WriterExtern _007B4481_007D)
	{
		_007B4481_007D.WriteByte(Location);
		_007B4481_007D.WriteByte(GameInfoID);
	}

	private void _007B4482_007D(WriterExtern _007B4483_007D)
	{
		Location = _007B4483_007D.ReadByte();
		GameInfoID = _007B4483_007D.ReadByte();
	}
}
