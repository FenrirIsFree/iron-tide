using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct TraderOfferCooldown : IMPSerializable
{
	public short Id;

	public double RemainSec;

	public TraderOfferCooldown(short _007B6835_007D, double _007B6836_007D)
	{
		Id = _007B6835_007D;
		RemainSec = _007B6836_007D;
	}

	public void Boxing(WriterExtern _007B6837_007D)
	{
		_007B6837_007D.WriteStruct<short>(Id);
		_007B6837_007D.WriteStruct<double>(RemainSec);
	}

	public void Unboxing(WriterExtern _007B6838_007D)
	{
		_007B6838_007D.ReadStruct<short>(ref Id);
		_007B6838_007D.ReadStruct<double>(ref RemainSec);
	}
}
