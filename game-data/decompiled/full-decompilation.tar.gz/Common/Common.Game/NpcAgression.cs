namespace Common.Game;

public enum NpcAgression
{
	Distance,
	Near,
	No
}
