using System;
using System.Collections.Generic;
using System.Linq;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;
using TheraEngine;

namespace Common.Game;

public class WhaleController : IMPSerializable
{
	public enum Status
	{
		Calm,
		InBattle,
		Stunned
	}

	public enum SubModel
	{
		Blue,
		Hump,
		Cachalot,
		Megalodon
	}

	public const float FenceExtraRadius = 300f;

	private float _007B5708_007D = 100f;

	private float _007B5709_007D = 100f;

	private Status _007B5710_007D;

	private Vector2 _007B5711_007D;

	private Vector2 _007B5712_007D;

	private float _007B5713_007D;

	private int _007B5714_007D;

	public Vector2 Client_CorrectPostion;

	public float Health => _007B5709_007D;

	public float MaxHealth => _007B5708_007D;

	public float VelocityAngle => (_007B5712_007D.X == 0f && _007B5712_007D.Y == 0f) ? 0f : MathF.Atan2(_007B5712_007D.Y, _007B5712_007D.X);

	public Vector2 VelocityNormal => (_007B5712_007D.X == 0f && _007B5712_007D.Y == 0f) ? Vector2.UnitX : _007B5712_007D.Normal();

	public Vector2 CurrentTarget => _007B5711_007D;

	public float Scale => MathF.Pow(_007B5708_007D / 100f, 0.4f) * 0.8f;

	public Status State => _007B5710_007D;

	public SubModel Subtype => (_007B5708_007D > 2000f) ? SubModel.Megalodon : ((!(_007B5708_007D > 500f)) ? ((_007B5708_007D > 300f) ? SubModel.Hump : SubModel.Cachalot) : SubModel.Blue);

	public WhaleController()
	{
	}

	public WhaleController(DropBonusInfo _007B5685_007D)
	{
		if (!CommonGlobal.IsServer)
		{
			throw new InvalidOperationException();
		}
		_007B5709_007D = (_007B5708_007D = _007B5685_007D.Server_WhaleHealth);
	}

	public bool Update(Drop _007B5686_007D, FrameTime _007B5687_007D)
	{
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		bool flag = false;
		if (_007B5711_007D == Vector2.Zero)
		{
			flag |= _007B5689_007D(_007B5686_007D);
		}
		float num = ((_007B5710_007D == Status.Stunned) ? 1.5f : ((_007B5710_007D == Status.InBattle) ? (13f * MathHelper.Clamp(0.5f + Scale / 1.5f, 1f, 2f)) : 7f));
		Vector2 _007B11438_007D = _007B5711_007D - _007B5686_007D.position;
		if (((Vector2)(ref _007B11438_007D)).LengthSquared() > 0.01f)
		{
			_007B5712_007D += _007B11438_007D.Normal() * (_007B5687_007D.secElapsed * Math.Min(1f, 0.1f + ((Vector2)(ref _007B11438_007D)).Length())) * 0.015f;
		}
		_007B5687_007D.Multiply(ref _007B5712_007D.X, 0.999f);
		_007B5687_007D.Multiply(ref _007B5712_007D.Y, 0.999f);
		_007B5686_007D.position += _007B5712_007D * _007B5687_007D.secElapsed * num * 2f;
		float num2 = Math.Min(((Vector2)(ref Client_CorrectPostion)).Length(), 3f * _007B5687_007D.secElapsed);
		if (num2 > 0f)
		{
			Vector2 val = Client_CorrectPostion.Normal() * num2;
			_007B5686_007D.position += val;
			Client_CorrectPostion -= val;
		}
		if (((Vector2)(ref _007B11438_007D)).LengthSquared() < 1f)
		{
			flag |= _007B5689_007D(_007B5686_007D);
		}
		return flag;
	}

	public bool ServerStunTimeUpdate(ref FrameTime _007B5688_007D)
	{
		if (_007B5710_007D == Status.Stunned)
		{
			_007B5713_007D -= _007B5688_007D.secElapsed;
			if (_007B5713_007D <= 0f)
			{
				_007B5713_007D = 0f;
				_007B5710_007D = Status.InBattle;
				_007B5709_007D = _007B5708_007D;
				return true;
			}
		}
		return false;
	}

	private bool _007B5689_007D(Drop _007B5690_007D)
	{
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		if (!CommonGlobal.IsServer)
		{
			return false;
		}
		if (_007B5710_007D != Status.InBattle)
		{
			if (_007B5690_007D.ConnectedWhales.Size < 1)
			{
				return _007B5693_007D(_007B5690_007D);
			}
			if (_007B5690_007D.uID >= _007B5690_007D.ConnectedWhales.Max((Drop _007B5715_007D) => _007B5715_007D.uID))
			{
				return _007B5693_007D(_007B5690_007D);
			}
			_007B5711_007D = _007B5690_007D.ConnectedWhales.Last((Drop _007B5716_007D) => _007B5716_007D != _007B5690_007D).Position;
		}
		return false;
	}

	public void ServerAvoidShip(Drop _007B5691_007D, Ship _007B5692_007D)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		int num = 0;
		Vector2 _007B11438_007D;
		do
		{
			_007B5711_007D = Gameplay.WorldMap.RandomPosition(new Vector3(_007B5691_007D.Position, 250f), 300f, 20f);
			_007B11438_007D = _007B5692_007D.Position - _007B5691_007D.Position;
			Vector2 _007B11438_007D2 = _007B5711_007D - _007B5691_007D.Position;
			if (Vector2.Dot(_007B11438_007D2.Normal(), _007B11438_007D.Normal()) < 0.22f)
			{
				return;
			}
		}
		while (num++ < 50);
		_007B5711_007D -= _007B11438_007D.Normal() * 7f;
	}

	private bool _007B5693_007D(Drop _007B5694_007D)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		Vector2? val = Gameplay.WorldMap.NextRandomPosition(_007B5694_007D.Position, 120f, ((Vector2)(ref _007B5712_007D)).IsZero ? ((Vector2?)null) : new Vector2?(_007B5712_007D.Normal()), 300f);
		if (!val.HasValue)
		{
			val = Gameplay.WorldMap.NextRandomPosition(_007B5694_007D.Position, 50f, null, 150f);
		}
		if (val.HasValue)
		{
			_007B5711_007D = val.Value;
		}
		return val.HasValue;
	}

	public void ServerCollision(Drop _007B5695_007D, Ship _007B5696_007D, float _007B5697_007D)
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		if (_007B5697_007D > 0f)
		{
			ServerDamage(_007B5695_007D, _007B5697_007D, _007B5696_007D.uID);
		}
		_007B5712_007D -= (_007B5696_007D.Position - _007B5695_007D.Position) * 0.025f * (0.5f + 3f * ((Vector2)(ref _007B5696_007D.physicsBody.VelocityPerSec)).Length() / 60f);
	}

	public void ServerDamage(Drop _007B5698_007D, float _007B5699_007D, int _007B5700_007D)
	{
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		_007B5709_007D -= _007B5699_007D;
		_007B5714_007D = _007B5700_007D;
		if (_007B5709_007D <= 0f)
		{
			_007B5710_007D = Status.Stunned;
			_007B5713_007D = 30f;
			_007B5709_007D = 0f;
		}
		if (_007B5710_007D == Status.Calm)
		{
			_007B5710_007D = Status.InBattle;
			_007B5703_007D(_007B5698_007D, _007B5700_007D);
			if (Vector2.Distance(_007B5711_007D, _007B5698_007D.Position) > 10f)
			{
				_007B5711_007D = _007B5698_007D.Position + Vector2.UnitX;
			}
		}
		_007B5711_007D = _007B5698_007D.Position + Vector2.UnitX;
	}

	public bool ServerBattlemodeUpdate(Drop _007B5701_007D, Func<int, Ship> _007B5702_007D)
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		if (_007B5710_007D == Status.InBattle)
		{
			Ship ship = _007B5702_007D(_007B5714_007D);
			if (ship == null)
			{
				_007B5710_007D = Status.Calm;
				return true;
			}
			float num = Vector2.DistanceSquared(ship.Position, _007B5701_007D.Position);
			if (num > 14400f)
			{
				_007B5710_007D = Status.Calm;
				return true;
			}
			if (Vector2.DistanceSquared(_007B5711_007D, _007B5701_007D.Position) < 1f || (Vector2.DistanceSquared(_007B5711_007D, ship.Position) > 100f && ship.MapInfo.CheckPosition(Vector2.Lerp(_007B5701_007D.Position, ship.Position, 0.5f))))
			{
				_007B5711_007D = ship.Position;
				return true;
			}
		}
		return false;
	}

	private void _007B5703_007D(Drop _007B5704_007D, int _007B5705_007D)
	{
		foreach (Drop item in (IEnumerable<Drop>)_007B5704_007D.ConnectedWhales)
		{
			if (item.Whale._007B5710_007D == Status.Calm)
			{
				item.Whale._007B5710_007D = Status.InBattle;
				item.Whale._007B5714_007D = _007B5705_007D;
			}
		}
	}

	public void Boxing(WriterExtern _007B5706_007D)
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		_007B5706_007D.WriteByte((byte)_007B5710_007D);
		_007B5706_007D.WriteStruct<float>(_007B5708_007D);
		_007B5706_007D.WriteStruct<float>(_007B5709_007D);
		_007B5706_007D.WriteStruct<Vector2>(_007B5711_007D);
		_007B5706_007D.WriteStruct<Vector2>(_007B5712_007D);
		_007B5706_007D.WriteStruct<float>(_007B5713_007D);
	}

	public void Unboxing(WriterExtern _007B5707_007D)
	{
		_007B5710_007D = (Status)_007B5707_007D.ReadByte();
		_007B5707_007D.ReadStruct<float>(ref _007B5708_007D);
		_007B5707_007D.ReadStruct<float>(ref _007B5709_007D);
		_007B5707_007D.ReadStruct<Vector2>(ref _007B5711_007D);
		_007B5707_007D.ReadStruct<Vector2>(ref _007B5712_007D);
		_007B5707_007D.ReadStruct<float>(ref _007B5713_007D);
	}
}
