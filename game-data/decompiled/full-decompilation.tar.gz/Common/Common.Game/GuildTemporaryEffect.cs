using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class GuildTemporaryEffect : IMPSerializable
{
	public enum Type : byte
	{
		UpgradeStaff = 0,
		removed6 = 1,
		removed = 3,
		ChangeFractionRistriction = 2,
		RemoveGuildNextSeason = 7,
		removed5 = 5,
		removed2 = 6,
		removed3 = 8,
		removed4 = 9,
		BlockChangeWindowAgain = 10,
		HqOrLicenseInPort = 11,
		DisputeVoteReceived = 12,
		VassalPortMarker = 13,
		FounderHasReputationProblem = 14,
		DisputeProtection = 15,
		BlockPortCaptureAgain = 16
	}

	public Type Case;

	public string Argument;

	public byte ArgumentByte;

	public double RemainingTimeSec;

	public GuildTemporaryEffect()
	{
	}

	internal GuildTemporaryEffect(Type _007B6500_007D, string _007B6501_007D, byte _007B6502_007D, double _007B6503_007D)
	{
		Case = _007B6500_007D;
		Argument = _007B6501_007D;
		RemainingTimeSec = _007B6503_007D;
		ArgumentByte = _007B6502_007D;
	}

	private void _007B6504_007D(WriterExtern _007B6505_007D)
	{
		_007B6505_007D.WriteByte((byte)Case);
		_007B6505_007D.WriteByte(ArgumentByte);
		_007B6505_007D.Write(Argument, (Encoding)null);
		if (RemainingTimeSec == -1.0)
		{
			_007B6505_007D.WriteByte((byte)1);
			return;
		}
		_007B6505_007D.WriteByte((byte)2);
		_007B6505_007D.WriteStruct<double>(RemainingTimeSec);
	}

	private void _007B6506_007D(WriterExtern _007B6507_007D)
	{
		Case = (Type)_007B6507_007D.ReadByte();
		ArgumentByte = _007B6507_007D.ReadByte();
		_007B6507_007D.ReadString(ref Argument, (Encoding)null);
		if (_007B6507_007D.ReadByte() == 2)
		{
			_007B6507_007D.ReadStruct<double>(ref RemainingTimeSec);
		}
		else
		{
			RemainingTimeSec = -1.0;
		}
	}
}
