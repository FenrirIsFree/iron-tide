using System;
using Common.Account;
using TheraEngine.Collections;
using World_Of_Sea_Battle.Constants;

namespace Common.Game;

internal static class NewYearChestRewards
{
	public static readonly ChestRewardInfo[] Elements = ShopChestApplyHelper.ComposeByProbabilityGroup(new(float, ChestRewardInfo[])[14]
	{
		(0.05f, new ChestRewardInfo[1]
		{
			new ChestRewardInfo(3, ShopChestApplyHelper.Ship(62), _007B8261_007D: true, Local.ship_62_name)
			{
				CheckShipID = new Tlist<int> { 62 },
				DisallowOnLowRang = true
			}
		}),
		(0.15f, new ChestRewardInfo[1]
		{
			new ChestRewardInfo(2, ShopChestApplyHelper.Resource(67, 5), _007B8261_007D: false, Local.chest_incas_BlueprintFragments(5))
		}),
		(0.4f, new ChestRewardInfo[1]
		{
			new ChestRewardInfo(3, ShopChestApplyHelper.RandomDesign(true, 451, 425), _007B8261_007D: false, Local.rare_ship_design)
		}),
		(0.2f, new ChestRewardInfo[1]
		{
			new ChestRewardInfo(3, ShopChestApplyHelper.Ship(46), _007B8261_007D: false, Local.ship_46_name)
			{
				CheckShipID = new Tlist<int> { 46 }
			}
		}),
		(0.2f, new ChestRewardInfo[1]
		{
			new ChestRewardInfo(3, ShopChestApplyHelper.Ship(61), _007B8261_007D: false, Local.ship_61_name)
			{
				CheckShipID = new Tlist<int> { 61 }
			}
		}),
		(2f, new ChestRewardInfo[1]
		{
			new ChestRewardInfo(2, ShopChestApplyHelper.Resource(38, 100), _007B8261_007D: false, Local.res_38_name + " 100 " + Local.pcs)
		}),
		(2f, new ChestRewardInfo[1]
		{
			new ChestRewardInfo(2, ShopChestApplyHelper.RandomDesign(true, 404), _007B8261_007D: false, Local.design_404_name)
		}),
		(5f, new ChestRewardInfo[1]
		{
			new ChestRewardInfo(2, ShopChestApplyHelper.Ammo(5, 10000), _007B8261_007D: false, Local.chest_big_RareAmmo)
			{
				FirstOpenChestCategory = true
			}
		}),
		(6f, new ChestRewardInfo[1]
		{
			new ChestRewardInfo(2, delegate(PlayerAccount _007B8284_007D, int _007B8285_007D, DateTime _007B8286_007D)
			{
				if (_007B8284_007D != null)
				{
					ShopChestApplyHelper.PremiumAdd(_007B8284_007D, _007B8286_007D, 10);
				}
				return new LocalizedString(string.Empty, "+10 ", new LocalizedString("premium_days"));
			}, _007B8261_007D: false, Local.premium)
			{
				CheckPremium = true,
				FirstOpenChestCategory = true
			}
		}),
		(7f, new ChestRewardInfo[1]
		{
			new ChestRewardInfo(2, ShopChestApplyHelper.Ammo(7, 10000), _007B8261_007D: false, Local.chest_big_RareAmmo)
			{
				FirstOpenChestCategory = true
			}
		}),
		(12f, new ChestRewardInfo[1]
		{
			new ChestRewardInfo(2, ShopChestApplyHelper.Resource(69, 50), _007B8261_007D: false, Local.res_69_name + " 50 " + Local.pcs)
			{
				FirstOpenChestCategory = true
			}
		}),
		(15f, new ChestRewardInfo[1]
		{
			new ChestRewardInfo(1, ShopChestApplyHelper.Gold(150000), _007B8261_007D: false, Local.chest_incas_Gold(StringHelper.BigValueHelper(150000)))
			{
				FirstOpenChestCategory = true
			}
		}),
		(20f, new ChestRewardInfo[1]
		{
			new ChestRewardInfo(1, ShopChestApplyHelper.Gold(50000), _007B8261_007D: false, Local.chest_incas_Gold(StringHelper.BigValueHelper(50000)))
			{
				FirstOpenChestCategory = true
			}
		}),
		(30f, new ChestRewardInfo[1]
		{
			new ChestRewardInfo(1, ShopChestApplyHelper.Ammo(18, 300), _007B8261_007D: false, Local.chest_big_FalconetFireworks)
			{
				FirstOpenChestCategory = true
			}
		})
	});
}
