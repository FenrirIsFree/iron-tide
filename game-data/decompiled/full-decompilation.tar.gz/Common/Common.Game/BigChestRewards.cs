using System;
using Common.Account;
using Common.Resources;
using CommonDataTypes;
using TheraEngine;
using TheraEngine.Collections;

namespace Common.Game;

internal static class BigChestRewards
{
	private static readonly RTI r_3 = new RTI(3);

	private static readonly RTI r_5 = new RTI(5);

	private static readonly RTI r_200 = new RTI(200);

	private static readonly RTI r_10 = new RTI(10);

	private static readonly RTI r_15 = new RTI(15);

	private static readonly RTI r_20 = new RTI(20);

	private static readonly RTI r_500 = new RTI(500);

	private static readonly RTI r_2000 = new RTI(2000);

	private static readonly RTI r_3000 = new RTI(3000);

	private static readonly RTI r_30 = new RTI(30);

	private static readonly RTI r_10000 = new RTI(10000);

	private static readonly RTI r_50 = new RTI(50);

	private static readonly RTI r_100 = new RTI(100);

	private static readonly RTI r_120 = new RTI(120);

	private static readonly RTI r_140 = new RTI(140);

	private static readonly RTI r_1000 = new RTI(1000);

	public static readonly ChestRewardInfo[] Elements = ShopChestApplyHelper.NormalizeWeightOfChestRewards(new ChestRewardInfo[41]
	{
		new ChestRewardInfo(1, 71f, delegate(PlayerAccount _007B8103_007D, int _007B8104_007D, DateTime _007B8105_007D)
		{
			if (_007B8103_007D != null)
			{
				_007B8103_007D.NearPortStorage.AddOrRemove(14, 5);
				_007B8103_007D.NearPortStorage.AddOrRemove(27, 5);
				_007B8103_007D.NearPortStorage.AddOrRemove(29, 5);
				_007B8103_007D.NearPortStorage.AddOrRemove(17, 5);
			}
			return new LocalizedString(string.Empty, "+5 ", new LocalizedString(Gameplay.ItemsInfo.FromID(14).nameKey), ", ", new LocalizedString(Gameplay.ItemsInfo.FromID(27).nameKey), ", ", new LocalizedString(Gameplay.ItemsInfo.FromID(29).nameKey), ", ", new LocalizedString(Gameplay.ItemsInfo.FromID(17).nameKey));
		}, _007B8270_007D: false, Local.chest_big_CraftingOrResource)
		{
			FirstOpenChestCategory = true
		},
		new ChestRewardInfo(1, 65f, delegate(PlayerAccount _007B8106_007D, int _007B8107_007D, DateTime _007B8108_007D)
		{
			_007B8106_007D?.NearPortStorage.AddOrRemove(4, 3000);
			return new LocalizedString(string.Empty, "+3000 ", new LocalizedString(Gameplay.ItemsInfo.FromID(4).nameKey));
		}, _007B8270_007D: false, Local.chest_big_CraftingOrResource),
		new ChestRewardInfo(1, 45f, delegate(PlayerAccount _007B8109_007D, int _007B8110_007D, DateTime _007B8111_007D)
		{
			_007B8109_007D?.NearPortStorage.AddOrRemove(15, 7);
			return new LocalizedString(string.Empty, "+7 ", new LocalizedString(Gameplay.ItemsInfo.FromID(15).nameKey));
		}, _007B8270_007D: false, Local.res_15_name)
		{
			FirstOpenChestCategory = true
		},
		new ChestRewardInfo(1, 60f, delegate(PlayerAccount _007B8112_007D, int _007B8113_007D, DateTime _007B8114_007D)
		{
			if (_007B8112_007D != null)
			{
				_007B8112_007D.PowderKegsAtStorage[5] += 10;
			}
			return new LocalizedString(string.Empty, "+10 ", new LocalizedString(Gameplay.PowderKegsInfo.FromID(5).nameKey));
		}, _007B8270_007D: false, Local.chest_big_Consumable),
		new ChestRewardInfo(2, 90f, delegate(PlayerAccount _007B8115_007D, int _007B8116_007D, DateTime _007B8117_007D)
		{
			if (_007B8115_007D != null)
			{
				ShopChestApplyHelper.PremiumAdd(_007B8115_007D, _007B8117_007D, 4);
			}
			return new LocalizedString(string.Empty, "+4 ", new LocalizedString("premium_days"));
		}, _007B8270_007D: false, Local.chest_big_PremiumSubscription)
		{
			CheckPremium = true,
			FirstOpenChestCategory = true
		},
		new ChestRewardInfo(2, 60f, delegate(PlayerAccount _007B8118_007D, int _007B8119_007D, DateTime _007B8120_007D)
		{
			if (_007B8118_007D != null)
			{
				_007B8118_007D.CBallsAtStorage.AddOrRemove(7, r_3000.Value);
				_007B8118_007D.CBallsAtStorage.AddOrRemove(5, r_1000.Value);
			}
			return new LocalizedString(string.Empty, "3000x ", new LocalizedString(Gameplay.BallsInfo.FromID(7).nameKey), ", 1000x ", new LocalizedString(Gameplay.BallsInfo.FromID(5).nameKey));
		}, _007B8270_007D: false, Local.chest_big_CannonballsHeavyAndSaxon)
		{
			FirstOpenChestCategory = true
		},
		new ChestRewardInfo(1, 55f, delegate(PlayerAccount _007B8121_007D, int _007B8122_007D, DateTime _007B8123_007D)
		{
			_007B8121_007D?.CBallsAtStorage.AddOrRemove(18, r_100.Value);
			return new LocalizedString(string.Empty, "100x ", new LocalizedString(Gameplay.BallsInfo.FromID(18).nameKey));
		}, _007B8270_007D: false, Local.chest_big_FalconetFireworks),
		new ChestRewardInfo(1, 73f, delegate(PlayerAccount _007B8124_007D, int _007B8125_007D, DateTime _007B8126_007D)
		{
			if (_007B8124_007D != null)
			{
				_007B8124_007D.TreasuryMaps[35] += r_50.Value;
			}
			return new LocalizedString(string.Empty, "+50x ", new LocalizedString(Gameplay.ItemsInfo.FromID(35).nameKey));
		}, _007B8270_007D: false, Local.res_35_name)
		{
			HasMapParts = true
		},
		new ChestRewardInfo(2, 20f, delegate(PlayerAccount _007B8127_007D, int _007B8128_007D, DateTime _007B8129_007D)
		{
			if (CalendarEvents.IsNewYear)
			{
				ShipDesignInfo shipDesignInfo = Gameplay.DesignsInfo.FromID(219);
				_007B8127_007D?.DesingElementsAtStorage.AddOrRemove(shipDesignInfo.ID, 1);
				return new LocalizedString(shipDesignInfo.nameKey);
			}
			ShipDesignInfo shipDesignInfo2 = ShopChestApplyHelper.RandomDesign((ShipDesignInfo _007B8130_007D) => _007B8130_007D.Category == ShipDesignCategory.Satellite && _007B8130_007D.Bonus.Length < 3, _007B8128_007D, _007B8127_007D);
			_007B8127_007D?.DesingElementsAtStorage.AddOrRemove(shipDesignInfo2.ID, 1);
			return (_007B8127_007D == null) ? new LocalizedString("chest_lightLessB") : new LocalizedString(shipDesignInfo2.nameKey);
		}, _007B8270_007D: false, Local.chest_big_Lantern),
		new ChestRewardInfo(2, 5f, delegate(PlayerAccount _007B8131_007D, int _007B8132_007D, DateTime _007B8133_007D)
		{
			ShipDesignInfo shipDesignInfo = ShopChestApplyHelper.RandomDesign((ShipDesignInfo _007B8134_007D) => _007B8134_007D.Category == ShipDesignCategory.Satellite && _007B8134_007D.Bonus.Length >= 3, _007B8132_007D, _007B8131_007D);
			_007B8131_007D?.DesingElementsAtStorage.AddOrRemove(shipDesignInfo.ID, 1);
			return (_007B8131_007D == null) ? new LocalizedString("chest_light3") : new LocalizedString(shipDesignInfo.nameKey);
		}, _007B8270_007D: false, Local.chest_big_Lantern),
		new ChestRewardInfo(2, 37f, delegate(PlayerAccount _007B8135_007D, int _007B8136_007D, DateTime _007B8137_007D)
		{
			ShipDesignInfo shipDesignInfo = ShopChestApplyHelper.RandomDesign((ShipDesignInfo _007B8138_007D) => _007B8138_007D.Category == ShipDesignCategory.Decal1, _007B8136_007D, _007B8135_007D);
			_007B8135_007D?.DesingElementsAtStorage.AddOrRemove(shipDesignInfo.ID, 1);
			return (_007B8135_007D == null) ? new LocalizedString("StringConstants_172") : new LocalizedString(shipDesignInfo.nameKey);
		}, _007B8270_007D: false, Local.chest_big_SailDesign)
		{
			FirstOpenChestCategory = true
		},
		new ChestRewardInfo(2, 50f, delegate(PlayerAccount _007B8139_007D, int _007B8140_007D, DateTime _007B8141_007D)
		{
			ShipDesignInfo shipDesignInfo = ShopChestApplyHelper.RandomDesign((ShipDesignInfo _007B8142_007D) => _007B8142_007D.Category == ShipDesignCategory.Decal2, _007B8140_007D, _007B8139_007D);
			_007B8139_007D?.DesingElementsAtStorage.AddOrRemove(shipDesignInfo.ID, 1);
			return (_007B8139_007D == null) ? new LocalizedString("StringConstants_173") : new LocalizedString(shipDesignInfo.nameKey);
		}, _007B8270_007D: false, Local.chest_big_SailDesign)
		{
			FirstOpenChestCategory = true
		},
		new ChestRewardInfo(2, 40f, delegate(PlayerAccount _007B8143_007D, int _007B8144_007D, DateTime _007B8145_007D)
		{
			ShipDesignInfo shipDesignInfo = ShopChestApplyHelper.RandomDesign((ShipDesignInfo _007B8146_007D) => _007B8146_007D.Category == ShipDesignCategory.Flag, _007B8144_007D, _007B8143_007D);
			_007B8143_007D?.DesingElementsAtStorage.AddOrRemove(shipDesignInfo.ID, 1);
			return (_007B8143_007D == null) ? new LocalizedString("StringConstants_170") : new LocalizedString(shipDesignInfo.nameKey);
		}, _007B8270_007D: false, Local.chest_big_Flag),
		new ChestRewardInfo(2, 6f, delegate(PlayerAccount _007B8147_007D, int _007B8148_007D, DateTime _007B8149_007D)
		{
			ShipDesignInfo shipDesignInfo = ShopChestApplyHelper.RandomDesign((ShipDesignInfo _007B8150_007D) => _007B8150_007D.Category == ShipDesignCategory.ShipFullDesign && _007B8150_007D.CostTier != DesignElementCostTier.TierU, _007B8148_007D, _007B8147_007D);
			_007B8147_007D?.DesingElementsAtStorage.AddOrRemove(shipDesignInfo.ID, 1);
			return (_007B8147_007D == null) ? new LocalizedString("StringConstants_174") : new LocalizedString("", new LocalizedString("StringConstants_174"), new LocalizedString(shipDesignInfo.nameKey));
		}, _007B8270_007D: false, Local.chest_big_HullPaint),
		new ChestRewardInfo(2, 25f, delegate(PlayerAccount _007B8151_007D, int _007B8152_007D, DateTime _007B8153_007D)
		{
			ShipDesignInfo shipDesignInfo = ShopChestApplyHelper.RandomDesign((ShipDesignInfo _007B8154_007D) => _007B8154_007D.Category == ShipDesignCategory.SailTexture, _007B8152_007D, _007B8151_007D);
			_007B8151_007D?.DesingElementsAtStorage.AddOrRemove(shipDesignInfo.ID, 1);
			return (_007B8151_007D == null) ? new LocalizedString("sailcloth") : new LocalizedString("", new LocalizedString("sailcloth"), new LocalizedString(shipDesignInfo.nameKey));
		}, _007B8270_007D: false, Local.chest_big_SailDesign),
		new ChestRewardInfo(1, 40f, delegate(PlayerAccount _007B8155_007D, int _007B8156_007D, DateTime _007B8157_007D)
		{
			int num = 10000 + _007B8156_007D % 5 * 10000;
			if (_007B8155_007D != null)
			{
				_007B8155_007D.Gold += num;
			}
			return (_007B8155_007D == null) ? new LocalizedString("chest_gold", 10000, 50000, 10000) : new LocalizedString(string.Empty, num + " ", new LocalizedString("gold2"));
		}, _007B8270_007D: false, Local.chest_big_Gold),
		new ChestRewardInfo(1, 30f, delegate(PlayerAccount _007B8158_007D, int _007B8159_007D, DateTime _007B8160_007D)
		{
			PowerupItemInfo powerupItemInfo = Gameplay.PowerupItems.Array[40];
			PowerupItemInfo powerupItemInfo2 = Gameplay.PowerupItems.Array[41];
			if (_007B8158_007D != null)
			{
				_007B8158_007D.PowerupItemsAtStorage.AddOrRemove(powerupItemInfo.Index, r_30.Value);
				_007B8158_007D.PowerupItemsAtStorage.AddOrRemove(powerupItemInfo2.Index, r_30.Value);
			}
			return new LocalizedString(string.Empty, "30х ", new LocalizedString(powerupItemInfo.nameKey), ", 30x ", new LocalizedString(powerupItemInfo2.nameKey));
		}, _007B8270_007D: false, Local.chest_big_Consumable),
		new ChestRewardInfo(1, 28f, delegate(PlayerAccount _007B8161_007D, int _007B8162_007D, DateTime _007B8163_007D)
		{
			PowerupItemInfo powerupItemInfo = Gameplay.PowerupItems.Array[30];
			PowerupItemInfo powerupItemInfo2 = Gameplay.PowerupItems.Array[31];
			if (_007B8161_007D != null)
			{
				_007B8161_007D.PowerupItemsAtStorage.AddOrRemove(powerupItemInfo.Index, r_20.Value);
				_007B8161_007D.PowerupItemsAtStorage.AddOrRemove(powerupItemInfo2.Index, r_20.Value);
			}
			return new LocalizedString(string.Empty, "20х ", new LocalizedString(powerupItemInfo.nameKey), ", 20x ", new LocalizedString(powerupItemInfo2.nameKey));
		}, _007B8270_007D: false, Local.chest_big_Consumable),
		new ChestRewardInfo(2, 35f, delegate(PlayerAccount _007B8164_007D, int _007B8165_007D, DateTime _007B8166_007D)
		{
			if (_007B8164_007D != null)
			{
				ShopChestApplyHelper.PremiumAdd(_007B8164_007D, _007B8166_007D, 14);
			}
			return new LocalizedString(string.Empty, "+14 ", new LocalizedString("premium_days"));
		}, _007B8270_007D: false, Local.chest_big_PremiumSubscription)
		{
			CheckPremium = true,
			FirstOpenChestCategory = true
		},
		new ChestRewardInfo(1, 25f, delegate(PlayerAccount _007B8167_007D, int _007B8168_007D, DateTime _007B8169_007D)
		{
			if (_007B8167_007D != null)
			{
				_007B8167_007D.MaxShipsCount.Value++;
			}
			return new LocalizedString(string.Empty, "+1 ", new LocalizedString("port_place"));
		}, _007B8270_007D: false, Local.PortRealShopPage_105)
		{
			HasShipPlace = true
		},
		new ChestRewardInfo(1, 35f, delegate(PlayerAccount _007B8170_007D, int _007B8171_007D, DateTime _007B8172_007D)
		{
			if (_007B8170_007D != null)
			{
				_007B8170_007D.TreasuryMaps[35] += r_120.Value;
			}
			return new LocalizedString(string.Empty, "+120x ", new LocalizedString(Gameplay.ItemsInfo.FromID(35).nameKey));
		}, _007B8270_007D: false, Local.res_35_name)
		{
			HasMapParts = true
		},
		new ChestRewardInfo(2, 25f, delegate(PlayerAccount _007B8173_007D, int _007B8174_007D, DateTime _007B8175_007D)
		{
			if (_007B8173_007D != null)
			{
				_007B8173_007D.NearPortStorage.AddOrRemove(37, r_200.Value);
				_007B8173_007D.NearPortStorage.AddOrRemove(38, r_5.Value);
			}
			return new LocalizedString(string.Empty, "+5x ", new LocalizedString(Gameplay.ItemsInfo.FromID(38).nameKey), ", 200x ", new LocalizedString(Gameplay.ItemsInfo.FromID(37).nameKey));
		}, _007B8270_007D: false, Local.chest_big_MarksAndSkulls),
		new ChestRewardInfo(2, 20f, delegate(PlayerAccount _007B8176_007D, int _007B8177_007D, DateTime _007B8178_007D)
		{
			_007B8176_007D?.NearPortStorage.AddOrRemove(38, 25);
			return new LocalizedString(string.Empty, "+25x ", new LocalizedString(Gameplay.ItemsInfo.FromID(38).nameKey));
		}, _007B8270_007D: false, Local.res_38_name)
		{
			FirstOpenChestCategory = true
		},
		new ChestRewardInfo(2, 15f, delegate(PlayerAccount _007B8179_007D, int _007B8180_007D, DateTime _007B8181_007D)
		{
			if (_007B8179_007D != null)
			{
				ShopChestApplyHelper.PremiumAdd(_007B8179_007D, _007B8181_007D, 30);
			}
			return new LocalizedString(string.Empty, "+30 ", new LocalizedString("premium_days"));
		}, _007B8270_007D: false, Local.chest_big_PremiumSubscription)
		{
			CheckPremium = true
		},
		new ChestRewardInfo(2, 15f, delegate(PlayerAccount _007B8182_007D, int _007B8183_007D, DateTime _007B8184_007D)
		{
			if (_007B8182_007D != null)
			{
				_007B8182_007D.Monets.Value += r_140.Value;
			}
			return new LocalizedString(string.Empty, "140 ", new LocalizedString("monets"));
		}, _007B8270_007D: false, Local.chest_big_Monets),
		new ChestRewardInfo(1, 8f, delegate(PlayerAccount _007B8185_007D, int _007B8186_007D, DateTime _007B8187_007D)
		{
			_007B8185_007D?.NearPortStorage.AddOrRemove(40, 1);
			return new LocalizedString(Gameplay.ItemsInfo.FromID(40).nameKey);
		}, _007B8270_007D: false, Local.res_40_name)
		{
			DisallowOnLowRang = true
		},
		new ChestRewardInfo(3, 7f, (PlayerAccount _007B8188_007D, int _007B8189_007D, DateTime _007B8190_007D) => new LocalizedString(string.Empty, ShopChestApplyHelper.ShipAdd(_007B8188_007D, 13)), _007B8270_007D: false, Local.chest_big_PremiumShip)
		{
			CheckShipID = new Tlist<int> { 13 }
		},
		new ChestRewardInfo(3, 6f, (PlayerAccount _007B8191_007D, int _007B8192_007D, DateTime _007B8193_007D) => new LocalizedString(string.Empty, ShopChestApplyHelper.ShipAdd(_007B8191_007D, 18)), _007B8270_007D: false, Local.chest_big_PremiumShip)
		{
			CheckShipID = new Tlist<int> { 18 }
		},
		new ChestRewardInfo(3, 6f, (PlayerAccount _007B8194_007D, int _007B8195_007D, DateTime _007B8196_007D) => new LocalizedString(string.Empty, ShopChestApplyHelper.ShipAdd(_007B8194_007D, 39)), _007B8270_007D: false, Local.chest_big_PremiumShip)
		{
			CheckShipID = new Tlist<int> { 39 }
		},
		new ChestRewardInfo(3, 6f, (PlayerAccount _007B8197_007D, int _007B8198_007D, DateTime _007B8199_007D) => new LocalizedString(string.Empty, ShopChestApplyHelper.ShipAdd(_007B8197_007D, 7)), _007B8270_007D: false, Local.chest_big_PremiumShip)
		{
			CheckShipID = new Tlist<int> { 7 }
		},
		new ChestRewardInfo(3, 6f, (PlayerAccount _007B8200_007D, int _007B8201_007D, DateTime _007B8202_007D) => new LocalizedString(string.Empty, ShopChestApplyHelper.ShipAdd(_007B8200_007D, 20)), _007B8270_007D: false, Local.chest_big_PremiumShip)
		{
			CheckShipID = new Tlist<int> { 20 }
		},
		new ChestRewardInfo(3, 4f, (PlayerAccount _007B8203_007D, int _007B8204_007D, DateTime _007B8205_007D) => new LocalizedString(string.Empty, ShopChestApplyHelper.ShipAdd(_007B8203_007D, 36)), _007B8270_007D: true, Local.chest_big_PremiumShip)
		{
			CheckShipID = new Tlist<int> { 36 }
		},
		new ChestRewardInfo(3, 0.9f, (PlayerAccount _007B8206_007D, int _007B8207_007D, DateTime _007B8208_007D) => new LocalizedString(string.Empty, ShopChestApplyHelper.ShipAdd(_007B8206_007D, 28)), _007B8270_007D: true, Local.chest_big_PremiumShip)
		{
			CheckShipID = new Tlist<int> { 28 }
		},
		new ChestRewardInfo(3, 0.9f, (PlayerAccount _007B8209_007D, int _007B8210_007D, DateTime _007B8211_007D) => new LocalizedString(string.Empty, ShopChestApplyHelper.ShipAdd(_007B8209_007D, 61)), _007B8270_007D: true, Local.chest_big_PremiumShip)
		{
			CheckShipID = new Tlist<int> { 61 }
		},
		new ChestRewardInfo(2, 0.2f, (PlayerAccount _007B8212_007D, int _007B8213_007D, DateTime _007B8214_007D) => (_007B8212_007D == null) ? new LocalizedString("chest_uniqueShip") : new LocalizedString(string.Empty, ShopChestApplyHelper.ShipAdd(_007B8212_007D, 16)), _007B8270_007D: false, Local.chest_big_UniqueShip)
		{
			CheckShipID = new Tlist<int> { 16 }
		},
		new ChestRewardInfo(2, 0.2f, (PlayerAccount _007B8215_007D, int _007B8216_007D, DateTime _007B8217_007D) => (_007B8215_007D == null) ? new LocalizedString("chest_uniqueShip") : new LocalizedString(string.Empty, ShopChestApplyHelper.ShipAdd(_007B8215_007D, 23)), _007B8270_007D: false, Local.chest_big_UniqueShip)
		{
			CheckShipID = new Tlist<int> { 23 }
		},
		new ChestRewardInfo(2, 0.2f, (PlayerAccount _007B8218_007D, int _007B8219_007D, DateTime _007B8220_007D) => (_007B8218_007D == null) ? new LocalizedString("chest_uniqueShip") : new LocalizedString(string.Empty, ShopChestApplyHelper.ShipAdd(_007B8218_007D, 26)), _007B8270_007D: false, Local.chest_big_UniqueShip)
		{
			CheckShipID = new Tlist<int> { 26 }
		},
		new ChestRewardInfo(2, 0.2f, (PlayerAccount _007B8221_007D, int _007B8222_007D, DateTime _007B8223_007D) => (_007B8221_007D == null) ? new LocalizedString("chest_uniqueShip") : new LocalizedString(string.Empty, ShopChestApplyHelper.ShipAdd(_007B8221_007D, 34)), _007B8270_007D: false, Local.chest_big_UniqueShip)
		{
			CheckShipID = new Tlist<int> { 34 }
		},
		new ChestRewardInfo(2, 0.2f, (PlayerAccount _007B8224_007D, int _007B8225_007D, DateTime _007B8226_007D) => (_007B8224_007D == null) ? new LocalizedString("chest_uniqueShip") : new LocalizedString(string.Empty, ShopChestApplyHelper.ShipAdd(_007B8224_007D, 46)), _007B8270_007D: false, Local.chest_big_UniqueShip)
		{
			CheckShipID = new Tlist<int> { 46 }
		},
		new ChestRewardInfo(2, 0.2f, (PlayerAccount _007B8227_007D, int _007B8228_007D, DateTime _007B8229_007D) => (_007B8227_007D == null) ? new LocalizedString("chest_uniqueShip") : new LocalizedString(string.Empty, ShopChestApplyHelper.ShipAdd(_007B8227_007D, 63)), _007B8270_007D: false, Local.chest_big_UniqueShip)
		{
			CheckShipID = new Tlist<int> { 63 }
		},
		new ChestRewardInfo(2, 0.15f, (PlayerAccount _007B8230_007D, int _007B8231_007D, DateTime _007B8232_007D) => (_007B8230_007D == null) ? new LocalizedString("chest_uniqueShip") : new LocalizedString(string.Empty, ShopChestApplyHelper.ShipAdd(_007B8230_007D, 3)), _007B8270_007D: false, Local.chest_big_UniqueShip)
		{
			CheckShipID = new Tlist<int> { 3 }
		}
	});
}
