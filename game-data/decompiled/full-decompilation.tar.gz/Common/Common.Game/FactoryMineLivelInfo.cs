using System;
using Common.Account;
using Common.Resources;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using TheraEngine.Helpers;

namespace Common.Game;

public class FactoryMineLivelInfo
{
	public readonly int ConsumedResId;

	public readonly int ProducedResId;

	public readonly float HoldCapacityBasic;

	public int ConsumedResCount;

	public int ProducedResCount;

	public ResourceInfo DisplayOutputRes => Gameplay.ItemsInfo.FromID(ProducedResId);

	public bool ConsumeProvision => ConsumedResCount > 0 && ConsumedResId == 39;

	public bool WorksWithoutPriovision(PlayerAccount _007B8413_007D)
	{
		return _007B8413_007D.CaptainSkills[PDynamicAccountBonus.BFactoryWorksWithoutProvision] > 0 && ProducedResId != 22;
	}

	public FactoryMineLivelInfo(GSI _007B8414_007D, GSI _007B8415_007D, float _007B8416_007D)
	{
		if (_007B8414_007D.NamesCount > 1 || _007B8415_007D.NamesCount > 1)
		{
			throw new ArgumentException();
		}
		ConsumedResId = ((_007B8414_007D.NamesCount == 0) ? 39 : _007B8414_007D.RandomName());
		ConsumedResCount = _007B8414_007D.GetTotalItemsCount();
		ProducedResId = _007B8415_007D.RandomName();
		ProducedResCount = _007B8415_007D.GetTotalItemsCount();
		HoldCapacityBasic = _007B8416_007D;
	}

	public float HoldCapacity(PlayerAccount _007B8417_007D)
	{
		return MathF.Floor(HoldCapacityBasic * (1f + (float)_007B8417_007D.CaptainSkills[PDynamicAccountBonus.PFactoryStorageLimit] / 100f));
	}

	public float WorkingSpeed(float _007B8418_007D, float _007B8419_007D, FactoryPlaceIsleInfo _007B8420_007D, PlayerAccount _007B8421_007D, bool _007B8422_007D, bool _007B8423_007D = true, float _007B8424_007D = 0f)
	{
		float num = 1f;
		if (_007B8421_007D != null)
		{
			if (_007B8421_007D.TradingSubscriptionSec > 0f)
			{
				num += 0.5f;
			}
			num += (float)_007B8421_007D.CaptainSkills[PDynamicAccountBonus.PFactorySpeed] / 100f;
			if (Gameplay.IsInHazardZone(in _007B8420_007D.GlobalPosition, 300f))
			{
				num += (float)_007B8421_007D.CaptainSkills[PDynamicAccountBonus.PFactorySpeedBonusHazardZone] / 100f;
			}
			if (ConsumedResCount != 0 && _007B8418_007D < 0.9f && WorksWithoutPriovision(_007B8421_007D))
			{
				num *= 0.25f;
			}
		}
		num += _007B8424_007D;
		if (_007B8422_007D)
		{
			if (CommonGlobal.IsServer)
			{
				throw new NotSupportedException();
			}
			num += WosbCrafting.BondmanFactoryBoostAmount;
		}
		if (ProducedResId == 22)
		{
			num *= _007B8427_007D(_007B8419_007D);
		}
		return num;
	}

	public float ExtrapolateWorkingSpeedForAnimals(float _007B8425_007D, float _007B8426_007D)
	{
		return MathHelper.Lerp(_007B8427_007D(0f), _007B8427_007D(HoldCapacityBasic), Geometry.Saturate(_007B8425_007D / HoldCapacityBasic) + MathF.Sqrt(Geometry.Saturate((float)ProducedResCount * _007B8426_007D / HoldCapacityBasic)));
	}

	private float _007B8427_007D(float _007B8428_007D)
	{
		return Geometry.Saturate(0.5f + 0.5f * _007B8428_007D / HoldCapacityBasic);
	}
}
