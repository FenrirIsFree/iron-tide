using Common.Resources;
using Microsoft.Xna.Framework;
using TheraEngine;

namespace Common.Game;

public class QuestTransferOrder : QuestStepHeader
{
	public ResourceInfo ResInfo;

	public RTI ResourceCount;

	public Vector2 TargetPosition;

	public IslePortInfo TargetAsPort;

	public bool IsSmuggling;

	public float SailingDistance;

	public override int ProgressComparand => -1;

	public int ResourceID => ResInfo.ID;

	public float Mass => ResInfo.Mass * (float)ResourceCount.Value;

	public QuestTransferOrder(string _007B7722_007D)
		: base(_007B7722_007D)
	{
	}
}
