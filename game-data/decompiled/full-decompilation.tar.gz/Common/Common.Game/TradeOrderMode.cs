namespace Common.Game;

public enum TradeOrderMode
{
	DisallowSellPartial,
	AllowSellPartial,
	Shop,
	Holding
}
