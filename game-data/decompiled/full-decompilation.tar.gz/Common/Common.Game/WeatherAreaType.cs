namespace Common.Game;

public enum WeatherAreaType
{
	Storm,
	Fog
}
