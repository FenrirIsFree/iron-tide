using System;
using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class LinkedExternalIds : ITKSerializable, IMPSerializable
{
	public string? VkId;

	public string? SteamId;

	public string? this[AuthType _007B5256_007D]
	{
		get
		{
			return _007B5256_007D switch
			{
				AuthType.Direct => null, 
				AuthType.Vk => VkId, 
				AuthType.Steam => SteamId, 
				_ => throw new NotSupportedException($"Unknown {"AuthType"}: {_007B5256_007D}"), 
			};
		}
		set
		{
			switch (_007B5257_007D)
			{
			case AuthType.Direct:
				return;
			case AuthType.Vk:
				VkId = value;
				return;
			case AuthType.Steam:
				SteamId = value;
				return;
			}
			throw new NotSupportedException($"Unknown {"AuthType"}: {_007B5257_007D}");
		}
	}

	public void Update(AuthType _007B5259_007D, string _007B5260_007D)
	{
		if (_007B5259_007D != AuthType.Direct && string.IsNullOrEmpty(this[_007B5259_007D]))
		{
			this[_007B5259_007D] = _007B5260_007D;
		}
	}

	public void PostInit()
	{
	}

	public void PreInit()
	{
	}

	public void Boxing(TKWriterExtern _007B5261_007D)
	{
		((TKWriterExtern)(ref _007B5261_007D)).Write((short)1, VkId);
		((TKWriterExtern)(ref _007B5261_007D)).Write((short)2, SteamId);
	}

	public void Load(short _007B5262_007D, WriterExtern _007B5263_007D, out bool _007B5264_007D)
	{
		_007B5264_007D = true;
		switch (_007B5262_007D)
		{
		case 1:
			_007B5263_007D.ReadString(ref VkId, (Encoding)null);
			break;
		case 2:
			_007B5263_007D.ReadString(ref SteamId, (Encoding)null);
			break;
		default:
			_007B5264_007D = false;
			break;
		}
	}

	public void Boxing(WriterExtern _007B5265_007D)
	{
		_007B5265_007D.Write(VkId, (Encoding)null);
		_007B5265_007D.Write(SteamId, (Encoding)null);
	}

	public void Unboxing(WriterExtern _007B5266_007D)
	{
		_007B5266_007D.ReadString(ref VkId, (Encoding)null);
		_007B5266_007D.ReadString(ref SteamId, (Encoding)null);
	}
}
