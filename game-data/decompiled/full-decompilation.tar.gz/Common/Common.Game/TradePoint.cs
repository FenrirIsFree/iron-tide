using System;
using Common.Data;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Game;

public class TradePoint : IMPSerializable
{
	public const int COrdersLimitPerPoint = 500;

	public const int MinOrderTotalCost = 200;

	public Tlist<TradeOrderCommon> Orders = new Tlist<TradeOrderCommon>();

	public void ForeachByType(StorageAssetEnum _007B6787_007D, Action<TradeOrderCommon> _007B6788_007D)
	{
		for (int i = 0; i < Orders.Size; i++)
		{
			if (Orders.Array[i].ItemInfo.getType == _007B6787_007D)
			{
				_007B6788_007D(Orders.Array[i]);
			}
		}
	}

	public void EvaluteRemainingTimeOneDay(Action<TradeOrderCommon> _007B6789_007D)
	{
		for (int i = 0; i < Orders.Size; i++)
		{
			TradeOrderCommon tradeOrderCommon = Orders.Array[i];
			tradeOrderCommon.RemainingLifetime--;
			if (tradeOrderCommon.RemainingLifetime == 0)
			{
				Orders.FastRemoveAt(i);
				_007B6789_007D(tradeOrderCommon);
				i--;
			}
		}
	}

	public void FilterAndRemoveOrders(Action<TradeOrderCommon> _007B6790_007D, Func<TradeOrderCommon, bool> _007B6791_007D)
	{
		for (int i = 0; i < Orders.Size; i++)
		{
			TradeOrderCommon tradeOrderCommon = Orders.Array[i];
			if (_007B6791_007D(tradeOrderCommon))
			{
				Orders.FastRemoveAt(i);
				_007B6790_007D(tradeOrderCommon);
				i--;
			}
		}
	}

	private void _007B6792_007D(WriterExtern _007B6793_007D)
	{
		_007B6793_007D.WriteStruct<int>(Orders.Size);
		for (int i = 0; i < Orders.Size; i++)
		{
			_007B6793_007D.Write<TradeOrderCommon>(Orders.Array[i]);
		}
	}

	private void _007B6794_007D(WriterExtern _007B6795_007D)
	{
		int num = default(int);
		_007B6795_007D.ReadStruct<int>(ref num);
		Orders = new Tlist<TradeOrderCommon>(num);
		TradeOrderCommon item = default(TradeOrderCommon);
		for (int i = 0; i < num; i++)
		{
			_007B6795_007D.ReadIMPS<TradeOrderCommon>(ref item);
			Orders.Add(in item);
		}
	}
}
