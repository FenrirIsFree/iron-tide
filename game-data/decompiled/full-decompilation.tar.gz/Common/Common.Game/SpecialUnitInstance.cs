using System;
using Common.Account;
using Common.Resources;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class SpecialUnitInstance : IInstanceOf<UnitInfo>, IMPSerializable
{
	public const int DefaultContractHours = 36;

	public byte ID;

	public float LeftContractTimeHours;

	public byte Extra;

	public UnitInfo GetInfo => Gameplay.UnitsInfo.FromID(ID);

	public bool HasUsage => LeftContractTimeHours < 36f;

	public int PayPerHour(int _007B4662_007D)
	{
		int num;
		if (GetInfo.SpecialUnitClass != SpecialUnitClass.Combats)
		{
			if (GetInfo.SpecialUnitClass != SpecialUnitClass.Pirates)
			{
				if (GetInfo.SpecialUnitClass != SpecialUnitClass.Sailors)
				{
					if (GetInfo.SpecialUnitClass != SpecialUnitClass.Adventurers)
					{
						throw new NotSupportedException();
					}
					num = 40;
				}
				else
				{
					num = 60;
				}
			}
			else
			{
				num = 60;
			}
		}
		else
		{
			num = 80;
		}
		return num * ((_007B4662_007D >= 5) ? 1 : ((_007B4662_007D >= 3) ? 2 : 3));
	}

	public SpecialUnitInstance()
	{
	}

	public SpecialUnitInstance(int _007B4663_007D)
	{
		ID = (byte)_007B4663_007D;
		LeftContractTimeHours = 36f;
		Extra = 0;
	}

	public void Boxing(WriterExtern _007B4664_007D)
	{
		_007B4664_007D.WriteByte(ID);
		_007B4664_007D.WriteStruct<float>(LeftContractTimeHours);
		_007B4664_007D.WriteByte(Extra);
	}

	public void Unboxing(WriterExtern _007B4665_007D)
	{
		ID = _007B4665_007D.ReadByte();
		_007B4665_007D.ReadStruct<float>(ref LeftContractTimeHours);
		Extra = _007B4665_007D.ReadByte();
	}
}
