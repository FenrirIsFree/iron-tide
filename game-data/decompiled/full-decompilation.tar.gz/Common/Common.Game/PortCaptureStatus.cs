using System;
using System.Text;
using Common.Resources;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine;

namespace Common.Game;

public class PortCaptureStatus : IMPSerializable, ITKSerializable
{
	public int PortID;

	public string CapturedBy = string.Empty;

	public FractionID CapturerFraction = FractionID.None;

	public float Server_DailyWelfare = 0f;

	public ValueGraph Server_Welfare = new ValueGraph(7);

	public float DisplayWelfare;

	public PortDevelopment Dev;

	public IslePortInfo PortInstance => Gameplay.WorldMap.Ports.Array[PortID];

	public bool IsCapturedByGuild => !string.IsNullOrEmpty(CapturedBy);

	public PortCaptureStatus(int _007B7881_007D)
	{
		PortID = _007B7881_007D;
		Dev = new PortDevelopment(_007B7881_007D);
	}

	public PortCaptureStatus()
	{
	}

	public virtual void UpdateStatus(float _007B7882_007D)
	{
		DisplayWelfare = Math.Max(Server_DailyWelfare, Server_Welfare.Avg);
	}

	public Relation StatusWith(GuildCommon _007B7883_007D)
	{
		if (_007B7883_007D.Tag == CapturedBy)
		{
			return Relation.Ally;
		}
		return FractionAPI.StatusWith(_007B7883_007D, new GuildShortInfo(CapturedBy, CapturerFraction));
	}

	public virtual void Boxing(WriterExtern _007B7884_007D)
	{
		BoxingSelf(_007B7884_007D);
	}

	internal void BoxingSelf(WriterExtern _007B7885_007D)
	{
		_007B7885_007D.WriteByte((byte)PortID);
		_007B7885_007D.Write(CapturedBy, (Encoding)null);
		_007B7885_007D.WriteByte((byte)CapturerFraction);
		_007B7885_007D.WriteStruct<float>(DisplayWelfare);
		_007B7885_007D.WriteNoNull<PortDevelopment>(Dev);
	}

	public virtual void Unboxing(WriterExtern _007B7886_007D)
	{
		UnboxingSelf(_007B7886_007D);
	}

	internal void UnboxingSelf(WriterExtern _007B7887_007D)
	{
		PortID = _007B7887_007D.ReadByte();
		_007B7887_007D.ReadString(ref CapturedBy, (Encoding)null);
		CapturerFraction = (FractionID)_007B7887_007D.ReadByte();
		_007B7887_007D.ReadStruct<float>(ref DisplayWelfare);
		_007B7887_007D.ReadIMPSNoNull<PortDevelopment>(ref Dev);
	}

	public virtual void Boxing(TKWriterExtern _007B7888_007D)
	{
		((TKWriterExtern)(ref _007B7888_007D)).WriteByte((short)1000, (byte)PortID);
		((TKWriterExtern)(ref _007B7888_007D)).Write((short)1001, CapturedBy);
		((TKWriterExtern)(ref _007B7888_007D)).WriteByte((short)1002, (byte)CapturerFraction);
		((TKWriterExtern)(ref _007B7888_007D)).WriteStruct<float>((short)1003, ref Server_DailyWelfare);
		((TKWriterExtern)(ref _007B7888_007D)).Write<PortDevelopment>((short)1005, Dev);
	}

	public virtual void Load(short _007B7889_007D, WriterExtern _007B7890_007D, out bool _007B7891_007D)
	{
		_007B7891_007D = true;
		switch (_007B7889_007D)
		{
		case 1000:
			PortID = _007B7890_007D.ReadByte();
			break;
		case 1001:
			_007B7890_007D.ReadString(ref CapturedBy, (Encoding)null);
			break;
		case 1002:
			CapturerFraction = (FractionID)_007B7890_007D.ReadByte();
			break;
		case 1003:
			_007B7890_007D.ReadStruct<float>(ref Server_DailyWelfare);
			break;
		case 1005:
			_007B7890_007D.ReadITKS<PortDevelopment>(ref Dev);
			break;
		default:
			_007B7891_007D = false;
			break;
		}
	}

	public virtual void PreInit()
	{
	}

	public virtual void PostInit()
	{
		if (Dev == null)
		{
			Dev = new PortDevelopment(PortID);
		}
	}

	public override int GetHashCode()
	{
		int num = 17;
		num = num * 23 + PortID.GetHashCode();
		num = num * 23 + ((CapturedBy != null) ? CapturedBy.GetHashCode() : 0);
		num = num * 23 + CapturerFraction.GetHashCode();
		num = num * 23 + Dev.PortLevel.GetHashCode();
		return num * 23 + Dev.Xp.GetHashCode();
	}

	public bool Equals(PortCaptureStatus? _007B7892_007D)
	{
		return _007B7892_007D != null && _007B7892_007D.CapturedBy == CapturedBy && _007B7892_007D.Dev.PortLevel == Dev.PortLevel && _007B7892_007D.Dev.Xp == Dev.Xp && _007B7892_007D.PortID == PortID;
	}
}
