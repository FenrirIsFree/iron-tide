using Common.Data;

namespace Common.Game;

public class TradeOrderCommonPartial
{
	public AuctionOrderPrice Price;

	public IStorageAsset ItemInfo;

	public int CurrentCount;

	public TradeOrderCommonPartial(IStorageAsset _007B6746_007D, AuctionOrderPrice _007B6747_007D, int _007B6748_007D)
	{
		Price = _007B6747_007D;
		ItemInfo = _007B6746_007D;
		CurrentCount = _007B6748_007D;
	}
}
