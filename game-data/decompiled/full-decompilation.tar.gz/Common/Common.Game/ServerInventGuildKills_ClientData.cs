using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Game;

public class ServerInventGuildKills_ClientData : IMPSerializable
{
	public Tlist<ServerInventGuildKills_Server.GuildInventInfo> TableFirstGuilds;

	public int MyGuildPoints;

	private void _007B6149_007D(WriterExtern _007B6150_007D)
	{
		_007B6150_007D.WriteStruct<int>(TableFirstGuilds.Size);
		for (int i = 0; i < TableFirstGuilds.Size; i++)
		{
			_007B6150_007D.Write<ServerInventGuildKills_Server.GuildInventInfo>(ref TableFirstGuilds.Array[i]);
		}
		_007B6150_007D.WriteStruct<int>(ref MyGuildPoints);
	}

	private void _007B6151_007D(WriterExtern _007B6152_007D)
	{
		int num = default(int);
		_007B6152_007D.ReadStruct<int>(ref num);
		TableFirstGuilds = new Tlist<ServerInventGuildKills_Server.GuildInventInfo>(num);
		ServerInventGuildKills_Server.GuildInventInfo item = default(ServerInventGuildKills_Server.GuildInventInfo);
		for (int i = 0; i < num; i++)
		{
			_007B6152_007D.ReadIMPS_struct<ServerInventGuildKills_Server.GuildInventInfo>(ref item);
			TableFirstGuilds.Add(in item);
		}
		_007B6152_007D.ReadStruct<int>(ref MyGuildPoints);
	}
}
