using System;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;
using TheraEngine.Helpers;

namespace Common.Game;

public class PbsTensity : IMPSerializable
{
	public struct Guild : IMPSerializable
	{
		public string GuildTag;

		public float Amount;

		public Guild(string _007B7868_007D, float _007B7869_007D)
		{
			GuildTag = _007B7868_007D;
			Amount = _007B7869_007D;
		}

		private void _007B7870_007D(WriterExtern _007B7871_007D)
		{
			_007B7871_007D.Write(GuildTag, (Encoding)null);
			_007B7871_007D.WriteStruct<float>(Amount);
		}

		private void _007B7872_007D(WriterExtern _007B7873_007D)
		{
			_007B7873_007D.ReadString(ref GuildTag, (Encoding)null);
			_007B7873_007D.ReadStruct<float>(ref Amount);
		}

		public string ToString(bool _007B7874_007D)
		{
			return $"[{GuildTag}] {(_007B7874_007D ? ((double)(int)Math.Ceiling(Amount * 100f)) : Math.Ceiling(Amount))}";
		}
	}

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private float _007B7864_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private Tlist<Guild> _007B7865_007D = new Tlist<Guild>();

	public float Amount => Math.Max(SelfAmount, (GuildsAmount.Size == 0) ? 0f : GuildsAmount.Max((Guild _007B7875_007D) => _007B7875_007D.Amount));

	public float SelfAmount
	{
		[CompilerGenerated]
		get
		{
			return _007B7864_007D;
		}
		[CompilerGenerated]
		private set
		{
			_007B7864_007D = value;
		}
	}

	public Tlist<Guild> GuildsAmount
	{
		[CompilerGenerated]
		get
		{
			return _007B7865_007D;
		}
		[CompilerGenerated]
		private set
		{
			_007B7865_007D = value;
		}
	}

	public PbsTensityEffects Effects => new PbsTensityEffects(Amount);

	public float this[string? _007B7851_007D] => string.IsNullOrEmpty(_007B7851_007D) ? SelfAmount : GuildsAmount.Find((Guild _007B7876_007D) => _007B7876_007D.GuildTag == _007B7851_007D).Amount;

	public override string ToString()
	{
		return $"{Amount * 100f:F0}%";
	}

	public float AddTensity(string? _007B7852_007D, float _007B7853_007D)
	{
		if (string.IsNullOrEmpty(_007B7852_007D))
		{
			float selfAmount = SelfAmount;
			SelfAmount = Geometry.Saturate(SelfAmount + _007B7853_007D);
			return SelfAmount - selfAmount;
		}
		return _007B7854_007D(_007B7852_007D, _007B7853_007D);
	}

	private float _007B7854_007D(string _007B7855_007D, float _007B7856_007D)
	{
		for (int i = 0; i < GuildsAmount.Size; i++)
		{
			ref Guild reference = ref GuildsAmount.Array[i];
			if (reference.GuildTag == _007B7855_007D)
			{
				float amount = reference.Amount;
				reference.Amount = Geometry.Saturate(reference.Amount + _007B7856_007D);
				return reference.Amount - amount;
			}
		}
		_007B7856_007D = Geometry.Saturate(_007B7856_007D);
		if (_007B7856_007D > 0f)
		{
			GuildsAmount.Add(new Guild(_007B7855_007D, _007B7856_007D));
		}
		return _007B7856_007D;
	}

	public float ReduceAll(float _007B7857_007D)
	{
		if (_007B7857_007D < 0f)
		{
			throw new ArgumentException();
		}
		float amount = Amount;
		SelfAmount = Math.Max(0f, SelfAmount - _007B7857_007D);
		for (int i = 0; i < GuildsAmount.Size; i++)
		{
			ref Guild reference = ref GuildsAmount.Array[i];
			reference.Amount = Math.Max(reference.Amount - _007B7857_007D, 0f);
			if (reference.Amount == 0f)
			{
				GuildsAmount.FastRemoveAt(i);
				i--;
			}
		}
		return amount - Amount;
	}

	public void TruncateAll(float _007B7858_007D = 0f)
	{
		SelfAmount = Math.Min(SelfAmount, _007B7858_007D);
		TruncateGuilds(_007B7858_007D);
	}

	public void TruncateGuilds(float _007B7859_007D = 0f)
	{
		if (_007B7859_007D == 0f)
		{
			GuildsAmount.Clear();
			return;
		}
		for (int i = 0; i < GuildsAmount.Size; i++)
		{
			GuildsAmount.Array[i].Amount = Math.Min(GuildsAmount.Array[i].Amount, _007B7859_007D);
		}
	}

	public void TruncateSpecificGuild(string _007B7860_007D, float _007B7861_007D = 0f)
	{
		for (int i = 0; i < GuildsAmount.Size; i++)
		{
			ref Guild reference = ref GuildsAmount.Array[i];
			if (reference.GuildTag == _007B7860_007D)
			{
				reference.Amount = Math.Min(reference.Amount, _007B7861_007D);
			}
		}
	}

	public void Boxing(WriterExtern _007B7862_007D)
	{
		_007B7862_007D.WriteStruct<float>(SelfAmount);
		_007B7862_007D.WriteTlistStruct<Guild>(GuildsAmount);
	}

	public void Unboxing(WriterExtern _007B7863_007D)
	{
		float selfAmount = default(float);
		_007B7863_007D.ReadStruct<float>(ref selfAmount);
		SelfAmount = selfAmount;
		_007B7863_007D.ReadTlistStruct<Guild>(out Tlist<Guild> _007B332_007D);
		GuildsAmount = _007B332_007D;
	}
}
