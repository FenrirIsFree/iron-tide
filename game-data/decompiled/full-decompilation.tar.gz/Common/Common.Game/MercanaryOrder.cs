using System;
using System.Runtime.CompilerServices;
using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class MercanaryOrder : IMPSerializable, ITKSerializable
{
	public class TargetPlayer : IMPSerializable
	{
		public string InitialName;

		public string InitialGuildTag;

		public TargetPlayer(string _007B8525_007D, string _007B8526_007D)
		{
			InitialName = _007B8525_007D;
			InitialGuildTag = _007B8526_007D;
		}

		public TargetPlayer()
		{
		}

		private void _007B8527_007D(WriterExtern _007B8528_007D)
		{
			_007B8528_007D.Write(InitialName, (Encoding)null);
			_007B8528_007D.Write(InitialGuildTag, (Encoding)null);
		}

		private void _007B8529_007D(WriterExtern _007B8530_007D)
		{
			_007B8530_007D.ReadString(ref InitialName, (Encoding)null);
			_007B8530_007D.ReadString(ref InitialGuildTag, (Encoding)null);
		}
	}

	public class TargetGuild : IMPSerializable
	{
		public string InitialTag;

		public TargetGuild(string _007B8532_007D)
		{
			InitialTag = _007B8532_007D;
		}

		public TargetGuild()
		{
		}

		private void _007B8533_007D(WriterExtern _007B8534_007D)
		{
			_007B8534_007D.Write(InitialTag, (Encoding)null);
		}

		private void _007B8535_007D(WriterExtern _007B8536_007D)
		{
			_007B8536_007D.ReadString(ref InitialTag, (Encoding)null);
		}
	}

	public const int DefaultDuration = 10;

	public const int MaxConcurrentTrackings = 10;

	public int ServerID;

	public uint CreatorSid;

	public int PaymentForHead;

	public int InitialCount;

	public int RemainCount;

	public SlimDateTimeInfo CreatingDate;

	public SlimDateTimeInfo TimeoutDate;

	public IMPSerializable Target;

	public string OrderCreatorNameOrNull;

	public int PaymentForHeadToCustomer => ToCustomer(PaymentForHead);

	public static int ToCustomer(int _007B8501_007D)
	{
		return _007B8501_007D * 2 / 3;
	}

	public MercanaryOrder(int _007B8502_007D, int _007B8503_007D, IMPSerializable _007B8504_007D, string _007B8505_007D)
	{
		PaymentForHead = _007B8502_007D;
		RemainCount = _007B8503_007D;
		InitialCount = _007B8503_007D;
		Target = _007B8504_007D;
		OrderCreatorNameOrNull = _007B8505_007D;
	}

	public MercanaryOrder()
	{
	}

	public string GetTitle()
	{
		return Local.q_killMercanary(GetTargetName());
	}

	public string GetTargetName(bool _007B8506_007D = false)
	{
		if (Target is TargetPlayer targetPlayer)
		{
			return targetPlayer.InitialName;
		}
		if (Target is TargetGuild targetGuild)
		{
			return (_007B8506_007D ? (Local.guild + " ") : "") + "[" + targetGuild.InitialTag + "]";
		}
		throw new NotSupportedException();
	}

	private void _007B8507_007D(WriterExtern _007B8508_007D)
	{
		_007B8508_007D.WriteStruct<uint>(CreatorSid);
		_007B8508_007D.WriteStruct<int>(ServerID);
		_007B8508_007D.WriteStruct<int>(PaymentForHead);
		_007B8508_007D.WriteStruct<int>(InitialCount);
		_007B8508_007D.WriteStruct<int>(RemainCount);
		_007B8508_007D.Write<SlimDateTimeInfo>(ref CreatingDate);
		_007B8508_007D.Write<SlimDateTimeInfo>(ref TimeoutDate);
		_007B8508_007D.WriteByte((byte)((Target is TargetPlayer) ? 1 : 2));
		_007B8508_007D.WriteNoNull<IMPSerializable>(Target);
		_007B8508_007D.Write(OrderCreatorNameOrNull, (Encoding)null);
	}

	private void _007B8509_007D(WriterExtern _007B8510_007D)
	{
		_007B8510_007D.ReadStruct<uint>(ref CreatorSid);
		_007B8510_007D.ReadStruct<int>(ref ServerID);
		_007B8510_007D.ReadStruct<int>(ref PaymentForHead);
		_007B8510_007D.ReadStruct<int>(ref InitialCount);
		_007B8510_007D.ReadStruct<int>(ref RemainCount);
		_007B8510_007D.ReadIMPS_struct<SlimDateTimeInfo>(ref CreatingDate);
		_007B8510_007D.ReadIMPS_struct<SlimDateTimeInfo>(ref TimeoutDate);
		if (_007B8510_007D.ReadByte() == 1)
		{
			TargetPlayer target = default(TargetPlayer);
			_007B8510_007D.ReadIMPSNoNull<TargetPlayer>(ref target);
			Target = (IMPSerializable)(object)target;
		}
		else
		{
			TargetGuild target2 = default(TargetGuild);
			_007B8510_007D.ReadIMPSNoNull<TargetGuild>(ref target2);
			Target = (IMPSerializable)(object)target2;
		}
		_007B8510_007D.ReadString(ref OrderCreatorNameOrNull, (Encoding)null);
	}

	private void _007B8511_007D()
	{
	}

	private void _007B8512_007D()
	{
	}

	private void _007B8513_007D(TKWriterExtern _007B8514_007D)
	{
		((TKWriterExtern)(ref _007B8514_007D)).WriteStruct<uint>((short)1, ref CreatorSid);
		((TKWriterExtern)(ref _007B8514_007D)).WriteStruct<int>((short)2, ref ServerID);
		((TKWriterExtern)(ref _007B8514_007D)).WriteStruct<int>((short)3, ref PaymentForHead);
		((TKWriterExtern)(ref _007B8514_007D)).WriteStruct<int>((short)4, ref InitialCount);
		((TKWriterExtern)(ref _007B8514_007D)).WriteStruct<int>((short)5, ref RemainCount);
		((TKWriterExtern)(ref _007B8514_007D)).WriteContent((short)6, (Action<WriterExtern>)delegate(WriterExtern _007B8520_007D)
		{
			_007B8520_007D.Write<SlimDateTimeInfo>(ref CreatingDate);
		});
		((TKWriterExtern)(ref _007B8514_007D)).WriteContent((short)7, (Action<WriterExtern>)delegate(WriterExtern _007B8522_007D)
		{
			_007B8522_007D.Write<SlimDateTimeInfo>(ref TimeoutDate);
		});
		((TKWriterExtern)(ref _007B8514_007D)).WriteIMP<IMPSerializable>((short)((Target is TargetPlayer) ? 8 : 9), Target);
		((TKWriterExtern)(ref _007B8514_007D)).Write((short)10, OrderCreatorNameOrNull);
	}

	private void _007B8515_007D(short _007B8516_007D, WriterExtern _007B8517_007D, out bool _007B8518_007D)
	{
		_007B8518_007D = true;
		switch (_007B8516_007D)
		{
		case 1:
			_007B8517_007D.ReadStruct<uint>(ref CreatorSid);
			break;
		case 2:
			_007B8517_007D.ReadStruct<int>(ref ServerID);
			break;
		case 3:
			_007B8517_007D.ReadStruct<int>(ref PaymentForHead);
			break;
		case 4:
			_007B8517_007D.ReadStruct<int>(ref InitialCount);
			break;
		case 5:
			_007B8517_007D.ReadStruct<int>(ref RemainCount);
			break;
		case 6:
			_007B8517_007D.ReadIMPS_struct<SlimDateTimeInfo>(ref CreatingDate);
			break;
		case 7:
			_007B8517_007D.ReadIMPS_struct<SlimDateTimeInfo>(ref TimeoutDate);
			break;
		case 8:
		{
			TargetPlayer target2 = default(TargetPlayer);
			_007B8517_007D.ReadIMPS<TargetPlayer>(ref target2);
			Target = (IMPSerializable)(object)target2;
			break;
		}
		case 9:
		{
			TargetGuild target = default(TargetGuild);
			_007B8517_007D.ReadIMPS<TargetGuild>(ref target);
			Target = (IMPSerializable)(object)target;
			break;
		}
		case 10:
			_007B8517_007D.ReadString(ref OrderCreatorNameOrNull, (Encoding)null);
			break;
		default:
			_007B8518_007D = false;
			break;
		}
	}

	[CompilerGenerated]
	private void _007B8519_007D(WriterExtern _007B8520_007D)
	{
		_007B8520_007D.Write<SlimDateTimeInfo>(ref CreatingDate);
	}

	[CompilerGenerated]
	private void _007B8521_007D(WriterExtern _007B8522_007D)
	{
		_007B8522_007D.Write<SlimDateTimeInfo>(ref TimeoutDate);
	}
}
