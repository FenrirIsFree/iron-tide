using System;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Helpers;

namespace Common.Game;

public class ShipFirstHp : IMPSerializable
{
	public const float bigBurningNoReturnPointMs = 12000f;

	public const float defaultBigHoleDurationSec = 10f;

	public const float floodingTimeMs = 13000f;

	internal float currentTimeFlooding;

	internal float burningDuration;

	internal float bigHoleTime;

	private PredefinedBurningType _007B5115_007D;

	private float _007B5116_007D;

	private float _007B5117_007D;

	private float _007B5118_007D;

	private float _007B5119_007D;

	public Tlist<MicroburningEffect> aliveMicroburning;

	public bool DestroyedByFloodingFlags;

	public float TemporalStrength;

	public float Summary;

	public float FloodingFactor => DestroyedByFloodingFlags ? 1f : ((currentTimeFlooding - _007B5118_007D) / 13000f);

	public float BigBurningProcessTime => burningDuration;

	public float BigBurningFlareUpLevel
	{
		get
		{
			if (burningDuration == 0f)
			{
				return 0f;
			}
			if (_007B5115_007D == PredefinedBurningType.Finite)
			{
				float num = burningDuration / 12000f;
				return num * (1f - num) * 4f * 0.6f;
			}
			if (_007B5115_007D == PredefinedBurningType.Infinite)
			{
				return Math.Min(1f, burningDuration / 4000f);
			}
			return Math.Min(Math.Max(0.01f, 1f - _007B5119_007D), MathF.Pow(burningDuration / 12000f, 1.7f) * 0.7f + ((burningDuration < 12000f) ? 0f : ((burningDuration - 12000f) / 2000f)));
		}
	}

	public bool IsInifinityBurning => burningDuration > 0f && _007B5115_007D == PredefinedBurningType.Infinite;

	public float BigBurningMengingLevel => _007B5119_007D;

	public float BigHoleTime => bigHoleTime;

	public ShipFirstHp()
	{
		aliveMicroburning = new Tlist<MicroburningEffect>();
	}

	public ShipFirstHp(float _007B5086_007D)
	{
		Summary = _007B5086_007D;
		aliveMicroburning = new Tlist<MicroburningEffect>();
	}

	public void ResetEffects()
	{
		burningDuration = 0f;
		bigHoleTime = 0f;
		currentTimeFlooding = 0f;
		_007B5118_007D = 0f;
		aliveMicroburning.Clear();
		_007B5119_007D = 0f;
		TemporalStrength = 0f;
	}

	public void SetFull(float _007B5087_007D)
	{
		ResetEffects();
		Summary = _007B5087_007D;
		DestroyedByFloodingFlags = false;
	}

	public void Check(float _007B5088_007D)
	{
		Summary = Math.Min(Summary, _007B5088_007D);
	}

	public float LimitizeForStatistics(float _007B5089_007D, float _007B5090_007D)
	{
		return Math.Min(Summary, _007B5089_007D);
	}

	public bool Restore(float _007B5091_007D, float _007B5092_007D)
	{
		if (currentTimeFlooding != 0f)
		{
			return true;
		}
		Summary = AddWithCarry(Summary, _007B5091_007D, _007B5092_007D, out var _007B5114_007D);
		TemporalStrength = Math.Max(TemporalStrength - _007B5114_007D, 0f);
		if (Summary >= _007B5092_007D && TemporalStrength == 0f)
		{
			Summary = _007B5092_007D;
			return true;
		}
		return false;
	}

	internal void AddTemporalStrength(float _007B5093_007D, float _007B5094_007D)
	{
		if (currentTimeFlooding == 0f)
		{
			float num = Math.Min(_007B5094_007D - Summary, _007B5093_007D);
			Summary += num;
			TemporalStrength += num;
		}
	}

	public float Damage(float _007B5095_007D)
	{
		if (currentTimeFlooding > 0f)
		{
			return 0f;
		}
		TemporalStrength = Math.Max(0f, TemporalStrength - _007B5095_007D);
		float num = Math.Min(_007B5095_007D, Summary);
		Summary = (((double)(Summary - num) < 0.5) ? 0f : (Summary - num));
		if (Summary <= 0f)
		{
			Summary = 0f;
		}
		if (Summary <= 0f)
		{
			currentTimeFlooding = 0.01f;
			Summary = 1f;
		}
		return num;
	}

	internal void StopFloodingSynchronized()
	{
		DestroyedByFloodingFlags = false;
		Summary = 0f;
	}

	internal void ReduceFlooding(float _007B5096_007D)
	{
		if (currentTimeFlooding == 0f)
		{
			throw new InvalidOperationException();
		}
		float num = Math.Min(12999f, currentTimeFlooding + 800f);
		_007B5118_007D = num - currentTimeFlooding;
		currentTimeFlooding = num;
	}

	internal void OnUpdateEffects(ref FrameTime _007B5097_007D, Ship _007B5098_007D)
	{
		if (Summary == 0f)
		{
			ResetEffects();
			return;
		}
		_007B5097_007D.EvaluteTimerSec(ref _007B5116_007D);
		_007B5097_007D.EvaluteTimerSec(ref _007B5117_007D);
		if (bigHoleTime > 0f)
		{
			bigHoleTime = Math.Max(0f, bigHoleTime - _007B5097_007D.secElapsed);
			_007B5117_007D = 60f;
		}
		if (burningDuration > 0f)
		{
			burningDuration += _007B5097_007D.msElapsed;
			if (_007B5115_007D == PredefinedBurningType.Finite && burningDuration > 12000f)
			{
				burningDuration = 0f;
				_007B5119_007D = 0f;
			}
			_007B5119_007D = Math.Max(0f, _007B5119_007D - _007B5097_007D.secElapsed * 0.1f);
			_007B5116_007D = 80f;
		}
		if (currentTimeFlooding > 0f && currentTimeFlooding <= 13000f)
		{
			TemporalStrength = 0f;
			_007B5118_007D = Math.Max(0f, _007B5118_007D - _007B5097_007D.msElapsed * 2f);
			currentTimeFlooding += _007B5097_007D.msElapsed * _007B5098_007D.UsedShip.StaticInfo.InertionFactor;
			if (currentTimeFlooding > 13000f)
			{
				currentTimeFlooding = 13000f;
				DestroyedByFloodingFlags = true;
			}
		}
		if (currentTimeFlooding == 0f)
		{
			for (int i = 0; i < aliveMicroburning.Size; i++)
			{
				aliveMicroburning.Array[i].TimeLeft -= _007B5097_007D.msElapsed / _007B5098_007D.UsedShip.MicrofireDurationFactor;
				if (aliveMicroburning.Array[i].TimeLeft <= 0f)
				{
					aliveMicroburning.FastRemoveAt(i);
					i--;
				}
			}
		}
		if (TemporalStrength > 0f && _007B5098_007D.UsedShip.ServerMendingTemporalStrengthPerSec == 0f)
		{
			float val = MathHelper.Lerp(1.9f, 2.5f, Geometry.Saturate(_007B5098_007D.UsedShip.MaxHp / 4000f));
			float num = Math.Min(val, TemporalStrength) * _007B5097_007D.secElapsed;
			TemporalStrength -= num;
			Summary -= num;
			TemporalStrength = Math.Max(0f, TemporalStrength);
		}
	}

	public bool ServerBurningCheck(float _007B5099_007D, Ship _007B5100_007D)
	{
		double num = 1.0 + Math.Round(_007B5100_007D.UsedShip.MaxHp / 1000f);
		if ((double)aliveMicroburning.Size < num)
		{
			return false;
		}
		if (Summary > _007B5100_007D.UsedShip.MaxHp * 0.95f || Summary < _007B5100_007D.UsedShip.MaxHp * 0.05f)
		{
			return false;
		}
		_007B5099_007D *= 0.5f + 0.5f * (Summary / _007B5100_007D.UsedShip.MaxHp);
		if (_007B5116_007D == 0f)
		{
			_007B5116_007D = _007B5099_007D;
			return true;
		}
		return false;
	}

	public bool ServerBigHoleCheck(float _007B5101_007D)
	{
		if (_007B5117_007D == 0f)
		{
			_007B5117_007D = _007B5101_007D;
			return true;
		}
		return false;
	}

	internal void CreateBurning(PredefinedBurningType _007B5102_007D)
	{
		if (burningDuration == 0f || _007B5115_007D != PredefinedBurningType.Infinite)
		{
			_007B5115_007D = _007B5102_007D;
			_007B5119_007D = 0f;
		}
		burningDuration = Math.Max(1f, burningDuration);
	}

	internal void BurningFight()
	{
		if (_007B5115_007D == PredefinedBurningType.Finite || _007B5115_007D == PredefinedBurningType.InfiniteAllowMening)
		{
			burningDuration = 0f;
			_007B5119_007D = 0f;
		}
	}

	internal void BurningMendingLoop(Ship _007B5103_007D)
	{
		if (burningDuration > 0f)
		{
			_007B5119_007D = Math.Min(1f, _007B5119_007D + 0.14f + 0.1f) * _007B5103_007D.UsedShip.BigFireFightingSpeed;
		}
	}

	public void CreateMicroburning(Ship _007B5104_007D, Vector3 _007B5105_007D, int _007B5106_007D)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		aliveMicroburning.Add(new MicroburningEffect(_007B5104_007D, _007B5105_007D, _007B5106_007D));
	}

	internal void OnPortEntry()
	{
		ResetEffects();
		DestroyedByFloodingFlags = false;
	}

	private void _007B5107_007D(WriterExtern _007B5108_007D)
	{
		_007B5108_007D.WriteStruct<short>((short)21103);
		_007B5108_007D.WriteStruct<float>(Summary);
		_007B5108_007D.WriteStruct<float>(TemporalStrength);
		_007B5108_007D.WriteStruct<float>(currentTimeFlooding);
		_007B5108_007D.WriteByte(byte.MaxValue);
		if (burningDuration != 0f || bigHoleTime != 0f)
		{
			_007B5108_007D.WriteByte((byte)1);
			_007B5108_007D.WriteByte((byte)_007B5115_007D);
			_007B5108_007D.WriteStruct<float>(ref burningDuration);
			_007B5108_007D.WriteStruct<float>(ref bigHoleTime);
		}
		else
		{
			_007B5108_007D.WriteByte((byte)0);
		}
	}

	private void _007B5109_007D(WriterExtern _007B5110_007D)
	{
		if (_007B5110_007D.PeekShort() == 21103)
		{
			short num = default(short);
			_007B5110_007D.ReadStruct<short>(ref num);
			float summary = default(float);
			_007B5110_007D.ReadStruct<float>(ref summary);
			Summary = summary;
			_007B5110_007D.ReadStruct<float>(ref TemporalStrength);
			_007B5110_007D.ReadStruct<float>(ref currentTimeFlooding);
			byte b = _007B5110_007D.ReadByte();
			if (_007B5110_007D.ReadByte() == 1)
			{
				_007B5115_007D = (PredefinedBurningType)_007B5110_007D.ReadByte();
				_007B5110_007D.ReadStruct<float>(ref burningDuration);
				_007B5110_007D.ReadStruct<float>(ref bigHoleTime);
			}
			if (Summary < 0f || float.IsNaN(Summary) || float.IsInfinity(Summary))
			{
				Summary = 0f;
			}
		}
		else
		{
			float summary2 = default(float);
			_007B5110_007D.ReadStruct<float>(ref summary2);
			Summary = summary2;
			byte b2 = _007B5110_007D.PeekByte();
			if (b2 == 222 || b2 == 223)
			{
				_007B5110_007D.ReadByte();
				if (_007B5110_007D.ReadByte() == 1)
				{
					_007B5110_007D.ReadStruct<float>(ref burningDuration);
					_007B5110_007D.ReadStruct<float>(ref bigHoleTime);
				}
				if (b2 == 223)
				{
					byte b3 = _007B5110_007D.ReadByte();
				}
			}
			if (_007B5110_007D.PeekByte() == 254)
			{
				_007B5110_007D.ReadByte();
				_007B5110_007D.ReadStruct<float>(ref TemporalStrength);
			}
		}
		aliveMicroburning = new Tlist<MicroburningEffect>();
		_007B5119_007D = 0f;
	}

	private static float AddWithCarry(float _007B5111_007D, float _007B5112_007D, float _007B5113_007D, out float _007B5114_007D)
	{
		_007B5111_007D += _007B5112_007D;
		_007B5114_007D = Math.Max(_007B5111_007D - _007B5113_007D, 0f);
		return Math.Min(_007B5111_007D, _007B5113_007D);
	}

	public override string ToString()
	{
		return Summary.ToString();
	}
}
