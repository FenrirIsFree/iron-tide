using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class GuildMember : IMPSerializable, ITKSerializable
{
	public byte RankId;

	public uint SID;

	public GuildMemberCache Cached;

	public int Salary;

	public GuildAccessRightsInfo Rights => GuildAccessRightsInfo.AllRights[RankId];

	public GuildMember()
	{
	}

	public GuildMember(int _007B6473_007D, uint _007B6474_007D, GuildMemberCache _007B6475_007D)
	{
		RankId = (byte)_007B6473_007D;
		SID = _007B6474_007D;
		Cached = _007B6475_007D;
	}

	private void _007B6476_007D(WriterExtern _007B6477_007D)
	{
		_007B6477_007D.WriteByte(RankId);
		_007B6477_007D.WriteStruct<uint>(ref SID);
		_007B6477_007D.Write<GuildMemberCache>(ref Cached);
	}

	private void _007B6478_007D(WriterExtern _007B6479_007D)
	{
		RankId = _007B6479_007D.ReadByte();
		_007B6479_007D.ReadStruct<uint>(ref SID);
		_007B6479_007D.ReadIMPS_struct<GuildMemberCache>(ref Cached);
	}

	private void _007B6480_007D()
	{
	}

	private void _007B6481_007D()
	{
	}

	private void _007B6482_007D(TKWriterExtern _007B6483_007D)
	{
		((TKWriterExtern)(ref _007B6483_007D)).WriteStruct<uint>((short)2, ref SID);
		((TKWriterExtern)(ref _007B6483_007D)).WriteByte((short)5, RankId);
		((TKWriterExtern)(ref _007B6483_007D)).WriteXXX<GuildMemberCache>((short)7, ref Cached);
		((TKWriterExtern)(ref _007B6483_007D)).WriteStruct<int>((short)8, ref Salary);
	}

	private void _007B6484_007D(short _007B6485_007D, WriterExtern _007B6486_007D, out bool _007B6487_007D)
	{
		_007B6487_007D = true;
		switch (_007B6485_007D)
		{
		case 2:
			_007B6486_007D.ReadStruct<uint>(ref SID);
			break;
		case 3:
			_007B6486_007D.ReadString(ref Cached.Name, (Encoding)null);
			break;
		case 4:
			_007B6486_007D.ReadStruct<SlimDateInfo>(ref Cached.LastActivity);
			break;
		case 5:
			RankId = _007B6486_007D.ReadByte();
			break;
		case 7:
			_007B6486_007D.ReadITKS_struct<GuildMemberCache>(ref Cached);
			break;
		case 8:
			_007B6486_007D.ReadStruct<int>(ref Salary);
			break;
		default:
			_007B6487_007D = false;
			break;
		}
	}
}
