using Common.Resources;
using Microsoft.Xna.Framework;
using TheraEngine;

namespace Common.Game;

public class QuestTransportPassengers : QuestStepHeader
{
	public RTI PassengerCount;

	public Vector2 TargetPosition;

	public IslePortInfo TargetPort;

	public float SailingDistance;

	public override int ProgressComparand => -1;

	public QuestTransportPassengers(string _007B7724_007D)
		: base(_007B7724_007D)
	{
	}
}
