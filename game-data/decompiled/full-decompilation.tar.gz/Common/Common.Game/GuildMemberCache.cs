using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct GuildMemberCache : IMPSerializable, ITKSerializable
{
	public string Name;

	public int AchievementRating;

	public SlimDateInfo LastActivity;

	public bool IsOnline;

	public GSI Refill;

	public GSI Withdraw;

	public float ConquerorBadgesParticipation;

	public bool HasReputationProblem;

	public float Server_KickByReputationTimer;

	public GuildMemberCache(string _007B6453_007D, int _007B6454_007D, SlimDateInfo _007B6455_007D, float _007B6456_007D, bool _007B6457_007D)
	{
		Server_KickByReputationTimer = 0f;
		Name = _007B6453_007D;
		AchievementRating = _007B6454_007D;
		LastActivity = _007B6455_007D;
		IsOnline = false;
		Refill = null;
		Withdraw = null;
		ConquerorBadgesParticipation = _007B6456_007D;
		HasReputationProblem = _007B6457_007D;
	}

	private void _007B6458_007D(WriterExtern _007B6459_007D)
	{
		_007B6459_007D.Write(Name, (Encoding)null);
		_007B6459_007D.WriteStruct<int>(AchievementRating);
		_007B6459_007D.Write<SlimDateInfo>(ref LastActivity);
		_007B6459_007D.Write(IsOnline);
		_007B6459_007D.Write<GSI>(Refill);
		_007B6459_007D.Write<GSI>(Withdraw);
		_007B6459_007D.WriteStruct<float>(ConquerorBadgesParticipation);
		_007B6459_007D.Write(HasReputationProblem);
	}

	private void _007B6460_007D(WriterExtern _007B6461_007D)
	{
		_007B6461_007D.ReadString(ref Name, (Encoding)null);
		_007B6461_007D.ReadStruct<int>(ref AchievementRating);
		_007B6461_007D.ReadIMPS_struct<SlimDateInfo>(ref LastActivity);
		_007B6461_007D.ReadBoolean(ref IsOnline);
		_007B6461_007D.ReadIMPS<GSI>(ref Refill);
		_007B6461_007D.ReadIMPS<GSI>(ref Withdraw);
		_007B6461_007D.ReadStruct<float>(ref ConquerorBadgesParticipation);
		_007B6461_007D.ReadBoolean(ref HasReputationProblem);
	}

	private void _007B6462_007D(TKWriterExtern _007B6463_007D)
	{
		((TKWriterExtern)(ref _007B6463_007D)).Write((short)1, Name);
		((TKWriterExtern)(ref _007B6463_007D)).WriteStruct<int>((short)2, ref AchievementRating);
		((TKWriterExtern)(ref _007B6463_007D)).WriteStruct<float>((short)7, ref ConquerorBadgesParticipation);
		((TKWriterExtern)(ref _007B6463_007D)).WriteIMP<SlimDateInfo>((short)4, ref LastActivity);
		((TKWriterExtern)(ref _007B6463_007D)).WriteIMP<GSI>((short)5, Refill);
		((TKWriterExtern)(ref _007B6463_007D)).WriteIMP<GSI>((short)6, Withdraw);
		((TKWriterExtern)(ref _007B6463_007D)).Write((short)8, HasReputationProblem);
	}

	private void _007B6464_007D()
	{
	}

	private void _007B6465_007D()
	{
	}

	private void _007B6466_007D(short _007B6467_007D, WriterExtern _007B6468_007D, out bool _007B6469_007D)
	{
		_007B6469_007D = true;
		switch (_007B6467_007D)
		{
		case 1:
			_007B6468_007D.ReadString(ref Name, (Encoding)null);
			break;
		case 2:
			_007B6468_007D.ReadStruct<int>(ref AchievementRating);
			break;
		case 7:
			_007B6468_007D.ReadStruct<float>(ref ConquerorBadgesParticipation);
			break;
		case 4:
			_007B6468_007D.ReadIMPS_struct<SlimDateInfo>(ref LastActivity);
			break;
		case 5:
			_007B6468_007D.ReadIMPS<GSI>(ref Refill);
			break;
		case 6:
			_007B6468_007D.ReadIMPS<GSI>(ref Withdraw);
			break;
		case 8:
			_007B6468_007D.ReadBoolean(ref HasReputationProblem);
			break;
		default:
			_007B6469_007D = false;
			break;
		}
	}
}
