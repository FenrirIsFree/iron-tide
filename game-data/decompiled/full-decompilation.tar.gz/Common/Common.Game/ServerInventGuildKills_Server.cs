using System;
using System.Collections.Generic;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class ServerInventGuildKills_Server : IMPSerializable
{
	private class GuildInventInfoCompareByRating : IComparer<GuildInventInfo>
	{
		private int _007B6142_007D(GuildInventInfo _007B6143_007D, GuildInventInfo _007B6144_007D)
		{
			throw new NotImplementedException();
		}

		int IComparer<GuildInventInfo>.Compare(GuildInventInfo _007B6143_007D, GuildInventInfo _007B6144_007D)
		{
			//ILSpy generated this explicit interface implementation from .override directive in {6142}
			return this._007B6142_007D(_007B6143_007D, _007B6144_007D);
		}
	}

	public struct GuildInventInfo : IMPSerializable
	{
		public string Tag;

		public int GuildServerID;

		public int CurrentInventRating;

		private void _007B6145_007D(WriterExtern _007B6146_007D)
		{
		}

		private void _007B6147_007D(WriterExtern _007B6148_007D)
		{
		}
	}

	public SortedSet<GuildInventInfo> sortedRating = new SortedSet<GuildInventInfo>(new GuildInventInfoCompareByRating());

	public void EnterKillComplete(GuildCommon _007B6136_007D, Player _007B6137_007D)
	{
	}

	private void _007B6138_007D(WriterExtern _007B6139_007D)
	{
		_007B6139_007D.WriteStruct<int>(sortedRating.Count);
		foreach (GuildInventInfo item in sortedRating)
		{
			GuildInventInfo guildInventInfo = item;
			_007B6139_007D.Write<GuildInventInfo>(ref guildInventInfo);
		}
	}

	private void _007B6140_007D(WriterExtern _007B6141_007D)
	{
		int num = default(int);
		_007B6141_007D.ReadStruct<int>(ref num);
		GuildInventInfo item = default(GuildInventInfo);
		for (int i = 0; i < num; i++)
		{
			_007B6141_007D.ReadIMPS_struct<GuildInventInfo>(ref item);
			sortedRating.Add(item);
		}
	}
}
