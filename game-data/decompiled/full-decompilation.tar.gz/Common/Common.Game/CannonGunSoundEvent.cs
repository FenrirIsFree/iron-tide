namespace Common.Game;

public enum CannonGunSoundEvent
{
	SingleShotAllCannons,
	ShotSingleCannon,
	TogetherSectionSingleGun
}
