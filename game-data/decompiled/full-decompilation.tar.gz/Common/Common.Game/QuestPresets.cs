using System;
using System.Linq;
using Common.Resources;

namespace Common.Game;

public static class QuestPresets
{
	public static QuestStepHeader[] KillAnyNpc(int _007B7421_007D)
	{
		return new QuestStepHeader[1]
		{
			new QuestKillShip(Local.q_kill_npc, _007B7421_007D, new TargetShipNpcForQuest())
		};
	}

	public static QuestStepHeader[] KillAnyNpcByMortar(int _007B7422_007D)
	{
		return new QuestStepHeader[1]
		{
			new QuestKillShip(Local.q_kill_npc_by_mortar, _007B7422_007D, DamageID.MortarShot)
		};
	}

	public static QuestStepHeader[] BoardingAnyNpc(int _007B7423_007D)
	{
		return new QuestStepHeader[1]
		{
			new QuestBoardingShip(Local.q_boarding_npc, _007B7423_007D, new TargetShipNpcForQuest())
		};
	}

	public static QuestStepHeader[] CollectBondmanFromNpc(int _007B7424_007D)
	{
		return new QuestStepHeader[1]
		{
			new QuestGetResFromBoarding(Local.q_get_bondman_boarding, 8, _007B7424_007D)
		};
	}

	public static QuestStepHeader[] KillEmpireNpcInSeamlessSea(int _007B7425_007D)
	{
		return new QuestStepHeader[1]
		{
			new QuestKillShip(Local.q_kill_empire_nps_in_seamless_sea, _007B7425_007D, new TargetShipNpcForQuest(NpcType.Empire_Regular, null, null, _007B7739_007D: false, (NpcShipDynamicInfo _007B7444_007D) => _007B7444_007D.Information.Location.IsSeamlessSea))
		};
	}

	public static QuestStepHeader[] CollectAndSellFish(int _007B7426_007D)
	{
		return CollectAndSellFish(_007B7426_007D, 10, 41, 34);
	}

	private static QuestStepHeader[] CollectAndSellFish(int _007B7427_007D, params int[] _007B7428_007D)
	{
		string text = string.Empty;
		if (_007B7428_007D.Length == 1)
		{
			text += GetPortName(_007B7428_007D[0]);
		}
		else
		{
			for (int i = 0; i < _007B7428_007D.Length - 2; i++)
			{
				text = text + GetPortName(_007B7428_007D[i]) + ", ";
			}
			text = text + GetPortName(_007B7428_007D[^2]) + Local.or + GetPortName(_007B7428_007D[^1]);
		}
		return new QuestStepHeader[2]
		{
			new QuestFishing(Local.q_fishing, _007B7427_007D),
			new QuestTradeItem(text, _007B7699_007D: true, _007B7427_007D, 34, _007B7428_007D)
		};
		static string GetPortName(int _007B7443_007D)
		{
			return Local.Current($"nport_{_007B7443_007D}_f");
		}
	}

	public static QuestStepHeader[] CollectKeys(int _007B7429_007D, int _007B7430_007D = 25)
	{
		return new QuestStepHeader[1]
		{
			new QuestCollectItems(Local.q_collect_keys, _007B7429_007D, 43, _007B7430_007D, DropModel.IsleFarming)
		};
	}

	public static QuestStepHeader[] ArenaNotDuel(int _007B7431_007D)
	{
		return new QuestStepHeader[1]
		{
			new QuestArenaGames(Local.q_arena_except_duel, QuestArenaGames.AllNotDuel(), _007B7431_007D, 250f, false)
		};
	}

	public static QuestStepHeader[] ArenaNotTraining(int _007B7432_007D)
	{
		return new QuestStepHeader[1]
		{
			new QuestArenaGames(Local.q_arena_except_training, Enum.GetValues<ArenaMode>().ToArray(), _007B7432_007D, 250f, false)
		};
	}

	public static QuestStepHeader[] FalkonetDamage(int _007B7433_007D)
	{
		return new QuestStepHeader[1]
		{
			new QuestMakeSpecificDamage(Local.q_falkonet_damage, _007B7433_007D, DamageID.FalkonetBall)
		};
	}

	public static QuestStepHeader[] FireAreaDamage(int _007B7434_007D)
	{
		return new QuestStepHeader[1]
		{
			new QuestMakeSpecificDamage(Local.q_firearea_damage, _007B7434_007D, DamageID.FireArea)
		};
	}

	public static QuestStepHeader[] BuyAndSell(int _007B7435_007D, EconomyRegion[] _007B7436_007D, EconomyRegion[] _007B7437_007D)
	{
		return new QuestStepHeader[2]
		{
			new QuestTradeItem(Local.q_buy_south, false, _007B7435_007D, _007B7436_007D),
			new QuestTradeItem(Local.q_sell_north, _007B7714_007D: true, _007B7435_007D, _007B7436_007D, _007B7437_007D)
		};
	}

	public static QuestStepHeader[] FortDamage(int _007B7438_007D)
	{
		return new QuestStepHeader[1]
		{
			new QuestWorldFortDamage(Local.q_fort_damage, _007B7438_007D)
		};
	}

	public static QuestStepHeader[] PassingMapEpic()
	{
		return new QuestStepHeader[1]
		{
			new QuestPassingMapEpic(Local.q_passing_map_epic)
		};
	}

	public static QuestStepHeader[] KillWhale(int _007B7439_007D)
	{
		return new QuestStepHeader[1]
		{
			new QuestKillWhale(Local.q_kill_whale, _007B7439_007D)
		};
	}

	public static QuestStepHeader[] CollectSpecialUnits(int _007B7440_007D)
	{
		return new QuestStepHeader[1]
		{
			new QuestCollectCrew(Local.q_collect_special, _007B7440_007D, _007B7559_007D: true)
		};
	}

	public static QuestStepHeader[] CollectEmpireDrop(int _007B7441_007D)
	{
		return new QuestStepHeader[1]
		{
			new QuestCollectDropInSea(Local.q_collect_empire, _007B7441_007D, DropModel.EmpireUnderwaterBox)
		};
	}

	public static QuestStepHeader[] KillEmpireLegend(int _007B7442_007D)
	{
		return new QuestStepHeader[1]
		{
			new QuestKillShip(Local.q_kill_empireLegend, _007B7442_007D, new TargetShipNpcForQuest((NpcShipDynamicInfo _007B7445_007D) => _007B7445_007D.Information.Descritpion == NpcType.Empire_Legendary2l || _007B7445_007D.Information.Descritpion == NpcType.Empire_Legendary3l))
		};
	}
}
