namespace Common.Game;

public enum AuctionModeFilter
{
	Buy = 1,
	Sell
}
