using TheraEngine;

namespace Common.Game;

public class QuestWorldFortDamage : QuestStepHeader
{
	public readonly RTI Count;

	public override int ProgressComparand => Count.Value;

	public QuestWorldFortDamage(string _007B7727_007D, int _007B7728_007D)
		: base(_007B7727_007D)
	{
		Count = new RTI(_007B7728_007D);
	}
}
