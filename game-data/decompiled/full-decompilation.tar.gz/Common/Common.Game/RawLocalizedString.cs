using System.Collections.Generic;
using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class RawLocalizedString : IMPSerializable
{
	private readonly Dictionary<Locale, string> _007B6234_007D = new Dictionary<Locale, string>();

	public RawLocalizedString()
	{
	}

	public RawLocalizedString(Locale _007B6226_007D, string _007B6227_007D)
	{
		_007B6234_007D.Add(_007B6226_007D, _007B6227_007D);
	}

	public bool TryAddLocalizedText(Locale _007B6228_007D, string _007B6229_007D)
	{
		return _007B6234_007D.TryAdd(_007B6228_007D, _007B6229_007D);
	}

	public bool TryGetLocalizedText(Locale _007B6230_007D, out string _007B6231_007D)
	{
		if (_007B6234_007D.TryGetValue(_007B6230_007D, out _007B6231_007D))
		{
			_007B6231_007D = _007B6234_007D[_007B6230_007D];
			return true;
		}
		_007B6231_007D = (_007B6234_007D.TryGetValue(Locale.En, out string value) ? value : string.Empty);
		return false;
	}

	public void Boxing(WriterExtern _007B6232_007D)
	{
		_007B6232_007D.WriteStruct<int>(_007B6234_007D.Count);
		foreach (var (locale2, text2) in _007B6234_007D)
		{
			_007B6232_007D.WriteEnum((object)locale2);
			_007B6232_007D.Write(text2, (Encoding)null);
		}
	}

	public void Unboxing(WriterExtern _007B6233_007D)
	{
		int num = default(int);
		_007B6233_007D.ReadStruct<int>(ref num);
		_007B6234_007D.Clear();
		Locale _007B6228_007D = default(Locale);
		string _007B6229_007D = default(string);
		for (int i = 0; i < num; i++)
		{
			_007B6233_007D.ReadEnum<Locale>(ref _007B6228_007D);
			_007B6233_007D.ReadString(ref _007B6229_007D, (Encoding)null);
			TryAddLocalizedText(_007B6228_007D, _007B6229_007D);
		}
	}
}
