using System;
using System.Runtime.CompilerServices;
using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class EventActionBase : IMPSerializable, ITKSerializable
{
	private string _007B6197_007D;

	private string _007B6198_007D;

	private RawLocalizedString _007B6199_007D;

	private RawLocalizedString _007B6200_007D;

	private bool _007B6201_007D;

	private bool _007B6202_007D;

	public string LinkInText = null;

	public int AID;

	public SlimDateTimeInfo StartDateTimeServer;

	public SlimDateTimeInfo EndDateTimeServer;

	public IEventActionBehavior Behavior;

	private byte _007B6203_007D;

	public string? NameKey => _007B6201_007D ? _007B6197_007D : null;

	public string? DescKey => _007B6202_007D ? _007B6198_007D : null;

	public string Name
	{
		get
		{
			if (_007B6199_007D != null && _007B6199_007D.TryGetLocalizedText(CurrentLocale, out string _007B6231_007D))
			{
				return _007B6231_007D;
			}
			return (!_007B6201_007D) ? _007B6197_007D : ((TextArgument != null) ? Local.Current(_007B6197_007D, TextArgument) : Local.Current(_007B6197_007D));
		}
	}

	public string Description
	{
		get
		{
			if (_007B6200_007D != null && _007B6200_007D.TryGetLocalizedText(CurrentLocale, out string _007B6231_007D))
			{
				return _007B6231_007D;
			}
			return (!_007B6202_007D) ? _007B6198_007D : ((TextArgument != null) ? Local.Current(_007B6198_007D, TextArgument) : Local.Current(_007B6198_007D));
		}
	}

	public bool CanHaveUnreadMarker => !(Behavior is EABehavior1 eABehavior) || (eABehavior.ShouldShowInLogbook && eABehavior.Category != EActionCaterory.SpecificResourceDeficit && eABehavior.Category != EActionCaterory.BEmpireShipbuilderInPort && eABehavior.Category != EActionCaterory.Season_ResourceManufacuringPortIncreaseID && eABehavior.Category != EActionCaterory.Season_ShipClassBuildingDiscountID);

	private string? TextArgument => (!string.IsNullOrEmpty(LinkInText)) ? LinkInText : ((Behavior is EABehavior1 eABehavior) ? eABehavior.TextArgument : null);

	private Locale CurrentLocale => LocaleInfo.Current.Id;

	public EventActionBase()
	{
	}

	public EventActionBase(string _007B6169_007D, string _007B6170_007D, int _007B6171_007D, IEventActionBehavior _007B6172_007D, SlimDateTimeInfo _007B6173_007D, SlimDateTimeInfo _007B6174_007D)
	{
		_007B6201_007D = Local.ContainsKey(_007B6169_007D);
		_007B6202_007D = Local.ContainsKey(_007B6170_007D);
		_007B6197_007D = _007B6169_007D;
		_007B6198_007D = _007B6170_007D;
		_007B6199_007D = new RawLocalizedString();
		_007B6200_007D = new RawLocalizedString();
		AID = _007B6171_007D;
		Behavior = _007B6172_007D;
		StartDateTimeServer = _007B6173_007D;
		EndDateTimeServer = _007B6174_007D;
	}

	public EventActionBase(RawLocalizedString _007B6175_007D, RawLocalizedString _007B6176_007D, int _007B6177_007D, IEventActionBehavior _007B6178_007D, SlimDateTimeInfo _007B6179_007D, SlimDateTimeInfo _007B6180_007D)
	{
		_007B6201_007D = true;
		_007B6202_007D = true;
		_007B6199_007D = _007B6175_007D;
		_007B6200_007D = _007B6176_007D;
		AID = _007B6177_007D;
		Behavior = _007B6178_007D;
		StartDateTimeServer = _007B6179_007D;
		EndDateTimeServer = _007B6180_007D;
	}

	private void _007B6181_007D(WriterExtern _007B6182_007D)
	{
		_007B6182_007D.Write(_007B6197_007D, (Encoding)null);
		_007B6182_007D.Write(_007B6198_007D, (Encoding)null);
		_007B6182_007D.Write(_007B6201_007D);
		_007B6182_007D.Write(_007B6202_007D);
		_007B6182_007D.WriteStruct<int>(AID);
		_007B6182_007D.Write<SlimDateTimeInfo>(ref StartDateTimeServer);
		_007B6182_007D.Write<SlimDateTimeInfo>(ref EndDateTimeServer);
		byte b = (byte)((Behavior is EABehavior1) ? 1u : 2u);
		_007B6182_007D.WriteByte(b);
		_007B6182_007D.Write<IEventActionBehavior>(Behavior);
		_007B6182_007D.Write(LinkInText, (Encoding)null);
		_007B6182_007D.Write<RawLocalizedString>(_007B6199_007D);
		_007B6182_007D.Write<RawLocalizedString>(_007B6200_007D);
	}

	private void _007B6183_007D(WriterExtern _007B6184_007D)
	{
		_007B6184_007D.ReadString(ref _007B6197_007D, (Encoding)null);
		_007B6184_007D.ReadString(ref _007B6198_007D, (Encoding)null);
		_007B6184_007D.ReadBoolean(ref _007B6201_007D);
		_007B6184_007D.ReadBoolean(ref _007B6202_007D);
		_007B6184_007D.ReadStruct<int>(ref AID);
		_007B6184_007D.ReadIMPS_struct<SlimDateTimeInfo>(ref StartDateTimeServer);
		_007B6184_007D.ReadIMPS_struct<SlimDateTimeInfo>(ref EndDateTimeServer);
		byte b = _007B6184_007D.ReadByte();
		switch (b)
		{
		case 1:
		{
			EABehavior1 behavior2 = default(EABehavior1);
			_007B6184_007D.ReadIMPS<EABehavior1>(ref behavior2);
			Behavior = behavior2;
			break;
		}
		case 2:
		{
			EABehavior2 behavior = default(EABehavior2);
			_007B6184_007D.ReadIMPS<EABehavior2>(ref behavior);
			Behavior = behavior;
			break;
		}
		default:
			throw new NotSupportedException($"Wrong behavior id {b}");
		}
		_007B6184_007D.ReadString(ref LinkInText, (Encoding)null);
		_007B6184_007D.ReadIMPS<RawLocalizedString>(ref _007B6199_007D);
		_007B6184_007D.ReadIMPS<RawLocalizedString>(ref _007B6200_007D);
	}

	private void _007B6185_007D()
	{
	}

	private void _007B6186_007D()
	{
	}

	private void _007B6187_007D(TKWriterExtern _007B6188_007D)
	{
		((TKWriterExtern)(ref _007B6188_007D)).Write((short)1, _007B6197_007D);
		((TKWriterExtern)(ref _007B6188_007D)).Write((short)2, _007B6198_007D);
		((TKWriterExtern)(ref _007B6188_007D)).Write((short)3, _007B6201_007D);
		((TKWriterExtern)(ref _007B6188_007D)).Write((short)4, _007B6202_007D);
		((TKWriterExtern)(ref _007B6188_007D)).WriteStruct<int>((short)5, ref AID);
		((TKWriterExtern)(ref _007B6188_007D)).WriteContent((short)6, (Action<WriterExtern>)delegate(WriterExtern _007B6194_007D)
		{
			_007B6194_007D.Write<SlimDateTimeInfo>(ref StartDateTimeServer);
		});
		((TKWriterExtern)(ref _007B6188_007D)).WriteContent((short)7, (Action<WriterExtern>)delegate(WriterExtern _007B6196_007D)
		{
			_007B6196_007D.Write<SlimDateTimeInfo>(ref EndDateTimeServer);
		});
		byte b = (byte)((Behavior is EABehavior1) ? 1u : 2u);
		((TKWriterExtern)(ref _007B6188_007D)).WriteByte((short)8, b);
		((TKWriterExtern)(ref _007B6188_007D)).WriteIMP<IEventActionBehavior>((short)9, Behavior);
		((TKWriterExtern)(ref _007B6188_007D)).Write((short)10, LinkInText);
		((TKWriterExtern)(ref _007B6188_007D)).WriteIMP<RawLocalizedString>((short)11, _007B6199_007D);
		((TKWriterExtern)(ref _007B6188_007D)).WriteIMP<RawLocalizedString>((short)12, _007B6200_007D);
	}

	private void _007B6189_007D(short _007B6190_007D, WriterExtern _007B6191_007D, out bool _007B6192_007D)
	{
		_007B6192_007D = true;
		switch (_007B6190_007D)
		{
		case 1:
			_007B6191_007D.ReadString(ref _007B6197_007D, (Encoding)null);
			break;
		case 2:
			_007B6191_007D.ReadString(ref _007B6198_007D, (Encoding)null);
			break;
		case 3:
			_007B6191_007D.ReadBoolean(ref _007B6201_007D);
			break;
		case 4:
			_007B6191_007D.ReadBoolean(ref _007B6202_007D);
			break;
		case 5:
			_007B6191_007D.ReadStruct<int>(ref AID);
			break;
		case 6:
			_007B6191_007D.ReadIMPS_struct<SlimDateTimeInfo>(ref StartDateTimeServer);
			break;
		case 7:
			_007B6191_007D.ReadIMPS_struct<SlimDateTimeInfo>(ref EndDateTimeServer);
			break;
		case 8:
			_007B6203_007D = _007B6191_007D.ReadByte();
			break;
		case 9:
			switch (_007B6203_007D)
			{
			case 1:
			{
				EABehavior1 behavior2 = default(EABehavior1);
				_007B6191_007D.ReadIMPS<EABehavior1>(ref behavior2);
				Behavior = behavior2;
				break;
			}
			case 2:
			{
				EABehavior2 behavior = default(EABehavior2);
				_007B6191_007D.ReadIMPS<EABehavior2>(ref behavior);
				Behavior = behavior;
				break;
			}
			default:
				throw new NotSupportedException($"Wrong behavior id {_007B6203_007D}");
			}
			break;
		case 10:
			_007B6191_007D.ReadString(ref LinkInText, (Encoding)null);
			break;
		case 11:
			_007B6191_007D.ReadIMPS<RawLocalizedString>(ref _007B6199_007D);
			break;
		case 12:
			_007B6191_007D.ReadIMPS<RawLocalizedString>(ref _007B6200_007D);
			break;
		default:
			_007B6192_007D = false;
			break;
		}
	}

	[CompilerGenerated]
	private void _007B6193_007D(WriterExtern _007B6194_007D)
	{
		_007B6194_007D.Write<SlimDateTimeInfo>(ref StartDateTimeServer);
	}

	[CompilerGenerated]
	private void _007B6195_007D(WriterExtern _007B6196_007D)
	{
		_007B6196_007D.Write<SlimDateTimeInfo>(ref EndDateTimeServer);
	}
}
