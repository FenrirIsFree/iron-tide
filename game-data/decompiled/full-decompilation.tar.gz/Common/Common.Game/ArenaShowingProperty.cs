namespace Common.Game;

public enum ArenaShowingProperty
{
	SendDamage,
	SendDamageBuldings,
	Kills,
	ReceivedDamage,
	SendDamageAlly,
	SendDamageEquip,
	SupportPoints,
	Boarding,
	Death,
	CargoPoints,
	LootedCargoPoints
}
