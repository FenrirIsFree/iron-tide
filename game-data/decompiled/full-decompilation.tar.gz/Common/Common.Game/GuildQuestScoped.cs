namespace Common.Game;

public enum GuildQuestScoped
{
	GrowTensity,
	GainExperience,
	MakeQuests,
	GrowRanks,
	GoldTurnover,
	Achievements,
	BuildTopShips,
	KillsAll,
	KillsInGuild,
	BoardingTraders,
	SellPearlEvent,
	UseCraftTime,
	EnemyDamage,
	BoardingEnemy,
	SupplyMission
}
