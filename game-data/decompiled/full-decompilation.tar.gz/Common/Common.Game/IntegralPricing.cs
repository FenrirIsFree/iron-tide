using System;
using Microsoft.Xna.Framework;

namespace Common.Game;

internal struct IntegralPricing
{
	private int _007B6677_007D;

	private float _007B6678_007D;

	private float _007B6679_007D;

	private float _007B6680_007D;

	private float _007B6681_007D;

	public IntegralPricing(int _007B6661_007D, float _007B6662_007D, float _007B6663_007D, float _007B6664_007D, float _007B6665_007D)
	{
		_007B6679_007D = _007B6662_007D;
		_007B6678_007D = _007B6663_007D;
		_007B6677_007D = _007B6661_007D;
		_007B6680_007D = _007B6664_007D;
		_007B6681_007D = _007B6665_007D;
	}

	public float PriceFunction()
	{
		return PriceFunction(_007B6677_007D);
	}

	public float PriceFunction(int _007B6666_007D)
	{
		if ((float)_007B6666_007D <= _007B6678_007D)
		{
			return _007B6679_007D * MathHelper.Lerp(_007B6681_007D, 1f, (float)_007B6666_007D / _007B6678_007D);
		}
		if ((float)_007B6666_007D <= _007B6678_007D * 2f)
		{
			return _007B6679_007D * MathHelper.Lerp(1f, _007B6680_007D, ((float)_007B6666_007D - _007B6678_007D) / _007B6678_007D);
		}
		return _007B6679_007D * _007B6680_007D;
	}

	private double _007B6667_007D(int _007B6668_007D, int _007B6669_007D)
	{
		return (double)(PriceFunction(_007B6668_007D) + PriceFunction(_007B6669_007D)) / 2.0 * (double)(_007B6669_007D - _007B6668_007D);
	}

	public double Integral(int _007B6670_007D, int _007B6671_007D)
	{
		if (_007B6670_007D > _007B6671_007D)
		{
			int num = _007B6670_007D;
			_007B6670_007D = _007B6671_007D;
			_007B6671_007D = num;
		}
		double num2 = 0.0;
		int[] array = new int[3]
		{
			(int)_007B6678_007D,
			(int)_007B6678_007D * 2,
			2147483646
		};
		int num3 = 0;
		do
		{
			if (_007B6670_007D < array[num3])
			{
				num2 += _007B6667_007D(Math.Min(array[num3], _007B6671_007D), _007B6670_007D);
				_007B6670_007D = array[num3];
			}
			num3++;
		}
		while (_007B6670_007D <= _007B6671_007D);
		return Math.Abs(num2);
	}

	public int MaxToBuyOrSell(float _007B6672_007D)
	{
		int num = (int)(_007B6678_007D / 40f);
		float num2 = Math.Abs(_007B6672_007D);
		int num3 = 0;
		float num4 = PriceFunction();
		while (true)
		{
			if (num3 >= _007B6677_007D && _007B6672_007D > 0f)
			{
				return _007B6677_007D;
			}
			if ((float)num3 >= _007B6678_007D * 4f && _007B6672_007D < 0f)
			{
				return (int)_007B6678_007D * 2;
			}
			float num5 = PriceFunction(_007B6677_007D - (num3 + num) * Math.Sign(_007B6672_007D));
			if (Math.Abs(num5 - num4) >= num2)
			{
				break;
			}
			num3 += num;
		}
		return num3;
	}

	public void MaxToBuyOrSellHelper(float _007B6673_007D, out int _007B6674_007D, out int _007B6675_007D)
	{
		int val = MaxToBuyOrSell((0f - _007B6673_007D) * 0.95f);
		int num = MaxToBuyOrSell(_007B6673_007D * 0.95f);
		int num2 = Math.Min(val, (_007B6677_007D == num) ? int.MaxValue : num);
		_007B6674_007D = Math.Min(_007B6677_007D, num2);
		_007B6675_007D = num2;
	}

	public int MaxCountToBuy(float _007B6676_007D)
	{
		float num = 0.2f;
		float num2 = 0f;
		for (int i = 0; i < 24; i++)
		{
			double num3 = Integral(_007B6677_007D, Math.Max(0, _007B6677_007D - (int)((float)_007B6677_007D * (num2 + num))));
			if (num3 > (double)_007B6676_007D)
			{
				num /= 2f;
			}
			else
			{
				num2 += num;
			}
		}
		return (int)Math.Floor((float)_007B6677_007D * num2);
	}
}
