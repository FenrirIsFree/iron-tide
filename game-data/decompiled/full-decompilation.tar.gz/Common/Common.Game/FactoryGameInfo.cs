using System;
using Common.Account;

namespace Common.Game;

public class FactoryGameInfo
{
	public readonly FactoryType Type;

	public readonly FactoryMineLivelInfo[] Levels;

	private string _007B8409_007D;

	public bool TemporaryHideInUi = false;

	public string Name => Local.Current(_007B8409_007D);

	public (int, GSI) InitBuildCost => WosbCrafting.FactoryBuildCostGold(0, Type);

	public (int, GSI) LevelUpCost(int _007B8404_007D)
	{
		return WosbCrafting.FactoryBuildCostGold(_007B8404_007D, Type);
	}

	public bool BuildHelper(PlayerAccount _007B8405_007D, bool _007B8406_007D)
	{
		if (_007B8406_007D)
		{
			if (_007B8405_007D.Shipyard.CurrentRealShip.PrivateResourcesOfHold[33] == 0)
			{
				return false;
			}
			_007B8405_007D.Shipyard.CurrentRealShip.PrivateResourcesOfHold[33]--;
			return true;
		}
		(int, GSI) initBuildCost = InitBuildCost;
		if (_007B8405_007D.Gold >= initBuildCost.Item1 && _007B8405_007D.Shipyard.CurrentRealShip.PrivateResourcesOfHold.CanRemove(initBuildCost.Item2))
		{
			_007B8405_007D.Gold -= initBuildCost.Item1;
			_007B8405_007D.Shipyard.CurrentRealShip.PrivateResourcesOfHold.Remove(initBuildCost.Item2);
			return true;
		}
		return false;
	}

	public FactoryGameInfo(FactoryType _007B8407_007D, params FactoryMineLivelInfo[] _007B8408_007D)
	{
		_007B8409_007D = "Fc" + _007B8407_007D;
		Type = _007B8407_007D;
		Levels = _007B8408_007D;
		if (!Local.ContainsKey(_007B8409_007D))
		{
			throw new Exception(_007B8409_007D);
		}
	}
}
