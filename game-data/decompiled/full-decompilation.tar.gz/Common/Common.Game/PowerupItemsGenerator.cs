using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Resources;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using TheraEngine.Collections;
using TheraEngine.Core;

namespace Common.Game;

public class PowerupItemsGenerator
{
	[CompilerGenerated]
	private sealed class _003CInitializePowerupItems_003Ed__5 : IEnumerable<PowerupItemInfo>, IEnumerable, IEnumerator<PowerupItemInfo>, IEnumerator, IDisposable
	{
		private int _007B7226_007D;

		private PowerupItemInfo _007B7227_007D;

		private int _007B7228_007D;

		private ContentManager _007B7229_007D;

		public ContentManager _003C_003E3__cm;

		private PowerupItemInfo _007B7230_007D;

		PowerupItemInfo IEnumerator<PowerupItemInfo>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B7227_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B7227_007D;
			}
		}

		[DebuggerHidden]
		public _003CInitializePowerupItems_003Ed__5(int _007B7221_007D)
		{
			_007B7226_007D = _007B7221_007D;
			_007B7228_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B7222_007D()
		{
			_007B7230_007D = null;
			_007B7226_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7222}
			this._007B7222_007D();
		}

		private bool _007B7223_007D()
		{
			switch (_007B7226_007D)
			{
			default:
				return false;
			case 0:
				_007B7226_007D = -1;
				_007B7230_007D = new PowerupItemInfo(Local.mending, icon(_007B7229_007D, "mendkit1"), 10, 10, null, delegate
				{
				})
				{
					overrideNameKey = "removed"
				};
				_007B7227_007D = new PowerupItemInfo(Local.mending, icon(_007B7229_007D, "mendkit1"), 120, 12, new CraftingRecipe(new GSI().Exs(1, 10), 0), null, new ShipBonus(ShipBonusEffect.ServMendingStrengthTemporal, 150f));
				_007B7226_007D = 1;
				return true;
			case 1:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.mending, icon(_007B7229_007D, "mendkit2"), 120, 12, new CraftingRecipe(new GSI().Exs(4, 30), 0), null, new ShipBonus(ShipBonusEffect.ServMendingStrengthTemporal, 250f))
				{
					CanBeUsedByLegendaryNpc = true
				};
				_007B7226_007D = 2;
				return true;
			case 2:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.mending, icon(_007B7229_007D, "mendkit3"), 120, 12, new CraftingRecipe(new GSI().Exs(14, 1), 0), null, new ShipBonus(ShipBonusEffect.ServMendingStrengthTemporal, 400f))
				{
					DisallowInLowRangShips = 3,
					CanBeUsedByLegendaryNpc = true
				};
				_007B7226_007D = 3;
				return true;
			case 3:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.mending, icon(_007B7229_007D, "mendkit_debris"), 65, 1, new CraftingRecipe(new GSI().Exs(20, 25).Exs(37, 1), 0), null, new ShipBonus(ShipBonusEffect.ServMendingStrengthTemporal, 200f))
				{
					DisallowInLowRangShips = 3
				};
				_007B7226_007D = 4;
				return true;
			case 4:
				_007B7226_007D = -1;
				_007B7227_007D = _007B7230_007D;
				_007B7226_007D = 5;
				return true;
			case 5:
				_007B7226_007D = -1;
				_007B7227_007D = _007B7230_007D;
				_007B7226_007D = 6;
				return true;
			case 6:
				_007B7226_007D = -1;
				_007B7227_007D = _007B7230_007D;
				_007B7226_007D = 7;
				return true;
			case 7:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.mending, icon(_007B7229_007D, "combkit1"), 120, 10, new CraftingRecipe(new GSI().Exs(3, 8).Exs(1, 10), 0), null, new ShipBonus(ShipBonusEffect.ServMendingStrength, 100f), new ShipBonus(ShipBonusEffect.ServMendingSailes, 8f), new ShipBonus(ShipBonusEffect.PReduceDamage, -25f))
				{
					AllowInterrupt = true
				};
				_007B7226_007D = 8;
				return true;
			case 8:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.mending, icon(_007B7229_007D, "combkit2"), 120, 10, new CraftingRecipe(new GSI().Exs(3, 30).Exs(4, 22), 0), null, new ShipBonus(ShipBonusEffect.ServMendingStrength, 150f), new ShipBonus(ShipBonusEffect.ServMendingSailes, 12f), new ShipBonus(ShipBonusEffect.PReduceDamage, -25f))
				{
					AllowInterrupt = true,
					CanBeUsedByLegendaryNpc = true
				};
				_007B7226_007D = 9;
				return true;
			case 9:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.mending, icon(_007B7229_007D, "combkit3"), 120, 10, new CraftingRecipe(new GSI().Exs(17, 1).Exs(14, 1), 0), null, new ShipBonus(ShipBonusEffect.ServMendingStrength, 230f), new ShipBonus(ShipBonusEffect.ServMendingSailes, 15f), new ShipBonus(ShipBonusEffect.PReduceDamage, -25f))
				{
					DisallowInLowRangShips = 3,
					AllowInterrupt = true
				};
				_007B7226_007D = 10;
				return true;
			case 10:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.mending, icon(_007B7229_007D, "hikekit"), 60, 1, new CraftingRecipe(new GSI().Exs(2, 10), 100), delegate(Ship _007B7216_007D)
				{
					_007B7216_007D.UsedShip.firstHP.bigHoleTime = 0f;
					_007B7216_007D.UsedShip.firstHP.aliveMicroburning.Clear();
					_007B7216_007D.UsedShip.Cannons.RestoreBrokenDynamic(3, _007B7216_007D.UsedShip.StaticInfo);
					_007B7216_007D.UsedShip.FirstHP.Restore(_007B7216_007D.UsedShip.MaxHp * 0.02f * (1f + _007B7216_007D.UsedShip.MendingKitEffectivityBonus), _007B7216_007D.UsedShip.MaxHp);
				})
				{
					ServerEffect = PowerupItemServerEffect.HealHurtedCrew
				};
				_007B7226_007D = 11;
				return true;
			case 11:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "rope1"), 60, 30, new CraftingRecipe(40), null, new ShipBonus(ShipBonusEffect.MSpeed, 2f))
				{
					AllowInterrupt = true
				};
				_007B7226_007D = 12;
				return true;
			case 12:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "rope2"), 60, 30, new CraftingRecipe(new GSI().Exs(17, 2)), delegate(Ship _007B7217_007D)
				{
					_007B7217_007D.Effect_Jerk();
				}, new ShipBonus(ShipBonusEffect.MSpeed, 3f), new ShipBonus(ShipBonusEffect.PSailProtection, -75f))
				{
					AllowInterrupt = true,
					CanBeUsedByLegendaryNpc = true
				};
				_007B7226_007D = 13;
				return true;
			case 13:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "shield1"), 40, 30, new CraftingRecipe(new GSI().Exs(4, 30)), null, new ShipBonus(ShipBonusEffect.MArmor, 2.5f), new ShipBonus(ShipBonusEffect.PMobilityBonus, -6f))
				{
					AllowInterrupt = true
				};
				_007B7226_007D = 14;
				return true;
			case 14:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "shield2"), 50, 30, new CraftingRecipe(new GSI().Exs(37, 5).Exs(16, 1)), null, new ShipBonus(ShipBonusEffect.MArmor, 4f), new ShipBonus(ShipBonusEffect.PMicrofireFightingSpeed, 50f), new ShipBonus(ShipBonusEffect.PMobilityBonus, -10f))
				{
					AllowInterrupt = true,
					CanBeUsedByLegendaryNpc = true,
					DisallowInLowRangShips = 3
				};
				_007B7226_007D = 15;
				return true;
			case 15:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "shadow1"), 25, 45, new CraftingRecipe(new GSI().Exs(37, 10)), null, new ShipBonus(ShipBonusEffect.PReduceDamage, 14f));
				_007B7226_007D = 16;
				return true;
			case 16:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "shadow2"), 60, 30, new CraftingRecipe(new GSI().Exs(37, 10).Exs(4, 40)), null, new ShipBonus(ShipBonusEffect.PReduceDamage, 24f))
				{
					CanBeUsedByLegendaryNpc = true
				};
				_007B7226_007D = 17;
				return true;
			case 17:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "extrause"), 240, 0, new CraftingRecipe(new GSI().Exs(38, 1)), null)
				{
					ServerEffect = PowerupItemServerEffect.CaptureNearNpc
				};
				_007B7226_007D = 18;
				return true;
			case 18:
				_007B7226_007D = -1;
				_007B7227_007D = _007B7230_007D;
				_007B7226_007D = 19;
				return true;
			case 19:
				_007B7226_007D = -1;
				_007B7227_007D = _007B7230_007D;
				_007B7226_007D = 20;
				return true;
			case 20:
				_007B7226_007D = -1;
				_007B7227_007D = _007B7230_007D;
				_007B7226_007D = 21;
				return true;
			case 21:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "powder_black"), 30, 50, new CraftingRecipe(60), null, new ShipBonus(ShipBonusEffect.MWeaponPenetration, 2.5f), new ShipBonus(ShipBonusEffect.PMortarDamageBonus, 14f), new ShipBonus(ShipBonusEffect.PCannonsReload, -9f), new ShipBonus(ShipBonusEffect.PMortarReload, -9f))
				{
					AllowInterrupt = true,
					CanBeUsedByLegendaryNpc = true
				};
				_007B7226_007D = 22;
				return true;
			case 22:
				_007B7226_007D = -1;
				_007B7227_007D = _007B7230_007D;
				_007B7226_007D = 23;
				return true;
			case 23:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "powder_red"), 30, 50, new CraftingRecipe(60), null, new ShipBonus(ShipBonusEffect.PDamageToBuilds, 25f), new ShipBonus(ShipBonusEffect.PFalkonetReloadBoost, 30f))
				{
					AllowInterrupt = true
				};
				_007B7226_007D = 24;
				return true;
			case 24:
				_007B7226_007D = -1;
				_007B7227_007D = _007B7230_007D;
				_007B7226_007D = 25;
				return true;
			case 25:
				_007B7226_007D = -1;
				_007B7227_007D = _007B7230_007D;
				_007B7226_007D = 26;
				return true;
			case 26:
				_007B7226_007D = -1;
				_007B7227_007D = _007B7230_007D;
				_007B7226_007D = 27;
				return true;
			case 27:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "powder_white"), 30, 50, new CraftingRecipe(60), null, new ShipBonus(ShipBonusEffect.MCannonsDistance, 10f), new ShipBonus(ShipBonusEffect.MMortarMaxDistance, 10f), new ShipBonus(ShipBonusEffect.PPlayerSightFocusSpeedAdd, 20f), new ShipBonus(ShipBonusEffect.MSpeed, -1f))
				{
					AllowInterrupt = true
				};
				_007B7226_007D = 28;
				return true;
			case 28:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.forGroup, icon(_007B7229_007D, "rocket_blue"), 40, 80, new CraftingRecipe(130), null, new ShipBonus(ShipBonusEffect.MSpeed, 1f))
				{
					GroupDistanceLimit = 500,
					IsGroupEffect = true
				};
				_007B7226_007D = 29;
				return true;
			case 29:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.forGroup, icon(_007B7229_007D, "rocket_red"), 40, 80, new CraftingRecipe(200), null, new ShipBonus(ShipBonusEffect.PBallDamage, 5f))
				{
					GroupDistanceLimit = 500,
					IsGroupEffect = true
				};
				_007B7226_007D = 30;
				return true;
			case 30:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.forGroup, icon(_007B7229_007D, "rocket_yellow"), 40, 80, new CraftingRecipe(new GSI().Exs(37, 10)), null, new ShipBonus(ShipBonusEffect.MSpeed, 1f), new ShipBonus(ShipBonusEffect.PBallDamage, 5f))
				{
					GroupDistanceLimit = 500,
					IsGroupEffect = true
				};
				_007B7226_007D = 31;
				return true;
			case 31:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.forGroup, icon(_007B7229_007D, "horn"), 120, 0, new CraftingRecipe(new GSI().Exs(38, 1)), delegate(Ship _007B7218_007D)
				{
					_007B7218_007D.UsedShip.FirstHP.AddTemporalStrength(_007B7218_007D.UsedShip.MaxHp * 0.05f * (1f + _007B7218_007D.UsedShip.MendingKitEffectivityBonus), _007B7218_007D.UsedShip.MaxHp);
				})
				{
					GroupDistanceLimit = 500,
					IsGroupEffect = true
				};
				_007B7226_007D = 32;
				return true;
			case 32:
				_007B7226_007D = -1;
				_007B7227_007D = _007B7230_007D;
				_007B7226_007D = 33;
				return true;
			case 33:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "rumkit"), 80, 60, new CraftingRecipe(new GSI().Exs(2, 20), 0), null, new ShipBonus(ShipBonusEffect.PCannonsReload, 20f), new ShipBonus(ShipBonusEffect.PSpeed, -8f))
				{
					AllowInterrupt = false
				};
				_007B7226_007D = 34;
				return true;
			case 34:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "meatAndFish"), 60, 120, new CraftingRecipe(new GSI().Exs(34, 20).Exs(21, 40), 0), null, new ShipBonus(ShipBonusEffect.PSpeedPaddles, 1.5f / PlayerShipInfo.Temp_displaySpeedRefactoring * 100f), new ShipBonus(ShipBonusEffect.PMendingEffectivity, 30f), new ShipBonus(ShipBonusEffect.PChangeShipSpeedBonus, 10f), new ShipBonus(ShipBonusEffect.PPowerupItemsReload, 30f), new ShipBonus(ShipBonusEffect.PChangeCBallsSpeed, 30f), new ShipBonus(ShipBonusEffect.MMobilityBonus, 5f))
				{
					AllowInterrupt = true
				};
				_007B7226_007D = 35;
				return true;
			case 35:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.mending, icon(_007B7229_007D, "mendkit4"), 120, 10, new CraftingRecipe(new GSI(), 0), null, new ShipBonus(ShipBonusEffect.ServMendingStrengthTemporal, 500f))
				{
					HideFromCraftUi = true
				};
				_007B7226_007D = 36;
				return true;
			case 36:
				_007B7226_007D = -1;
				_007B7227_007D = _007B7230_007D;
				_007B7226_007D = 37;
				return true;
			case 37:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "bonus_hp"), 60, 0, new CraftingRecipe(new GSI(), 0), delegate(Ship _007B7219_007D)
				{
					_007B7219_007D.RestoreHp(_007B7219_007D.UsedShip.MaxHp * 0.2f);
				})
				{
					HideFromCraftUi = true
				};
				_007B7226_007D = 38;
				return true;
			case 38:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "bonus_weapons"), 60, 30, new CraftingRecipe(new GSI(), 0), null, new ShipBonus(ShipBonusEffect.MCannonsDistance, 14f), new ShipBonus(ShipBonusEffect.MMortarMaxDistance, 14f))
				{
					HideFromCraftUi = true
				};
				_007B7226_007D = 39;
				return true;
			case 39:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "bonus_speed"), 60, 30, new CraftingRecipe(new GSI(), 0), null, new ShipBonus(ShipBonusEffect.MSpeed, 3f))
				{
					HideFromCraftUi = true
				};
				_007B7226_007D = 40;
				return true;
			case 40:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "fosfpowder"), 30, 60, new CraftingRecipe(new GSI().Exs(37, 4), 150), null, new ShipBonus(ShipBonusEffect.MCannonsAngleBonus, -5f), new ShipBonus(ShipBonusEffect.BCannonBallFosforEffects, 1f), new ShipBonus(ShipBonusEffect.MWeaponPenetration, 2f))
				{
					AllowInterrupt = false
				};
				_007B7226_007D = 41;
				return true;
			case 41:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "bombershell"), 40, 50, new CraftingRecipe(new GSI().Exs(37, 4), 150), null, new ShipBonus(ShipBonusEffect.PBallDamage, -50f), new ShipBonus(ShipBonusEffect.MCannonsDistance, -5f), new ShipBonus(ShipBonusEffect.BCannonBallBobershell, 1f))
				{
					AllowInterrupt = true
				};
				_007B7226_007D = 42;
				return true;
			case 42:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "dropboost"), 180, 90, new CraftingRecipe(new GSI().Exs(38, 1), 5000), null, new ShipBonus(ShipBonusEffect.PImproveQuantityOfDropCannons, 100f))
				{
					AllowInterrupt = false
				};
				_007B7226_007D = 43;
				return true;
			case 43:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "empire_skill"), 70, 18, null, null, new ShipBonus(ShipBonusEffect.PInvisibility, 60f))
				{
					AllowInterrupt = false
				};
				_007B7226_007D = 44;
				return true;
			case 44:
				_007B7226_007D = -1;
				_007B7227_007D = new PowerupItemInfo(Local.items_cat_up, icon(_007B7229_007D, "empire_skill"), 180, 420, null, null, new ShipBonus(ShipBonusEffect.BAvanpostMode, 1f), new ShipBonus(ShipBonusEffect.BCanGoOnly2Speed, 1f), new ShipBonus(ShipBonusEffect.PCannonsReload, -50f))
				{
					AllowInterrupt = true
				};
				_007B7226_007D = 45;
				return true;
			case 45:
				_007B7226_007D = -1;
				_007B7227_007D = _007B7230_007D;
				_007B7226_007D = 46;
				return true;
			case 46:
				_007B7226_007D = -1;
				_007B7227_007D = _007B7230_007D;
				_007B7226_007D = 47;
				return true;
			case 47:
				_007B7226_007D = -1;
				_007B7227_007D = _007B7230_007D;
				_007B7226_007D = 48;
				return true;
			case 48:
				_007B7226_007D = -1;
				return false;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7223}
			return this._007B7223_007D();
		}

		[DebuggerHidden]
		private void _007B7224_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7224}
			this._007B7224_007D();
		}

		[DebuggerHidden]
		IEnumerator<PowerupItemInfo> IEnumerable<PowerupItemInfo>.GetEnumerator()
		{
			_003CInitializePowerupItems_003Ed__5 _003CInitializePowerupItems_003Ed__;
			if (_007B7226_007D == -2 && _007B7228_007D == Environment.CurrentManagedThreadId)
			{
				_007B7226_007D = 0;
				_003CInitializePowerupItems_003Ed__ = this;
			}
			else
			{
				_003CInitializePowerupItems_003Ed__ = new _003CInitializePowerupItems_003Ed__5(0);
			}
			_003CInitializePowerupItems_003Ed__._007B7229_007D = _003C_003E3__cm;
			return _003CInitializePowerupItems_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B7225_007D()
		{
			return ((IEnumerable<PowerupItemInfo>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7225}
			return this._007B7225_007D();
		}
	}

	public static readonly float CaptureNpcItemMaxDist = 50f;

	public static readonly Tlist<int> SkillsIds = new Tlist<int> { 43, 44 };

	private static Dictionary<string, Texture2D> loadedTextures = new Dictionary<string, Texture2D>();

	public static Tlist<int[]> enemyItemsId;

	private static Texture2D icon(ContentManager _007B7209_007D, string _007B7210_007D)
	{
		if (loadedTextures.ContainsKey(_007B7210_007D))
		{
			return loadedTextures[_007B7210_007D];
		}
		Texture2D val = _007B7209_007D.Load<Texture2D>("_lzcommon\\Items\\PowerupItems\\" + _007B7210_007D);
		loadedTextures.Add(_007B7210_007D, val);
		return val;
	}

	[IteratorStateMachine(typeof(_003CInitializePowerupItems_003Ed__5))]
	public static IEnumerable<PowerupItemInfo> InitializePowerupItems(ContentManager _007B7211_007D)
	{
		//yield-return decompiler failed: Method not found
		return new _003CInitializePowerupItems_003Ed__5(-2)
		{
			_003C_003E3__cm = _007B7211_007D
		};
	}

	public static bool CanNpcBeCapturedByPowerupItem(Npc _007B7212_007D, Player _007B7213_007D, out int _007B7214_007D)
	{
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		_007B7214_007D = (int)_007B7212_007D.UsedShip.MaxHp;
		if (_007B7212_007D.IsStatic || _007B7212_007D.IsPlayerCaper || _007B7212_007D.UsedShip.StaticInfo.IsBalloon || _007B7212_007D.UsedShip.HpFactor < 0.999f || _007B7212_007D.UsedShip.StaticInfo.ID == 1 || !_007B7212_007D.UsedShipNpc.Information.Extras.AllowCapture(_007B7212_007D.MapInfo) || Vector2.Distance(_007B7212_007D.Position, _007B7213_007D.Position) > CaptureNpcItemMaxDist * (CommonGlobal.IsServer ? 1.1f : 1f))
		{
			return false;
		}
		return true;
	}

	static PowerupItemsGenerator()
	{
		Tlist<int[]> tlist = new Tlist<int[]>();
		int[] item = new int[5] { 0, 1, 2, 3, 43 };
		tlist.Add(in item);
		int[] item2 = new int[3] { 7, 8, 9 };
		tlist.Add(in item2);
		int[] item3 = new int[2] { 11, 12 };
		tlist.Add(in item3);
		int[] item4 = new int[2] { 13, 14 };
		tlist.Add(in item4);
		int[] item5 = new int[2] { 15, 16 };
		tlist.Add(in item5);
		int[] item6 = new int[2] { 21, 44 };
		tlist.Add(in item6);
		enemyItemsId = tlist;
	}
}
