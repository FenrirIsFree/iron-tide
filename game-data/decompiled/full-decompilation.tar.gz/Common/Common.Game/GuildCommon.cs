using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Text.RegularExpressions.Generated;
using Common.Packets;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine;
using TheraEngine.Collections;

namespace Common.Game;

public class GuildCommon : IMPSerializable, ITKSerializable
{
	[CompilerGenerated]
	private sealed class _003CGetGuildsTitleIds_003Ed__77 : IEnumerable<int>, IEnumerable, IEnumerator<int>, IEnumerator, IDisposable
	{
		private int _007B6398_007D;

		private int _007B6399_007D;

		private int _007B6400_007D;

		private FractionID _007B6401_007D;

		public FractionID _003C_003E3__fraction;

		private int _007B6402_007D;

		public int _003C_003E3__guildsCount;

		private int _007B6403_007D;

		public int _003C_003E3__totalGameGuilds;

		private int _007B6404_007D;

		private int _007B6405_007D;

		private int _007B6406_007D;

		int IEnumerator<int>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B6399_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B6399_007D;
			}
		}

		[DebuggerHidden]
		public _003CGetGuildsTitleIds_003Ed__77(int _007B6393_007D)
		{
			_007B6398_007D = _007B6393_007D;
			_007B6400_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B6394_007D()
		{
			_007B6398_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {6394}
			this._007B6394_007D();
		}

		private bool _007B6395_007D()
		{
			switch (_007B6398_007D)
			{
			default:
				return false;
			case 0:
				_007B6398_007D = -1;
				_007B6399_007D = Gameplay.GuildTitlesByFraction[_007B6401_007D].First((GuildTitle _007B6376_007D) => _007B6376_007D.Place == GuildTitlePlace.Gold).Id;
				_007B6398_007D = 1;
				return true;
			case 1:
				_007B6398_007D = -1;
				_007B6404_007D = 0;
				goto IL_00f7;
			case 2:
			{
				_007B6398_007D = -1;
				int num = _007B6404_007D + 1;
				_007B6404_007D = num;
				goto IL_00f7;
			}
			case 3:
			{
				_007B6398_007D = -1;
				int num = _007B6405_007D + 1;
				_007B6405_007D = num;
				goto IL_018c;
			}
			case 4:
				{
					_007B6398_007D = -1;
					int num = _007B6406_007D + 1;
					_007B6406_007D = num;
					break;
				}
				IL_00f7:
				if ((float)_007B6404_007D < Math.Max(1f, (float)_007B6403_007D * 3f / 500f))
				{
					_007B6399_007D = Gameplay.GuildTitlesByFraction[_007B6401_007D].First((GuildTitle _007B6377_007D) => _007B6377_007D.Place == GuildTitlePlace.Silver).Id;
					_007B6398_007D = 2;
					return true;
				}
				_007B6405_007D = 0;
				goto IL_018c;
				IL_018c:
				if ((float)_007B6405_007D < Math.Max(1f, (float)_007B6403_007D * 4f / 500f))
				{
					_007B6399_007D = Gameplay.GuildTitlesByFraction[_007B6401_007D].First((GuildTitle _007B6378_007D) => _007B6378_007D.Place == GuildTitlePlace.Bronze).Id;
					_007B6398_007D = 3;
					return true;
				}
				_007B6406_007D = 0;
				break;
			}
			if ((float)_007B6406_007D < Math.Max(1f, (float)_007B6403_007D * 5f / 500f))
			{
				_007B6399_007D = Gameplay.GuildTitlesByFraction[_007B6401_007D].First((GuildTitle _007B6379_007D) => _007B6379_007D.Place == GuildTitlePlace.Copper).Id;
				_007B6398_007D = 4;
				return true;
			}
			return false;
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {6395}
			return this._007B6395_007D();
		}

		[DebuggerHidden]
		private void _007B6396_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {6396}
			this._007B6396_007D();
		}

		[DebuggerHidden]
		IEnumerator<int> IEnumerable<int>.GetEnumerator()
		{
			_003CGetGuildsTitleIds_003Ed__77 _003CGetGuildsTitleIds_003Ed__;
			if (_007B6398_007D == -2 && _007B6400_007D == Environment.CurrentManagedThreadId)
			{
				_007B6398_007D = 0;
				_003CGetGuildsTitleIds_003Ed__ = this;
			}
			else
			{
				_003CGetGuildsTitleIds_003Ed__ = new _003CGetGuildsTitleIds_003Ed__77(0);
			}
			_003CGetGuildsTitleIds_003Ed__._007B6401_007D = _003C_003E3__fraction;
			_003CGetGuildsTitleIds_003Ed__._007B6402_007D = _003C_003E3__guildsCount;
			_003CGetGuildsTitleIds_003Ed__._007B6403_007D = _003C_003E3__totalGameGuilds;
			return _003CGetGuildsTitleIds_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B6397_007D()
		{
			return ((IEnumerable<int>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {6397}
			return this._007B6397_007D();
		}
	}

	public const int DelayMinutesToApplyRules = 120;

	public const int ActionLogRecordLimit = 100;

	public const int ReparationIngotsPrice = 5000;

	public const int MembershipConquerBadgesPrice = 25;

	public const int MinMembersForNationKick = 15;

	public uint GuildID;

	private Tlist<GuildActionLogRecord> _007B6361_007D;

	private Tlist<GuildMember> _007B6362_007D;

	private Tlist<GuildInvite> _007B6363_007D;

	private string _007B6364_007D;

	private string _007B6365_007D;

	private string _007B6366_007D;

	private string _007B6367_007D;

	private string _007B6368_007D;

	private int _007B6369_007D;

	private byte[] _007B6370_007D;

	private RTI _007B6371_007D;

	private RTI _007B6372_007D;

	private RTI _007B6373_007D;

	private FractionID _007B6374_007D;

	public Tlist<GuildTemporaryEffect> Effects;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private FractionID _007B6375_007D = FractionID.TradeUnion;

	public Tlist<GuildRuleToOther> TrustedGuilds;

	public int MaxPlayers;

	public ushort Version;

	public bool ActiveForNewPlayers;

	public PbCaptureMode PbCaptureMode = PbCaptureMode.Capture;

	public PbsAttackWindow PbsWindow;

	public GSI ReceivedTitles = new GSI();

	public byte PotentialTitleId;

	public byte CachedSupplyMissionCount;

	public static int MinMembersToUpdateFlotilia => 5;

	public int AllyHqLimit => 1;

	private int HqBonusDuration => 7;

	public int MaxTrustedGuilds => 4;

	public float AmountMoneyWillShareToSalary => HasMintAndSalary ? 0.2f : 0f;

	public bool HasMintAndSalary => !IsFlotilia;

	public int MakeDisputePrice => 10;

	public FractionID Fraction
	{
		[CompilerGenerated]
		get
		{
			return _007B6375_007D;
		}
		[CompilerGenerated]
		private set
		{
			_007B6375_007D = value;
		}
	}

	public bool IsFlotilia => CommonSupport.IsGuildFlotilia(Fraction);

	public float ColonizeTax => (Fraction == FractionID.Pirate) ? 0.6f : (Fraction.IsNation() ? 0.4f : 0f);

	public string Tag => _007B6364_007D;

	public string Name => _007B6365_007D;

	public string Description => _007B6366_007D;

	public string InternalInformation => _007B6367_007D;

	public byte[] Image => _007B6370_007D;

	public Tlist<GuildMember> Members => _007B6362_007D;

	public Tlist<GuildActionLogRecord> Log => _007B6361_007D;

	public int ConquerBadges => _007B6372_007D.Value;

	public (string, int) CurrentAnnouncment => (_007B6368_007D, _007B6369_007D);

	public bool ProbablyCISGuild => CiryllicRegex().IsMatch(_007B6364_007D) || CiryllicRegex().IsMatch(_007B6365_007D) || CiryllicRegex().IsMatch(_007B6366_007D);

	public GuildMember GetFounder
	{
		get
		{
			for (int i = 0; i < _007B6362_007D.Size; i++)
			{
				if (_007B6362_007D.Array[i].RankId == GuildAccessRightsInfo.FounderRights.RankId)
				{
					return _007B6362_007D.Array[i];
				}
			}
			throw new InvalidOperationException("No founder: guild");
		}
	}

	public Tlist<GuildInvite> Invites => _007B6363_007D;

	public int Treasury
	{
		get
		{
			return _007B6371_007D.Value;
		}
		set
		{
			_007B6371_007D.Value = value;
		}
	}

	public int Mint
	{
		get
		{
			return _007B6373_007D.Value;
		}
		set
		{
			_007B6373_007D.Value = value;
		}
	}

	public static int GuildRelogTimeRistriction(bool _007B6277_007D)
	{
		return _007B6277_007D ? 1 : 48;
	}

	public static RTI GuildCreateCostGold(bool _007B6278_007D, bool _007B6279_007D = false)
	{
		return _007B6278_007D ? 10000 : (_007B6279_007D ? 2000000 : 3000000);
	}

	public RTI GuildUpgradeCostIngots()
	{
		return (GuildCreateCostGold(_007B6278_007D: false, _007B6372_007D.Value > 0).Value - GuildCreateCostGold(_007B6278_007D: true, _007B6372_007D.Value > 0).Value) / 500;
	}

	public static int GuildInitialPlayersLimit(bool _007B6280_007D)
	{
		return _007B6280_007D ? GuildMaxPlayersLim(_007B6281_007D: true) : 10;
	}

	public static int GuildMaxPlayersLim(bool _007B6281_007D)
	{
		return _007B6281_007D ? 30 : 70;
	}

	public static int MinimalCaptainRank(bool _007B6282_007D)
	{
		return _007B6282_007D ? 5 : 20;
	}

	public static int MinMembersForNation(bool _007B6283_007D)
	{
		return _007B6283_007D ? 20 : 25;
	}

	[GeneratedRegex("\\p{IsCyrillic}")]
	[GeneratedCode("System.Text.RegularExpressions.Generator", "7.0.10.26716")]
	private static Regex CiryllicRegex()
	{
		return _003CRegexGenerator_g_003EF0C3BD9BB37024C1C1D9D4B7EE90EE7516B5C31DF06DF20770F21125BE4FD7C5D__CiryllicRegex_0.Instance;
	}

	[IteratorStateMachine(typeof(_003CGetGuildsTitleIds_003Ed__77))]
	public static IEnumerable<int> GetGuildsTitleIds(FractionID _007B6285_007D, int _007B6286_007D, int _007B6287_007D)
	{
		//yield-return decompiler failed: Method not found
		return new _003CGetGuildsTitleIds_003Ed__77(-2)
		{
			_003C_003E3__fraction = _007B6285_007D,
			_003C_003E3__guildsCount = _007B6286_007D,
			_003C_003E3__totalGameGuilds = _007B6287_007D
		};
	}

	public GuildCommon()
	{
	}

	public GuildCommon(uint _007B6290_007D, string _007B6291_007D, string _007B6292_007D, GuildMemberCache _007B6293_007D, FractionID _007B6294_007D)
	{
		_007B6362_007D = new Tlist<GuildMember>
		{
			new GuildMember(GuildAccessRightsInfo.FounderRights.RankId, _007B6290_007D, _007B6293_007D)
		};
		_007B6361_007D = new Tlist<GuildActionLogRecord>();
		_007B6363_007D = new Tlist<GuildInvite>();
		_007B6365_007D = _007B6291_007D;
		_007B6364_007D = _007B6292_007D;
		_007B6366_007D = string.Empty;
		_007B6370_007D = new byte[0];
		_007B6371_007D = new RTI(0);
		_007B6367_007D = string.Empty;
		_007B6368_007D = string.Empty;
		_007B6369_007D = 0;
		Fraction = _007B6294_007D;
		MaxPlayers = GuildInitialPlayersLimit(IsFlotilia);
		_007B6373_007D = new RTI(0);
		Effects = new Tlist<GuildTemporaryEffect>();
		TrustedGuilds = new Tlist<GuildRuleToOther>();
		_007B6372_007D = new RTI(10);
		PbsWindow = new PbsAttackWindow(20);
	}

	public void AddMemberAndUpdate(GuildMember _007B6295_007D)
	{
		for (int i = 0; i < _007B6362_007D.Size; i++)
		{
			if (_007B6362_007D.Array[i].SID == _007B6295_007D.SID)
			{
				_007B6362_007D.FastRemoveAt(i);
				i--;
			}
		}
		_007B6362_007D.Add(in _007B6295_007D);
	}

	public virtual bool RemoveMemberAndUpdate(uint _007B6296_007D)
	{
		for (int i = 0; i < _007B6362_007D.Size; i++)
		{
			if (_007B6362_007D.Array[i].SID == _007B6296_007D)
			{
				_007B6362_007D.RemoveAt(i);
				return true;
			}
		}
		return false;
	}

	public virtual void UpdateName(string _007B6297_007D)
	{
		_007B6365_007D = _007B6297_007D;
	}

	public virtual void UpdateDescription(string _007B6298_007D)
	{
		_007B6366_007D = _007B6298_007D;
	}

	public virtual void UpdateImage(byte[] _007B6299_007D)
	{
		_007B6370_007D = _007B6299_007D;
	}

	public virtual void UpdateInternalInformation(string _007B6300_007D)
	{
		_007B6367_007D = _007B6300_007D;
	}

	public virtual void UpdateAnnouncment(string _007B6301_007D)
	{
		if (_007B6368_007D != _007B6301_007D)
		{
			_007B6368_007D = _007B6301_007D;
			_007B6369_007D++;
		}
	}

	public void UpdateTextField(OnChangeGuldTextProperty _007B6302_007D)
	{
		switch (_007B6302_007D.ValueID)
		{
		case 1:
			UpdateName(_007B6302_007D.Value);
			break;
		case 2:
			UpdateDescription(_007B6302_007D.Value);
			break;
		case 4:
			UpdateInternalInformation(_007B6302_007D.Value);
			break;
		case 5:
			UpdateAnnouncment(_007B6302_007D.Value);
			break;
		case 3:
			break;
		}
	}

	public GuildMember AddMemberByInvite(uint _007B6303_007D, GuildMemberCache _007B6304_007D)
	{
		GuildMember item = new GuildMember(GuildAccessRightsInfo.NewPlayerRights.RankId, _007B6303_007D, _007B6304_007D);
		_007B6362_007D.Add(in item);
		TryRemoveInvite(_007B6303_007D);
		return item;
	}

	public void AddInvite(GuildInvite _007B6305_007D)
	{
		if (!_007B6363_007D.Contains((GuildInvite _007B6386_007D) => _007B6386_007D.SID == _007B6305_007D.SID))
		{
			Version++;
			_007B6363_007D.Add(in _007B6305_007D);
		}
	}

	public bool TryRemoveInvite(uint _007B6306_007D)
	{
		for (int i = 0; i < _007B6363_007D.Size; i++)
		{
			if (_007B6363_007D.Array[i].SID == _007B6306_007D)
			{
				_007B6363_007D.RemoveAt(i);
				return true;
			}
		}
		return false;
	}

	public GuildDisplayInfo GetGuildCondensedInfo(int _007B6307_007D, int _007B6308_007D, GuildQuests _007B6309_007D)
	{
		return new GuildDisplayInfo
		{
			Tag = _007B6364_007D,
			GuildName = _007B6365_007D,
			Description = _007B6366_007D,
			Fraction = Fraction,
			TrustedGuilds = new Tlist<string>(TrustedGuilds.Select((GuildRuleToOther _007B6380_007D) => _007B6380_007D.Tag)),
			MembersCount = _007B6362_007D.Size,
			DisputeVotes = new Tlist<GuildTemporaryEffect>(Effects.Where((GuildTemporaryEffect _007B6381_007D) => _007B6381_007D.Case == GuildTemporaryEffect.Type.DisputeVoteReceived)),
			DisputeProtectionSec = (Effects.FirstOrDefault((GuildTemporaryEffect _007B6382_007D) => _007B6382_007D.Case == GuildTemporaryEffect.Type.DisputeProtection)?.RemainingTimeSec ?? 0.0),
			FounderContact = new PlayerContact(GetFounder.SID, GetFounder.Cached.Name),
			ContactsFirstSuppors = new Tlist<PlayerContact>(from _007B6384_007D in _007B6362_007D
				where _007B6384_007D.RankId == 6
				select new PlayerContact(_007B6384_007D.SID, _007B6384_007D.Cached.Name)),
			CapturedPorts = (short)_007B6307_007D,
			GuildRating = (short)_007B6308_007D,
			TradeUnionHqCount = ((Fraction == FractionID.TradeUnion) ? Effects.Count((GuildTemporaryEffect _007B6385_007D) => _007B6385_007D.Case == GuildTemporaryEffect.Type.HqOrLicenseInPort) : 0),
			ActiveForNewPlayers = ActiveForNewPlayers,
			GuildTitles = ReceivedTitles,
			Quests = _007B6309_007D
		};
	}

	public bool IsUpgradeAvailable(GuildTemporaryEffect.Type _007B6310_007D, byte _007B6311_007D, out (int ingots, int badges) _007B6312_007D)
	{
		_007B6312_007D = (ingots: 0, badges: 0);
		if (_007B6310_007D == GuildTemporaryEffect.Type.UpgradeStaff)
		{
			if (MaxPlayers >= GuildMaxPlayersLim(IsFlotilia))
			{
				return false;
			}
			_007B6312_007D = (ingots: 2, badges: (MaxPlayers >= 60) ? 4 : ((MaxPlayers >= 50) ? 2 : ((MaxPlayers >= 30) ? 1 : 0)));
			return true;
		}
		return false;
	}

	public (int currentLevel, int maxLevel) GetUpgradeLevel(GuildTemporaryEffect.Type _007B6313_007D, byte _007B6314_007D)
	{
		if (_007B6313_007D == GuildTemporaryEffect.Type.UpgradeStaff)
		{
			return (currentLevel: MaxPlayers - GuildInitialPlayersLimit(IsFlotilia), maxLevel: GuildMaxPlayersLim(IsFlotilia) - GuildInitialPlayersLimit(IsFlotilia));
		}
		throw new NotSupportedException();
	}

	public GuildTemporaryEffect? TryRemoveEffect(GuildTemporaryEffect.Type _007B6315_007D, string? _007B6316_007D = null, byte? _007B6317_007D = null)
	{
		for (int i = 0; i < Effects.Size; i++)
		{
			GuildTemporaryEffect guildTemporaryEffect = Effects[i];
			if (guildTemporaryEffect.Case == _007B6315_007D && (_007B6316_007D == null || _007B6316_007D == guildTemporaryEffect.Argument) && (!_007B6317_007D.HasValue || _007B6317_007D == guildTemporaryEffect.ArgumentByte))
			{
				Effects.RemoveAt(i);
				return guildTemporaryEffect;
			}
		}
		return null;
	}

	public void TryMakeEffect(GuildTemporaryEffect.Type _007B6318_007D, string _007B6319_007D, byte _007B6320_007D, EventActionsPipelineBase _007B6321_007D)
	{
		if (IsUpgradeAvailable(_007B6318_007D, _007B6320_007D, out (int, int) _007B6312_007D) && _007B6312_007D.Item2 <= _007B6372_007D.Value && _007B6312_007D.Item1 <= Treasury)
		{
			Treasury -= _007B6312_007D.Item1;
			_007B6372_007D.Value -= _007B6312_007D.Item2;
		}
		else if (_007B6318_007D == GuildTemporaryEffect.Type.UpgradeStaff)
		{
			return;
		}
		if (_007B6318_007D == GuildTemporaryEffect.Type.UpgradeStaff)
		{
			int num = Effects.FindIndex((GuildTemporaryEffect _007B6387_007D) => _007B6387_007D.Case == _007B6318_007D);
			if (num != -1)
			{
				Effects.Array[num].ArgumentByte++;
				MaxPlayers++;
				return;
			}
		}
		int effectDurationDays = GetEffectDurationDays(_007B6318_007D, _007B6321_007D);
		Effects.Add(new GuildTemporaryEffect(_007B6318_007D, _007B6319_007D, _007B6320_007D, (effectDurationDays == -1) ? (-1.0) : ((double)effectDurationDays * 24.0 * 3600.0)));
		Version++;
	}

	public int GetEffectDurationDays(GuildTemporaryEffect.Type _007B6322_007D, EventActionsPipelineBase _007B6323_007D)
	{
		return _007B6322_007D switch
		{
			GuildTemporaryEffect.Type.ChangeFractionRistriction => (_007B6323_007D.EventCategoryAmount(EActionCaterory.LowChangeFractionCooldown) > 0f) ? 1 : FractionAPI.ChangeAgainRestrictionDays(_007B6374_007D, Fraction), 
			GuildTemporaryEffect.Type.DisputeVoteReceived => 7, 
			GuildTemporaryEffect.Type.HqOrLicenseInPort => (Fraction == FractionID.TradeUnion) ? 7 : (-1), 
			GuildTemporaryEffect.Type.BlockChangeWindowAgain => 3, 
			GuildTemporaryEffect.Type.VassalPortMarker => 5, 
			GuildTemporaryEffect.Type.DisputeProtection => 10, 
			GuildTemporaryEffect.Type.BlockPortCaptureAgain => 10, 
			_ => -1, 
		};
	}

	public bool HasEffect(GuildTemporaryEffect.Type _007B6324_007D)
	{
		for (int i = 0; i < Effects.Size; i++)
		{
			if (Effects.Array[i].Case == _007B6324_007D)
			{
				return true;
			}
		}
		return false;
	}

	public bool IsTrusted(string _007B6325_007D, bool _007B6326_007D = false)
	{
		for (int i = 0; i < TrustedGuilds.Size; i++)
		{
			if (TrustedGuilds.Array[i].Tag == _007B6325_007D && TrustedGuilds.Array[i].IsConfirmed)
			{
				return true;
			}
		}
		return false;
	}

	public void SetFraction(FractionID _007B6327_007D, EventActionsPipelineBase _007B6328_007D)
	{
		_007B6374_007D = Fraction;
		Fraction = _007B6327_007D;
		for (int i = 0; i < Effects.Size; i++)
		{
			if (Effects.Array[i].Case == GuildTemporaryEffect.Type.ChangeFractionRistriction || Effects.Array[i].Case == GuildTemporaryEffect.Type.DisputeVoteReceived || Effects.Array[i].Case == GuildTemporaryEffect.Type.HqOrLicenseInPort || Effects.Array[i].Case == GuildTemporaryEffect.Type.DisputeProtection)
			{
				Effects.RemoveAt(i);
				i--;
			}
		}
		TryMakeEffect(GuildTemporaryEffect.Type.ChangeFractionRistriction, "", 0, _007B6328_007D);
		if (_007B6327_007D.DisputeType() != FractionDisputeType.None)
		{
			TryMakeEffect(GuildTemporaryEffect.Type.DisputeProtection, "", 0, _007B6328_007D);
		}
	}

	public void ChangeTrustedGuilds(OnGuildRulesChanged _007B6329_007D)
	{
		OnGuildRulesChanged.Target target = _007B6329_007D.target;
		if ((uint)target <= 1u)
		{
			if (!TrustedGuilds.Contains((GuildRuleToOther _007B6388_007D) => _007B6388_007D.Tag == _007B6329_007D.Tag) && TrustedGuilds.Size < MaxTrustedGuilds)
			{
				TrustedGuilds.Add(new GuildRuleToOther(_007B6329_007D.Tag, 7200000f));
			}
		}
		else if (_007B6329_007D.target == OnGuildRulesChanged.Target.TrustedGuildRemove)
		{
			TrustedGuilds.RemoveAll((GuildRuleToOther _007B6389_007D) => _007B6389_007D.Tag == _007B6329_007D.Tag);
		}
		if (_007B6329_007D.target == OnGuildRulesChanged.Target.TrustedGuildAddConfirmed)
		{
			TrustedGuilds.First((GuildRuleToOther _007B6390_007D) => _007B6390_007D.Tag == _007B6329_007D.Tag).IsConfirmed = true;
		}
	}

	public GuildMember GetMember(uint _007B6330_007D)
	{
		for (int i = 0; i < _007B6362_007D.Size; i++)
		{
			if (_007B6362_007D.Array[i].SID == _007B6330_007D)
			{
				return _007B6362_007D.Array[i];
			}
		}
		return null;
	}

	public void SetConquerBadgesCountDirect(int _007B6331_007D)
	{
		_007B6372_007D.Value = _007B6331_007D;
		if (_007B6372_007D.Value <= 0)
		{
			return;
		}
		for (int i = 0; i < Effects.Size; i++)
		{
			if (Effects.Array[i].Case == GuildTemporaryEffect.Type.RemoveGuildNextSeason)
			{
				Effects.RemoveAt(i);
				break;
			}
		}
	}

	public void ResetCustomFields(bool _007B6332_007D, bool _007B6333_007D, bool _007B6334_007D)
	{
		if (_007B6332_007D)
		{
			foreach (GuildMember item in (IEnumerable<GuildMember>)_007B6362_007D)
			{
				item.Cached.Refill = null;
			}
		}
		if (_007B6333_007D)
		{
			foreach (GuildMember item2 in (IEnumerable<GuildMember>)_007B6362_007D)
			{
				item2.Cached.Withdraw = null;
			}
		}
		if (!_007B6334_007D)
		{
			return;
		}
		foreach (GuildMember item3 in (IEnumerable<GuildMember>)_007B6362_007D)
		{
			item3.Cached.ConquerorBadgesParticipation = 0f;
		}
	}

	public bool HasHqOrLicense(int _007B6335_007D)
	{
		return Effects.Contains((GuildTemporaryEffect _007B6391_007D) => _007B6391_007D.Case == GuildTemporaryEffect.Type.HqOrLicenseInPort && _007B6391_007D.ArgumentByte == _007B6335_007D);
	}

	public bool TryRemoveHqOrLicense(int _007B6336_007D)
	{
		for (int i = 0; i < Effects.Size; i++)
		{
			if (Effects.Array[i].Case == GuildTemporaryEffect.Type.HqOrLicenseInPort && Effects.Array[i].ArgumentByte == _007B6336_007D)
			{
				Effects.RemoveAt(i);
				return true;
			}
		}
		return false;
	}

	public void Update(ref FrameTime _007B6337_007D)
	{
		for (int i = 0; i < Effects.Size; i++)
		{
			GuildTemporaryEffect guildTemporaryEffect = Effects.Array[i];
			if (guildTemporaryEffect.RemainingTimeSec != -1.0)
			{
				guildTemporaryEffect.RemainingTimeSec -= _007B6337_007D.secElapsed;
				if (guildTemporaryEffect.RemainingTimeSec <= 0.0)
				{
					OnEffectFinished(guildTemporaryEffect);
					Effects.RemoveAt(i);
					i--;
				}
			}
		}
		for (int j = 0; j < _007B6363_007D.Size; j++)
		{
			_007B6363_007D.Array[j].TimeoutSec -= _007B6337_007D.secElapsed;
			if (_007B6363_007D.Array[j].TimeoutSec <= 0.0)
			{
				_007B6363_007D.RemoveAt(j);
				j--;
			}
		}
		UpdateRules(ref _007B6337_007D, TrustedGuilds);
	}

	protected virtual void OnEffectFinished(GuildTemporaryEffect _007B6338_007D)
	{
	}

	private static void UpdateRules(ref FrameTime _007B6339_007D, Tlist<GuildRuleToOther> _007B6340_007D)
	{
		if (_007B6340_007D == null)
		{
			_007B6340_007D = new Tlist<GuildRuleToOther>();
		}
		for (int i = 0; i < _007B6340_007D.Size; i++)
		{
			_007B6339_007D.EvaluteTimerMs(ref _007B6340_007D.Array[i].DelayToWorkMs);
		}
	}

	private void _007B6341_007D(WriterExtern _007B6342_007D)
	{
		_007B6342_007D.WriteStruct<int>(ref _007B6362_007D.Size);
		for (int i = 0; i < _007B6362_007D.Size; i++)
		{
			_007B6342_007D.Write<GuildMember>(_007B6362_007D.Array[i]);
		}
		_007B6342_007D.Write(_007B6364_007D, (Encoding)null);
		_007B6342_007D.Write(_007B6365_007D, (Encoding)null);
		_007B6342_007D.Write(_007B6366_007D, (Encoding)null);
		_007B6342_007D.Write(_007B6367_007D, (Encoding)null);
		_007B6342_007D.WriteTlistImps(_007B6363_007D);
		_007B6342_007D.WriteStruct<int>(_007B6371_007D.Value);
		_007B6342_007D.WriteStruct<int>(_007B6372_007D.Value);
		_007B6342_007D.WriteStruct<int>(ref MaxPlayers);
		_007B6342_007D.WriteStruct<int>(_007B6373_007D.Value);
		_007B6342_007D.WriteByte((byte)Fraction);
		_007B6342_007D.WriteTlistImps(TrustedGuilds);
		_007B6342_007D.WriteTlistImps(Effects);
		_007B6342_007D.WriteStruct<ushort>(Version);
		_007B6342_007D.Write(_007B6368_007D, (Encoding)null);
		_007B6342_007D.WriteStruct<int>(_007B6369_007D);
		_007B6342_007D.WriteTlistStruct<GuildActionLogRecord>(_007B6361_007D);
		_007B6342_007D.Write(ActiveForNewPlayers);
		_007B6342_007D.WriteStruct<uint>(GuildID);
		_007B6342_007D.Write<PbsAttackWindow>(ref PbsWindow);
		_007B6342_007D.WriteByte((byte)PbCaptureMode);
		_007B6342_007D.WriteByte(PotentialTitleId);
		_007B6342_007D.Write<GSI>(ReceivedTitles);
		_007B6342_007D.WriteByte(CachedSupplyMissionCount);
	}

	private void _007B6343_007D(WriterExtern _007B6344_007D)
	{
		int num = default(int);
		_007B6344_007D.ReadStruct<int>(ref num);
		_007B6362_007D = new Tlist<GuildMember>(num * 2);
		GuildMember item = default(GuildMember);
		for (int i = 0; i < num; i++)
		{
			_007B6344_007D.ReadIMPS<GuildMember>(ref item);
			_007B6362_007D.Add(in item);
		}
		_007B6344_007D.ReadString(ref _007B6364_007D, (Encoding)null);
		_007B6344_007D.ReadString(ref _007B6365_007D, (Encoding)null);
		_007B6344_007D.ReadString(ref _007B6366_007D, (Encoding)null);
		_007B6344_007D.ReadString(ref _007B6367_007D, (Encoding)null);
		_007B6344_007D.ReadTlistImps(out _007B6363_007D);
		int _007B11342_007D = default(int);
		_007B6344_007D.ReadStruct<int>(ref _007B11342_007D);
		_007B6371_007D = new RTI(_007B11342_007D);
		_007B6344_007D.ReadStruct<int>(ref _007B11342_007D);
		_007B6372_007D = new RTI(_007B11342_007D);
		_007B6344_007D.ReadStruct<int>(ref MaxPlayers);
		int _007B11342_007D2 = default(int);
		_007B6344_007D.ReadStruct<int>(ref _007B11342_007D2);
		_007B6373_007D = new RTI(_007B11342_007D2);
		Fraction = (FractionID)_007B6344_007D.ReadByte();
		_007B6344_007D.ReadTlistImps(out TrustedGuilds);
		_007B6344_007D.ReadTlistImps(out Effects);
		_007B6344_007D.ReadStruct<ushort>(ref Version);
		_007B6344_007D.ReadString(ref _007B6368_007D, (Encoding)null);
		_007B6344_007D.ReadStruct<int>(ref _007B6369_007D);
		_007B6344_007D.ReadTlistStruct<GuildActionLogRecord>(out _007B6361_007D);
		_007B6344_007D.ReadBoolean(ref ActiveForNewPlayers);
		_007B6344_007D.ReadStruct<uint>(ref GuildID);
		_007B6344_007D.ReadIMPS_struct<PbsAttackWindow>(ref PbsWindow);
		PbCaptureMode = (PbCaptureMode)_007B6344_007D.ReadByte();
		PotentialTitleId = _007B6344_007D.ReadByte();
		_007B6344_007D.ReadIMPS<GSI>(ref ReceivedTitles);
		CachedSupplyMissionCount = _007B6344_007D.ReadByte();
	}

	public virtual void PreInit()
	{
		PbCaptureMode = PbCaptureMode.Capture;
		Effects = new Tlist<GuildTemporaryEffect>();
		PbsWindow = new PbsAttackWindow(20);
	}

	public virtual void PostInit()
	{
		if (_007B6363_007D == null)
		{
			_007B6363_007D = new Tlist<GuildInvite>();
		}
		if (_007B6361_007D == null)
		{
			_007B6361_007D = new Tlist<GuildActionLogRecord>();
		}
		if (TrustedGuilds == null)
		{
			TrustedGuilds = new Tlist<GuildRuleToOther>();
		}
		for (int i = 0; i < Effects.Size; i++)
		{
			bool flag;
			switch (Effects[i].Case)
			{
			case GuildTemporaryEffect.Type.removed6:
			case GuildTemporaryEffect.Type.removed:
			case GuildTemporaryEffect.Type.removed5:
			case GuildTemporaryEffect.Type.removed2:
			case GuildTemporaryEffect.Type.removed3:
			case GuildTemporaryEffect.Type.removed4:
				flag = true;
				break;
			default:
				flag = false;
				break;
			}
			if (flag)
			{
				Effects.RemoveAt(i);
				i--;
			}
		}
	}

	public virtual void Boxing(TKWriterExtern _007B6345_007D)
	{
		((TKWriterExtern)(ref _007B6345_007D)).WriteDynamicTKArray<GuildMember>((short)1, _007B6362_007D.Array, _007B6362_007D.Size);
		((TKWriterExtern)(ref _007B6345_007D)).Write((short)2, _007B6364_007D);
		((TKWriterExtern)(ref _007B6345_007D)).Write((short)3, _007B6365_007D);
		((TKWriterExtern)(ref _007B6345_007D)).Write((short)4, _007B6366_007D);
		((TKWriterExtern)(ref _007B6345_007D)).WriteContent((short)5, (Action<WriterExtern>)delegate(WriterExtern _007B6350_007D)
		{
			_007B6350_007D.WriteBytes32bitSize(_007B6370_007D);
		});
		((TKWriterExtern)(ref _007B6345_007D)).WriteContent((short)45, (Action<WriterExtern>)delegate(WriterExtern _007B6352_007D)
		{
			_007B6352_007D.WriteTlistImps(_007B6363_007D);
		});
		int value = _007B6371_007D.Value;
		((TKWriterExtern)(ref _007B6345_007D)).WriteStruct<int>((short)7, ref value);
		((TKWriterExtern)(ref _007B6345_007D)).Write((short)12, _007B6367_007D);
		value = _007B6372_007D.Value;
		((TKWriterExtern)(ref _007B6345_007D)).WriteStruct<int>((short)28, ref value);
		((TKWriterExtern)(ref _007B6345_007D)).WriteStruct<int>((short)22, ref MaxPlayers);
		value = _007B6373_007D.Value;
		((TKWriterExtern)(ref _007B6345_007D)).WriteStruct<int>((short)26, ref value);
		((TKWriterExtern)(ref _007B6345_007D)).WriteByte((short)30, (byte)Fraction);
		((TKWriterExtern)(ref _007B6345_007D)).WriteContent((short)36, (Action<WriterExtern>)delegate(WriterExtern _007B6354_007D)
		{
			_007B6354_007D.WriteTlistImps(Effects);
		});
		((TKWriterExtern)(ref _007B6345_007D)).WriteStruct<ushort>((short)41, ref Version);
		((TKWriterExtern)(ref _007B6345_007D)).Write((short)42, _007B6368_007D);
		((TKWriterExtern)(ref _007B6345_007D)).WriteStruct<int>((short)43, ref _007B6369_007D);
		((TKWriterExtern)(ref _007B6345_007D)).WriteContent((short)44, (Action<WriterExtern>)delegate(WriterExtern _007B6356_007D)
		{
			_007B6356_007D.WriteTlistStruct<GuildActionLogRecord>(_007B6361_007D);
		});
		((TKWriterExtern)(ref _007B6345_007D)).Write((short)46, ActiveForNewPlayers);
		((TKWriterExtern)(ref _007B6345_007D)).WriteContent((short)48, (Action<WriterExtern>)delegate(WriterExtern _007B6358_007D)
		{
			_007B6358_007D.WriteTlistImps(TrustedGuilds);
		});
		((TKWriterExtern)(ref _007B6345_007D)).WriteContent((short)49, (Action<WriterExtern>)delegate(WriterExtern _007B6360_007D)
		{
			_007B6360_007D.Write<PbsAttackWindow>(ref PbsWindow);
		});
		((TKWriterExtern)(ref _007B6345_007D)).WriteByte((short)50, (byte)PbCaptureMode);
		((TKWriterExtern)(ref _007B6345_007D)).WriteIMP<GSI>((short)52, ReceivedTitles);
		((TKWriterExtern)(ref _007B6345_007D)).WriteByte((short)54, PotentialTitleId);
	}

	public virtual void Load(short _007B6346_007D, WriterExtern _007B6347_007D, out bool _007B6348_007D)
	{
		_007B6348_007D = true;
		int _007B11342_007D2 = default(int);
		switch (_007B6346_007D)
		{
		case 1:
		{
			GuildMember[] collection = default(GuildMember[]);
			_007B6347_007D.ReadDynamicTKArray<GuildMember>(ref collection);
			_007B6362_007D = new Tlist<GuildMember>(collection);
			MaxPlayers = Math.Max(MaxPlayers, Math.Min(_007B6362_007D.Size, 45));
			break;
		}
		case 2:
			_007B6347_007D.ReadString(ref _007B6364_007D, (Encoding)null);
			break;
		case 3:
			_007B6347_007D.ReadString(ref _007B6365_007D, (Encoding)null);
			break;
		case 4:
			_007B6347_007D.ReadString(ref _007B6366_007D, (Encoding)null);
			break;
		case 5:
			_007B6347_007D.ReadBytes32bitSize(ref _007B6370_007D);
			break;
		case 45:
			_007B6347_007D.ReadTlistImps(out _007B6363_007D);
			break;
		case 7:
			_007B6347_007D.ReadStruct<int>(ref _007B11342_007D2);
			_007B6371_007D = new RTI(_007B11342_007D2);
			break;
		case 12:
			_007B6347_007D.ReadString(ref _007B6367_007D, (Encoding)null);
			break;
		case 28:
			_007B6347_007D.ReadStruct<int>(ref _007B11342_007D2);
			_007B6372_007D = new RTI(_007B11342_007D2);
			break;
		case 22:
			_007B6347_007D.ReadStruct<int>(ref MaxPlayers);
			break;
		case 26:
		{
			int _007B11342_007D = default(int);
			_007B6347_007D.ReadStruct<int>(ref _007B11342_007D);
			_007B6373_007D = new RTI(_007B11342_007D);
			break;
		}
		case 30:
			Fraction = (FractionID)_007B6347_007D.ReadByte();
			break;
		case 36:
			_007B6347_007D.ReadTlistImps(out Effects);
			break;
		case 41:
			_007B6347_007D.ReadStruct<ushort>(ref Version);
			break;
		case 42:
			_007B6347_007D.ReadString(ref _007B6368_007D, (Encoding)null);
			break;
		case 43:
			_007B6347_007D.ReadStruct<int>(ref _007B6369_007D);
			break;
		case 44:
			_007B6347_007D.ReadTlistStruct<GuildActionLogRecord>(out _007B6361_007D);
			break;
		case 46:
			_007B6347_007D.ReadBoolean(ref ActiveForNewPlayers);
			break;
		case 48:
			_007B6347_007D.ReadTlistImps(out TrustedGuilds);
			TrustedGuilds.Size = Math.Min(MaxTrustedGuilds, TrustedGuilds.Size);
			break;
		case 49:
			_007B6347_007D.ReadIMPS_struct<PbsAttackWindow>(ref PbsWindow);
			break;
		case 50:
			PbCaptureMode = (PbCaptureMode)_007B6347_007D.ReadByte();
			break;
		case 52:
			_007B6347_007D.ReadIMPS<GSI>(ref ReceivedTitles);
			break;
		case 53:
		{
			_007B6347_007D.ReadTlist(out Tlist<int> _007B326_007D);
			PotentialTitleId = (byte)_007B326_007D.FirstOrDefault();
			break;
		}
		case 54:
			PotentialTitleId = _007B6347_007D.ReadByte();
			break;
		default:
			_007B6348_007D = false;
			break;
		}
	}

	public override string ToString()
	{
		return $"[{_007B6364_007D}], {GuildID}";
	}

	[CompilerGenerated]
	private void _007B6349_007D(WriterExtern _007B6350_007D)
	{
		_007B6350_007D.WriteBytes32bitSize(_007B6370_007D);
	}

	[CompilerGenerated]
	private void _007B6351_007D(WriterExtern _007B6352_007D)
	{
		_007B6352_007D.WriteTlistImps(_007B6363_007D);
	}

	[CompilerGenerated]
	private void _007B6353_007D(WriterExtern _007B6354_007D)
	{
		_007B6354_007D.WriteTlistImps(Effects);
	}

	[CompilerGenerated]
	private void _007B6355_007D(WriterExtern _007B6356_007D)
	{
		_007B6356_007D.WriteTlistStruct<GuildActionLogRecord>(_007B6361_007D);
	}

	[CompilerGenerated]
	private void _007B6357_007D(WriterExtern _007B6358_007D)
	{
		_007B6358_007D.WriteTlistImps(TrustedGuilds);
	}

	[CompilerGenerated]
	private void _007B6359_007D(WriterExtern _007B6360_007D)
	{
		_007B6360_007D.Write<PbsAttackWindow>(ref PbsWindow);
	}
}
