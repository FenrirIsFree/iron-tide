using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace Common.Game;

public static class VKPlayCommonApi
{
	public static string GenerateSignature(Dictionary<string, string> _007B5268_007D)
	{
		string text = string.Join("", _007B5268_007D.Select<KeyValuePair<string, string>, string>((KeyValuePair<string, string> _007B5272_007D) => _007B5272_007D.Key + "=" + _007B5272_007D.Value).Order());
		string s = text + CommonGameConfig.CurrentSettings.VKPlaySecret;
		byte[] inArray = MD5.HashData(Encoding.UTF8.GetBytes(s));
		return Convert.ToHexString(inArray).ToLower();
	}

	public static bool CheckSignature(NameValueCollection _007B5269_007D)
	{
		string text = string.Join("", (from _007B5274_007D in _007B5269_007D.AllKeys
			where _007B5274_007D != "sign"
			select _007B5274_007D + "=" + _007B5269_007D[_007B5274_007D]).Order());
		string s = text + CommonGameConfig.CurrentSettings.VKPlaySecret;
		byte[] inArray = MD5.HashData(Encoding.UTF8.GetBytes(s));
		return Convert.ToHexString(inArray).ToLower() == _007B5269_007D["sign"];
	}

	public static string GenerateSignedUrl(string _007B5270_007D, Dictionary<string, string> _007B5271_007D)
	{
		string value = GenerateSignature(_007B5271_007D);
		_007B5271_007D.Add("sign", value);
		NameValueCollection nameValueCollection = HttpUtility.ParseQueryString(string.Empty);
		foreach (KeyValuePair<string, string> item in _007B5271_007D)
		{
			item.Deconstruct(out var key, out var value2);
			string name = key;
			string value3 = value2;
			nameValueCollection[name] = value3;
		}
		return new UriBuilder(_007B5270_007D)
		{
			Query = nameValueCollection.ToString()
		}.ToString();
	}
}
