using System;
using Common.Resources;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Helpers;

namespace Common.Game;

public class DeferredShooting<T> where T : struct, IShootingInfo
{
	public const int MsBetweenTargets = 110;

	private static int[] timings_linear = new int[1] { 110 };

	private Action<Ship, T, bool> nextShotHandler;

	private bool isActive;

	private float nextShotTimer;

	private int nextTimingIndex;

	private int nextWeaponIndex;

	private float speedMultipliter;

	private float additionalTimeout;

	private float previewTimeout;

	private Ship ship;

	public Tlist<T> Queued = new Tlist<T>();

	public int CurrentShootingQueueIndex => nextWeaponIndex;

	public bool ShotIsProcessing => isActive;

	private static int[] mul(int[] _007B4635_007D, float _007B4636_007D)
	{
		for (int i = 0; i < _007B4635_007D.Length; i++)
		{
			_007B4635_007D[i] = Math.Max(17, (int)((float)_007B4635_007D[i] * _007B4636_007D));
		}
		return _007B4635_007D;
	}

	public void BeginGunEventCommon(Ship _007B4637_007D, int _007B4638_007D, CannonsAttackMode? _007B4639_007D, Action<Ship, T, bool> _007B4640_007D)
	{
		ship = _007B4637_007D;
		nextShotHandler = _007B4640_007D;
		if (_007B4639_007D.HasValue)
		{
			speedMultipliter = Math.Max(1f, 1f + (float)(_007B4637_007D.UsedShip.StaticInfo.Decks.Size - 1) * 0.14f);
			if (_007B4639_007D == CannonsAttackMode.AllRandomized)
			{
				previewTimeout = 100f;
				additionalTimeout = 2200f;
				for (int i = 0; i < Queued.Size; i++)
				{
					additionalTimeout += (float)timings_linear[i % timings_linear.Length] / speedMultipliter;
				}
				speedMultipliter *= 4f;
			}
			else if (_007B4639_007D == CannonsAttackMode.SingleCannon)
			{
				additionalTimeout = _007B4637_007D.UsedShip.StaticInfo.SingleModeShotInterval;
			}
			else
			{
				additionalTimeout = 750f * Geometry.Saturate(((float)_007B4637_007D.UsedShip.StaticInfo.LeftSidePorts.Length - 30f) / 35f);
			}
		}
		else
		{
			speedMultipliter = 0.66f;
			additionalTimeout = 0f;
			previewTimeout = 0f;
		}
		nextTimingIndex = _007B4638_007D % timings_linear.Length;
		nextWeaponIndex = -1;
		isActive = true;
		if (previewTimeout == 0f)
		{
			NextShot();
		}
		if (nextShotTimer == 0f)
		{
			nextShotTimer = timings_linear[nextTimingIndex];
		}
	}

	public static float TotalCannonShotDurationMs(ShipStaticInfo _007B4641_007D)
	{
		float num = Math.Max(1f, 1f + (float)(_007B4641_007D.Decks.Size - 1) * 0.14f);
		int num2 = _007B4641_007D.LeftSidePorts.Length;
		float num3 = 0f;
		for (int i = 0; i < num2; i++)
		{
			num3 += (float)timings_linear[i % timings_linear.Length] / num;
		}
		return num3 + 750f * Geometry.Saturate(((float)_007B4641_007D.LeftSidePorts.Length - 30f) / 35f);
	}

	public void Update(ref FrameTime _007B4642_007D)
	{
		if (!isActive)
		{
			return;
		}
		if (previewTimeout > 0f)
		{
			_007B4642_007D.EvaluteTimerMs(ref previewTimeout);
			return;
		}
		if (nextWeaponIndex + 1 == Queued.Size && additionalTimeout > 0f)
		{
			_007B4642_007D.EvaluteTimerMs(ref additionalTimeout);
			return;
		}
		nextShotTimer -= _007B4642_007D.msElapsed * speedMultipliter;
		while (nextShotTimer < 0f)
		{
			nextShotTimer += timings_linear[nextTimingIndex];
			nextTimingIndex++;
			if (nextTimingIndex == timings_linear.Length)
			{
				nextTimingIndex = 0;
			}
			NextShot();
		}
	}

	private void NextShot()
	{
		nextWeaponIndex++;
		if (nextWeaponIndex < Queued.Size)
		{
			T arg = Queued.Array[nextWeaponIndex];
			bool flag = nextWeaponIndex % arg.DisableInterruptParts != 0;
			nextShotHandler?.Invoke(ship, arg, !flag);
			if (flag)
			{
				NextShot();
			}
		}
		else
		{
			Queued.Clear();
			nextWeaponIndex = -1;
			isActive = false;
			nextShotTimer = timings_linear[nextTimingIndex];
		}
	}

	public void Reset()
	{
		nextTimingIndex = 0;
		nextShotTimer = timings_linear[0];
		nextWeaponIndex = -1;
		Queued.Clear();
		isActive = false;
		speedMultipliter = 1f;
		additionalTimeout = 0f;
		previewTimeout = 0f;
		ship = null;
	}

	public void ChangeRemainBuckets(Func<T, T> _007B4643_007D)
	{
		for (int i = nextWeaponIndex + 1; i < Queued.Size; i++)
		{
			Queued.Array[i] = _007B4643_007D(Queued.Array[i]);
		}
	}
}
