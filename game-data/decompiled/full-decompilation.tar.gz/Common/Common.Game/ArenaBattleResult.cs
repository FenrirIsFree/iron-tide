namespace Common.Game;

public enum ArenaBattleResult
{
	YourComandWin,
	YourComandFail,
	Tie
}
