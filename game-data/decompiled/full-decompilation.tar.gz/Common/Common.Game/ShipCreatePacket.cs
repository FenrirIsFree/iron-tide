using Common.Resources;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Game;

public abstract class ShipCreatePacket : IMPSerializable
{
	public ShipPositionInfo PositionInfo;

	public int uID;

	public float NowSpeed;

	public float axisInertion;

	public ShipFirstHp NowHP;

	public float[] NowSailHP;

	public UnitCollection Crew;

	public GSI ItemsInHoldExemplary;

	public DynamicEffectHelper DynamicEffects;

	public GuildShortInfo GuildInfo;

	public Tlist<PublicDesignInfo> PublicDesigns;

	public ShipCreatePacket(Ship _007B5074_007D, in GuildShortInfo _007B5075_007D, Tlist<PublicDesignInfo> _007B5076_007D)
	{
		DynamicEffects = _007B5074_007D.UsedShip.DynamicBonus;
		PositionInfo = _007B5074_007D.GetShipPositionInfo;
		uID = _007B5074_007D.uID;
		NowSpeed = _007B5074_007D.NowSpeed;
		NowHP = _007B5074_007D.UsedShip.firstHP;
		NowSailHP = _007B5074_007D.UsedShip.HitboxSailsStrength;
		Crew = _007B5074_007D.UsedShip.Crew;
		GuildInfo = _007B5075_007D;
		axisInertion = _007B5074_007D.physicsBody.axisInertion;
		PublicDesigns = _007B5076_007D;
	}

	public ShipCreatePacket()
	{
	}

	public virtual void Boxing(WriterExtern _007B5077_007D)
	{
		_007B5077_007D.Write<ShipPositionInfo>(ref PositionInfo);
		_007B5077_007D.WriteStruct<int>(ref uID);
		_007B5077_007D.WriteStruct<float>(ref NowSpeed);
		_007B5077_007D.WriteNoNull<ShipFirstHp>(NowHP);
		_007B5077_007D.WriteByte((byte)NowSailHP.Length);
		for (int i = 0; i < NowSailHP.Length; i++)
		{
			_007B5077_007D.WriteStruct<float>(ref NowSailHP[i]);
		}
		_007B5077_007D.Write<UnitCollection>(Crew);
		_007B5077_007D.WriteNoNull<GSI>(ItemsInHoldExemplary);
		_007B5077_007D.Write<GuildShortInfo>(ref GuildInfo);
		_007B5077_007D.WriteStruct<float>(axisInertion);
		_007B5077_007D.WriteNoNull<DynamicEffectHelper>(DynamicEffects);
		_007B5077_007D.WriteTlistImps(PublicDesigns);
	}

	public virtual void Unboxing(WriterExtern _007B5078_007D)
	{
		_007B5078_007D.ReadIMPS_struct<ShipPositionInfo>(ref PositionInfo);
		_007B5078_007D.ReadStruct<int>(ref uID);
		_007B5078_007D.ReadStruct<float>(ref NowSpeed);
		_007B5078_007D.ReadIMPSNoNull<ShipFirstHp>(ref NowHP);
		byte b = _007B5078_007D.ReadByte();
		NowSailHP = new float[b];
		for (int i = 0; i < b; i++)
		{
			_007B5078_007D.ReadStruct<float>(ref NowSailHP[i]);
		}
		_007B5078_007D.ReadIMPS<UnitCollection>(ref Crew);
		_007B5078_007D.ReadIMPSNoNull<GSI>(ref ItemsInHoldExemplary);
		_007B5078_007D.ReadIMPS_struct<GuildShortInfo>(ref GuildInfo);
		_007B5078_007D.ReadStruct<float>(ref axisInertion);
		_007B5078_007D.ReadIMPSNoNull<DynamicEffectHelper>(ref DynamicEffects);
		_007B5078_007D.ReadTlistImps(out PublicDesigns);
	}
}
