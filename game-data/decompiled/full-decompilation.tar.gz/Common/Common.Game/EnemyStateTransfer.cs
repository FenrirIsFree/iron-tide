using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;

namespace Common.Game;

public struct EnemyStateTransfer : IMPSerializable
{
	public CompressedShipPositionInfo Position;

	public int ShipUID;

	public EnemyIcon Icon;

	public int ByQuestID;

	public EnemyStateTransfer(Ship _007B5996_007D, int _007B5997_007D)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		Position = new CompressedShipPositionInfo(_007B5996_007D.PositionClampedToMap, _007B5996_007D.Rotation);
		ShipUID = _007B5996_007D.uID;
		Icon = ((_007B5996_007D is Npc) ? EnemyIcon.QuestNpc : EnemyIcon.ShipPlayer);
		ByQuestID = _007B5997_007D;
	}

	public EnemyStateTransfer(Vector2 _007B5998_007D, Vector2 _007B5999_007D, EnemyIcon _007B6000_007D = EnemyIcon.QuestPoint)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		Position = new CompressedShipPositionInfo(_007B5998_007D, 0f);
		ShipUID = 0;
		Icon = _007B6000_007D;
		ByQuestID = 0;
	}

	private void _007B6001_007D(WriterExtern _007B6002_007D)
	{
		_007B6002_007D.Write<CompressedShipPositionInfo>(ref Position);
		_007B6002_007D.WriteStruct<int>(ShipUID);
		_007B6002_007D.WriteByte((byte)Icon);
		_007B6002_007D.WriteStruct<int>(ref ByQuestID);
	}

	private void _007B6003_007D(WriterExtern _007B6004_007D)
	{
		_007B6004_007D.ReadIMPS_struct<CompressedShipPositionInfo>(ref Position);
		_007B6004_007D.ReadStruct<int>(ref ShipUID);
		Icon = (EnemyIcon)_007B6004_007D.ReadByte();
		_007B6004_007D.ReadStruct<int>(ref ByQuestID);
	}
}
