using TheraEngine.Collections;

namespace Common.Game;

internal static class EmpireChestRewards
{
	public static readonly ChestRewardInfo[] Elements;

	static EmpireChestRewards()
	{
		(float, ChestRewardInfo[])[] array = new(float, ChestRewardInfo[])[8];
		ChestRewardInfo[] array2 = new ChestRewardInfo[1];
		ChestRewardInfo chestRewardInfo = new ChestRewardInfo(3, ShopChestApplyHelper.RandomShip(72, 73, 74, 75), _007B8261_007D: true, Local.chest_empire_EarlyAccessShips)
		{
			CheckShipID = new Tlist<int> { 72, 73, 74, 75 },
			AssuranceOpen = (8, 100)
		};
		array2[0] = chestRewardInfo;
		array[0] = (0.5f, array2);
		ChestRewardInfo[] array3 = new ChestRewardInfo[1];
		chestRewardInfo = new ChestRewardInfo(3, ShopChestApplyHelper.RandomDesign(false, 454, 455, 449, 448, 428, 425, 409, 451, 432, 450, 408, 427, 407, 426, 397), _007B8261_007D: false, Local.chest_empire_UniqueHullPaint)
		{
			OverrideChatMessage = new LocalizedString("rare_ship_design"),
			AssuranceOpen = (3, 75)
		};
		array3[0] = chestRewardInfo;
		array[1] = (1f, array3);
		ChestRewardInfo[] array4 = new ChestRewardInfo[1];
		chestRewardInfo = new ChestRewardInfo(3, ShopChestApplyHelper.RandomDesign(true, 459, 460, 406, 219, 453, 431, 399, 398, 400, 411), _007B8261_007D: false, Local.chest_empire_UniqueSailDesign)
		{
			OverrideChatMessage = new LocalizedString("rare_sail_design"),
			AssuranceOpen = (4, 50),
			FirstOpenChestCategory = true
		};
		array4[0] = chestRewardInfo;
		array[2] = (1.5f, array4);
		ChestRewardInfo[] array5 = new ChestRewardInfo[1];
		chestRewardInfo = new ChestRewardInfo(3, ShopChestApplyHelper.RandomDesign(true, 456, 457, 458, 405, 419, 452, 403, 430, 401, 410), _007B8261_007D: false, Local.chest_empire_UniqueFlag)
		{
			OverrideChatMessage = new LocalizedString("rare_flag_design"),
			FirstOpenChestCategory = true
		};
		array5[0] = chestRewardInfo;
		array[3] = (2f, array5);
		array[4] = (20f, new ChestRewardInfo[8]
		{
			new ChestRewardInfo(2, ShopChestApplyHelper.Gold(150000), _007B8261_007D: false, Local.chest_empire_Gold(150)),
			new ChestRewardInfo(2, ShopChestApplyHelper.Resource(37, 200), _007B8261_007D: false, Local.war_marks_pack)
			{
				FirstOpenChestCategory = true
			},
			new ChestRewardInfo(2, ShopChestApplyHelper.Resource(15, 30), _007B8261_007D: false, Local.res_15_name)
			{
				FirstOpenChestCategory = true
			},
			new ChestRewardInfo(2, ShopChestApplyHelper.Resource(38, 20), _007B8261_007D: false, Local.res_38_name)
			{
				FirstOpenChestCategory = true
			},
			new ChestRewardInfo(2, ShopChestApplyHelper.Resource(67, 8), _007B8261_007D: false, Local.res_44_name)
			{
				FirstOpenChestCategory = true
			},
			new ChestRewardInfo(2, ShopChestApplyHelper.Ammo(7, 5000), _007B8261_007D: false, Local.chest_reward_SaxonAmmo)
			{
				FirstOpenChestCategory = true
			},
			new ChestRewardInfo(2, ShopChestApplyHelper.Ammo(5, 3500), _007B8261_007D: false, Local.chest_reward_HeavyAmmo)
			{
				FirstOpenChestCategory = true
			},
			new ChestRewardInfo(2, ShopChestApplyHelper.Resource(33, 1), _007B8261_007D: false, Local.res_33_name)
		});
		array[5] = (10f, new ChestRewardInfo[2]
		{
			new ChestRewardInfo(1, ShopChestApplyHelper.PowderKeg(5, 3), _007B8261_007D: false, Local.ammo),
			new ChestRewardInfo(1, ShopChestApplyHelper.Ammo(16, 50), _007B8261_007D: false, Local.ammo)
		});
		array[6] = (25f, new ChestRewardInfo[5]
		{
			new ChestRewardInfo(1, ShopChestApplyHelper.TempGain(16, 5), _007B8261_007D: false, Local.chest_reward_Consumable),
			new ChestRewardInfo(1, ShopChestApplyHelper.TempGain(3, 35), _007B8261_007D: false, Local.chest_reward_Consumable),
			new ChestRewardInfo(1, ShopChestApplyHelper.TempGain(14, 8), _007B8261_007D: false, Local.chest_reward_Consumable),
			new ChestRewardInfo(1, ShopChestApplyHelper.TempGain(2, 40), _007B8261_007D: false, Local.chest_reward_Consumable),
			new ChestRewardInfo(1, ShopChestApplyHelper.TempGain(12, 120), _007B8261_007D: false, Local.chest_reward_Consumable)
		});
		array[7] = (40f, new ChestRewardInfo[7]
		{
			new ChestRewardInfo(1, ShopChestApplyHelper.Resource(39, 250), _007B8261_007D: false, Local.chest_empire_CraftResources),
			new ChestRewardInfo(1, ShopChestApplyHelper.Resource(17, 250), _007B8261_007D: false, Local.chest_empire_CraftResources),
			new ChestRewardInfo(1, ShopChestApplyHelper.Resource(27, 70), _007B8261_007D: false, Local.chest_empire_CraftResources),
			new ChestRewardInfo(1, ShopChestApplyHelper.Resource(16, 50), _007B8261_007D: false, Local.chest_empire_CraftResources),
			new ChestRewardInfo(1, ShopChestApplyHelper.Resource(29, 45), _007B8261_007D: false, Local.chest_empire_CraftResources),
			new ChestRewardInfo(1, ShopChestApplyHelper.Resource(4, 2500), _007B8261_007D: false, Local.chest_empire_CraftResources),
			new ChestRewardInfo(1, ShopChestApplyHelper.Resource(9, 1000), _007B8261_007D: false, Local.chest_empire_CraftResources)
		});
		Elements = ShopChestApplyHelper.ComposeByProbabilityGroup(array);
	}
}
