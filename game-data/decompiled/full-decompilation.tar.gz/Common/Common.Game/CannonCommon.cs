using System;
using Common.Resources;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using TheraEngine.Components;
using TheraEngine.Helpers;

namespace Common.Game;

public class CannonCommon
{
	private const float multiplierRandom = 0.6f;

	private static readonly Vector2[] randomDirections = directionArray();

	public readonly CannonLocationInfo Location;

	public readonly CannonGameInfo GameInfo;

	internal float overheat;

	internal float reloadTimer;

	private float _007B4594_007D;

	internal int multiCannonRemainShots;

	private int _007B4595_007D;

	public float RollbackEffect;

	public float RollbackEffectMax;

	public float ClientHitEffectMs;

	public Vector2 CurrentRandomValue => randomDirections[_007B4595_007D];

	public bool IsReloaded => reloadTimer == 0f && overheat >= 0f;

	public float ReloadFactor => 1f - reloadTimer / Math.Max(_007B4594_007D, GameInfo.ReloadTime);

	public float OverheatValue => overheat;

	private static Vector2[] directionArray()
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		int num = 516515;
		Vector2[] array = (Vector2[])(object)new Vector2[128];
		for (int i = 0; i < 128; i++)
		{
			array[i] = new Vector2(MathHelper.Lerp(-0.1f, 0.1f, HashHelper.greater(num + i)), MathHelper.Lerp(-0.125f, 0.125f, HashHelper.greater(num + i)));
		}
		return array;
	}

	internal bool DirectionTest(ref Vector2 _007B4564_007D, float _007B4565_007D, bool _007B4566_007D, float _007B4567_007D)
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		val.X = Location.CurrentDirection.X;
		val.Y = Location.CurrentDirection.Y + _007B4565_007D + (float)Math.PI;
		return Geometry.AxisDistance(val.Y, _007B4564_007D.Y) < _007B4567_007D + (_007B4566_007D ? 0.1f : 0f);
	}

	internal bool DirectionTestSide(ref Vector2 _007B4568_007D, float _007B4569_007D)
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		val.X = Location.CurrentDirection.X;
		val.Y = Location.CurrentDirection.Y + _007B4569_007D + (float)Math.PI;
		return Geometry.AxisDistance(val.Y, _007B4568_007D.Y) < (float)Math.PI / 4f;
	}

	internal void BeginReload(CannonCollection _007B4570_007D, float _007B4571_007D)
	{
		_007B4570_007D.isAllCannonsReloaded = false;
		float num = GameInfo.ReloadTime / (1f + _007B4571_007D);
		reloadTimer = Math.Min(reloadTimer + num, Math.Max(reloadTimer, GameInfo.ReloadTime));
	}

	public void BeginLoad(CannonCollection _007B4572_007D, CannonBallInfo _007B4573_007D, float _007B4574_007D = 1f)
	{
		_007B4572_007D.isAllCannonsReloaded = false;
		multiCannonRemainShots++;
		if (GameInfo.Feature == CannonFeature.Firegun)
		{
			reloadTimer = 300f;
			_007B4594_007D = reloadTimer;
		}
		else if (multiCannonRemainShots == GameInfo.ShotsCount)
		{
			multiCannonRemainShots = 0;
			reloadTimer = GameInfo.ReloadTime * (_007B4573_007D?.ReloadFactor ?? 1f) * _007B4574_007D;
			_007B4594_007D = reloadTimer;
		}
		else
		{
			reloadTimer = 1200f;
			_007B4594_007D = reloadTimer;
		}
		_007B4595_007D++;
		if (_007B4595_007D == randomDirections.Length)
		{
			_007B4595_007D = 0;
		}
		if (GameInfo.Feature == CannonFeature.Firegun)
		{
			overheat += 0.08f;
		}
	}

	public void StartRollbackEffect()
	{
		RollbackEffectMax = Math.Max(4000f, reloadTimer / 2f);
		RollbackEffect = RollbackEffectMax;
	}

	public Vector3 GetPosition(Transform3D _007B4575_007D)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		_007B4575_007D.CreateWorldMatrix(out var _007B14801_007D);
		Vector3 result = default(Vector3);
		Vector3.Transform(ref Location.PositionI, ref _007B14801_007D, ref result);
		return result;
	}

	public Vector3 GetPosition(ref Matrix _007B4576_007D)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		Vector3 result = default(Vector3);
		Vector3.Transform(ref Location.PositionI, ref _007B4576_007D, ref result);
		return result;
	}

	internal void OnExitFromPort()
	{
		_007B4595_007D = Location.SectionID % randomDirections.Length;
		multiCannonRemainShots = 0;
	}

	public void CreateTransform(Ship _007B4577_007D, Transform3D _007B4578_007D)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		Transform3D transform = _007B4577_007D.Transform;
		transform.CreateWorldMatrix(out var _007B14801_007D);
		_007B4578_007D.Translation = GetPosition(ref _007B14801_007D);
		_007B4578_007D.Pitch = transform.Pitch;
		_007B4578_007D.Yaw = Location.CurrentDirection.Y + transform.Yaw + (float)Math.PI;
		_007B4578_007D.Roll = 0f - transform.Roll;
		_007B4578_007D.MiddleScale = transform.MiddleScale;
	}

	public bool GetRollbackAdditionalTransform(float _007B4579_007D, out Matrix _007B4580_007D)
	{
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		int num = 400;
		float val = ((GameInfo.Class == CannonClass.HeavyCannon || GameInfo.Feature == CannonFeature.TripleShot || GameInfo.Feature == CannonFeature.Firegun) ? 0f : ((RollbackEffect > RollbackEffectMax - (float)num) ? (1f - (RollbackEffect - (RollbackEffectMax - (float)num)) / (float)num) : (RollbackEffect / (RollbackEffectMax - (float)num))));
		val = Math.Max(val, _007B4579_007D);
		if (val > 0.01f)
		{
			val = ((val > 1f) ? val : Geometry.Smoothstep(val));
			Matrix.CreateTranslation((0f - Location.Normal.X) * val * 0.75f, 0f, (0f - Location.Normal.Z) * val * 0.75f, ref _007B4580_007D);
			return true;
		}
		_007B4580_007D = default(Matrix);
		return false;
	}

	public CannonCommon(CannonLocationInfo _007B4581_007D, CannonGameInfo _007B4582_007D)
	{
		Location = _007B4581_007D;
		GameInfo = _007B4582_007D;
		reloadTimer = 0f;
		_007B4595_007D = _007B4581_007D.SectionID % randomDirections.Length;
	}

	public float ModifySightReductionFactor(float _007B4583_007D, CannonBallInfo _007B4584_007D, ShipDynamicInfo _007B4585_007D, bool _007B4586_007D = false, bool _007B4587_007D = false)
	{
		if (GameInfo.WorseScatter)
		{
			_007B4583_007D *= 1.4f;
		}
		if (!_007B4586_007D)
		{
			float num = Geometry.Saturate((float)(_007B4585_007D.StaticInfo.RightSidePorts.Length / 50));
			_007B4583_007D += GameInfo.Scatter / GameInfo.MaxDistance * ((float)Math.PI * 2f) * 0.5f * (1f - _007B4585_007D.ReduceCannonsScatter) * CommonGameConfig.CurrentSettings.ExperimentalCannonBallsDistance * (0.6f + 0.6f * num);
			if (_007B4584_007D[CannonBallInfoEffects.AdditionalDispersion])
			{
				_007B4583_007D = Math.Max(_007B4583_007D, 0.25f + 0.15f * num);
			}
			if (_007B4584_007D[CannonBallInfoEffects.LessScatter])
			{
				_007B4583_007D *= 0.6f;
			}
		}
		if (_007B4587_007D)
		{
			_007B4583_007D *= 0.2f;
		}
		return _007B4583_007D;
	}

	public void FocusAndGunDispersion(ref Vector3 _007B4588_007D, ref float _007B4589_007D, ref float _007B4590_007D, float _007B4591_007D, float _007B4592_007D, bool _007B4593_007D)
	{
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		float num = 0f;
		num = ((Location.Side != CannonLocation.InBack && Location.Side != CannonLocation.InFront) ? (Location.FocusingOffsetMultiplier / GameInfo.MaxDistance) : (Location.FocusingOffsetMultiplier / (0f - GameInfo.MaxDistance)));
		num *= 0.7f;
		Matrix val = default(Matrix);
		if (!_007B4593_007D)
		{
			Matrix.CreateFromYawPitchRoll(CurrentRandomValue.X * _007B4591_007D + num, CurrentRandomValue.Y * _007B4591_007D, 0f, ref val);
		}
		else
		{
			Matrix.CreateFromYawPitchRoll(CurrentRandomValue.X * _007B4591_007D * 1.1f + num * 0.5f, CurrentRandomValue.Y * _007B4591_007D * 1.1f, 0f, ref val);
		}
		Vector3.Transform(ref _007B4588_007D, ref val, ref _007B4588_007D);
		float num2 = MathHelper.Lerp(-0.13f, 0.06f, Geometry.InverseLerp(-0.125f, 0.125f, CurrentRandomValue.Y)) * _007B4591_007D;
		float num3 = 1f + 120f * num2 / (20f + _007B4592_007D);
		_007B4589_007D *= num3;
		_007B4590_007D *= 1f + num2;
	}

	public override string ToString()
	{
		return $"{GameInfo.Name} ,Place {Location.SectionID}";
	}
}
