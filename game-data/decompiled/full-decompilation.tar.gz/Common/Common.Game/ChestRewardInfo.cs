using System;
using System.Linq;
using Common.Account;
using Common.Resources;
using TheraEngine.Collections;

namespace Common.Game;

public struct ChestRewardInfo
{
	public int Tier;

	public float Weight;

	public ActionDelegate Complete;

	public bool ShowInChat;

	public bool CheckPremium;

	public Tlist<int> CheckShipID;

	public bool HasMapParts;

	public bool HasShipPlace;

	public bool CheckReputation;

	public bool DisallowOnLowRang;

	public LocalizedString OverrideChatMessage;

	public (byte id, int counter)? AssuranceOpen;

	public string RewardCategory;

	public bool FirstOpenChestCategory;

	public readonly bool IsPremiumShip => CheckShipID.Size != 0 && Gameplay.PlayersInfo.FromID(CheckShipID.First()).Coolness == PlayerShipCoolness.Elite;

	public ChestRewardInfo(int _007B8259_007D, ActionDelegate _007B8260_007D, bool _007B8261_007D, string _007B8262_007D = null)
		: this(_007B8259_007D, 0f, _007B8260_007D, _007B8261_007D, _007B8262_007D)
	{
	}

	public ChestRewardInfo(float _007B8263_007D, ActionDelegate _007B8264_007D, bool _007B8265_007D, string _007B8266_007D = null)
		: this(0, _007B8263_007D, _007B8264_007D, _007B8265_007D, _007B8266_007D)
	{
	}

	public ChestRewardInfo(int _007B8267_007D, float _007B8268_007D, ActionDelegate _007B8269_007D, bool _007B8270_007D, string _007B8271_007D = null)
	{
		FirstOpenChestCategory = false;
		Tier = _007B8267_007D;
		Weight = _007B8268_007D;
		Complete = _007B8269_007D;
		ShowInChat = _007B8270_007D;
		RewardCategory = _007B8271_007D;
		CheckPremium = false;
		CheckShipID = new Tlist<int>();
		HasMapParts = false;
		HasShipPlace = false;
		CheckReputation = false;
		DisallowOnLowRang = false;
		OverrideChatMessage = null;
		AssuranceOpen = null;
	}

	public bool AbleToReceiveAndDisplay(PlayerAccount _007B8272_007D)
	{
		if (CheckPremium && _007B8272_007D.IsPremium && _007B8272_007D.PremiumEnds.ToDateTime.Subtract(DateTime.Now).TotalDays > 180.0)
		{
			return false;
		}
		if (CheckShipID.Size != 0 && CheckShipID.All((int _007B8273_007D) => _007B8272_007D.Shipyard.ContainsCount(Gameplay.PlayersInfo.FromID(_007B8273_007D)) > 0))
		{
			return false;
		}
		if (HasShipPlace && _007B8272_007D.MaxShipsCount.Value >= _007B8272_007D.HardShipPlacesLimit)
		{
			return false;
		}
		return true;
	}
}
