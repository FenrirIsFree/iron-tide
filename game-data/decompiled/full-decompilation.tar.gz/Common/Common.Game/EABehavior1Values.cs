namespace Common.Game;

public static class EABehavior1Values
{
	public const short RandomPvpArenaOuterRadius = 600;

	public const short RandomPvpArenaInnerRadius = 250;

	public const short RandomPvpArenaBeingReward = 500;

	public const short RandomPvpArenaKillReward = 10000;
}
