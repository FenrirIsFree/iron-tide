using ManualPacketSerialization;

namespace Common.Game;

public interface IEventActionBehavior : IMPSerializable
{
}
