namespace Common.Game;

public enum GroupCommandId
{
	FocusOn,
	NpcSetSimple,
	NpcSetAnticrew,
	NpcSetAntisail,
	NpcSetSakson,
	NpcStopFire,
	Retreat,
	ComeHere,
	InviteGroup,
	Prepare,
	Help,
	Special_EnteringPassingMap
}
