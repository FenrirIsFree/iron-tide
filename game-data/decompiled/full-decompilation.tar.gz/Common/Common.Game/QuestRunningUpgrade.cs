using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct QuestRunningUpgrade : IMPSerializable
{
	public int QuestID;

	public byte NewStep;

	public int NewProgressInStep;

	public QuestInfo Info => Gameplay.QuestsInfo.FromID(QuestID);

	public QuestRunningUpgrade(int _007B7449_007D, byte _007B7450_007D, int _007B7451_007D)
	{
		QuestID = _007B7449_007D;
		NewStep = _007B7450_007D;
		NewProgressInStep = _007B7451_007D;
	}

	private void _007B7452_007D(WriterExtern _007B7453_007D)
	{
		_007B7453_007D.WriteStruct<int>(QuestID);
		_007B7453_007D.WriteByte(NewStep);
		_007B7453_007D.WriteStruct<int>(NewProgressInStep);
	}

	private void _007B7454_007D(WriterExtern _007B7455_007D)
	{
		_007B7455_007D.ReadStruct<int>(ref QuestID);
		NewStep = _007B7455_007D.ReadByte();
		_007B7455_007D.ReadStruct<int>(ref NewProgressInStep);
	}
}
