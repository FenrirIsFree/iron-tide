using System;
using System.Collections.Generic;
using System.Linq;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Game;

public class PortCaputreStatusList : Tlist<PortCaptureStatus>, IMPSerializable
{
	private string? _007B7902_007D;

	private bool _007B7903_007D;

	private int _007B7904_007D;

	public T? GetByPortId<T>(int _007B7893_007D) where T : PortCaptureStatus
	{
		return GetByPortId(_007B7893_007D) as T;
	}

	public PortCaptureStatus? GetByPortId(int _007B7894_007D)
	{
		for (int i = 0; i < Size; i++)
		{
			if (Array[i].PortID == _007B7894_007D)
			{
				return Array[i];
			}
		}
		return null;
	}

	public IEnumerable<T> Enumerate<T>() where T : PortCaptureStatus
	{
		for (int i = 0; i < Size; i++)
		{
			PortCaptureStatus portCaptureStatus = Array[i];
			if (portCaptureStatus is T item)
			{
				yield return item;
			}
		}
	}

	public new void Add(in PortCaptureStatus _007B7895_007D)
	{
		int portId = _007B7895_007D.PortID;
		if (this.Any((PortCaptureStatus _007B7905_007D) => _007B7905_007D.PortID == portId))
		{
			throw new InvalidOperationException("Port already added");
		}
		base.Add(in _007B7895_007D);
	}

	public bool FractionBonusHelper(FractionID _007B7896_007D)
	{
		return WosbPbs.FractionHasPBBonus(_007B7896_007D, Count((PortCaptureStatus _007B7906_007D) => _007B7906_007D.IsCapturedByGuild && _007B7906_007D.CapturerFraction == _007B7896_007D));
	}

	public void Boxing(WriterExtern _007B7897_007D)
	{
		_007B7897_007D.WriteByte((byte)Size);
		for (int i = 0; i < Size; i++)
		{
			PortCaptureStatus portCaptureStatus = Array[i];
			_007B7897_007D.CustomParameter = ((string.IsNullOrEmpty(_007B7902_007D) || !(_007B7902_007D == portCaptureStatus.CapturedBy)) ? PortStatusAccessLevel.BuildingsOnlyPosition : PortStatusAccessLevel.Full);
			if (_007B7903_007D)
			{
				_007B7897_007D.WriteByte((byte)4);
				portCaptureStatus.BoxingSelf(_007B7897_007D);
				continue;
			}
			int num;
			if (!(portCaptureStatus is PbsStatus))
			{
				if (!(portCaptureStatus is PiratePortCaptureStatus))
				{
					if (!(portCaptureStatus is ArabPortCaptureStatus))
					{
						throw new NotSupportedException();
					}
					num = 2;
				}
				else
				{
					num = 3;
				}
			}
			else
			{
				num = 1;
			}
			_007B7897_007D.WriteByte((byte)num);
			portCaptureStatus.Boxing(_007B7897_007D);
		}
	}

	public void Unboxing(WriterExtern _007B7898_007D)
	{
		byte b = _007B7898_007D.ReadByte();
		EnsureCapacitry(b);
		Size = b;
		for (int i = 0; i < b; i++)
		{
			switch (_007B7898_007D.ReadByte())
			{
			case 4:
				Array[i] = new PortCaptureStatus();
				Array[i].UnboxingSelf(_007B7898_007D);
				continue;
			case 1:
				Array[i] = new PbsStatus();
				break;
			case 2:
				Array[i] = new ArabPortCaptureStatus();
				break;
			case 3:
				Array[i] = new PiratePortCaptureStatus();
				break;
			}
			Array[i].Unboxing(_007B7898_007D);
		}
	}

	public PortCaputreStatusList MakeDataForSend(string _007B7899_007D)
	{
		return new PortCaputreStatusList
		{
			Array = Array,
			Size = Size,
			_007B7902_007D = _007B7899_007D
		};
	}

	public PortCaputreStatusList AsSlim()
	{
		PortCaputreStatusList portCaputreStatusList = new PortCaputreStatusList
		{
			Array = Array,
			Size = Size,
			_007B7903_007D = true
		};
		portCaputreStatusList._007B7900_007D();
		return portCaputreStatusList;
	}

	private void _007B7900_007D()
	{
		_007B7904_007D = 19;
		for (int i = 0; i < Size; i++)
		{
			_007B7904_007D = _007B7904_007D * 31 + base[i].GetHashCode();
		}
	}

	public bool Equals(PortCaputreStatusList? _007B7901_007D)
	{
		if (_007B7901_007D == null)
		{
			return false;
		}
		if (_007B7901_007D._007B7904_007D == _007B7904_007D)
		{
			return true;
		}
		if (_007B7901_007D.Size != Size)
		{
			return false;
		}
		if (_007B7901_007D._007B7904_007D != _007B7904_007D)
		{
			return false;
		}
		return true;
	}
}
