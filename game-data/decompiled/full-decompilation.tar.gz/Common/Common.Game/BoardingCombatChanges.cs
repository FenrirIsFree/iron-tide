using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Game;

public struct BoardingCombatChanges : IMPSerializable
{
	public Tlist<BoardingCombatBatllePass> DamageAndKills;

	public byte AppendNewSighting;

	public BoardingCombatChanges(Tlist<BoardingCombatBatllePass> _007B8007_007D, byte _007B8008_007D)
	{
		DamageAndKills = _007B8007_007D;
		AppendNewSighting = _007B8008_007D;
	}

	private void _007B8009_007D(WriterExtern _007B8010_007D)
	{
		_007B8010_007D.WriteTlistStruct<BoardingCombatBatllePass>(DamageAndKills);
		_007B8010_007D.WriteByte(AppendNewSighting);
	}

	private void _007B8011_007D(WriterExtern _007B8012_007D)
	{
		_007B8012_007D.ReadTlistStruct<BoardingCombatBatllePass>(out DamageAndKills);
		AppendNewSighting = _007B8012_007D.ReadByte();
	}
}
