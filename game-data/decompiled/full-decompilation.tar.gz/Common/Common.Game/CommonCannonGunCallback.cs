namespace Common.Game;

public delegate void CommonCannonGunCallback<T>(T _007B4604_007D, int _007B4605_007D);
