namespace Common.Game;

public class PbsTowerDescription
{
	public float SingleWeaponDamage;

	public float SingleWeaponCooldown;

	public float WeaponsAngle;

	public float DeadZone;

	public float MaxDistance;

	public PbsTowerDescription(float _007B4288_007D, float _007B4289_007D, float _007B4290_007D, float _007B4291_007D, float _007B4292_007D)
	{
		SingleWeaponDamage = _007B4288_007D;
		SingleWeaponCooldown = _007B4289_007D;
		WeaponsAngle = _007B4290_007D;
		DeadZone = _007B4291_007D;
		MaxDistance = _007B4292_007D;
	}
}
