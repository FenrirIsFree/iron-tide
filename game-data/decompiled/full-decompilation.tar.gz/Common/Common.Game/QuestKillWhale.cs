using TheraEngine;

namespace Common.Game;

public class QuestKillWhale : QuestStepHeader
{
	public readonly RTI Count;

	public override int ProgressComparand => Count.Value;

	public QuestKillWhale(string _007B7646_007D, int _007B7647_007D)
		: base(_007B7646_007D)
	{
		Count = new RTI(_007B7647_007D);
	}
}
