using System;
using System.Collections.Generic;
using System.Linq;
using Common.Account;
using Common.Resources;
using Microsoft.Xna.Framework;

namespace Common.Game;

public static class WosbTreasuryMaps
{
	public static readonly ResourceInfo[] AllMaps = Gameplay.ItemsInfo.Where((ResourceInfo _007B4386_007D) => _007B4386_007D.IsMap).ToArray();

	public static int CountToComplete(int _007B4376_007D)
	{
		if (1 == 0)
		{
		}
		int result = _007B4376_007D switch
		{
			35 => -1, 
			72 => -1, 
			71 => 7, 
			73 => 5, 
			74 => 10, 
			75 => 15, 
			_ => throw new NotSupportedException(), 
		};
		if (1 == 0)
		{
		}
		return result;
	}

	public static QuestInfo? GetQuestForMap(int _007B4377_007D, PlayerAccount _007B4378_007D)
	{
		foreach (QuestInfo item in (IEnumerable<QuestInfo>)Gameplay.QuestsInfo)
		{
			if (item.TreasuryMapID == _007B4377_007D && item.FirstStep is QuestIndividualLoot && !_007B4378_007D.Quests.ProgressRunningQuests.Any((QuestRunningProgress _007B4387_007D) => _007B4387_007D.Info.TreasuryMapID == _007B4377_007D))
			{
				return item;
			}
		}
		return null;
	}

	public static (QuestInfo? info, QuestRuntimeParameter? param) ConnectQuestForMap(int _007B4379_007D, PlayerAccount _007B4380_007D, Vector2 _007B4381_007D)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		QuestInfo questForMap = GetQuestForMap(_007B4379_007D, _007B4380_007D);
		if (questForMap?.FirstStep is QuestIndividualLoot)
		{
			return (info: questForMap, param: new QuestRuntimeParameter
			{
				PositionParameter = Gameplay.WorldMap.PositionsForDropInIsle.Rand(delegate(Vector2 _007B4388_007D)
				{
					//IL_0001: Unknown result type (might be due to invalid IL or missing references)
					//IL_0003: Unknown result type (might be due to invalid IL or missing references)
					float num = Vector2.Distance(_007B4388_007D, _007B4381_007D);
					return num < 4500f && num > 1000f;
				})
			});
		}
		return (info: questForMap, param: null);
	}

	public static void DetachMaps(PlayerAccount _007B4382_007D)
	{
		if (_007B4382_007D.NearPortStorage != null)
		{
			DetachMaps(_007B4382_007D.NearPortStorage, _007B4382_007D);
		}
		DetachMaps(_007B4382_007D.Shipyard.CurrentRealShip.PrivateResourcesOfHold, _007B4382_007D);
	}

	public static void DetachMaps(GSI _007B4383_007D, PlayerAccount? _007B4384_007D)
	{
		ResourceInfo[] allMaps = AllMaps;
		foreach (ResourceInfo resourceInfo in allMaps)
		{
			int num = _007B4383_007D[resourceInfo.ID];
			if (num > 0)
			{
				_007B4383_007D[resourceInfo.ID] = 0;
				if (_007B4384_007D != null)
				{
					_007B4384_007D.TreasuryMaps[resourceInfo.ID] += num;
				}
			}
		}
	}

	public static bool CanDrop(PlayerAccount _007B4385_007D)
	{
		return CalendarEvents.IsNewYear && _007B4385_007D.ServerSaveData.NewYearMapUsedToday < 3 && _007B4385_007D.TreasuryMaps[71] < CountToComplete(71);
	}
}
