using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct BoardingCombatBatllePass : IMPSerializable
{
	public byte SourceVisualGroup;

	public byte TatgetVisualGroup;

	public float Damage;

	private void _007B8001_007D(WriterExtern _007B8002_007D)
	{
		_007B8002_007D.WriteByte(SourceVisualGroup);
		_007B8002_007D.WriteByte(TatgetVisualGroup);
		_007B8002_007D.WriteStruct<float>(Damage);
	}

	private void _007B8003_007D(WriterExtern _007B8004_007D)
	{
		SourceVisualGroup = _007B8004_007D.ReadByte();
		TatgetVisualGroup = _007B8004_007D.ReadByte();
		_007B8004_007D.ReadStruct<float>(ref Damage);
	}
}
