using Common.Packets;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct OnNpcAgressionTargetChanged : IPacketBase, IMPSerializable
{
	public int NpcUID;

	public int NewTargetUID;

	public bool ByRedSpyglass;

	public bool IsInShieldGroup;

	public FlowOfPack Flow => FlowOfPack.FromServerToClient;

	public OnNpcAgressionTargetChanged(int _007B4899_007D, int _007B4900_007D, bool _007B4901_007D, bool _007B4902_007D)
	{
		NpcUID = -1;
		NewTargetUID = -1;
		NpcUID = _007B4899_007D;
		NewTargetUID = _007B4900_007D;
		ByRedSpyglass = _007B4901_007D;
		IsInShieldGroup = _007B4902_007D;
	}

	public void Boxing(WriterExtern _007B4903_007D)
	{
		_007B4903_007D.WriteStruct<int>(NpcUID);
		_007B4903_007D.WriteStruct<int>(NewTargetUID);
		_007B4903_007D.Write(IsInShieldGroup);
		_007B4903_007D.WriteStruct<bool>(ByRedSpyglass);
	}

	public void Unboxing(WriterExtern _007B4904_007D)
	{
		_007B4904_007D.ReadStruct<int>(ref NpcUID);
		_007B4904_007D.ReadStruct<int>(ref NewTargetUID);
		_007B4904_007D.ReadBoolean(ref IsInShieldGroup);
	}
}
