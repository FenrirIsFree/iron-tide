namespace Common.Game;

public enum PredefinedBurningType
{
	Infinite,
	InfiniteAllowMening,
	Finite
}
