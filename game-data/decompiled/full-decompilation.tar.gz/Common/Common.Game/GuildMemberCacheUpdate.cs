using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct GuildMemberCacheUpdate : IMPSerializable
{
	public GuildMemberCache Value;

	public uint SID;

	public GuildMemberCacheUpdate(GuildMemberCache _007B6444_007D, uint _007B6445_007D)
	{
		Value = _007B6444_007D;
		SID = _007B6445_007D;
	}

	public void Boxing(WriterExtern _007B6446_007D)
	{
		_007B6446_007D.Write<GuildMemberCache>(ref Value);
		_007B6446_007D.WriteStruct<uint>(SID);
	}

	public void Unboxing(WriterExtern _007B6447_007D)
	{
		_007B6447_007D.ReadIMPS_struct<GuildMemberCache>(ref Value);
		_007B6447_007D.ReadStruct<uint>(ref SID);
	}
}
