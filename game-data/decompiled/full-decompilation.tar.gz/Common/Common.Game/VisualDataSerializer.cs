using System;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

internal class VisualDataSerializer
{
	public static bool CheckEquals(IMPSerializable _007B7100_007D, IMPSerializable _007B7101_007D)
	{
		if (_007B7100_007D == null && _007B7101_007D == null)
		{
			return true;
		}
		if (_007B7100_007D == null || _007B7101_007D == null)
		{
			return false;
		}
		if (((object)_007B7100_007D).GetType() != ((object)_007B7101_007D).GetType())
		{
			return false;
		}
		return ((object)_007B7100_007D).Equals((object?)_007B7101_007D);
	}

	public static void Write(WriterExtern _007B7102_007D, IMPSerializable _007B7103_007D)
	{
		if (_007B7103_007D == null)
		{
			_007B7102_007D.WriteByte((byte)0);
			return;
		}
		if (_007B7103_007D is GuildBuildingVisualData guildBuildingVisualData)
		{
			_007B7102_007D.WriteByte((byte)1);
			_007B7102_007D.Write<GuildBuildingVisualData>(ref guildBuildingVisualData);
			return;
		}
		if (_007B7103_007D is ArenaOrPassingVisualData arenaOrPassingVisualData)
		{
			_007B7102_007D.WriteByte((byte)2);
			_007B7102_007D.Write<ArenaOrPassingVisualData>(ref arenaOrPassingVisualData);
			return;
		}
		if (_007B7103_007D is WorldFortVisualData worldFortVisualData)
		{
			_007B7102_007D.WriteByte((byte)3);
			_007B7102_007D.Write<WorldFortVisualData>(ref worldFortVisualData);
			return;
		}
		throw new NotSupportedException();
	}

	public static void Read(WriterExtern _007B7104_007D, out IMPSerializable _007B7105_007D)
	{
		switch (_007B7104_007D.ReadByte())
		{
		case 0:
			_007B7105_007D = null;
			break;
		case 1:
		{
			GuildBuildingVisualData guildBuildingVisualData = default(GuildBuildingVisualData);
			_007B7104_007D.ReadIMPS_struct<GuildBuildingVisualData>(ref guildBuildingVisualData);
			_007B7105_007D = (IMPSerializable)(object)guildBuildingVisualData;
			break;
		}
		case 2:
		{
			ArenaOrPassingVisualData arenaOrPassingVisualData = default(ArenaOrPassingVisualData);
			_007B7104_007D.ReadIMPS_struct<ArenaOrPassingVisualData>(ref arenaOrPassingVisualData);
			_007B7105_007D = (IMPSerializable)(object)arenaOrPassingVisualData;
			break;
		}
		case 3:
		{
			WorldFortVisualData worldFortVisualData = default(WorldFortVisualData);
			_007B7104_007D.ReadIMPS_struct<WorldFortVisualData>(ref worldFortVisualData);
			_007B7105_007D = (IMPSerializable)(object)worldFortVisualData;
			break;
		}
		default:
			throw new NotSupportedException();
		}
	}
}
