namespace Common.Game;

internal class BoardingBehavior
{
}
