namespace Common.Game;

public enum PbsBatlleSide
{
	None,
	Attacker,
	Defender
}
