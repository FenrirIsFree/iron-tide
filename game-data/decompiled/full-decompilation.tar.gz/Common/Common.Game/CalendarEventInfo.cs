using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Account;
using TheraEngine.Helpers;
using TheraEngine.PacketValues;

namespace Common.Game;

public class CalendarEventInfo
{
	public const int ExtraDaysAfterEventEnd = 6;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly CalendarEvent _007B6066_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly string _007B6067_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly string _007B6068_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly DateTime _007B6069_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly DayInfo[] _007B6070_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly Action<PlayerAccount>? _007B6071_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly Action<PlayerAccount, int>? _007B6072_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly bool _007B6073_007D = false;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly bool _007B6074_007D = false;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly bool _007B6075_007D = false;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly bool _007B6076_007D = false;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly float _007B6077_007D = 0f;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly bool _007B6078_007D = false;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private int _007B6079_007D = -1;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B6080_007D = false;

	public List<TraderOffer> GoldfishTrader = new List<TraderOffer>();

	public CalendarEvent Type
	{
		[CompilerGenerated]
		get
		{
			return _007B6066_007D;
		}
	}

	public string Name
	{
		[CompilerGenerated]
		get
		{
			return _007B6067_007D;
		}
	}

	public string FirstOpenText
	{
		[CompilerGenerated]
		get
		{
			return _007B6068_007D;
		}
	}

	public required DateTime StartDate
	{
		[CompilerGenerated]
		get
		{
			return _007B6069_007D;
		}
		[CompilerGenerated]
		init
		{
			_007B6069_007D = value;
		}
	}

	public required DayInfo[] Days
	{
		[CompilerGenerated]
		get
		{
			return _007B6070_007D;
		}
		[CompilerGenerated]
		init
		{
			_007B6070_007D = value;
		}
	}

	public Action<PlayerAccount>? OnFirstOpenAction
	{
		[CompilerGenerated]
		private get
		{
			return _007B6071_007D;
		}
		[CompilerGenerated]
		init
		{
			_007B6071_007D = value;
		}
	}

	public Action<PlayerAccount, int>? OnDayClosed
	{
		[CompilerGenerated]
		private get
		{
			return _007B6072_007D;
		}
		[CompilerGenerated]
		init
		{
			_007B6072_007D = value;
		}
	}

	public bool GoldFishingEnabled
	{
		[CompilerGenerated]
		get
		{
			return _007B6073_007D;
		}
		[CompilerGenerated]
		init
		{
			_007B6073_007D = value;
		}
	}

	public bool PumpkinLootEnabled
	{
		[CompilerGenerated]
		get
		{
			return _007B6074_007D;
		}
		[CompilerGenerated]
		init
		{
			_007B6074_007D = value;
		}
	}

	public bool IceBallsDropEnabled
	{
		[CompilerGenerated]
		get
		{
			return _007B6075_007D;
		}
		[CompilerGenerated]
		init
		{
			_007B6075_007D = value;
		}
	}

	public bool AltarGoldFishEnabled
	{
		[CompilerGenerated]
		get
		{
			return _007B6076_007D;
		}
		[CompilerGenerated]
		init
		{
			_007B6076_007D = value;
		}
	}

	public float DiscountAllShips
	{
		[CompilerGenerated]
		get
		{
			return _007B6077_007D;
		}
		[CompilerGenerated]
		init
		{
			_007B6077_007D = value;
		}
	}

	public bool RandomizedQuestDays
	{
		[CompilerGenerated]
		get
		{
			return _007B6078_007D;
		}
		[CompilerGenerated]
		init
		{
			_007B6078_007D = value;
		}
	}

	public int CurrentDayCached
	{
		[CompilerGenerated]
		get
		{
			return _007B6079_007D;
		}
		[CompilerGenerated]
		set
		{
			_007B6079_007D = value;
		}
	}

	public int Duration => Days.Length;

	public bool IsActive => CurrentDayCached >= 1 && CurrentDayCached <= Duration;

	public bool IsActiveExtended => CurrentDayCached >= 1 && CurrentDayCached <= Duration + 6;

	public bool SyncedFromServer
	{
		[CompilerGenerated]
		get
		{
			return _007B6080_007D;
		}
		[CompilerGenerated]
		set
		{
			_007B6080_007D = value;
		}
	}

	public CalendarEventInfo(CalendarEvent _007B6049_007D)
	{
		_007B6066_007D = _007B6049_007D;
		_007B6067_007D = Local.Current(Type.ToString().ToLower() + "_name");
		_007B6068_007D = Local.Current(Type.ToString().ToLower() + "_firstOpen");
	}

	public DayInfo GetDay(int _007B6050_007D)
	{
		return Days[_007B6050_007D - 1];
	}

	public (string Name, string Desc) GetQuestNameAndDesc(int _007B6051_007D)
	{
		return (Name: Local.Current(Type.ToString().ToLower() + "_quest_name", _007B6051_007D), Desc: Local.Current($"calendar_quest_d{_007B6051_007D}"));
	}

	public void CloseDay(PlayerAccount _007B6052_007D, int _007B6053_007D)
	{
		ref Bits16 reference = ref _007B6052_007D.Events.GetEvent(Type);
		if (!reference[_007B6053_007D])
		{
			reference[_007B6053_007D] = true;
			OnDayClosed?.Invoke(_007B6052_007D, TotalDaysClosed(_007B6052_007D));
		}
	}

	public bool IsDayClosed(PlayerAccount _007B6054_007D, int _007B6055_007D)
	{
		return _007B6054_007D.Events.GetEvent(Type)[_007B6055_007D];
	}

	public int TotalDaysClosed(PlayerAccount _007B6056_007D)
	{
		int num = 0;
		for (int i = 0; i < Days.Length; i++)
		{
			if (IsDayClosed(_007B6056_007D, i + 1))
			{
				num++;
			}
		}
		return num;
	}

	public bool IsFirstOpened(PlayerAccount _007B6057_007D)
	{
		return _007B6057_007D.Events.GetEvent(Type)[0];
	}

	public void FirstOpen(PlayerAccount _007B6058_007D)
	{
		_007B6058_007D.Events.GetEvent(Type)[0] = true;
		OnFirstOpenAction?.Invoke(_007B6058_007D);
		CalendarEvents.SendLogbookMessage(FirstOpenText);
	}

	public bool TryAddCurrentDayReward(PlayerAccount _007B6059_007D)
	{
		if (!IsActive)
		{
			return false;
		}
		if (!IsDayClosed(_007B6059_007D, CurrentDayCached))
		{
			DayInfo day = GetDay(CurrentDayCached);
			if (day.OnDayRewardApply != null)
			{
				day.OnDayRewardApply(_007B6059_007D, this);
				CloseDay(_007B6059_007D, CurrentDayCached);
				return true;
			}
		}
		return false;
	}

	public int GetCurrentQuestDay(PlayerAccount _007B6060_007D)
	{
		return GetQuestDay(_007B6060_007D, CurrentDayCached);
	}

	public int GetQuestDay(PlayerAccount _007B6061_007D, int _007B6062_007D)
	{
		if (!RandomizedQuestDays)
		{
			return _007B6062_007D;
		}
		if (_007B6062_007D == -1 || _007B6062_007D > Duration)
		{
			return -1;
		}
		return GetEventDay(_007B6061_007D.SID, _007B6062_007D, Days.Length);
	}

	private static int GetEventDay(uint _007B6063_007D, int _007B6064_007D, int _007B6065_007D)
	{
		int _007B14369_007D = (int)_007B6063_007D * -1640531535;
		int num = HashHelper.AffineShuffle(_007B14369_007D, _007B6064_007D - 1, _007B6065_007D);
		return num + 1;
	}
}
