using Common.Packets;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct OnSteamOrderMsg : IPacketBase, IMPSerializable
{
	public ulong OrderId;

	public FlowOfPack Flow => FlowOfPack.FromClientToServer;

	public OnSteamOrderMsg(ulong _007B8688_007D)
	{
		OrderId = _007B8688_007D;
	}

	public void Boxing(WriterExtern _007B8689_007D)
	{
		_007B8689_007D.WriteStruct<ulong>(OrderId);
	}

	public void Unboxing(WriterExtern _007B8690_007D)
	{
		_007B8690_007D.ReadStruct<ulong>(ref OrderId);
	}
}
