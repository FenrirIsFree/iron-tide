namespace Common.Game;

public class ServerArenaBuildDamageEvent
{
	private float _007B7164_007D;

	public void AddDamage(float _007B7163_007D)
	{
		_007B7164_007D += _007B7163_007D;
	}

	public float Receive()
	{
		float result = _007B7164_007D;
		_007B7164_007D = 0f;
		return result;
	}

	public float Peek()
	{
		return _007B7164_007D;
	}
}
