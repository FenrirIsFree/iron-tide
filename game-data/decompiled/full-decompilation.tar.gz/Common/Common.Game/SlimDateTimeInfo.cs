using System;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct SlimDateTimeInfo : IMPSerializable
{
	public SlimDateInfo Date;

	public byte Hours;

	public byte Minutes;

	public readonly DateTime ToDateTime => IsValid ? new DateTime(Date.Year, Date.Month, Date.Day, Hours, Minutes, 0) : new DateTime(1970, 1, 1);

	public readonly bool IsValid => Date.IsValid && Hours >= 0 && Hours <= 23 && Minutes >= 0 && Minutes <= 59;

	public SlimDateTimeInfo(DateTime _007B5580_007D)
	{
		Date = new SlimDateInfo(_007B5580_007D);
		Hours = (byte)_007B5580_007D.Hour;
		Minutes = (byte)_007B5580_007D.Minute;
	}

	private void _007B5581_007D(WriterExtern _007B5582_007D)
	{
		_007B5582_007D.Write<SlimDateInfo>(ref Date);
		_007B5582_007D.WriteByte(Hours);
		_007B5582_007D.WriteByte(Minutes);
	}

	private void _007B5583_007D(WriterExtern _007B5584_007D)
	{
		_007B5584_007D.ReadIMPS_struct<SlimDateInfo>(ref Date);
		Hours = _007B5584_007D.ReadByte();
		Minutes = _007B5584_007D.ReadByte();
	}

	public override string ToString()
	{
		LocalizedDateTime localizedDateTime = new LocalizedDateTime(this);
		localizedDateTime.PreferredTimeMode = TimeFormat.PreferServerTime;
		return localizedDateTime.GetDateAndTime();
	}
}
