using Common.Account;
using Common.Resources;

namespace Common.Game;

public static class RelationRistrictions
{
	public static bool CanChangeFlagsInPort(this Decorator _007B8677_007D, OpenWorldFlag _007B8678_007D)
	{
		int result;
		if (_007B8677_007D.ship.NearPortType != PortEnteringType.PersonalIsle)
		{
			if (!_007B8678_007D.IsPeaceMode())
			{
				result = 1;
			}
			else
			{
				GuildCommon guild = _007B8677_007D.guild;
				result = ((guild != null && guild.Fraction == FractionID.Pirate && _007B8677_007D.NearPortGuild.Fraction == FractionID.Pirate) ? 1 : ((_007B8677_007D.NearPortRelation != Relation.Enemy || _007B8677_007D.NearPortStatus.CapturerFraction == FractionID.Empire) ? 1 : 0));
			}
		}
		else
		{
			result = 1;
		}
		return (byte)result != 0;
	}
}
