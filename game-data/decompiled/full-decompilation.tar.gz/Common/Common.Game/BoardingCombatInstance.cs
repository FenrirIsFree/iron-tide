using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using Common.Packets;
using Common.Resources;
using TheraEngine.Collections;
using TheraEngine.Helpers;

namespace Common.Game;

public class BoardingCombatInstance
{
	[CompilerGenerated]
	private sealed class _003CMakeExternalDamage_003Ed__14 : IEnumerable<BoardingCombatBatllePass>, IEnumerable, IEnumerator<BoardingCombatBatllePass>, IEnumerator, IDisposable
	{
		private int _007B7985_007D;

		private BoardingCombatBatllePass _007B7986_007D;

		private int _007B7987_007D;

		private float _007B7988_007D;

		public float _003C_003E3__damageAmount;

		private byte _007B7989_007D;

		public byte _003C_003E3__sourceVisualGroup;

		private Tlist<byte> _007B7990_007D;

		public Tlist<byte> _003C_003E3__sighting;

		public BoardingCombatInstance _003C_003E4__this;

		private int _007B7991_007D;

		private int _007B7992_007D;

		private IEnumerator<BoardingCombatVisualGroup> _007B7993_007D;

		private BoardingCombatVisualGroup _007B7994_007D;

		private BoardingCombatBatllePass _007B7995_007D;

		private int _007B7996_007D;

		private int _007B7997_007D;

		private BoardingCombatVisualGroup _007B7998_007D;

		private BoardingCombatBatllePass _007B7999_007D;

		private int _007B8000_007D;

		BoardingCombatBatllePass IEnumerator<BoardingCombatBatllePass>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B7986_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B7986_007D;
			}
		}

		[DebuggerHidden]
		public _003CMakeExternalDamage_003Ed__14(int _007B7979_007D)
		{
			_007B7985_007D = _007B7979_007D;
			_007B7987_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B7980_007D()
		{
			int num = _007B7985_007D;
			if (num == -3 || num == 1)
			{
				try
				{
				}
				finally
				{
					_007B7982_007D();
				}
			}
			_007B7993_007D = null;
			_007B7994_007D = null;
			_007B7998_007D = null;
			_007B7985_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7980}
			this._007B7980_007D();
		}

		private bool _007B7981_007D()
		{
			try
			{
				switch (_007B7985_007D)
				{
				default:
					return false;
				case 0:
				{
					_007B7985_007D = -1;
					if (_007B7990_007D.Size == 0)
					{
						throw new InvalidOperationException();
					}
					bool flag = true;
					_003C_003E4__this._007B7974_007D.Clear();
					_007B7991_007D = 0;
					while (_007B7991_007D < _007B7990_007D.Size)
					{
						_007B7992_007D = _007B7990_007D.Array[_007B7991_007D];
						if (_007B7992_007D < _003C_003E4__this.VisualGroups.Size && _003C_003E4__this.VisualGroups.Array[_007B7992_007D].HealthFactor > 0f)
						{
							_003C_003E4__this._007B7974_007D.Add(in _003C_003E4__this.VisualGroups.Array[_007B7992_007D]);
						}
						_007B7991_007D++;
					}
					if (_003C_003E4__this._007B7974_007D.Size == 0)
					{
						return false;
					}
					_007B7993_007D = ((IEnumerable<BoardingCombatVisualGroup>)_003C_003E4__this._007B7974_007D).GetEnumerator();
					_007B7985_007D = -3;
					goto IL_0236;
				}
				case 1:
					_007B7985_007D = -3;
					_007B7994_007D = null;
					goto IL_0236;
				case 2:
					{
						_007B7985_007D = -1;
						_007B7998_007D = null;
						break;
					}
					IL_0236:
					if (_007B7993_007D.MoveNext())
					{
						_007B7994_007D = _007B7993_007D.Current;
						_007B7995_007D = default(BoardingCombatBatllePass);
						_007B7995_007D.Damage = _007B7988_007D / (float)_003C_003E4__this._007B7974_007D.Size;
						_007B7995_007D.SourceVisualGroup = _007B7989_007D;
						_007B7995_007D.TatgetVisualGroup = _007B7994_007D.VisualGroupIndex;
						if (_003C_003E4__this.MyProtectionSetted.IndexOf(in _007B7994_007D.VisualGroupIndex) != -1)
						{
							_007B7995_007D.Damage *= WosbBoarding.UnitInProtectionDamageIn;
						}
						_007B7986_007D = _007B7995_007D;
						_007B7985_007D = 1;
						return true;
					}
					_007B7982_007D();
					_007B7993_007D = null;
					break;
				}
				return false;
			}
			catch
			{
				//try-fault
				_007B7980_007D();
				throw;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7981}
			return this._007B7981_007D();
		}

		private void _007B7982_007D()
		{
			_007B7985_007D = -1;
			if (_007B7993_007D != null)
			{
				_007B7993_007D.Dispose();
			}
		}

		[DebuggerHidden]
		private void _007B7983_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7983}
			this._007B7983_007D();
		}

		[DebuggerHidden]
		IEnumerator<BoardingCombatBatllePass> IEnumerable<BoardingCombatBatllePass>.GetEnumerator()
		{
			_003CMakeExternalDamage_003Ed__14 _003CMakeExternalDamage_003Ed__;
			if (_007B7985_007D == -2 && _007B7987_007D == Environment.CurrentManagedThreadId)
			{
				_007B7985_007D = 0;
				_003CMakeExternalDamage_003Ed__ = this;
			}
			else
			{
				_003CMakeExternalDamage_003Ed__ = new _003CMakeExternalDamage_003Ed__14(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			_003CMakeExternalDamage_003Ed__._007B7988_007D = _003C_003E3__damageAmount;
			_003CMakeExternalDamage_003Ed__._007B7989_007D = _003C_003E3__sourceVisualGroup;
			_003CMakeExternalDamage_003Ed__._007B7990_007D = _003C_003E3__sighting;
			return _003CMakeExternalDamage_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B7984_007D()
		{
			return ((IEnumerable<BoardingCombatBatllePass>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7984}
			return this._007B7984_007D();
		}
	}

	internal const float speedeMultiplier = 1f;

	public int VisualGroupSize;

	public Tlist<byte> EnemyTargetsSetted;

	public Tlist<byte> MyProtectionSetted;

	public Tlist<BoardingCombatVisualGroup> VisualGroups;

	private Tlist<BoardingCombatVisualGroup> _007B7974_007D = new Tlist<BoardingCombatVisualGroup>();

	public BoardingCombatInstance()
	{
		VisualGroups = new Tlist<BoardingCombatVisualGroup>();
	}

	public BoardingCombatInstance(Ship _007B7951_007D)
		: this()
	{
		VisualGroupSize = 16 + _007B7951_007D.MaxUnitPlacesCount(_007B5018_007D: true) / 15;
		EnemyTargetsSetted = new Tlist<byte>(20);
		MyProtectionSetted = new Tlist<byte>(20);
		GSI gSI = new GSI();
		foreach (GSILocalEnumerablePair<UnitInfo> item in _007B7951_007D.UsedShip.Crew.Raw.UnitInfo.OrderBy<GSILocalEnumerablePair<UnitInfo>, short>((GSILocalEnumerablePair<UnitInfo> _007B7975_007D) => _007B7975_007D.Info.ID))
		{
			int num = item.Count;
			while (num > 0)
			{
				int val = VisualGroupSize - gSI.GetTotalItemsCount();
				gSI[item.Info.ID] += Math.Min(val, num);
				num -= Math.Min(val, num);
				if (gSI.GetTotalItemsCount() >= VisualGroupSize)
				{
					VisualGroups.Add(new BoardingCombatVisualGroup(VisualGroups.Size, gSI));
					gSI = new GSI();
				}
			}
			if (gSI.GetTotalItemsCount() >= 1)
			{
				VisualGroups.Add(new BoardingCombatVisualGroup(VisualGroups.Size, gSI));
				gSI = new GSI();
			}
		}
	}

	public static void Configure(Ship _007B7952_007D, BoardingCombatInstance _007B7953_007D, BoardingCombatInstance _007B7954_007D)
	{
		if (_007B7952_007D is Player player)
		{
			if (player.UsedShip.BoardingStartsMusketeersDefence)
			{
				_007B7953_007D._007B7959_007D(player.UsedShipPlayer.CraftFrom.BoardingProtectedGroupsLimit);
			}
			_007B7953_007D._007B7955_007D(_007B7952_007D, _007B7954_007D, player.UsedShip.BoardingStartsWithNoTarget);
		}
		if (_007B7952_007D is Npc && CommonGlobal.IsServer)
		{
			_007B7953_007D._007B7961_007D(_007B7954_007D);
		}
	}

	private void _007B7955_007D(Ship _007B7956_007D, BoardingCombatInstance _007B7957_007D, bool _007B7958_007D)
	{
		EnemyTargetsSetted.Clear();
		if (_007B7957_007D.VisualGroups.Size == 0)
		{
			return;
		}
		if (_007B7958_007D)
		{
			EnemyTargetsSetted.Add(in _007B7957_007D.VisualGroups.Rand(new Sequence(_007B7956_007D.uID + _007B7956_007D.UsedShip.Crew.Count)).VisualGroupIndex);
			return;
		}
		EnemyTargetsSetted.Add(_007B7957_007D.VisualGroups.Select((BoardingCombatVisualGroup _007B7976_007D) => _007B7976_007D.VisualGroupIndex).Take(3));
	}

	private void _007B7959_007D(int _007B7960_007D)
	{
		foreach (BoardingCombatVisualGroup item in (IEnumerable<BoardingCombatVisualGroup>)VisualGroups)
		{
			if (item.IncludingLiveUnits.UnitInfo.First().Info.IsMusketeer)
			{
				if (_007B7960_007D-- <= 0)
				{
					break;
				}
				MyProtectionSetted.AddIfNotContains(in item.VisualGroupIndex);
			}
		}
	}

	private void _007B7961_007D(BoardingCombatInstance _007B7962_007D)
	{
		EnemyTargetsSetted.Clear();
		int val = Rand.RangeInt(1, 4);
		val = Math.Min(_007B7962_007D.VisualGroups.Size, val);
		Tlist<BoardingCombatVisualGroup> tlist = _007B7962_007D.VisualGroups.Clone();
		tlist.Shuffle();
		tlist.Size = val;
		foreach (BoardingCombatVisualGroup item in (IEnumerable<BoardingCombatVisualGroup>)_007B7962_007D.VisualGroups)
		{
			EnemyTargetsSetted.Add(in item.VisualGroupIndex);
		}
	}

	public void Resight(OnBoardingResightingOrProtectMsg _007B7963_007D)
	{
		if (_007B7963_007D.attackPlaces != null)
		{
			EnemyTargetsSetted.Clear();
			EnemyTargetsSetted.Add(_007B7963_007D.attackPlaces);
		}
		if (_007B7963_007D.protectPlaces != null)
		{
			MyProtectionSetted.Clear();
			MyProtectionSetted.Add(_007B7963_007D.protectPlaces);
		}
	}

	public void UpdateGunnery(BoardingCombatInstance _007B7964_007D, float _007B7965_007D, Tlist<BoardingCombatBatllePass> _007B7966_007D)
	{
		if (!CommonGlobal.IsServer)
		{
			throw new NotSupportedException();
		}
		if (EnemyTargetsSetted.Size == 0)
		{
			return;
		}
		foreach (BoardingCombatVisualGroup item in (IEnumerable<BoardingCombatVisualGroup>)VisualGroups)
		{
			if (!(item.HealthFactor > 0f))
			{
				continue;
			}
			foreach (BoardingCombatBatllePass item2 in _007B7964_007D.MakeExternalDamage(item.TotalDamage * item.DamageFactor * (MyProtectionSetted.Contains(item.VisualGroupIndex) ? WosbBoarding.UnitInProtectionDamageOut : 1f), item.VisualGroupIndex, EnemyTargetsSetted))
			{
				_007B7966_007D.Add(item2);
			}
		}
	}

	[IteratorStateMachine(typeof(_003CMakeExternalDamage_003Ed__14))]
	private IEnumerable<BoardingCombatBatllePass> MakeExternalDamage(float _007B7967_007D, byte _007B7968_007D, Tlist<byte> _007B7969_007D)
	{
		//yield-return decompiler failed: Method not found
		return new _003CMakeExternalDamage_003Ed__14(-2)
		{
			_003C_003E4__this = this,
			_003C_003E3__damageAmount = _007B7967_007D,
			_003C_003E3__sourceVisualGroup = _007B7968_007D,
			_003C_003E3__sighting = _007B7969_007D
		};
	}

	public int CommonApplyDamage(Tlist<BoardingCombatBatllePass> _007B7970_007D, UnitCollection _007B7971_007D, GSI _007B7972_007D, int _007B7973_007D)
	{
		int num = 0;
		int num2 = 0;
		foreach (BoardingCombatBatllePass damage in (IEnumerable<BoardingCombatBatllePass>)_007B7970_007D)
		{
			if (VisualGroups.TryFind((BoardingCombatVisualGroup _007B7977_007D) => _007B7977_007D.VisualGroupIndex == damage.TatgetVisualGroup, out BoardingCombatVisualGroup item))
			{
				GSI gSI = item.MatchDamage(_007B7973_007D + num2, damage.Damage);
				if (_007B7971_007D.Remove(gSI, _007B4683_007D: false, out var _007B4684_007D))
				{
					_007B7972_007D?.Add(gSI);
					num += _007B4684_007D;
				}
			}
			num2++;
		}
		return num;
	}
}
