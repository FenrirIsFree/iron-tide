using Common.Game.Console;

namespace Common.Game;

internal static class Arguments
{
	public static IntArgument Int()
	{
		return new IntArgument();
	}

	public static IntArgument OptionalInt()
	{
		return new IntArgument
		{
			Optional = true
		};
	}

	public static BoolArgument Bool()
	{
		return new BoolArgument();
	}

	public static BoolArgument OptionalBool()
	{
		return new BoolArgument
		{
			Optional = true
		};
	}

	public static StringArgument Word(params string[] _007B8568_007D)
	{
		return new StringArgument
		{
			Values = _007B8568_007D
		};
	}

	public static StringArgument OptionalWord(params string[] _007B8569_007D)
	{
		return new StringArgument
		{
			Values = _007B8569_007D,
			Optional = true
		};
	}
}
