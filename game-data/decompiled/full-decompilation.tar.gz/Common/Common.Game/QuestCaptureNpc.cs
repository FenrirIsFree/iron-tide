namespace Common.Game;

public class QuestCaptureNpc : QuestStepHeader
{
	public override int ProgressComparand => -1;

	public QuestCaptureNpc(string _007B7552_007D, TargetShipForQuest _007B7553_007D)
		: base(_007B7552_007D, _007B7553_007D)
	{
	}
}
