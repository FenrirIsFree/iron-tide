using Common.Resources;

namespace Common.Game;

public class QuestDeliverNpc : QuestStepHeader
{
	public IslePortInfo? DeliverTo;

	public int CapturedNpcID;

	public bool spawnNpc;

	public bool agressionToPlayer;

	public override int ProgressComparand => -1;

	public QuestDeliverNpc(string _007B7587_007D, int _007B7588_007D, IslePortInfo _007B7589_007D, bool _007B7590_007D = false, bool _007B7591_007D = false)
		: base(_007B7587_007D)
	{
		CapturedNpcID = _007B7588_007D;
		DeliverTo = _007B7589_007D;
		spawnNpc = _007B7590_007D;
		agressionToPlayer = _007B7591_007D;
	}
}
