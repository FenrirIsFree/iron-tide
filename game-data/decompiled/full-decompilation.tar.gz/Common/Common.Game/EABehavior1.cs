using System.Collections.Generic;
using System.Linq;
using Common.Resources;
using CommonDataTypes;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;

namespace Common.Game;

public sealed class EABehavior1 : IEventActionBehavior, IMPSerializable
{
	public EActionCaterory Category;

	public float Amount;

	public Vector2 Position;

	private short[] _007B6130_007D = new short[0];

	public bool ShouldShowAtWorldMap => Category == EActionCaterory.BEmpireAttack || Category == EActionCaterory.PTensitySpeedUp || Category == EActionCaterory.BTadePortRandomizing || Category == EActionCaterory.StrongFog || Category == EActionCaterory.WaterDrought || Category == EActionCaterory.Cooling || Category == EActionCaterory.Epidemy || Category == EActionCaterory.SpecificResourceDeficit || Category == EActionCaterory.RareTrader || Category == EActionCaterory.BTender;

	public bool ShowStartAndEndDateTime => Category != EActionCaterory.SpecificResourceDeficit;

	public bool ShouldShowInLogbook => Category != EActionCaterory.ClosedCenter && Category != EActionCaterory.LongStartPremium;

	public bool IsSeasonEvent => Category.ToString().StartsWith("Season_");

	public IEnumerable<ShipClass> ShipClassArgument => _007B6130_007D.Select((short _007B6131_007D) => (ShipClass)_007B6131_007D);

	public ShipClass ShipClassSingleArgument => (ShipClass)_007B6130_007D[0];

	public PlayerShipCoolness ShipCoolnessArgument => (PlayerShipCoolness)_007B6130_007D[0];

	public int ArgumentInt => _007B6130_007D[0];

	public int Argument2Int => _007B6130_007D[1];

	public int Argument3Int => _007B6130_007D[2];

	public int Argument4Int => _007B6130_007D[3];

	internal string? TextArgument
	{
		get
		{
			EActionCaterory category = Category;
			bool flag = ((category == EActionCaterory.SpecificResourceDeficit || category == EActionCaterory.Season_ResourceManufacuringPortIncreaseID) ? true : false);
			return flag ? Gameplay.ItemsInfo.FromID(_007B6130_007D[0]).Name : ((Category == EActionCaterory.Season_ShipClassBuildingDiscountID) ? ShipClassSingleArgument.ToStringLocal(_007B440_007D: false) : ((Category == EActionCaterory.BEmpireShipbuilderInPort) ? Gameplay.WorldMap.Ports.Array[_007B6130_007D[0]].PortNameShort : ((Category == EActionCaterory.RandomPvpArena) ? Argument3Int.ToString() : null)));
		}
	}

	public EABehavior1()
	{
	}

	public EABehavior1(EActionCaterory _007B6119_007D, float _007B6120_007D, params short[] _007B6121_007D)
	{
		Category = _007B6119_007D;
		Amount = _007B6120_007D;
		_007B6130_007D = _007B6121_007D;
	}

	public EABehavior1(EActionCaterory _007B6122_007D, float _007B6123_007D, Vector2 _007B6124_007D, params short[] _007B6125_007D)
		: this(_007B6122_007D, _007B6123_007D, _007B6125_007D)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		Position = _007B6124_007D;
	}

	private void _007B6126_007D(WriterExtern _007B6127_007D)
	{
		_007B6127_007D.WriteEnum((object)Category);
		_007B6127_007D.WriteStruct<float>(ref Amount);
		_007B6127_007D.WriteByte((byte)_007B6130_007D.Length);
		for (int i = 0; i < _007B6130_007D.Length; i++)
		{
			_007B6127_007D.WriteStruct<short>(ref _007B6130_007D[i]);
		}
		if (Category == EActionCaterory.RandomPvpArena)
		{
			_007B6127_007D.WriteStruct<Vector2>(ref Position);
		}
	}

	private void _007B6128_007D(WriterExtern _007B6129_007D)
	{
		_007B6129_007D.ReadEnum<EActionCaterory>(ref Category);
		_007B6129_007D.ReadStruct<float>(ref Amount);
		byte b = _007B6129_007D.ReadByte();
		_007B6130_007D = new short[b];
		for (int i = 0; i < b; i++)
		{
			_007B6129_007D.ReadStruct<short>(ref _007B6130_007D[i]);
		}
		if (Category == EActionCaterory.RandomPvpArena)
		{
			_007B6129_007D.ReadStruct<Vector2>(ref Position);
		}
	}
}
