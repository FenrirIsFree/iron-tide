using Microsoft.Xna.Framework;

namespace Common.Game;

public class QuestFindSomething : QuestStepHeader
{
	public enum LocationType
	{
		ShipDebrisInSea,
		BoxInSea
	}

	public LocationType Location;

	public Vector2 LocationPos;

	public override int ProgressComparand => -1;

	public QuestFindSomething(string _007B7603_007D, LocationType _007B7604_007D, Vector2 _007B7605_007D)
		: base(_007B7603_007D)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		Location = _007B7604_007D;
		LocationPos = _007B7605_007D;
	}
}
