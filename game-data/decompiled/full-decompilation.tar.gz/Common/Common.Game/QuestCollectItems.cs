namespace Common.Game;

public class QuestCollectItems : QuestStepHeader
{
	public int Count;

	public int ItemId;

	public float Chance;

	public DropModel DropModel;

	public override int ProgressComparand => Count;

	public QuestCollectItems(string _007B7571_007D, int _007B7572_007D, int _007B7573_007D, float _007B7574_007D, DropModel _007B7575_007D)
		: base(_007B7571_007D)
	{
		Count = _007B7572_007D;
		ItemId = _007B7573_007D;
		Chance = _007B7574_007D;
		DropModel = _007B7575_007D;
	}
}
