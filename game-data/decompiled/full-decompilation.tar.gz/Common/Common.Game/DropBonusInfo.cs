using System;
using Common.Resources;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Helpers;

namespace Common.Game;

public struct DropBonusInfo : IMPSerializable
{
	public GSI Resources;

	public int GoldBonus;

	public int BonusXp;

	public GSI Ammo;

	public GSI PowderKegs;

	public byte PowerupItemIDindex;

	public GSI Crew;

	public GSI Cannons;

	public bool MineTrapInside;

	public float DisplayOnly_InitialBonusItemsTotalCount;

	public float Server_WhaleHealth;

	public float Mass => Resources.ComputeMass<ResourceInfo>() + Ammo.ComputeMass<CannonBallInfo>() + PowderKegs.ComputeMass<PowderKegInfo>();

	public bool IsEmpty => Resources.IsEmpty && GoldBonus == 0 && PowerupItemIDindex == byte.MaxValue && Ammo.IsEmpty && Cannons.IsEmpty && Crew.IsEmpty && PowderKegs.IsEmpty && BonusXp == 0 && !MineTrapInside;

	public void Add(in DropBonusInfo _007B5617_007D)
	{
		Resources.Add(_007B5617_007D.Resources);
		GoldBonus += _007B5617_007D.GoldBonus;
		PowerupItemIDindex = _007B5617_007D.PowerupItemIDindex;
		Ammo.Add(_007B5617_007D.Ammo);
		Crew.Add(_007B5617_007D.Crew);
		Cannons.Add(_007B5617_007D.Cannons);
		PowderKegs.Add(_007B5617_007D.PowderKegs);
		BonusXp += _007B5617_007D.BonusXp;
		MineTrapInside |= _007B5617_007D.MineTrapInside;
	}

	public void Remove(in DropBonusInfo _007B5618_007D)
	{
		Resources.Remove(_007B5618_007D.Resources);
		GoldBonus -= _007B5618_007D.GoldBonus;
		if (_007B5618_007D.PowerupItemIDindex != byte.MaxValue)
		{
			PowerupItemIDindex = byte.MaxValue;
		}
		Ammo.Remove(_007B5618_007D.Ammo);
		Crew.Remove(_007B5618_007D.Crew);
		Cannons.Remove(_007B5618_007D.Cannons);
		PowderKegs.Remove(_007B5618_007D.PowderKegs);
		BonusXp -= _007B5618_007D.BonusXp;
		MineTrapInside = false;
	}

	public DropBonusInfo Clone(float _007B5619_007D = 1f, RoundMode _007B5620_007D = RoundMode.Rand)
	{
		DropBonusInfo result = default(DropBonusInfo);
		if (_007B5619_007D == 1f)
		{
			result.Resources = Resources.Clone();
			result.Ammo = Ammo.Clone();
			result.Cannons = Cannons.Clone();
			result.PowderKegs = PowderKegs.Clone();
			result.PowerupItemIDindex = PowerupItemIDindex;
			result.Crew = Crew;
			result.BonusXp = BonusXp;
			result.GoldBonus = GoldBonus;
			result.DisplayOnly_InitialBonusItemsTotalCount = DisplayOnly_InitialBonusItemsTotalCount;
		}
		else
		{
			result.Resources = Resources.Clone(_007B5619_007D, _007B5620_007D);
			result.Ammo = Ammo.Clone(_007B5619_007D, _007B5620_007D);
			result.Cannons = Cannons.Clone(_007B5619_007D, _007B5620_007D);
			result.PowderKegs = PowderKegs.Clone(_007B5619_007D, _007B5620_007D);
			result.PowerupItemIDindex = PowerupItemIDindex;
			result.Crew = Crew.Clone(_007B5619_007D, _007B5620_007D);
			result.BonusXp = ((_007B5620_007D == RoundMode.Rand) ? Rand.Round((float)BonusXp * _007B5619_007D) : ((int)MathF.Round((float)BonusXp * _007B5619_007D)));
			result.GoldBonus = ((_007B5620_007D == RoundMode.Rand) ? Rand.Round((float)GoldBonus * _007B5619_007D) : ((int)MathF.Round((float)GoldBonus * _007B5619_007D)));
			result.DisplayOnly_InitialBonusItemsTotalCount = DisplayOnly_InitialBonusItemsTotalCount * _007B5619_007D;
		}
		result.Server_WhaleHealth = Server_WhaleHealth;
		result.MineTrapInside = MineTrapInside;
		return result;
	}

	public bool CanRemove(DropBonusInfo _007B5621_007D)
	{
		return Resources.CanRemove(_007B5621_007D.Resources) && GoldBonus >= _007B5621_007D.GoldBonus && BonusXp >= _007B5621_007D.BonusXp && Cannons.CanRemove(_007B5621_007D.Cannons) && Ammo.CanRemove(_007B5621_007D.Ammo) && Crew.CanRemove(_007B5621_007D.Crew) && PowderKegs.CanRemove(_007B5621_007D.PowderKegs);
	}

	public DropBonusInfo(int _007B5622_007D, GSI _007B5623_007D, GSI _007B5624_007D)
	{
		MineTrapInside = false;
		Server_WhaleHealth = 0f;
		Resources = _007B5624_007D;
		GoldBonus = _007B5622_007D;
		Ammo = _007B5623_007D;
		PowerupItemIDindex = byte.MaxValue;
		DisplayOnly_InitialBonusItemsTotalCount = _007B5624_007D.GetTotalItemsCount();
		BonusXp = 0;
		Crew = new GSI();
		Cannons = new GSI();
		PowderKegs = new GSI();
	}

	private void _007B5625_007D(WriterExtern _007B5626_007D)
	{
		_007B5626_007D.WriteStruct<int>(GoldBonus);
		_007B5626_007D.WriteNoNull<GSI>(Ammo);
		_007B5626_007D.WriteNoNull<GSI>(PowderKegs);
		_007B5626_007D.WriteNoNull<GSI>(Cannons);
		_007B5626_007D.WriteNoNull<GSI>(Crew);
		_007B5626_007D.WriteNoNull<GSI>(Resources);
		_007B5626_007D.WriteByte(PowerupItemIDindex);
		_007B5626_007D.WriteStruct<float>(ref DisplayOnly_InitialBonusItemsTotalCount);
		_007B5626_007D.WriteStruct<int>(BonusXp);
		_007B5626_007D.Write(MineTrapInside);
	}

	private void _007B5627_007D(WriterExtern _007B5628_007D)
	{
		_007B5628_007D.ReadStruct<int>(ref GoldBonus);
		_007B5628_007D.ReadIMPSNoNull<GSI>(ref Ammo);
		_007B5628_007D.ReadIMPSNoNull<GSI>(ref PowderKegs);
		_007B5628_007D.ReadIMPSNoNull<GSI>(ref Cannons);
		_007B5628_007D.ReadIMPSNoNull<GSI>(ref Crew);
		_007B5628_007D.ReadIMPSNoNull<GSI>(ref Resources);
		PowerupItemIDindex = _007B5628_007D.ReadByte();
		_007B5628_007D.ReadStruct<float>(ref DisplayOnly_InitialBonusItemsTotalCount);
		_007B5628_007D.ReadStruct<int>(ref BonusXp);
		_007B5628_007D.ReadBoolean(ref MineTrapInside);
	}

	public override bool Equals(object _007B5629_007D)
	{
		throw new NotSupportedException();
	}
}
