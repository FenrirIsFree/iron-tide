namespace Common.Game;

public interface IShootingInfo
{
	int DisableInterruptParts { get; }
}
