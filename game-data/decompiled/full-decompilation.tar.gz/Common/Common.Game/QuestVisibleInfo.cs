using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct QuestVisibleInfo : IMPSerializable
{
	public ushort ID;

	public float Timeout;

	public bool WasHidden;

	public QuestInfo Info => Gameplay.QuestsInfo[ID];

	public QuestVisibleInfo(ushort _007B7767_007D, float _007B7768_007D)
	{
		ID = _007B7767_007D;
		Timeout = _007B7768_007D;
		WasHidden = false;
	}

	private void _007B7769_007D(WriterExtern _007B7770_007D)
	{
		_007B7770_007D.WriteStruct<ushort>(ID);
		_007B7770_007D.WriteStruct<float>(Timeout);
		_007B7770_007D.Write(WasHidden);
	}

	private void _007B7771_007D(WriterExtern _007B7772_007D)
	{
		_007B7772_007D.ReadStruct<ushort>(ref ID);
		_007B7772_007D.ReadStruct<float>(ref Timeout);
		_007B7772_007D.ReadBoolean(ref WasHidden);
	}
}
