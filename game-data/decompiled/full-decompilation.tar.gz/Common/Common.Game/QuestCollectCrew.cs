namespace Common.Game;

public class QuestCollectCrew : QuestStepHeader
{
	public int Count;

	public bool Special;

	public override int ProgressComparand => Count;

	public QuestCollectCrew(string _007B7557_007D, int _007B7558_007D, bool _007B7559_007D)
		: base(_007B7557_007D)
	{
		Count = _007B7558_007D;
		Special = _007B7559_007D;
	}
}
