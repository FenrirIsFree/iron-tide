using System;
using Common.Resources;

namespace Common.Game;

public readonly struct ShipBonus
{
	public readonly ShipBonusEffect Type;

	public readonly float Value;

	public readonly float[] Values;

	public bool IsIdentity => Type == ShipBonusEffect.Identity;

	public static ShipBonus[] ParseStrings(string _007B5037_007D, string _007B5038_007D)
	{
		if (string.IsNullOrEmpty(_007B5037_007D))
		{
			return new ShipBonus[0];
		}
		string[] array = _007B5037_007D.Split(' ');
		string[] array2 = _007B5038_007D.Split(' ');
		ShipBonus[] array3 = new ShipBonus[array.Length];
		for (int i = 0; i < array.Length; i++)
		{
			ShipBonusEffect _007B5039_007D = (ShipBonusEffect)Enum.Parse(typeof(ShipBonusEffect), array[i]);
			float _007B5040_007D = array2[i].ParseSafe();
			array3[i] = new ShipBonus(_007B5039_007D, _007B5040_007D);
		}
		return array3;
	}

	public ShipBonus(ShipBonusEffect _007B5039_007D, float _007B5040_007D)
	{
		Values = null;
		Type = _007B5039_007D;
		Value = _007B5040_007D;
	}

	public ShipBonus(ShipBonusEffect _007B5041_007D, float _007B5042_007D, float[] _007B5043_007D)
	{
		Type = _007B5041_007D;
		Value = _007B5042_007D;
		Values = _007B5043_007D;
	}

	public static bool operator ==(ShipBonus _007B5044_007D, ShipBonus _007B5045_007D)
	{
		return _007B5044_007D.Type == _007B5045_007D.Type && _007B5044_007D.Value == _007B5045_007D.Value;
	}

	public static bool operator !=(ShipBonus _007B5046_007D, ShipBonus _007B5047_007D)
	{
		return _007B5046_007D.Type != _007B5047_007D.Type || _007B5046_007D.Value != _007B5047_007D.Value;
	}

	public ShipBonus Scale(float _007B5048_007D, bool _007B5049_007D)
	{
		return new ShipBonus(Type, _007B5049_007D ? ((float)(int)(Value * _007B5048_007D)) : (Value * _007B5048_007D));
	}

	public float GetValueByRank(int _007B5050_007D)
	{
		if (Values == null || Values.Length == 0)
		{
			return Value;
		}
		int num = Math.Clamp(Values.Length - _007B5050_007D, 0, Values.Length - 1);
		return Values[num];
	}

	public new string ToString()
	{
		return Type switch
		{
			ShipBonusEffect.MArmor => Local.armor + pn(Value), 
			ShipBonusEffect.MCapacity => Local.hold + pn(Value), 
			ShipBonusEffect.PCapacity => Local.hold + pn(Value) + "%", 
			ShipBonusEffect.MExtraPlaces => Local.crew + pn(Value), 
			ShipBonusEffect.MHealth => Local.strength + pn(Value), 
			ShipBonusEffect.PPowderKegReloadBoost => Local.StringConstants_81 + pn(Value) + "%", 
			ShipBonusEffect.MSpeed => Local.speed + pn(Value * PlayerShipInfo.Temp_displaySpeedRefactoring) + Local.StringConstants_83, 
			ShipBonusEffect.PAddCollisionDamage => Local.StringConstants_84 + pn(Value) + "%", 
			ShipBonusEffect.PArmor => Local.armor + pn(Value) + "%", 
			ShipBonusEffect.PCannonsReload => Local.StringConstants_85b + pn(Value) + "%", 
			ShipBonusEffect.PBallDamage => Local.StringConstants_86 + pn(Value) + "%", 
			ShipBonusEffect.PHealth => Local.strength + pn(Value) + "%", 
			ShipBonusEffect.PPlayerMendingKitEffectivity => Local.StringConstants_87 + pn(Value) + "%", 
			ShipBonusEffect.MPlayerJerkEffectPowerAdd => Local.StringConstants_88 + pn(Value), 
			ShipBonusEffect.PPlayerSightFocusSpeedAdd => (Value >= 1000f) ? Local.StringConstants_89 : (Local.StringConstants_90 + pn(Value) + "%"), 
			ShipBonusEffect.PReduceDamageToNose => Local.StringConstants_91 + pn(Value) + "%", 
			ShipBonusEffect.PReduceDamageToSailFromBurning => (Value >= 100f) ? Local.StringConstants_92 : (Local.StringConstants_93 + pn(Value) + "%"), 
			ShipBonusEffect.PReduceFireAreaDamage => Local.StringConstants_94 + pn(Value) + "%", 
			ShipBonusEffect.PSailProtection => Local.StringConstants_95 + pn(Value) + "%", 
			ShipBonusEffect.PSpeed => Local.speed + pn(Value) + "%", 
			ShipBonusEffect.PVisibilityZone => Local.StringConstants_96 + pn(Value) + "%", 
			ShipBonusEffect.PCannonBallsSpeed => Local.StringConstants_97 + pn(Value) + "%", 
			ShipBonusEffect.PMortarDamageBonus => Local.StringConstants_98 + pn(Value) + "%", 
			ShipBonusEffect.BMortarAngleBonus => Local.StringConstants_99, 
			ShipBonusEffect.MMobilityBonus => Local.mobility + pn(Value), 
			ShipBonusEffect.PChangeShipSpeedBonus => Local.StringConstants_102 + pn(Value) + "%", 
			ShipBonusEffect.PDamageCannonIfStrengthBelow30P => Local.StringConstants_103 + pn(Value) + Local.StringConstants_104, 
			ShipBonusEffect.PFrontAndBackCannonsAddDamage => Local.StringConstants_106 + pn(Value) + "%", 
			ShipBonusEffect.MMakeInvisiblePlaces => Local.StringConstants_108, 
			ShipBonusEffect.PPowerupItemsReload => Local.StringConstants_109 + pn(Value) + "%", 
			ShipBonusEffect.PChangeCBallsSpeed => Local.StringConstants_110 + pn(Value) + "%", 
			ShipBonusEffect.MCannonsDistance => Local.StringConstants_111 + pn(Value), 
			ShipBonusEffect.MMortarMaxDistance => Local.distance + pn(Value), 
			ShipBonusEffect.PSouredItemsReduce => Local.StringConstants_113, 
			ShipBonusEffect.MCannonsAngleBonus => Local.StringConstants_weapAngle + pn(Value), 
			ShipBonusEffect.PReduceReceivesMortarDamage => Local.StringConstants_mortarProtect + pn(Value) + "%", 
			ShipBonusEffect.PReduceLossesWhenKilled => Local.StringConstants_lossResMinus + pn(0f - Value) + "%", 
			ShipBonusEffect.PMendingEffectivity => Local.StringConstants_mendingEff + pn(Value) + "%", 
			ShipBonusEffect.BMoreFireAreaAndBurning => Local.StringConstants_105, 
			ShipBonusEffect.PTiltReduce => Local.StringConstants_114_b + pn(Value) + "%", 
			ShipBonusEffect.BCannonBallFosforEffects => Local.StringConstants_256, 
			ShipBonusEffect.ServMendingStrength => Local.StringConstants_257(Value), 
			ShipBonusEffect.PReducePowderKegDamage => Local.StringConstants_258 + pn(Value) + "%", 
			ShipBonusEffect.MExtraUpgradePlaces => Local.StringConstants_259 + pn(Value), 
			ShipBonusEffect.PBoardingGold => Local.StringConstants_260(pn(Value)), 
			ShipBonusEffect.BCannonBallBobershell => Local.StringConstants_261, 
			ShipBonusEffect.Display_ProtectedOfManTheCrew => Local.StringConstants_262, 
			ShipBonusEffect.PMarchingSpeed => Local.StringConstants_263 + pn(Value) + "%", 
			ShipBonusEffect.PFishingSpeed => Local.StringConstants_264 + pn(Value) + "%", 
			ShipBonusEffect.BDestroyFloodingShopByCollision => Local.StringConstants_265, 
			ShipBonusEffect.PDropLootingSpeed => Local.StringConstants_270 + pn(Value) + "%", 
			ShipBonusEffect.PBoardingDistance => Local.StringConstants_271 + pn(Value) + "%", 
			ShipBonusEffect.PMortarReload => Local.StringConstants_273 + pn(Value) + "%", 
			ShipBonusEffect.PReduceCannonsScatter => Local.StringConstants_274 + pn(0f - Value) + "%", 
			ShipBonusEffect.BExtraMortars => Local.StringConstants_275(Value), 
			ShipBonusEffect.BBoardingStartsMusketeersDefence => Local.StringConstants_278, 
			ShipBonusEffect.PBigFireFightingSpeed => Local.StringConstants_279 + pn(Value) + "%", 
			ShipBonusEffect.PReduceBigFireDamage => Local.StringConstants_280 + pn(0f - Value) + "%", 
			ShipBonusEffect.PMicrofireFightingSpeed => Local.StringConstants_281 + pn(Value) + "%", 
			ShipBonusEffect.BHealUnitsWhenMending => Local.StringConstants_283, 
			ShipBonusEffect.PCrewFineReduce => Local.StringConstants_284 + pn(Value) + "%", 
			ShipBonusEffect.PReloadingAfterSingleShot => Local.StringConstants_286(Value), 
			ShipBonusEffect.PCannonsReloadWithLowHp => Local.StringConstants_287 + pn(Value) + "%", 
			ShipBonusEffect.PMortarAimSpeed => Local.StringConstants_288 + pn(Value) + "%", 
			ShipBonusEffect.PMortarReloadWhenCannonsAreReloaded => Local.StringConstants_290(Value), 
			ShipBonusEffect.PDecreaseSpeedLossMarchingMode => Local.StringConstants_291 + pn(0f - Value) + "%", 
			ShipBonusEffect.MMobility0And1 => Local.StringConstants_294 + pn(Value), 
			ShipBonusEffect.MMobilityWithLowHp => Local.StringConstants_295 + pn(Value), 
			ShipBonusEffect.PSailAutoRepairSpeed => Local.StringConstants_296 + pn(Value) + "%", 
			ShipBonusEffect.BRepairAllowOnSpeed2 => Local.StringConstants_297, 
			ShipBonusEffect.POverweightFineReduce => Local.StringConstants_298 + pn(Value) + "%", 
			ShipBonusEffect.BAllowConsumeAnimalsToFood => Local.StringConstants_299, 
			ShipBonusEffect.PFishingProfit => Local.StringConstants_302 + pn(Value) + "%", 
			ShipBonusEffect.PXpBonus => Local.StringConstants_303 + pn(Value) + "%", 
			ShipBonusEffect.BBoardingStartsWithNoTarget => Local.StringConstants_305, 
			ShipBonusEffect.PBoardingHookReload => Local.StringConstants_306 + pn(Value) + "%", 
			ShipBonusEffect.PMoreBondmanFromBoarding => Local.StringConstants_309 + pn(Value) + "%", 
			ShipBonusEffect.BCrewWillntDeadInSea => Local.StringConstants_313, 
			ShipBonusEffect.PCrewProtectionCballs => Local.StringConstants_315 + pn(Value) + "%", 
			ShipBonusEffect.PBoardingCrewProtectionCballs => Local.StringConstants_317 + pn(Value) + "%", 
			ShipBonusEffect.PSailorsCrewProtectionCballs => Local.StringConstants_318 + pn(Value) + "%", 
			ShipBonusEffect.MMoreExtraCrew => Local.StringConstants_319 + pn(Value), 
			ShipBonusEffect.PFalkonetReloadBoost => Local.StringConstants_320 + pn(Value) + "%", 
			ShipBonusEffect.BAllowPowderKegAnySpeed => Local.StringConstants_321, 
			ShipBonusEffect.PSpecialUnitImperialUniqueChance => Local.StringConstants_324 + pn(Value) + "%", 
			ShipBonusEffect.PSpecialUnitChanseAtSea => Local.StringConstants_325 + pn(Value) + "%", 
			ShipBonusEffect.PSpecialUnitGameModeUniqueChance => Local.StringConstants_326 + pn(Value) + "%", 
			ShipBonusEffect.PMoreLootAtSea => Local.StringConstants_328 + pn(Value) + "%", 
			ShipBonusEffect.PMoreRareItemsAtSea => Local.StringConstants_329 + pn(Value) + "%", 
			ShipBonusEffect.PReduceSickDeadChanse => Local.StringConstants_331 + pn(0f - Value) + "%", 
			ShipBonusEffect.PReduceSickGettingChanse => Local.StringConstants_332 + pn(0f - Value) + "%", 
			ShipBonusEffect.BExtraItemHasNoTimeout => Local.StringConstants_333, 
			ShipBonusEffect.PRestoreHealthWhenGettingDebris => Local.StringConstants_334 + pn(Value) + "%", 
			ShipBonusEffect.BSpecialUnitEndConflicts => Local.StringConstants_335, 
			ShipBonusEffect.PMoreWeightAtBoarding => Local.StringConstants_338 + pn(Value) + "%", 
			ShipBonusEffect.PFoodValueBonus => Local.StringConstants_339 + pn(Value) + "%", 
			ShipBonusEffect.PXpBonusUpgradesAndBranch => Local.StringConstants_340 + pn(Value) + "%", 
			ShipBonusEffect.PReduceCannonsWear => Local.StringConstants_341 + pn(Value) + "%", 
			ShipBonusEffect.PLootInteropDistance => Local.StringConstants_342 + pn(Value) + "%", 
			ShipBonusEffect.PMinimapLootVisibleDistance => Local.StringConstants_343 + pn(Value) + "%", 
			ShipBonusEffect.PPowderKegIncreaseTriggerRadius => Local.StringConstants_344 + pn(Value) + "%", 
			ShipBonusEffect.PRestoreUnitsAfterBoarding => Local.StringConstants_345 + pn(Value) + "%", 
			ShipBonusEffect.PMortarDecreaseDeadzone => Local.StringConstants_346 + pn(Value) + "%", 
			ShipBonusEffect.MPReduceCannonsQuantity => Local.StringConstants_347 + Value, 
			ShipBonusEffect.PBuckshotDamage => Local.StringConstants_buckshotDamage + pn(Value) + "%", 
			ShipBonusEffect.BDisableWindCourseChange => Local.StringConstants_348, 
			ShipBonusEffect.PSpeedPaddles => Local.StringConstants_349 + pn(Value), 
			ShipBonusEffect.PMobilityBonus => Local.mobility + pn(Value) + "%", 
			_ => throw new NotSupportedException(), 
		};
	}

	private static string pn(float _007B5051_007D)
	{
		return (_007B5051_007D > 0f) ? $"+{_007B5051_007D}" : _007B5051_007D.ToString();
	}
}
