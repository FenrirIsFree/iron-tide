using System.Collections.Generic;

namespace Common.Game;

public class ArenaPlayerShowingDictionaryMetadata<T> : ArenaPlayerShowingDictionary
{
	private Dictionary<uint, T> meta = new Dictionary<uint, T>(1000);

	public void Add(ArenaShowingProperty _007B6974_007D, float _007B6975_007D, T _007B6976_007D, string _007B6977_007D, uint _007B6978_007D, int _007B6979_007D)
	{
		lock (syncRoot)
		{
			Add(_007B6974_007D, _007B6975_007D, _007B6977_007D, _007B6978_007D, _007B6979_007D);
			if (!meta.ContainsKey(_007B6978_007D))
			{
				meta.Add(_007B6978_007D, _007B6976_007D);
			}
		}
	}

	public new float GetProperty(ArenaShowingProperty _007B6980_007D, uint _007B6981_007D)
	{
		lock (syncRoot)
		{
			if (TryGetValue(_007B6981_007D, out ArenaPlayerShowing value))
			{
				return value.GetStat(_007B6980_007D);
			}
			return 0f;
		}
	}

	public T TryGetMeta(uint _007B6982_007D, T _007B6983_007D = default(T))
	{
		lock (syncRoot)
		{
			if (meta.TryGetValue(_007B6982_007D, out var value))
			{
				return value;
			}
			return _007B6983_007D;
		}
	}
}
