using Common.Resources;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;
using TheraEngine.Collections;

namespace Common.Game;

public struct DynamicBuildCreatePacket : IMPSerializable
{
	public Vector2 Position;

	public float Axis;

	public short ModelID;

	public int uIDinScene;

	public WorldObjectID Flags;

	public float NowStrength;

	public float MaxStrength;

	public ushort UnitsCount;

	public ushort MaxUnitsCount;

	public IMPSerializable VisualData;

	public DynamicBuildCreatePacket(Vector2 _007B7082_007D, float _007B7083_007D, int _007B7084_007D, int _007B7085_007D, WorldObjectID _007B7086_007D, float _007B7087_007D, float _007B7088_007D, ushort _007B7089_007D, ushort _007B7090_007D, IMPSerializable _007B7091_007D)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		Position = _007B7082_007D;
		Axis = _007B7083_007D;
		ModelID = (short)_007B7084_007D;
		uIDinScene = _007B7085_007D;
		Flags = _007B7086_007D;
		NowStrength = _007B7087_007D;
		MaxStrength = _007B7088_007D;
		UnitsCount = _007B7089_007D;
		MaxUnitsCount = _007B7090_007D;
		VisualData = _007B7091_007D;
	}

	private void _007B7092_007D(WriterExtern _007B7093_007D)
	{
		_007B7093_007D.WriteStruct<Vector2>(ref Position);
		_007B7093_007D.WriteStruct<float>(ref Axis);
		_007B7093_007D.WriteStruct<short>(ref ModelID);
		_007B7093_007D.WriteStruct<int>(ref uIDinScene);
		_007B7093_007D.WriteByte((byte)Flags);
		_007B7093_007D.WriteStruct<float>(ref NowStrength);
		_007B7093_007D.WriteStruct<float>(ref MaxStrength);
		_007B7093_007D.WriteStruct<ushort>(ref MaxUnitsCount);
		if (MaxUnitsCount != 0)
		{
			_007B7093_007D.WriteStruct<ushort>(ref UnitsCount);
		}
		VisualDataSerializer.Write(_007B7093_007D, VisualData);
	}

	private void _007B7094_007D(WriterExtern _007B7095_007D)
	{
		_007B7095_007D.ReadStruct<Vector2>(ref Position);
		_007B7095_007D.ReadStruct<float>(ref Axis);
		_007B7095_007D.ReadStruct<short>(ref ModelID);
		_007B7095_007D.ReadStruct<int>(ref uIDinScene);
		Flags = (WorldObjectID)_007B7095_007D.ReadByte();
		_007B7095_007D.ReadStruct<float>(ref NowStrength);
		_007B7095_007D.ReadStruct<float>(ref MaxStrength);
		_007B7095_007D.ReadStruct<ushort>(ref MaxUnitsCount);
		if (MaxUnitsCount != 0)
		{
			_007B7095_007D.ReadStruct<ushort>(ref UnitsCount);
		}
		VisualDataSerializer.Read(_007B7095_007D, out VisualData);
	}

	public bool CheckChanges(ref DynamicBuildCreatePacket _007B7096_007D, Tlist<DynamicBuildVisibleChanges> _007B7097_007D)
	{
		DynamicBuildVisibleChanges item = new DynamicBuildVisibleChanges(uIDinScene, ModelID, NowStrength, MaxStrength, UnitsCount, MaxUnitsCount, VisualData);
		if (ModelID != _007B7096_007D.ModelID)
		{
			item.FieldsHangesFlags[0] = true;
		}
		if (MaxStrength != _007B7096_007D.MaxStrength)
		{
			item.FieldsHangesFlags[1] = true;
		}
		if (NowStrength != _007B7096_007D.NowStrength)
		{
			item.FieldsHangesFlags[2] = true;
		}
		if (UnitsCount != _007B7096_007D.UnitsCount)
		{
			item.FieldsHangesFlags[3] = true;
		}
		if (!VisualDataSerializer.CheckEquals(VisualData, _007B7096_007D.VisualData))
		{
			item.FieldsHangesFlags[4] = true;
		}
		if (MaxUnitsCount != _007B7096_007D.MaxUnitsCount)
		{
			item.FieldsHangesFlags[5] = true;
		}
		if (item.FieldsHangesFlags.Value > 0)
		{
			_007B7097_007D.Add(in item);
			return true;
		}
		return false;
	}

	public void Actualize(DynamicBuildVisibleChanges _007B7098_007D, out bool _007B7099_007D)
	{
		if (_007B7099_007D = _007B7098_007D.FieldsHangesFlags[0])
		{
			ModelID = _007B7098_007D.ModelID;
		}
		if (_007B7098_007D.FieldsHangesFlags[1])
		{
			MaxStrength = _007B7098_007D.MaxStrength;
		}
		if (_007B7098_007D.FieldsHangesFlags[2])
		{
			NowStrength = _007B7098_007D.NowStrength;
		}
		if (_007B7098_007D.FieldsHangesFlags[3])
		{
			UnitsCount = _007B7098_007D.UnitsCount;
		}
		if (_007B7098_007D.FieldsHangesFlags[4])
		{
			VisualData = _007B7098_007D.VisualData;
		}
		if (_007B7098_007D.FieldsHangesFlags[5])
		{
			MaxUnitsCount = _007B7098_007D.MaxUnitsCount;
		}
	}
}
