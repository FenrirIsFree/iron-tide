using System;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Helpers;

namespace Common.Game;

public class ShipKeyController
{
	public const byte KCS_FullOff = 0;

	public const byte KCS_Stop = 0;

	public const byte KCS_ForwardSpeed1 = 1;

	public const byte KCS_ForwardSpeed2 = 2;

	public const byte KCS_ForwardSpeed3 = 3;

	public const byte KCS_BackwardWind = 4;

	public const byte KCS_DirZero = 0;

	public const byte KCS_DirRight = 1;

	public const byte KCS_DirLeft = 2;

	public const byte AnchorDeployCode = 244;

	public const byte AnchorUpCode = 245;

	public Action Change;

	private byte _007B5131_007D;

	private float _007B5132_007D = 1f;

	private int _007B5133_007D;

	private int _007B5134_007D;

	public byte GetCode => _007B5131_007D;

	public int LinearStateCode => _007B5133_007D;

	public int AxisStateCode => _007B5134_007D;

	public ShipKeyController()
	{
		_007B5131_007D = 0;
	}

	public void Set(byte _007B5120_007D)
	{
		if (_007B5131_007D != _007B5120_007D)
		{
			_007B5131_007D = _007B5120_007D;
			_007B5134_007D = _007B5120_007D / 10;
			_007B5133_007D = _007B5120_007D - _007B5134_007D * 10;
			Change?.Invoke();
		}
	}

	public void EvaluteLinearSpeed(int _007B5121_007D)
	{
		if (_007B5121_007D * _007B5121_007D != 1)
		{
			throw new ArgumentException();
		}
		_007B5133_007D += _007B5121_007D;
		if (_007B5133_007D < 0)
		{
			_007B5133_007D = 0;
		}
		if (_007B5133_007D > 3)
		{
			_007B5133_007D = 3;
		}
		Set((byte)(_007B5133_007D + 10 * _007B5134_007D));
	}

	public void SetLinearSpeed(int _007B5122_007D)
	{
		Set((byte)(_007B5122_007D + 10 * _007B5134_007D));
	}

	public void EvaluteAxisSpeed(int _007B5123_007D)
	{
		if (_007B5123_007D * _007B5123_007D > 1)
		{
			throw new ArgumentException();
		}
		_007B5134_007D = _007B5123_007D switch
		{
			-1 => 2, 
			1 => 1, 
			_ => 0, 
		};
		Set((byte)(_007B5133_007D + 10 * _007B5134_007D));
	}

	public void SetAll(int _007B5124_007D, int _007B5125_007D)
	{
		_007B5134_007D = _007B5125_007D switch
		{
			-1 => 2, 
			1 => 1, 
			_ => 0, 
		};
		Set((byte)(_007B5124_007D + 10 * _007B5134_007D));
	}

	internal void Update(Ship _007B5126_007D, ref FrameTime _007B5127_007D, ref float _007B5128_007D, ref float _007B5129_007D, out int _007B5130_007D)
	{
		_007B5130_007D = ((_007B5134_007D != 0) ? ((_007B5134_007D == 2) ? 1 : (-1)) : 0);
		int num = 0;
		float num2 = _007B5128_007D * 0.66f;
		float num3 = _007B5128_007D;
		float num4 = 0.39600003f;
		float num5 = (1.15f + (_007B5126_007D.UsedShip.StaticInfo.InertionFactor - 1f) * 0.5f) * 0.38f;
		float num6 = (1.6f + (_007B5126_007D.UsedShip.StaticInfo.InertionFactor - 1f) * 0.2f) * (0.75f + (_007B5126_007D.UsedShip.StaticInfo.InertionFactor - 1f) * 0.1f);
		float num7 = 1.3f;
		float num8 = 1f - (_007B5126_007D.UsedShip.StaticInfo.InertionFactor - 1f) * 0.15f;
		if (_007B5126_007D.UsedShip.StaticInfo.IsBalloon)
		{
			num5 += 1f;
			num6 += 0.5f;
		}
		float mobilityBonusAtLowSpeeds = _007B5126_007D.UsedShip.MobilityBonusAtLowSpeeds;
		num5 *= 1f + mobilityBonusAtLowSpeeds;
		num6 *= 1f + mobilityBonusAtLowSpeeds * 0.5f;
		switch (_007B5133_007D)
		{
		case 0:
			_007B5128_007D = num;
			break;
		case 1:
			_007B5128_007D = num2;
			break;
		case 2:
			_007B5128_007D = num3;
			break;
		case 3:
			_007B5128_007D = num3;
			break;
		case 4:
			_007B5128_007D = 0f - num2;
			break;
		}
		float nowSpeed = _007B5126_007D.physicsBody.NowSpeed;
		if (nowSpeed <= (float)num)
		{
			_007B5132_007D = MathHelper.Lerp(num5, num4, Geometry.Saturate((0f - nowSpeed) / 2f));
		}
		else if (nowSpeed < num2)
		{
			_007B5132_007D = MathHelper.Lerp(num5, num6, MathF.Sqrt(nowSpeed / num2));
		}
		else if (nowSpeed < num3)
		{
			_007B5132_007D = MathHelper.Lerp(num6, num7, (nowSpeed - num2) / (num3 - num2));
		}
		else
		{
			_007B5132_007D = MathHelper.Lerp(num7, num8, Math.Min(1f, (nowSpeed - num3) / 1f));
		}
		_007B5129_007D *= _007B5132_007D / 1.3f;
	}

	public void Reset()
	{
		bool flag = _007B5131_007D != 0;
		_007B5131_007D = 0;
		_007B5134_007D = 0;
		_007B5133_007D = 0;
		_007B5132_007D = 1f;
		if (flag)
		{
			Change?.Invoke();
		}
	}
}
