using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class ArenaPlayerShowing : IMPSerializable
{
	public string PlayerName;

	public Bonus ComputedServerReward;

	public Dictionary<int, ArenaShipStats> StatsPerShip = new Dictionary<int, ArenaShipStats>();

	public uint Server_AccSid;

	public int Server_Flags;

	public PbsBatlleSide Server_BattleSide;

	public int Server_UID;

	public float GetInternalPoints(ArenaMode? _007B6990_007D)
	{
		float huracanStatsMod = 0.85f;
		float num = StatsPerShip.Sum((KeyValuePair<int, ArenaShipStats> _007B7015_007D) => _007B7015_007D.Value.SendDamage * ((_007B7015_007D.Key == 65) ? huracanStatsMod : 1f));
		float num2 = StatsPerShip.Sum((KeyValuePair<int, ArenaShipStats> _007B7016_007D) => _007B7016_007D.Value.ReceivedDamage * ((_007B7016_007D.Key == 65) ? huracanStatsMod : 1f));
		float num3 = StatsPerShip.Sum((KeyValuePair<int, ArenaShipStats> _007B7017_007D) => _007B7017_007D.Value.SendDamageEquip * ((_007B7017_007D.Key == 65) ? huracanStatsMod : 1f));
		float num4 = StatsPerShip.Sum((KeyValuePair<int, ArenaShipStats> _007B7018_007D) => _007B7018_007D.Value.SendDamageBuldings * ((_007B7018_007D.Key == 65) ? huracanStatsMod : 1f));
		float num5 = StatsPerShip.Sum((KeyValuePair<int, ArenaShipStats> _007B7001_007D) => _007B7001_007D.Value.SendDamageAlly);
		int num6 = StatsPerShip.Sum((KeyValuePair<int, ArenaShipStats> _007B7002_007D) => _007B7002_007D.Value.Kills);
		int num7 = StatsPerShip.Sum((KeyValuePair<int, ArenaShipStats> _007B7003_007D) => _007B7003_007D.Value.Death * ((_007B7003_007D.Key != 65) ? 1 : 2));
		int num8 = StatsPerShip.Sum((KeyValuePair<int, ArenaShipStats> _007B7004_007D) => _007B7004_007D.Value.CargoPoints);
		int num9 = StatsPerShip.Sum((KeyValuePair<int, ArenaShipStats> _007B7005_007D) => _007B7005_007D.Value.LootedCargoPoints);
		if (_007B6990_007D.HasValue && _007B6990_007D == ArenaMode.WallVsWall)
		{
			float num10 = 1f;
			float num11 = 0.4f;
			float num12 = 0.3f;
			float num13 = 45f;
			float num14 = 10f;
			return (num * num10 + num2 * num11 + num3 * num12) * (1f + (float)num6 / num13) * (1f - (float)num7 / num14);
		}
		if (_007B6990_007D.HasValue && _007B6990_007D == ArenaMode.Collecting)
		{
			float num15 = 0.6f;
			float num16 = 0.24f;
			float num17 = 0.36f;
			int num18 = 100;
			int num19 = 300;
			return num * num15 + num2 * num16 + num3 * num17 + (float)(num9 * num18) + (float)(num8 * num19);
		}
		if (_007B6990_007D.HasValue && _007B6990_007D == ArenaMode.DuelRating)
		{
			float num20 = 1f;
			float num21 = 0.4f;
			float num22 = 0.3f;
			return num * num20 + num2 * num21 + num3 * num22;
		}
		if (!_007B6990_007D.HasValue || _007B6990_007D == ArenaMode.TowerDefence)
		{
			float num23 = 1f;
			float num24 = 0.4f;
			float num25 = 1.1f;
			float num26 = 0.3f;
			float num27 = 60f;
			float num28 = 16f;
			float num29 = (num * num23 + num2 * num24 + num4 * num25 + num3 * num26) * (1f + (float)num6 / num27) * Math.Max(0.2f, 1f - (float)num7 / num28);
			float num30 = 50000f;
			if (num29 > num30)
			{
				num29 = num30 + 0.66f * (num29 - num30);
			}
			return num29;
		}
		return 0f;
	}

	public ArenaPlayerShowing()
	{
	}

	public ArenaPlayerShowing(string _007B6991_007D, Bonus _007B6992_007D)
	{
		PlayerName = _007B6991_007D;
		ComputedServerReward = _007B6992_007D;
		StatsPerShip = new Dictionary<int, ArenaShipStats>();
		Server_AccSid = 0u;
		Server_Flags = 0;
		Server_BattleSide = PbsBatlleSide.None;
	}

	public void AddStat(ArenaShowingProperty _007B6993_007D, float _007B6994_007D, int _007B6995_007D)
	{
		if (!StatsPerShip.TryGetValue(_007B6995_007D, out var value))
		{
			value = default(ArenaShipStats);
		}
		switch (_007B6993_007D)
		{
		case ArenaShowingProperty.SendDamage:
			value.SendDamage += _007B6994_007D;
			break;
		case ArenaShowingProperty.SendDamageBuldings:
			value.SendDamageBuldings += _007B6994_007D;
			break;
		case ArenaShowingProperty.Kills:
			value.Kills += (int)_007B6994_007D;
			break;
		case ArenaShowingProperty.ReceivedDamage:
			value.ReceivedDamage += _007B6994_007D;
			break;
		case ArenaShowingProperty.SendDamageAlly:
			value.SendDamageAlly += _007B6994_007D;
			break;
		case ArenaShowingProperty.SendDamageEquip:
			value.SendDamageEquip += _007B6994_007D;
			break;
		case ArenaShowingProperty.Death:
			value.Death += (int)_007B6994_007D;
			break;
		case ArenaShowingProperty.CargoPoints:
			value.CargoPoints += (int)_007B6994_007D;
			break;
		case ArenaShowingProperty.LootedCargoPoints:
			value.LootedCargoPoints += (int)_007B6994_007D;
			break;
		default:
			throw new NotSupportedException();
		case ArenaShowingProperty.SupportPoints:
		case ArenaShowingProperty.Boarding:
			break;
		}
		StatsPerShip[_007B6995_007D] = value;
	}

	public float GetStat(ArenaShowingProperty _007B6996_007D)
	{
		if (1 == 0)
		{
		}
		float result = _007B6996_007D switch
		{
			ArenaShowingProperty.SendDamage => StatsPerShip.Sum((KeyValuePair<int, ArenaShipStats> _007B7006_007D) => _007B7006_007D.Value.SendDamage), 
			ArenaShowingProperty.SendDamageBuldings => StatsPerShip.Sum((KeyValuePair<int, ArenaShipStats> _007B7007_007D) => _007B7007_007D.Value.SendDamageBuldings), 
			ArenaShowingProperty.Kills => StatsPerShip.Sum((KeyValuePair<int, ArenaShipStats> _007B7008_007D) => _007B7008_007D.Value.Kills), 
			ArenaShowingProperty.ReceivedDamage => StatsPerShip.Sum((KeyValuePair<int, ArenaShipStats> _007B7009_007D) => _007B7009_007D.Value.ReceivedDamage), 
			ArenaShowingProperty.SendDamageAlly => StatsPerShip.Sum((KeyValuePair<int, ArenaShipStats> _007B7010_007D) => _007B7010_007D.Value.SendDamageAlly), 
			ArenaShowingProperty.SendDamageEquip => StatsPerShip.Sum((KeyValuePair<int, ArenaShipStats> _007B7011_007D) => _007B7011_007D.Value.SendDamageEquip), 
			ArenaShowingProperty.SupportPoints => 0f, 
			ArenaShowingProperty.Boarding => 0f, 
			ArenaShowingProperty.Death => StatsPerShip.Sum((KeyValuePair<int, ArenaShipStats> _007B7012_007D) => _007B7012_007D.Value.Death), 
			ArenaShowingProperty.CargoPoints => StatsPerShip.Sum((KeyValuePair<int, ArenaShipStats> _007B7013_007D) => _007B7013_007D.Value.CargoPoints), 
			ArenaShowingProperty.LootedCargoPoints => StatsPerShip.Sum((KeyValuePair<int, ArenaShipStats> _007B7014_007D) => _007B7014_007D.Value.LootedCargoPoints), 
			_ => throw new NotSupportedException(), 
		};
		if (1 == 0)
		{
		}
		return result;
	}

	private void _007B6997_007D(WriterExtern _007B6998_007D)
	{
		_007B6998_007D.Write(PlayerName, (Encoding)null);
		_007B6998_007D.Write<Bonus>(ref ComputedServerReward);
		_007B6998_007D.WriteDictImps<int, ArenaShipStats>(StatsPerShip);
	}

	private void _007B6999_007D(WriterExtern _007B7000_007D)
	{
		_007B7000_007D.ReadString(ref PlayerName, (Encoding)null);
		_007B7000_007D.ReadIMPS_struct<Bonus>(ref ComputedServerReward);
		_007B7000_007D.ReadDictImps<int, ArenaShipStats>(out StatsPerShip);
	}
}
