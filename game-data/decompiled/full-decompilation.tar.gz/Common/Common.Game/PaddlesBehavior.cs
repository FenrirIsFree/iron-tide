namespace Common.Game;

internal class PaddlesBehavior
{
}
