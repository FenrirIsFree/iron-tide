namespace Common.Game;

public enum PlatformType
{
	Standalone,
	VKPlay,
	Steam,
	MSStore
}
