using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;

namespace Common.Game;

public class QuestRuntimeParameter : IMPSerializable
{
	public Vector2 PositionParameter;

	public int CountParameter;

	public int IDParameter;

	public QuestRuntimeParameter(Vector2 _007B7468_007D, int _007B7469_007D, int _007B7470_007D)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		PositionParameter = _007B7468_007D;
		CountParameter = _007B7469_007D;
		IDParameter = _007B7470_007D;
	}

	public QuestRuntimeParameter()
	{
	}

	private void _007B7471_007D(WriterExtern _007B7472_007D)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		_007B7472_007D.WriteStruct<Vector2>(PositionParameter);
		_007B7472_007D.WriteStruct<int>(CountParameter);
		_007B7472_007D.WriteStruct<int>(IDParameter);
	}

	private void _007B7473_007D(WriterExtern _007B7474_007D)
	{
		_007B7474_007D.ReadStruct<Vector2>(ref PositionParameter);
		_007B7474_007D.ReadStruct<int>(ref CountParameter);
		_007B7474_007D.ReadStruct<int>(ref IDParameter);
	}
}
