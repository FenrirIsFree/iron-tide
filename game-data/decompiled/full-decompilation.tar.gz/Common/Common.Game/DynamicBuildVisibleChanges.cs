using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.PacketValues;

namespace Common.Game;

public struct DynamicBuildVisibleChanges : IMPSerializable
{
	public int uID;

	public short ModelID;

	public float MaxStrength;

	public float NowStrength;

	public ushort UnitsCount;

	public ushort MaxUnitsCount;

	public IMPSerializable VisualData;

	public Bits8 FieldsHangesFlags;

	public bool IsChangesNowStrength => FieldsHangesFlags[2];

	public bool IsChangesUnitsCount => FieldsHangesFlags[3];

	internal DynamicBuildVisibleChanges(int _007B7152_007D, short _007B7153_007D, float _007B7154_007D, float _007B7155_007D, ushort _007B7156_007D, ushort _007B7157_007D, IMPSerializable _007B7158_007D)
	{
		FieldsHangesFlags.Value = 0;
		uID = _007B7152_007D;
		ModelID = _007B7153_007D;
		NowStrength = _007B7154_007D;
		MaxStrength = _007B7155_007D;
		UnitsCount = _007B7156_007D;
		VisualData = _007B7158_007D;
		MaxUnitsCount = _007B7157_007D;
	}

	private void _007B7159_007D(WriterExtern _007B7160_007D)
	{
		_007B7160_007D.WriteByte(FieldsHangesFlags.Value);
		_007B7160_007D.WriteStruct<int>(uID);
		if (FieldsHangesFlags[0])
		{
			_007B7160_007D.WriteStruct<short>(ModelID);
		}
		if (FieldsHangesFlags[1])
		{
			_007B7160_007D.WriteStruct<float>(MaxStrength);
		}
		if (FieldsHangesFlags[2])
		{
			_007B7160_007D.WriteStruct<float>(NowStrength);
		}
		if (FieldsHangesFlags[3])
		{
			_007B7160_007D.WriteStruct<ushort>(UnitsCount);
		}
		if (FieldsHangesFlags[4])
		{
			VisualDataSerializer.Write(_007B7160_007D, VisualData);
		}
		if (FieldsHangesFlags[5])
		{
			_007B7160_007D.WriteStruct<ushort>(MaxUnitsCount);
		}
	}

	private void _007B7161_007D(WriterExtern _007B7162_007D)
	{
		FieldsHangesFlags.Value = _007B7162_007D.ReadByte();
		_007B7162_007D.ReadStruct<int>(ref uID);
		if (FieldsHangesFlags[0])
		{
			_007B7162_007D.ReadStruct<short>(ref ModelID);
		}
		if (FieldsHangesFlags[1])
		{
			_007B7162_007D.ReadStruct<float>(ref MaxStrength);
		}
		if (FieldsHangesFlags[2])
		{
			_007B7162_007D.ReadStruct<float>(ref NowStrength);
		}
		if (FieldsHangesFlags[3])
		{
			_007B7162_007D.ReadStruct<ushort>(ref UnitsCount);
		}
		if (FieldsHangesFlags[4])
		{
			VisualDataSerializer.Read(_007B7162_007D, out VisualData);
		}
		if (FieldsHangesFlags[5])
		{
			_007B7162_007D.ReadStruct<ushort>(ref MaxUnitsCount);
		}
	}
}
