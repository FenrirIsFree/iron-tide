namespace Common.Game;

public enum ArenaWinKretery
{
	KillAll,
	KillCount,
	DestroyFort,
	LootCount
}
