using System;
using Common.Account;
using Common.Resources;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;

namespace Common.Game;

public class CapturedShipIntance : IMPSerializable
{
	public enum NpcMode
	{
		Agressive,
		Neutral,
		Passive,
		Wait
	}

	public GSI ResourcesInHold;

	public GSI AmmoInHold;

	public int LastServerUid;

	public byte ReferencePlayerShipId;

	public float ReferenceStrength;

	public int ReferenceNpcShipId;

	public byte RepairsCount;

	public Vector2 SavedPosition;

	public float SavedStrength;

	public GSI SavedCrew;

	public bool SavedOnIsle;

	public NpcMode BehaviorMode;

	public PlayerShipInfo ReferenceShip => Gameplay.PlayersInfo.FromID(ReferencePlayerShipId);

	public float CurrentHoldLoad => AmmoInHold.ComputeMass<CannonBallInfo>() + ResourcesInHold.ComputeMass<ResourceInfo>();

	public float MaxHoldLoad(OpenWorldFlag _007B8017_007D)
	{
		return GetMaxHoldLoad(ReferenceShip, _007B8017_007D);
	}

	public static float GetMaxHoldLoad(PlayerShipInfo _007B8018_007D, OpenWorldFlag _007B8019_007D)
	{
		return MathF.Round(_007B8018_007D.PatCapacity / ((_007B8019_007D == OpenWorldFlag.Peaceful || _007B8019_007D == OpenWorldFlag.PeacefulDisallowed) ? 4f : 1.8f));
	}

	public CapturedShipIntance()
	{
	}

	public CapturedShipIntance(Npc _007B8020_007D, GSI _007B8021_007D, GSI _007B8022_007D, NpcMode _007B8023_007D)
	{
		RepairsCount = 0;
		ResourcesInHold = _007B8021_007D;
		AmmoInHold = _007B8022_007D;
		LastServerUid = _007B8020_007D.uID;
		ReferencePlayerShipId = (byte)_007B8020_007D.UsedShipNpc.Information.BasedOn.ID;
		ReferenceStrength = _007B8020_007D.UsedShipNpc.Information.ShipProperties.MaxHp.Value;
		ReferenceNpcShipId = _007B8020_007D.UsedShipNpc.Information.ID;
		Sync(_007B8020_007D, _007B8023_007D);
	}

	public void Sync(Npc _007B8024_007D, NpcMode _007B8025_007D)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		SavedPosition = _007B8024_007D.Position;
		SavedStrength = Math.Max(1f, _007B8024_007D.UsedShip.firstHP.Summary);
		SavedCrew = _007B8024_007D.UsedShip.Crew.Raw;
		BehaviorMode = _007B8025_007D;
	}

	public void Boxing(WriterExtern _007B8026_007D)
	{
		_007B8026_007D.WriteByte(RepairsCount);
		_007B8026_007D.WriteNoNull<GSI>(ResourcesInHold);
		_007B8026_007D.WriteNoNull<GSI>(AmmoInHold);
		_007B8026_007D.WriteStruct<int>(LastServerUid);
		_007B8026_007D.WriteByte(ReferencePlayerShipId);
		_007B8026_007D.WriteStruct<float>(ReferenceStrength);
		_007B8026_007D.WriteStruct<Vector2>(ref SavedPosition);
		_007B8026_007D.WriteStruct<float>(SavedStrength);
		_007B8026_007D.WriteNoNull<GSI>(SavedCrew);
		_007B8026_007D.WriteStruct<int>(ReferenceNpcShipId);
		_007B8026_007D.Write(SavedOnIsle);
		_007B8026_007D.WriteByte((byte)103);
		_007B8026_007D.WriteByte((byte)BehaviorMode);
	}

	public void Unboxing(WriterExtern _007B8027_007D)
	{
		RepairsCount = _007B8027_007D.ReadByte();
		_007B8027_007D.ReadIMPSNoNull<GSI>(ref ResourcesInHold);
		_007B8027_007D.ReadIMPSNoNull<GSI>(ref AmmoInHold);
		_007B8027_007D.ReadStruct<int>(ref LastServerUid);
		ReferencePlayerShipId = _007B8027_007D.ReadByte();
		_007B8027_007D.ReadStruct<float>(ref ReferenceStrength);
		_007B8027_007D.ReadStruct<Vector2>(ref SavedPosition);
		_007B8027_007D.ReadStruct<float>(ref SavedStrength);
		_007B8027_007D.ReadIMPSNoNull<GSI>(ref SavedCrew);
		_007B8027_007D.ReadStruct<int>(ref ReferenceNpcShipId);
		_007B8027_007D.ReadBoolean(ref SavedOnIsle);
		if (_007B8027_007D.PeekByte() == 103)
		{
			_007B8027_007D.ReadByte();
			BehaviorMode = (NpcMode)_007B8027_007D.ReadByte();
		}
	}
}
