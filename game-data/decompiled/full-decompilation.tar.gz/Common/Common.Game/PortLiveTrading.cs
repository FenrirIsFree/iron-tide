using System;
using System.Collections.Generic;
using Common.Resources;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Helpers;

namespace Common.Game;

public class PortLiveTrading : IMPSerializable
{
	public const bool NewTradingModel = true;

	public GSI CurrentCount;

	internal int PortID;

	public IslePortInfo PortInstance => Gameplay.WorldMap.Ports.Array[PortID];

	public PortLiveTrading(GSI _007B6685_007D, int _007B6686_007D)
	{
		PortID = _007B6686_007D;
		CurrentCount = _007B6685_007D;
	}

	public PortLiveTrading(int _007B6687_007D)
	{
		PortID = _007B6687_007D;
		CurrentCount = PortInstance.LiveTrading.Clone();
	}

	public PortLiveTrading()
	{
	}

	private void _007B6688_007D(int _007B6689_007D, EventActionsPipelineBase _007B6690_007D, out IntegralPricing _007B6691_007D, out float _007B6692_007D)
	{
		float _007B6664_007D = 0.5f;
		float _007B6665_007D = 2.5f;
		if (_007B6689_007D == 5 && _007B6690_007D != null && _007B6690_007D.EventCategoryAmount(EActionCaterory.WaterDrought) > 0f && PortInstance.HasWaterConsumption)
		{
			_007B6664_007D = 1.5f;
			_007B6665_007D = 3.5f;
		}
		int value = Gameplay.ItemsInfo.FromID(_007B6689_007D).MediumCost.Value;
		_007B6691_007D = new IntegralPricing(CurrentCount[_007B6689_007D], value, PortInstance.LiveTrading.GetCount(_007B6689_007D), _007B6664_007D, _007B6665_007D);
		_007B6692_007D = MathF.Round((float)value / 10f, (value <= 10) ? 1 : 0);
		if (_007B6689_007D == 5)
		{
			_007B6692_007D *= 4f;
		}
	}

	private float _007B6693_007D(float _007B6694_007D)
	{
		if (_007B6694_007D > 30f)
		{
			return MathF.Ceiling(_007B6694_007D);
		}
		return MathF.Ceiling(_007B6694_007D * 10f) / 10f;
	}

	private float _007B6695_007D(float _007B6696_007D)
	{
		if (_007B6696_007D > 30f)
		{
			return MathF.Floor(_007B6696_007D);
		}
		return MathF.Floor(_007B6696_007D * 10f) / 10f;
	}

	public void MaxOperationSize(int _007B6697_007D, EventActionsPipelineBase _007B6698_007D, float _007B6699_007D, out int _007B6700_007D, out int _007B6701_007D)
	{
		_007B6688_007D(_007B6697_007D, _007B6698_007D, out var _007B6691_007D, out var _007B6692_007D);
		bool flag = true;
		_007B6691_007D.MaxToBuyOrSellHelper(_007B6692_007D, out _007B6700_007D, out _007B6701_007D);
		_007B6700_007D = Math.Min(_007B6700_007D, _007B6691_007D.MaxCountToBuy(_007B6699_007D));
	}

	public void NowPrice(int _007B6702_007D, EventActionsPipelineBase _007B6703_007D, out float _007B6704_007D, out float _007B6705_007D)
	{
		_007B6688_007D(_007B6702_007D, _007B6703_007D, out var _007B6691_007D, out var _007B6692_007D);
		bool flag = true;
		_007B6704_007D = _007B6693_007D(_007B6691_007D.PriceFunction() + _007B6692_007D * 0.5f);
		_007B6705_007D = _007B6695_007D(_007B6691_007D.PriceFunction() - _007B6692_007D * 0.5f);
	}

	private int _007B6706_007D(int _007B6707_007D, int _007B6708_007D, EventActionsPipelineBase _007B6709_007D)
	{
		_007B6688_007D(_007B6707_007D, _007B6709_007D, out var _007B6691_007D, out var _);
		double num = _007B6691_007D.Integral(CurrentCount[_007B6707_007D], Math.Max(0, CurrentCount[_007B6707_007D] + _007B6708_007D));
		if (_007B6708_007D < 0)
		{
			return (int)Math.Ceiling(num);
		}
		return (int)Math.Floor(num);
	}

	public int TotalPrice(int _007B6710_007D, int _007B6711_007D, EventActionsPipelineBase _007B6712_007D)
	{
		bool flag = true;
		NowPrice(_007B6710_007D, _007B6712_007D, out var _007B6704_007D, out var _007B6705_007D);
		float num = _007B6704_007D * (float)(-_007B6711_007D);
		float num2 = _007B6705_007D * (float)_007B6711_007D;
		if (_007B6711_007D < 0)
		{
			return (int)Math.Ceiling(num);
		}
		return (int)Math.Floor(num2);
	}

	public void Shuffle(bool _007B6713_007D)
	{
		foreach (GSILocalPair item in (IEnumerable<GSILocalPair>)PortInstance.LiveTrading)
		{
			if (_007B6713_007D)
			{
				int count = item.Count;
				int count2 = CurrentCount.GetCount(item.ID);
				int num = (int)((float)(count * Rand.Sign()) * Rand.Range(0.1f, 0.15f));
				int num2 = count2 + num;
				if (num2 > count / 2 && num2 < count * 2)
				{
					CurrentCount[item.ID] = num2;
				}
			}
			else if (Rand.Chanse(75f))
			{
				CurrentCount[item.ID] = (int)((float)CurrentCount.GetCount(item.ID) * Rand.Range(0.6f, 1.2f));
			}
		}
	}

	public void MultiplyCount(float _007B6714_007D)
	{
		GSI gSI = CurrentCount.Clone();
		foreach (GSILocalEnumerablePair<ResourceInfo> item in (IEnumerable<GSILocalEnumerablePair<ResourceInfo>>)gSI.ResourceInfo/*cast due to .constrained prefix*/)
		{
			ResourceInfo info = item.Info;
			int count = CurrentCount.GetCount(info.ID);
			if (count > 0)
			{
				CurrentCount[info.ID] = Rand.Round(_007B6714_007D * (float)count);
			}
		}
	}

	public void ConsumeResources(float _007B6715_007D)
	{
		GSI gSI = CurrentCount.Clone();
		foreach (GSILocalEnumerablePair<ResourceInfo> item in (IEnumerable<GSILocalEnumerablePair<ResourceInfo>>)gSI.ResourceInfo/*cast due to .constrained prefix*/)
		{
			ResourceInfo info = item.Info;
			int count = CurrentCount.GetCount(info.ID);
			if (count > 0)
			{
				CurrentCount.AddOrRemove(info.ID, -Math.Min(Rand.Round((float)PortInstance.LiveTrading.GetCount(info.ID) * _007B6715_007D), count));
			}
		}
	}

	private void _007B6716_007D(WriterExtern _007B6717_007D)
	{
		_007B6717_007D.WriteByte((byte)PortID);
		_007B6717_007D.Write<GSI>(CurrentCount);
	}

	private void _007B6718_007D(WriterExtern _007B6719_007D)
	{
		PortID = _007B6719_007D.ReadByte();
		_007B6719_007D.ReadIMPS<GSI>(ref CurrentCount);
	}
}
