using System;
using System.Runtime.CompilerServices;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;

namespace Common.Game;

public class WeatherArea : IMPSerializable
{
	public Vector2 CurrentPosition;

	public Vector2 VelocityDirection;

	public float WInternalRadius;

	private float _007B5914_007D;

	public float WExternalRadius;

	private float _007B5915_007D;

	public float SInternalRadius;

	private float _007B5916_007D;

	public float SExternalRadius;

	private float _007B5917_007D;

	public WeatherAreaType Type;

	public WeatherArea()
	{
	}

	public WeatherArea(Vector2 _007B5901_007D, Vector2 _007B5902_007D, float _007B5903_007D, float _007B5904_007D, WeatherAreaType _007B5905_007D)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		CurrentPosition = _007B5901_007D;
		VelocityDirection = _007B5902_007D;
		WInternalRadius = _007B5903_007D;
		WExternalRadius = _007B5904_007D;
		_007B5914_007D = WInternalRadius * WInternalRadius;
		_007B5915_007D = WExternalRadius * WExternalRadius;
		SInternalRadius = WInternalRadius * 0.5f;
		SExternalRadius = WExternalRadius * 0.5f;
		_007B5916_007D = SInternalRadius * SInternalRadius;
		_007B5917_007D = SExternalRadius * SExternalRadius;
		Type = _007B5905_007D;
	}

	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	internal float IntensityRaining(Vector2 _007B5906_007D)
	{
		if (Type == WeatherAreaType.Storm)
		{
			float num = default(float);
			Vector2.DistanceSquared(ref CurrentPosition, ref _007B5906_007D, ref num);
			if (num < _007B5915_007D)
			{
				if (num < _007B5916_007D)
				{
					return 1f;
				}
				num = MathF.Sqrt(num);
				return 1f - (num - SInternalRadius) / (WExternalRadius - SInternalRadius);
			}
		}
		return 0f;
	}

	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	internal float IntensityWind(Vector2 _007B5907_007D)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		if (Type == WeatherAreaType.Storm)
		{
			return IntensityExternalRadius(_007B5907_007D);
		}
		return 0f;
	}

	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	internal float IntensityFog(Vector2 _007B5908_007D)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		if (Type == WeatherAreaType.Fog)
		{
			return IntensityExternalRadius(_007B5908_007D);
		}
		return 0f;
	}

	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	internal float IntensityExternalRadius(Vector2 _007B5909_007D)
	{
		float num = default(float);
		Vector2.DistanceSquared(ref CurrentPosition, ref _007B5909_007D, ref num);
		if (num < _007B5915_007D)
		{
			if (num < _007B5914_007D)
			{
				return 1f;
			}
			num = MathF.Sqrt(num);
			return 1f - (num - WInternalRadius) / (WExternalRadius - WInternalRadius);
		}
		return 0f;
	}

	private void _007B5910_007D(WriterExtern _007B5911_007D)
	{
		_007B5911_007D.WriteStruct<Vector2>(ref CurrentPosition);
		_007B5911_007D.WriteStruct<Vector2>(ref VelocityDirection);
		_007B5911_007D.WriteStruct<float>(ref WInternalRadius);
		_007B5911_007D.WriteStruct<float>(ref WExternalRadius);
		_007B5911_007D.WriteByte((byte)Type);
	}

	private void _007B5912_007D(WriterExtern _007B5913_007D)
	{
		_007B5913_007D.ReadStruct<Vector2>(ref CurrentPosition);
		_007B5913_007D.ReadStruct<Vector2>(ref VelocityDirection);
		_007B5913_007D.ReadStruct<float>(ref WInternalRadius);
		_007B5913_007D.ReadStruct<float>(ref WExternalRadius);
		_007B5914_007D = WInternalRadius * WInternalRadius;
		_007B5915_007D = WExternalRadius * WExternalRadius;
		SInternalRadius = WInternalRadius * 0.5f;
		SExternalRadius = WExternalRadius * 0.5f;
		_007B5916_007D = SInternalRadius * SInternalRadius;
		_007B5917_007D = SExternalRadius * SExternalRadius;
		Type = (WeatherAreaType)_007B5913_007D.ReadByte();
	}
}
