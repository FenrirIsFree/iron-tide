using System;
using System.Collections.Generic;
using System.Linq;
using Common.Resources;
using CommonDataTypes;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Graphics.Models;

namespace Common.Game;

public class FactoryPlaceIsleInfo : IsleInstance
{
	public readonly int FcID;

	public Tlist<FactoryType> Predefines;

	private bool _007B8445_007D = false;

	public readonly FenceSphereStruct InteropZone;

	public readonly Tlist<(Vector3 pos, int size)> ConnectionsPersonalIsleDecor;

	public bool IsHidden => Gameplay.WorldMap.Shallows.Get(in GlobalPosition) >= 6 && Predefines.FirstOrDefault() == FactoryType.Temp_PersonalIsle;

	public static FactoryType FactoryNameToType(string _007B8434_007D)
	{
		if (_007B8434_007D.Contains("factory_ice"))
		{
			return FactoryType.NIceFactory;
		}
		if (_007B8434_007D.Contains("factory_copper"))
		{
			return FactoryType.NCopperMine;
		}
		if (_007B8434_007D.Contains("factory_farm"))
		{
			return FactoryType.NFarm;
		}
		if (_007B8434_007D.Contains("factory_iron"))
		{
			return FactoryType.NIronMine;
		}
		if (_007B8434_007D.Contains("factory_resin"))
		{
			return FactoryType.NResinFactory;
		}
		if (_007B8434_007D.Contains("factory_rum"))
		{
			return FactoryType.NRumFactory;
		}
		if (_007B8434_007D.Contains("factory_wood"))
		{
			return FactoryType.NWoodcutter;
		}
		if (_007B8434_007D.Contains("factory_mhidden"))
		{
			return FactoryType.NUnderground;
		}
		if (_007B8434_007D.Contains("factory_coal"))
		{
			return FactoryType.NCoalMine;
		}
		throw new NotSupportedException();
	}

	public static Tlist<FactoryType> ParsePath(string _007B8435_007D)
	{
		if (_007B8435_007D.Contains("fc_buildings_all"))
		{
			throw new NotSupportedException();
		}
		if (_007B8435_007D.Contains("personal_isle"))
		{
			return new Tlist<FactoryType>().AddFirst(FactoryType.Temp_PersonalIsle);
		}
		if (_007B8435_007D.Contains("factory_"))
		{
			return new Tlist<FactoryType>().AddFirst(FactoryNameToType(_007B8435_007D));
		}
		return null;
	}

	public static bool ParsePath(string _007B8436_007D, out Tlist<FactoryType> _007B8437_007D)
	{
		_007B8437_007D = ParsePath(_007B8436_007D);
		return _007B8437_007D != null;
	}

	public FactoryPlaceIsleInfo(int _007B8438_007D, IsleInfoToken _007B8439_007D, IsleModelInfo _007B8440_007D, WorldMapInfo _007B8441_007D, Tlist<FactoryType> _007B8442_007D)
		: base(WorldObjectID.WSomeObject, _007B8439_007D, _007B8441_007D, _007B8440_007D, _007B8439_007D.Terrain, _007B8439_007D)
	{
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		FcID = _007B8438_007D;
		Predefines = _007B8442_007D;
		if (ModelData.IsEmptyShapeModel && _007B8442_007D.Array[0] != FactoryType.Temp_PersonalIsle)
		{
			throw new InvalidOperationException();
		}
		_007B8445_007D = Predefines.First() == FactoryType.Temp_PersonalIsle;
		if (Predefines.First() == FactoryType.NIceFactory)
		{
			InteropZone = new FenceSphereStruct(GlobalTransform.Transform3X3(new Vector3(0f, 0f, 0f)).XZ(), 35f);
		}
		else
		{
			InteropZone = new FenceSphereStruct(GlobalTransform.Transform3X3(new Vector3(-50.27f, 0f, 11.576f)).XZ(), 35f);
		}
		if (_007B8445_007D)
		{
			ConnectionsPersonalIsleDecor = new Tlist<(Vector3, int)>(from _007B8447_007D in ModelData.Connections
				where _007B8447_007D.Key.Contains("Decor")
				select (Center: _007B8447_007D.Value.CommonSphere.Center, _007B8447_007D.Key.Contains("smallType") ? 1 : (_007B8447_007D.Key.Contains("midType") ? 2 : 3)));
			for (int num = 0; num < ConnectionsPersonalIsleDecor.Size; num++)
			{
				ConnectionsPersonalIsleDecor.Array[num].pos.Y = Math.Max(0f, ConnectionsPersonalIsleDecor.Array[num].pos.Y);
			}
		}
	}

	public bool ContainsInteropZone(in Vector2 _007B8443_007D, float _007B8444_007D = 0f)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		_007B8444_007D += InteropZone.R;
		return Vector2.DistanceSquared(InteropZone.C, _007B8443_007D) < _007B8444_007D * _007B8444_007D;
	}
}
