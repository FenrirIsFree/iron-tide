using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class GroupMemberInfo : IMPSerializable
{
	public int UID;

	public uint AccountSID;

	public string Name;

	public GroupMemberInfo(int _007B5984_007D, uint _007B5985_007D, string _007B5986_007D)
	{
		UID = _007B5984_007D;
		AccountSID = _007B5985_007D;
		Name = _007B5986_007D;
	}

	public GroupMemberInfo()
	{
	}

	private void _007B5987_007D(WriterExtern _007B5988_007D)
	{
		_007B5988_007D.WriteStruct<int>(ref UID);
		_007B5988_007D.WriteStruct<uint>(ref AccountSID);
		_007B5988_007D.Write(Name, (Encoding)null);
	}

	private void _007B5989_007D(WriterExtern _007B5990_007D)
	{
		_007B5990_007D.ReadStruct<int>(ref UID);
		_007B5990_007D.ReadStruct<uint>(ref AccountSID);
		_007B5990_007D.ReadString(ref Name, (Encoding)null);
	}
}
