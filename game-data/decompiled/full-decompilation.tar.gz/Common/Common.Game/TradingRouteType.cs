namespace Common.Game;

public enum TradingRouteType
{
	None,
	Main,
	Coastal,
	Supply,
	Central,
	Smuggling
}
