using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;
using TheraEngine.PacketValues;

namespace Common.Game;

public class GuildRatingInfo : IMPSerializable
{
	public struct Item : IMPSerializable
	{
		public string Tag;

		public string Name;

		public ushort RatingPoints;

		public byte CapturedPorts;

		public FractionID Fraction;

		public byte HQQuantity;

		public byte MembersCount;

		public byte PotentialTitleId;

		public byte DisputeProtectionDays;

		private Bits8 _007B6639_007D;

		public bool IsNewGuild => _007B6639_007D[0];

		public bool HasReceivedDispute => _007B6639_007D[1];

		public bool ActiveForNewPlayers => _007B6639_007D[3];

		public bool IsFlotilia => _007B6639_007D[4];

		public bool ProbablyCISGuild => _007B6639_007D[5];

		public Item(string _007B6623_007D, string _007B6624_007D, int _007B6625_007D, byte _007B6626_007D, FractionID _007B6627_007D, byte _007B6628_007D, byte _007B6629_007D, bool _007B6630_007D, bool _007B6631_007D, bool _007B6632_007D, bool _007B6633_007D, byte _007B6634_007D)
		{
			HQQuantity = 0;
			Tag = _007B6623_007D;
			Name = _007B6624_007D;
			RatingPoints = (ushort)_007B6625_007D;
			CapturedPorts = _007B6626_007D;
			Fraction = _007B6627_007D;
			MembersCount = _007B6628_007D;
			PotentialTitleId = _007B6629_007D;
			_007B6639_007D = default(Bits8);
			_007B6639_007D[0] = _007B6630_007D;
			_007B6639_007D[1] = _007B6631_007D;
			_007B6639_007D[3] = _007B6632_007D;
			_007B6639_007D[4] = CommonSupport.IsGuildFlotilia(_007B6627_007D);
			_007B6639_007D[5] = _007B6633_007D;
			DisputeProtectionDays = _007B6634_007D;
		}

		private void _007B6635_007D(WriterExtern _007B6636_007D)
		{
			_007B6636_007D.Write(Tag, (Encoding)null);
			_007B6636_007D.Write(Name, Encoding.UTF8);
			_007B6636_007D.WriteStruct<ushort>(RatingPoints);
			_007B6636_007D.WriteByte(CapturedPorts);
			_007B6636_007D.WriteByte((byte)Fraction);
			_007B6636_007D.WriteByte(_007B6639_007D.Value);
			_007B6636_007D.WriteByte(MembersCount);
			_007B6636_007D.WriteByte(PotentialTitleId);
			_007B6636_007D.WriteByte(DisputeProtectionDays);
		}

		private void _007B6637_007D(WriterExtern _007B6638_007D)
		{
			_007B6638_007D.ReadString(ref Tag, (Encoding)null);
			_007B6638_007D.ReadString(ref Name, Encoding.UTF8);
			_007B6638_007D.ReadStruct<ushort>(ref RatingPoints);
			CapturedPorts = _007B6638_007D.ReadByte();
			Fraction = (FractionID)_007B6638_007D.ReadByte();
			_007B6639_007D.Value = _007B6638_007D.ReadByte();
			MembersCount = _007B6638_007D.ReadByte();
			PotentialTitleId = _007B6638_007D.ReadByte();
			DisputeProtectionDays = _007B6638_007D.ReadByte();
		}

		public override int GetHashCode()
		{
			return Tag.GetHashCode();
		}
	}

	public Tlist<Item> Data;

	public GuildRatingInfo(Tlist<Item> _007B6606_007D)
	{
		Data = _007B6606_007D;
	}

	public GuildRatingInfo()
	{
	}

	private void _007B6607_007D(WriterExtern _007B6608_007D)
	{
		_007B6608_007D.WriteTlistStruct<Item>(Data);
	}

	private void _007B6609_007D(WriterExtern _007B6610_007D)
	{
		_007B6610_007D.ReadTlistStruct<Item>(out Data);
	}
}
