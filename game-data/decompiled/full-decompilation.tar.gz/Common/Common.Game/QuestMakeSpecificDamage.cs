namespace Common.Game;

public class QuestMakeSpecificDamage : QuestStepHeader
{
	public int Count;

	public readonly DamageID? SourcePawnType;

	public readonly SpecificDamageFlags Flags;

	public readonly bool OnePerShip;

	public readonly bool OnlyWorldMap;

	public override int ProgressComparand => Count;

	public QuestMakeSpecificDamage(string _007B7659_007D, int _007B7660_007D, DamageID? _007B7661_007D, SpecificDamageFlags _007B7662_007D = SpecificDamageFlags.None, bool _007B7663_007D = false, bool _007B7664_007D = true, TargetShipForQuest? _007B7665_007D = null)
		: base(_007B7659_007D, _007B7665_007D)
	{
		Count = _007B7660_007D;
		SourcePawnType = _007B7661_007D;
		Flags = _007B7662_007D;
		OnePerShip = _007B7663_007D;
		OnlyWorldMap = _007B7664_007D;
	}
}
