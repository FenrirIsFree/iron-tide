using System;
using System.Text;
using Common.Packets;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct GuildActionLogRecord : IMPSerializable
{
	public enum Reason
	{
		MemberAccepted,
		MemberRemoved,
		MemberLeftGuild,
		MemberRulesChanged,
		TreasuryIncreased,
		MintDecreased,
		WarDeclared,
		WarRemoed,
		FortWindowChanged,
		FortNewFactoryOpened,
		FortUpgraded,
		TrustedGuildAdded,
		TrustedGuildRemoved,
		PortEdictTaken,
		OnFractionChanged,
		InviteRejected,
		MintAddByPort,
		MintAddByRobbing,
		MemberRemovedByReputation,
		SeasonTitleReward,
		OpenTradeHq,
		OnFractionChangedByKick,
		DisputeVoting,
		Custom
	}

	public SlimDateTimeInfo LogTime;

	public uint SID;

	public Reason ActionReason;

	public string ActionInfo;

	public int Parameter;

	public GuildActionLogRecord(DateTime _007B6260_007D, uint _007B6261_007D, Reason _007B6262_007D, string _007B6263_007D = "", int _007B6264_007D = 0)
	{
		LogTime = new SlimDateTimeInfo(_007B6260_007D);
		SID = _007B6261_007D;
		ActionReason = _007B6262_007D;
		ActionInfo = _007B6263_007D;
		Parameter = _007B6264_007D;
	}

	private void _007B6265_007D(WriterExtern _007B6266_007D)
	{
		_007B6266_007D.WriteStruct<SlimDateTimeInfo>(ref LogTime);
		_007B6266_007D.WriteStruct<uint>(ref SID);
		_007B6266_007D.WriteStruct<Reason>(ref ActionReason);
		_007B6266_007D.Write(ActionInfo, (Encoding)null);
		_007B6266_007D.WriteStruct<int>(Parameter);
	}

	private void _007B6267_007D(WriterExtern _007B6268_007D)
	{
		_007B6268_007D.ReadStruct<SlimDateTimeInfo>(ref LogTime);
		_007B6268_007D.ReadStruct<uint>(ref SID);
		_007B6268_007D.ReadStruct<Reason>(ref ActionReason);
		_007B6268_007D.ReadString(ref ActionInfo, (Encoding)null);
		_007B6268_007D.ReadStruct<int>(ref Parameter);
	}

	public override string ToString()
	{
		string text = "%";
		switch (ActionReason)
		{
		case Reason.MemberAccepted:
			return Local.guildLog_MemberAccepted(text, ActionInfo);
		case Reason.MemberRemoved:
			return Local.guildLog_MemberRemoved(text, ActionInfo);
		case Reason.MemberLeftGuild:
			return Local.guildLog_MemberLeftGuild(ActionInfo);
		case Reason.MemberRulesChanged:
			return Local.guildLog_MemberRulesChanged(text, ActionInfo, _007B6269_007D());
		case Reason.TreasuryIncreased:
			return Local.guildLog_TreasuryIncreased(text, Parameter);
		case Reason.MintDecreased:
			return Local.guildLog_MintDecreased(text, ActionInfo, Parameter);
		case Reason.WarDeclared:
			return Local.guildLog_WarDeclared(text, ActionInfo);
		case Reason.WarRemoed:
			return Local.guildLog_WarRemoed(text, ActionInfo);
		case Reason.FortWindowChanged:
			return Local.guildLog_FortWindowChanged(text, ActionInfo);
		case Reason.FortNewFactoryOpened:
			return Local.guildLog_FortNewFactoryOpened(text, _007B6270_007D());
		case Reason.FortUpgraded:
			return Local.guildLog_FortUpgraded(text, _007B6270_007D());
		case Reason.OnFractionChanged:
			return Local.guildLog_OnFractionChanged(text, ((FractionID)Parameter).GetName());
		case Reason.OnFractionChangedByKick:
			return Local.guildLog_OnFractionChangedByKick(((FractionID)Parameter).GetName());
		case Reason.PortEdictTaken:
		{
			string _007B555_007D = string.Empty;
			if (int.TryParse(ActionInfo, out var _))
			{
				_007B555_007D = (OnBuildingGuildOperationMsg.OpType)int.Parse(ActionInfo) switch
				{
					OnBuildingGuildOperationMsg.OpType.BuyBoostFactory => Local.GuidFortManagingUi_boostFactory, 
					OnBuildingGuildOperationMsg.OpType.BuyTensityProtection => Local.guild_protection_title, 
					_ => "", 
				};
			}
			return Local.guildLog_PortEdictTaken(text, _007B555_007D, _007B6270_007D());
		}
		case Reason.TrustedGuildAdded:
			return Local.guildLog_TrustedGuildAdded(text, ActionInfo);
		case Reason.TrustedGuildRemoved:
			return Local.guildLog_TrustedGuildRemoved(text, ActionInfo);
		case Reason.InviteRejected:
			return Local.guildLog_InviteRejected(text, ActionInfo);
		case Reason.MintAddByPort:
			return Local.guildLog_MintAddByPort(ActionInfo, _007B6270_007D());
		case Reason.MintAddByRobbing:
			return Local.guildLog_MintAddByRobbing(ActionInfo, _007B6270_007D());
		case Reason.MemberRemovedByReputation:
			return Local.guildLog_MemberRemovedByReputation(ActionInfo);
		case Reason.SeasonTitleReward:
			return Local.guildLog_SeasonTitleReward(Gameplay.GuildTitles[Parameter].Name, ActionInfo);
		case Reason.OpenTradeHq:
			return Local.guildLog_OpenTradeHq(text, _007B6270_007D());
		case Reason.DisputeVoting:
			return Local.guildLog_DisputeVoting(text, ActionInfo);
		case Reason.Custom:
			return ActionInfo;
		default:
			throw new NotSupportedException();
		}
	}

	private string _007B6269_007D()
	{
		try
		{
			return GuildAccessRightsInfo.AllRights[Parameter].DisplayName;
		}
		catch
		{
			return "undefined";
		}
	}

	private string _007B6270_007D()
	{
		try
		{
			return Gameplay.WorldMap.Ports.Array[Parameter].PortName;
		}
		catch
		{
			return "undefined";
		}
	}

	public string ToString(GuildCommon _007B6271_007D)
	{
		GuildMember member = _007B6271_007D.GetMember(SID);
		string newValue = ((member == null) ? Local.guildLog_removedMember : member.Cached.Name);
		return ToString().Replace("%", newValue);
	}
}
