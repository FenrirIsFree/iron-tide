using System;

namespace Common.Game;

public struct ResuideCounter
{
	private float _007B3574_007D;

	public int Add(float _007B3573_007D)
	{
		_007B3574_007D += _007B3573_007D;
		int num = (int)Math.Floor(_007B3574_007D);
		_007B3574_007D -= num;
		return num;
	}

	public void Reset()
	{
		_007B3574_007D = 0f;
	}
}
