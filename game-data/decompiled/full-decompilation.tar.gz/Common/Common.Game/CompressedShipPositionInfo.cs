using System;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;
using TheraEngine.PacketValues;

namespace Common.Game;

public struct CompressedShipPositionInfo : IMPSerializable
{
	private ByteAngle _007B5207_007D;

	private short _007B5208_007D;

	private short _007B5209_007D;

	public Vector2 Position => new Vector2((float)_007B5208_007D, (float)_007B5209_007D) / 32767f * Gameplay.WorldMapSizeXY;

	public float Rotation => _007B5207_007D.Angle;

	public CompressedShipPositionInfo(Vector2 _007B5201_007D, float _007B5202_007D)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		_007B5207_007D = new ByteAngle(_007B5202_007D);
		_007B5201_007D = _007B5201_007D / Gameplay.WorldMapSizeXY * 32767f;
		_007B5208_007D = (short)Math.Max(-32768.0, Math.Min(Math.Round(_007B5201_007D.X), 32767.0));
		_007B5209_007D = (short)Math.Max(-32768.0, Math.Min(Math.Round(_007B5201_007D.Y), 32767.0));
	}

	private void _007B5203_007D(WriterExtern _007B5204_007D)
	{
		_007B5204_007D.WriteByte(_007B5207_007D.RawValue);
		_007B5204_007D.WriteStruct<short>(_007B5208_007D);
		_007B5204_007D.WriteStruct<short>(_007B5209_007D);
	}

	private void _007B5205_007D(WriterExtern _007B5206_007D)
	{
		_007B5207_007D.RawValue = _007B5206_007D.ReadByte();
		_007B5206_007D.ReadStruct<short>(ref _007B5208_007D);
		_007B5206_007D.ReadStruct<short>(ref _007B5209_007D);
	}
}
