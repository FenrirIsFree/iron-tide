using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading;
using TheraEngine.Collections;

namespace Common.Game;

public abstract class EventActionsPipelineBase
{
	protected internal Tlist<EventActionBase> actions;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private Action _007B6221_007D;

	private float[] _007B6222_007D;

	private readonly int _007B6223_007D;

	public event Action StateChanged
	{
		[CompilerGenerated]
		add
		{
			Action action = _007B6221_007D;
			Action action2;
			do
			{
				action2 = action;
				Action value2 = (Action)Delegate.Combine(action2, value);
				action = Interlocked.CompareExchange(ref _007B6221_007D, value2, action2);
			}
			while ((object)action != action2);
		}
		[CompilerGenerated]
		remove
		{
			Action action = _007B6221_007D;
			Action action2;
			do
			{
				action2 = action;
				Action value2 = (Action)Delegate.Remove(action2, value);
				action = Interlocked.CompareExchange(ref _007B6221_007D, value2, action2);
			}
			while ((object)action != action2);
		}
	}

	public EventActionsPipelineBase()
	{
		actions = new Tlist<EventActionBase>(8);
		_007B6222_007D = new float[_007B6223_007D = Enum.GetValues(typeof(EActionCaterory)).Length];
	}

	protected void Add(EventActionBase _007B6216_007D)
	{
		actions.Add(in _007B6216_007D);
		OnStateChanged();
	}

	protected void Remove(int _007B6217_007D)
	{
		for (int i = 0; i < actions.Size; i++)
		{
			if (actions.Array[i].AID == _007B6217_007D)
			{
				actions.RemoveAt(i);
				OnStateChanged();
				break;
			}
		}
	}

	protected void RemoveFromIndex(int _007B6218_007D)
	{
		actions.RemoveAt(_007B6218_007D);
		OnStateChanged();
	}

	protected void ClearAll()
	{
		actions.Clear();
		OnStateChanged();
	}

	protected virtual void OnStateChanged()
	{
		for (int i = 0; i < _007B6223_007D; i++)
		{
			_007B6222_007D[i] = 0f;
		}
		for (int j = 0; j < actions.Size; j++)
		{
			EventActionBase eventActionBase = actions.Array[j];
			if (eventActionBase.Behavior is EABehavior1 eABehavior)
			{
				_007B6222_007D[(int)eABehavior.Category] += eABehavior.Amount / 100f;
			}
		}
		_007B6221_007D?.Invoke();
	}

	public float EventCategoryAmount(EActionCaterory _007B6219_007D)
	{
		return _007B6222_007D[(int)_007B6219_007D];
	}

	public EABehavior1 GetActionBehavior1(EActionCaterory _007B6220_007D)
	{
		foreach (EventActionBase item in (IEnumerable<EventActionBase>)actions)
		{
			if (item.Behavior is EABehavior1 eABehavior && eABehavior.Category == _007B6220_007D)
			{
				return eABehavior;
			}
		}
		return null;
	}
}
