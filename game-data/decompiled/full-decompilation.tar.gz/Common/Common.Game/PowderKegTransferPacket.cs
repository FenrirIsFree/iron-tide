using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;

namespace Common.Game;

public struct PowderKegTransferPacket : IMPSerializable
{
	public byte InfoID;

	public Vector2 NowPosition;

	public Vector2 DriftingSpeed;

	public float Ttl;

	public float TtlInit;

	public int uID;

	public int SourceUID;

	private void _007B5673_007D(WriterExtern _007B5674_007D)
	{
		_007B5674_007D.WriteByte(InfoID);
		_007B5674_007D.WriteStruct<Vector2>(ref NowPosition);
		_007B5674_007D.WriteStruct<Vector2>(ref DriftingSpeed);
		_007B5674_007D.WriteStruct<float>(ref TtlInit);
		_007B5674_007D.WriteStruct<float>(ref Ttl);
		_007B5674_007D.WriteStruct<int>(ref uID);
		_007B5674_007D.WriteStruct<int>(ref SourceUID);
	}

	private void _007B5675_007D(WriterExtern _007B5676_007D)
	{
		InfoID = _007B5676_007D.ReadByte();
		_007B5676_007D.ReadStruct<Vector2>(ref NowPosition);
		_007B5676_007D.ReadStruct<Vector2>(ref DriftingSpeed);
		_007B5676_007D.ReadStruct<float>(ref TtlInit);
		_007B5676_007D.ReadStruct<float>(ref Ttl);
		_007B5676_007D.ReadStruct<int>(ref uID);
		_007B5676_007D.ReadStruct<int>(ref SourceUID);
	}
}
