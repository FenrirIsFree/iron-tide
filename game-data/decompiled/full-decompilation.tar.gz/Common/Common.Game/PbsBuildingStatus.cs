using System;
using System.Collections.Generic;
using System.Linq;
using Common.Data;
using Common.Resources;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class PbsBuildingStatus : IMPSerializable
{
	public PbsStatus InPbsStatus;

	public byte PlaceIDInPort = byte.MaxValue;

	public InitialDynamicBuildingId CustomizationModel;

	public float Strength;

	public GSI HoldResources;

	public GSI HoldCannonBalls;

	public byte CurrentSelectedCannonsBalls;

	public byte CurrentSelectedWeapons;

	public GSI LiveUnits;

	public bool Server_CapturedByAttacker;

	public int uIDDynamicServerBuild;

	internal bool broken_Place_Old;

	public PbsBuildingPlaceInfo Place => InPbsStatus.PortInstance.PbSystem[PlaceIDInPort];

	public byte DynamicModelIndex => (byte)(Gameplay.DyanmicBuildingsDictionary[(Place.GroupID == WorldObjectID.WGuildFort) ? InitialDynamicBuildingId.FortMain : CustomizationModel].Array[0].TableID + ((Place.GroupID == WorldObjectID.WGuildFort) ? InPbsStatus.FortLevelInfo.ModelIndex : InPbsStatus.TowerLevelInfo.ModelIndex));

	public bool IsFort => CustomizationModel == InitialDynamicBuildingId.FortMain;

	public bool IsTower => !IsFort;

	public DynamicBuildingInfo DynamicModel => Gameplay.DyanmicBuildingsTable.Array[DynamicModelIndex];

	public PbsTowerDescription TowerWeapons => WosbPbs.TowerDesription[CustomizationModel];

	public string UiName => (Place.GroupID == WorldObjectID.WGuildFort) ? Local.fort : WosbPbs.TowerNameByIndex(CustomizationModel);

	public int TowerNumber
	{
		get
		{
			int num = 0;
			foreach (KeyValuePair<int, PbsBuildingPlaceInfo> item in InPbsStatus.PortInstance.PbSystem)
			{
				if (item.Value.GroupID == WorldObjectID.WGuildFortTower)
				{
					num++;
					if (item.Value == Place)
					{
						return num;
					}
				}
			}
			return -1;
		}
	}

	public float MaxStrength => WosbPbs.CalculateBuildingStrength(InPbsStatus.PortInstance, InPbsStatus.Dev.PortLevel, CustomizationModel != InitialDynamicBuildingId.FortMain);

	public float HpFactor => Strength / MaxStrength;

	public int MaxUnitsCount => WosbPbs.UnitsCount(Place.AssociatedPort);

	public bool AllowBoardingUnits => IsFort;

	public float AttackTimerMaxDistance(PbsStatus _007B7790_007D)
	{
		return ((CustomizationModel == InitialDynamicBuildingId.FortTowerMortar || CustomizationModel == InitialDynamicBuildingId.FortTowerFire) ? TowerWeapons.MaxDistance : Gameplay.CannonsGameInfo.FromID(_007B7790_007D.FirstFort().CurrentSelectedWeapons).MaxDistance) + DynamicModel.Model.ShapeModelBs.Radius * 0.246f;
	}

	public bool ServerAllowBoardingUnitsNow(PbsStatus _007B7791_007D)
	{
		return AllowBoardingUnits && Strength == 0f && _007B7791_007D.Buildings.Count((PbsBuildingStatus _007B7800_007D) => _007B7800_007D.Strength > 0f && !_007B7800_007D.Server_CapturedByAttacker && _007B7800_007D.IsTower) == 0;
	}

	public bool ServerAllowRonbbingNow(PbsStatus _007B7792_007D)
	{
		if (IsTower || ServerAllowBoardingUnitsNow(_007B7792_007D))
		{
			return false;
		}
		int num = _007B7792_007D.Buildings.Count((PbsBuildingStatus _007B7801_007D) => (_007B7801_007D.Strength == 0f || _007B7801_007D.Server_CapturedByAttacker) && _007B7801_007D.IsTower);
		int num2 = _007B7792_007D.Buildings.Count((PbsBuildingStatus _007B7802_007D) => _007B7802_007D.IsTower) / 2;
		if (num < num2)
		{
			return false;
		}
		return Strength == 0f;
	}

	public PbsBuildingStatus()
	{
	}

	public PbsBuildingStatus(int _007B7793_007D, int _007B7794_007D, PbsStatus _007B7795_007D)
	{
		InPbsStatus = _007B7795_007D;
		PlaceIDInPort = (byte)_007B7793_007D;
		Strength = MaxStrength;
		if (Place.GroupID == WorldObjectID.WGuildFort)
		{
			HoldResources = new GSI();
			HoldCannonBalls = new GSI();
			HoldResources.AddOrRemove(4, 1000);
			HoldResources.AddOrRemove(1, 1000);
			HoldResources.AddOrRemove(2, 100);
			HoldResources.AddOrRemove(10, 100);
			HoldCannonBalls.AddOrRemove(1, 10000);
			CustomizationModel = InitialDynamicBuildingId.FortMain;
		}
		else
		{
			CustomizationModel = ((_007B7794_007D % 2 == 0) ? InitialDynamicBuildingId.FortTowerCannons : InitialDynamicBuildingId.FortTowerMortar);
		}
		if (AllowBoardingUnits)
		{
			LiveUnits = new GSI();
			LiveUnits.AddOrRemove(2, MaxUnitsCount);
		}
		CheckWeapons();
	}

	private void _007B7796_007D(WriterExtern _007B7797_007D)
	{
		if (uIDDynamicServerBuild <= 0)
		{
			throw new InvalidOperationException("PortWarBuildingStatus UID not setted!");
		}
		_007B7797_007D.WriteByte(PlaceIDInPort);
		_007B7797_007D.WriteStruct<float>(Strength);
		_007B7797_007D.WriteByte((byte)CustomizationModel);
		if (AllowBoardingUnits)
		{
			_007B7797_007D.WriteNoNull<GSI>(LiveUnits);
		}
		object customParameter = _007B7797_007D.CustomParameter;
		if (customParameter is PortStatusAccessLevel && (PortStatusAccessLevel)customParameter == PortStatusAccessLevel.BuildingsOnlyPosition)
		{
			_007B7797_007D.WriteByte((byte)0);
			_007B7797_007D.Write(Server_CapturedByAttacker);
		}
		else
		{
			_007B7797_007D.WriteByte(byte.MaxValue);
			_007B7797_007D.Write<GSI>(HoldResources);
			_007B7797_007D.Write<GSI>(HoldCannonBalls);
			_007B7797_007D.WriteByte(CurrentSelectedCannonsBalls);
			_007B7797_007D.WriteByte(CurrentSelectedWeapons);
		}
		_007B7797_007D.WriteStruct<int>(uIDDynamicServerBuild);
	}

	private void _007B7798_007D(WriterExtern _007B7799_007D)
	{
		InPbsStatus = (PbsStatus)_007B7799_007D.CustomParameter;
		PlaceIDInPort = _007B7799_007D.ReadByte();
		_007B7799_007D.ReadStruct<float>(ref Strength);
		CustomizationModel = (InitialDynamicBuildingId)_007B7799_007D.ReadByte();
		if (AllowBoardingUnits)
		{
			_007B7799_007D.ReadIMPSNoNull<GSI>(ref LiveUnits);
		}
		if (_007B7799_007D.ReadByte() == byte.MaxValue)
		{
			_007B7799_007D.ReadIMPS<GSI>(ref HoldResources);
			_007B7799_007D.ReadIMPS<GSI>(ref HoldCannonBalls);
			CurrentSelectedCannonsBalls = _007B7799_007D.ReadByte();
			CurrentSelectedWeapons = _007B7799_007D.ReadByte();
			CheckWeapons();
		}
		else
		{
			_007B7799_007D.ReadBoolean(ref Server_CapturedByAttacker);
		}
		_007B7799_007D.ReadStruct<int>(ref uIDDynamicServerBuild);
		try
		{
			Strength = Math.Min(Strength, MaxStrength);
		}
		catch (Exception)
		{
			broken_Place_Old = true;
		}
	}

	public void CheckWeapons()
	{
		if (CustomizationModel == InitialDynamicBuildingId.FortMain)
		{
			int[] availableCannonsToSet = InPbsStatus.FortLevelInfo.AvailableCannonsToSet;
			if (!availableCannonsToSet.Contains(CurrentSelectedWeapons))
			{
				CurrentSelectedWeapons = (byte)availableCannonsToSet[0];
			}
			if (CurrentSelectedCannonsBalls == 0 || CurrentSelectedCannonsBalls > Gameplay.BallsInfo.Count || Gameplay.BallsInfo.FromID(CurrentSelectedCannonsBalls).AmmoType != CannonAmmoType.CannonBall)
			{
				CurrentSelectedCannonsBalls = 1;
			}
		}
	}

	public void FullRestoreUnits()
	{
		LiveUnits = new GSI().Exs(2, MaxUnitsCount);
	}
}
