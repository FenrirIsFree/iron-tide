namespace Common.Game;

public class QuestKillShip : QuestStepHeader
{
	public int Count;

	public readonly DamageID? SourcePawnType;

	public readonly SpecificDamageFlags Flags;

	public readonly bool NpcOrPvp;

	public override int ProgressComparand => Count;

	public QuestKillShip(string _007B7636_007D, int _007B7637_007D, TargetShipForQuest _007B7638_007D)
		: base(_007B7636_007D, _007B7638_007D)
	{
		Count = _007B7637_007D;
		SourcePawnType = null;
		Flags = SpecificDamageFlags.None;
	}

	public QuestKillShip(string _007B7639_007D, int _007B7640_007D, DamageID? _007B7641_007D, SpecificDamageFlags _007B7642_007D = SpecificDamageFlags.None, bool _007B7643_007D = true)
		: base(_007B7639_007D)
	{
		Count = _007B7640_007D;
		SourcePawnType = _007B7641_007D;
		Flags = _007B7642_007D;
		NpcOrPvp = _007B7643_007D;
	}
}
