using System;
using Common.Account;
using Common.Data;
using Common.Resources;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class TradeOrderCommon : IMPSerializable
{
	public const bool HoldingTakesPlace = false;

	public const int InstanceSize = 24;

	public int OrderServerID;

	public uint OwnerSID;

	public IStorageAsset ItemInfo;

	public AuctionOrderPrice Price;

	public int CurrentCount;

	public byte RemainingLifetime;

	public TradeOrderMode Mode;

	public byte PortID;

	public int ItemID => ((IGameResource)ItemInfo).ID;

	public int CostMargin => (int)MathF.Ceiling(Price.CostPerUnit * (float)CurrentCount * Tax);

	public int CostMarginConvertedToGold => Price.IsGold ? CostMargin : (CostMargin * 600);

	public int CostTotal => (int)MathF.Ceiling(Price.CostPerUnit * (float)CurrentCount);

	public int CostTotalConvToMonets => Price.TotalCostConvertedToMonets(CurrentCount);

	public int CostTotalConvToGold => Price.IsGold ? CostTotal : (CostTotal * 600);

	public IslePortInfo InstPort => Gameplay.WorldMap.Ports.Array[PortID];

	public float Tax => WosbTrading.GetTradingTax(InstPort, ItemInfo, Mode == TradeOrderMode.Holding, !Price.IsGold);

	public bool TakePlace => Mode != TradeOrderMode.Holding;

	public TradeOrderCommon()
	{
	}

	public TradeOrderCommon Clone()
	{
		TradeOrderCommon tradeOrderCommon = new TradeOrderCommon();
		tradeOrderCommon.Price = Price;
		tradeOrderCommon.CurrentCount = CurrentCount;
		tradeOrderCommon.ItemInfo = ItemInfo;
		tradeOrderCommon.OrderServerID = OrderServerID;
		tradeOrderCommon.OwnerSID = OwnerSID;
		tradeOrderCommon.RemainingLifetime = RemainingLifetime;
		tradeOrderCommon.Mode = Mode;
		return tradeOrderCommon;
	}

	public TradeOrderCommon(int _007B6756_007D, uint _007B6757_007D, IStorageAsset _007B6758_007D, int _007B6759_007D, AuctionOrderPrice _007B6760_007D, TradeOrderMode _007B6761_007D, int _007B6762_007D)
	{
		OrderServerID = _007B6756_007D;
		OwnerSID = _007B6757_007D;
		ItemInfo = _007B6758_007D;
		CurrentCount = _007B6759_007D;
		Price = _007B6760_007D;
		RemainingLifetime = ((_007B6761_007D == TradeOrderMode.Holding) ? ((byte)WosbTrading.TradeOrderLifetimeHolding) : ((byte)WosbTrading.TradeOrderLifetime));
		Mode = _007B6761_007D;
		PortID = (byte)_007B6762_007D;
	}

	private void _007B6763_007D(WriterExtern _007B6764_007D)
	{
		_007B6764_007D.WriteStruct<int>(OrderServerID);
		_007B6764_007D.WriteStruct<uint>(OwnerSID);
		_007B6764_007D.WriteStruct<short>(((IGameResource)ItemInfo).ID);
		_007B6764_007D.WriteByte((byte)251);
		_007B6764_007D.WriteByte((byte)ItemInfo.getType);
		_007B6764_007D.WriteStruct<int>(CurrentCount);
		_007B6764_007D.Write<AuctionOrderPrice>(ref Price);
		_007B6764_007D.WriteByte(RemainingLifetime);
		_007B6764_007D.WriteByte((byte)Mode);
		_007B6764_007D.WriteByte(PortID);
	}

	private void _007B6765_007D(WriterExtern _007B6766_007D)
	{
		_007B6766_007D.ReadStruct<int>(ref OrderServerID);
		_007B6766_007D.ReadStruct<uint>(ref OwnerSID);
		short _007B3638_007D = default(short);
		_007B6766_007D.ReadStruct<short>(ref _007B3638_007D);
		if (_007B6766_007D.PeekByte() == 251)
		{
			_007B6766_007D.ReadByte();
			StorageAssetEnum _007B3639_007D = (StorageAssetEnum)_007B6766_007D.ReadByte();
			ItemInfo = Gameplay.GetResource(_007B3638_007D, _007B3639_007D);
			_007B6766_007D.ReadStruct<int>(ref CurrentCount);
			_007B6766_007D.ReadIMPS_struct<AuctionOrderPrice>(ref Price);
			RemainingLifetime = _007B6766_007D.ReadByte();
			Mode = (TradeOrderMode)_007B6766_007D.ReadByte();
			PortID = _007B6766_007D.ReadByte();
		}
		else
		{
			StorageAssetEnum _007B3639_007D2 = (StorageAssetEnum)_007B6766_007D.ReadByte();
			ItemInfo = Gameplay.GetResource(_007B3638_007D, _007B3639_007D2);
			_007B6766_007D.ReadStruct<int>(ref CurrentCount);
			float num = default(float);
			_007B6766_007D.ReadStruct<float>(ref num);
			Price = new AuctionOrderPrice(_007B6733_007D: true, (int)num);
			RemainingLifetime = _007B6766_007D.ReadByte();
			Mode = (TradeOrderMode)_007B6766_007D.ReadByte();
			PortID = _007B6766_007D.ReadByte();
		}
	}

	private void _007B6767_007D(PlayerAccount _007B6768_007D)
	{
		switch (ItemInfo.getType)
		{
		case StorageAssetEnum.SimpleItem:
			_007B6768_007D.NearPortStorage.AddOrRemove(((IGameResource)ItemInfo).ID, -CurrentCount);
			break;
		case StorageAssetEnum.Ammo:
			_007B6768_007D.CBallsAtStorage.AddOrRemove(((IGameResource)ItemInfo).ID, -CurrentCount);
			break;
		case StorageAssetEnum.PowderKeg:
			_007B6768_007D.PowderKegsAtStorage.AddOrRemove(((IGameResource)ItemInfo).ID, -CurrentCount);
			break;
		case StorageAssetEnum.Ship_DisplayOnly:
		{
			ProceduralShipInfo proceduralShipInfo = (ProceduralShipInfo)(object)ItemInfo;
			if (new ProceduralShipInfo(_007B6768_007D.Shipyard.CurrentRealShip).CompressedID == proceduralShipInfo.CompressedID)
			{
				_007B6768_007D.TakeOffAllEquipment(_007B6768_007D.Shipyard.CurrentRealShip);
				_007B6768_007D.Shipyard.RemoveFromList(_007B6768_007D.Shipyard.CurrentRealShip);
				break;
			}
			throw new InvalidOperationException("remove Ship_DisplayOnly");
		}
		case StorageAssetEnum.Cannon_DiplayOnly:
			_007B6768_007D.CannonsAtStorage.AddOrRemove(((IGameResource)ItemInfo).ID, -CurrentCount);
			break;
		default:
			throw new NotSupportedException();
		}
	}

	private void _007B6769_007D(PlayerAccount _007B6770_007D, int _007B6771_007D)
	{
		switch (ItemInfo.getType)
		{
		case StorageAssetEnum.SimpleItem:
			_007B6770_007D.ResourcesInPorts.GetHolder(_007B6771_007D).AddOrRemove(ItemInfo.ID, CurrentCount);
			break;
		case StorageAssetEnum.Ammo:
			_007B6770_007D.CBallsAtStorage.AddOrRemove(ItemInfo.ID, CurrentCount);
			break;
		case StorageAssetEnum.PowderKeg:
			_007B6770_007D.PowderKegsAtStorage.AddOrRemove(ItemInfo.ID, CurrentCount);
			break;
		case StorageAssetEnum.Ship_DisplayOnly:
			_007B6770_007D.Shipyard.CreateNewShip((ProceduralShipInfo)(object)ItemInfo, _007B6770_007D);
			break;
		case StorageAssetEnum.Cannon_DiplayOnly:
			_007B6770_007D.CannonsAtStorage.AddOrRemove(ItemInfo.ID, CurrentCount);
			break;
		default:
			throw new NotSupportedException();
		}
	}

	private void _007B6772_007D(int _007B6773_007D, PlayerAccount _007B6774_007D)
	{
		switch (ItemInfo.getType)
		{
		case StorageAssetEnum.SimpleItem:
			_007B6774_007D.NearPortStorage.AddOrRemove(ItemInfo.ID, _007B6773_007D);
			break;
		case StorageAssetEnum.Ammo:
			_007B6774_007D.CBallsAtStorage.AddOrRemove(ItemInfo.ID, _007B6773_007D);
			break;
		case StorageAssetEnum.PowderKeg:
			_007B6774_007D.PowderKegsAtStorage.AddOrRemove(ItemInfo.ID, _007B6773_007D);
			break;
		case StorageAssetEnum.Ship_DisplayOnly:
			_007B6774_007D.Shipyard.CreateNewShip((ProceduralShipInfo)(object)ItemInfo, _007B6774_007D);
			break;
		case StorageAssetEnum.Cannon_DiplayOnly:
			_007B6774_007D.CannonsAtStorage.AddOrRemove(((IGameResource)ItemInfo).ID, _007B6773_007D);
			break;
		default:
			throw new NotSupportedException();
		}
	}

	public bool CanRemoveItems(PlayerAccount _007B6775_007D)
	{
		return ItemInfo.getType switch
		{
			StorageAssetEnum.SimpleItem => _007B6775_007D.NearPortStorage.GetCount(((IGameResource)ItemInfo).ID) >= CurrentCount, 
			StorageAssetEnum.Ammo => _007B6775_007D.CBallsAtStorage.GetCount(((IGameResource)ItemInfo).ID) >= CurrentCount, 
			StorageAssetEnum.PowderKeg => _007B6775_007D.PowderKegsAtStorage.GetCount(((IGameResource)ItemInfo).ID) >= CurrentCount, 
			StorageAssetEnum.Ship_DisplayOnly => new ProceduralShipInfo(_007B6775_007D.Shipyard.CurrentRealShip).CompressedID == ((ProceduralShipInfo)ItemInfo).CompressedID, 
			StorageAssetEnum.Cannon_DiplayOnly => _007B6775_007D.CannonsAtStorage.GetCount(((IGameResource)ItemInfo).ID) >= CurrentCount, 
			_ => throw new NotSupportedException(), 
		};
	}

	public static bool CreationHelper(PlayerAccount _007B6776_007D, TradeOrderCommon _007B6777_007D, out Exception _007B6778_007D)
	{
		_007B6778_007D = null;
		try
		{
			if (_007B6777_007D.Mode == TradeOrderMode.Shop)
			{
				int num = _007B6777_007D.CostTotal + _007B6777_007D.CostMargin;
				if (_007B6777_007D.Price.IsGold)
				{
					if (_007B6776_007D.Gold < num)
					{
						return false;
					}
					_007B6776_007D.Gold -= num;
				}
				else
				{
					if (_007B6776_007D.Monets.Value < num)
					{
						return false;
					}
					_007B6776_007D.Monets.Value -= num;
				}
			}
			else
			{
				if (!_007B6777_007D.CanRemoveItems(_007B6776_007D))
				{
					return false;
				}
				int costMargin = _007B6777_007D.CostMargin;
				if (_007B6777_007D.Price.IsGold)
				{
					if (_007B6776_007D.Gold < costMargin)
					{
						return false;
					}
					_007B6776_007D.Gold -= costMargin;
				}
				else
				{
					if (_007B6776_007D.Monets.Value < costMargin)
					{
						return false;
					}
					_007B6776_007D.Monets.Value -= costMargin;
				}
				_007B6777_007D._007B6767_007D(_007B6776_007D);
			}
			return true;
		}
		catch (Exception ex)
		{
			_007B6778_007D = ex;
			return false;
		}
	}

	public static void UndoHelper(PlayerAccount _007B6779_007D, TradeOrderCommon _007B6780_007D, int _007B6781_007D)
	{
		if (_007B6780_007D.Mode == TradeOrderMode.Shop)
		{
			if (_007B6780_007D.Price.IsGold)
			{
				_007B6779_007D.Gold += _007B6780_007D.CostTotal;
			}
			else
			{
				_007B6779_007D.Monets.Value += _007B6780_007D.CostTotal;
			}
		}
		else
		{
			_007B6780_007D._007B6769_007D(_007B6779_007D, _007B6781_007D);
		}
	}

	public static void CompleteForCustomer(PlayerAccount _007B6782_007D, TradeOrderCommon _007B6783_007D, bool _007B6784_007D)
	{
		if (_007B6783_007D.Mode == TradeOrderMode.Shop)
		{
			_007B6783_007D._007B6767_007D(_007B6782_007D);
			if (_007B6783_007D.Price.IsGold && !_007B6784_007D)
			{
				_007B6782_007D.Gold += _007B6783_007D.CostTotal;
			}
			else
			{
				_007B6782_007D.Monets.Value += _007B6783_007D.CostTotalConvToMonets;
			}
			return;
		}
		_007B6783_007D._007B6772_007D(_007B6783_007D.CurrentCount, _007B6782_007D);
		if (_007B6783_007D.Mode != TradeOrderMode.Holding)
		{
			if (_007B6783_007D.Price.IsGold && !_007B6784_007D)
			{
				_007B6782_007D.Gold -= _007B6783_007D.CostTotal;
			}
			else
			{
				_007B6782_007D.Monets.Value -= _007B6783_007D.CostTotalConvToMonets;
			}
		}
	}

	public static void CompleteForCreatorAnySync(PlayerAccount _007B6785_007D, TradeOrderCommon _007B6786_007D)
	{
		if (_007B6786_007D.Mode == TradeOrderMode.Shop)
		{
			_007B6786_007D._007B6769_007D(_007B6785_007D, _007B6786_007D.PortID);
		}
		else if (_007B6786_007D.Mode != TradeOrderMode.Holding)
		{
			if (_007B6786_007D.Price.IsGold)
			{
				_007B6785_007D.Gold += _007B6786_007D.CostTotal;
			}
			else
			{
				_007B6785_007D.Monets.Value += _007B6786_007D.CostTotal;
			}
		}
	}
}
