namespace Common.Game;

public enum BoardingAvailability
{
	DisallowHp,
	DisallowGameRights,
	Allow,
	Server_Unavailable,
	Server_NpsLowDamage
}
