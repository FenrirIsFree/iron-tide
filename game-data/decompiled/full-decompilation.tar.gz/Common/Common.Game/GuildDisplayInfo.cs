using System.Linq;
using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Game;

public class GuildDisplayInfo : IMPSerializable
{
	public string Tag;

	public string GuildName;

	public string Description;

	public Tlist<string> TrustedGuilds;

	public FractionID Fraction;

	public int MembersCount;

	public Tlist<GuildTemporaryEffect> DisputeVotes;

	public double DisputeProtectionSec;

	public PlayerContact FounderContact;

	public Tlist<PlayerContact> ContactsFirstSuppors;

	public int TradeUnionHqCount;

	public bool ActiveForNewPlayers;

	public GSI GuildTitles;

	public GuildQuests Quests;

	public short CapturedPorts;

	public short GuildRating;

	public bool IsFlotilia => CommonSupport.IsGuildFlotilia(Fraction);

	public int DisputePoints => DisputeVotes.Sum((GuildTemporaryEffect _007B6419_007D) => _007B6419_007D.ArgumentByte);

	private void _007B6415_007D(WriterExtern _007B6416_007D)
	{
		_007B6416_007D.Write(Tag, (Encoding)null);
		_007B6416_007D.Write(GuildName, (Encoding)null);
		_007B6416_007D.Write(Description, (Encoding)null);
		_007B6416_007D.WriteByte((byte)Fraction);
		_007B6416_007D.WriteStruct<int>(ref MembersCount);
		_007B6416_007D.WriteTlist(TrustedGuilds);
		_007B6416_007D.WriteTlistImps(DisputeVotes);
		_007B6416_007D.Write<PlayerContact>(ref FounderContact);
		_007B6416_007D.WriteTlistStruct<PlayerContact>(ContactsFirstSuppors);
		_007B6416_007D.WriteStruct<short>(CapturedPorts);
		_007B6416_007D.WriteStruct<short>(GuildRating);
		_007B6416_007D.WriteStruct<int>(TradeUnionHqCount);
		_007B6416_007D.Write(ActiveForNewPlayers);
		_007B6416_007D.Write<GSI>(GuildTitles);
		_007B6416_007D.Write<GuildQuests>(Quests);
		_007B6416_007D.WriteStruct<double>(DisputeProtectionSec);
	}

	private void _007B6417_007D(WriterExtern _007B6418_007D)
	{
		_007B6418_007D.ReadString(ref Tag, (Encoding)null);
		_007B6418_007D.ReadString(ref GuildName, (Encoding)null);
		_007B6418_007D.ReadString(ref Description, (Encoding)null);
		Fraction = (FractionID)_007B6418_007D.ReadByte();
		_007B6418_007D.ReadStruct<int>(ref MembersCount);
		_007B6418_007D.ReadTlist(out TrustedGuilds);
		_007B6418_007D.ReadTlistImps(out DisputeVotes);
		_007B6418_007D.ReadIMPS_struct<PlayerContact>(ref FounderContact);
		_007B6418_007D.ReadTlistStruct<PlayerContact>(out ContactsFirstSuppors);
		_007B6418_007D.ReadStruct<short>(ref CapturedPorts);
		_007B6418_007D.ReadStruct<short>(ref GuildRating);
		_007B6418_007D.ReadStruct<int>(ref TradeUnionHqCount);
		_007B6418_007D.ReadBoolean(ref ActiveForNewPlayers);
		_007B6418_007D.ReadIMPS<GSI>(ref GuildTitles);
		_007B6418_007D.ReadIMPS<GuildQuests>(ref Quests);
		_007B6418_007D.ReadStruct<double>(ref DisputeProtectionSec);
	}
}
