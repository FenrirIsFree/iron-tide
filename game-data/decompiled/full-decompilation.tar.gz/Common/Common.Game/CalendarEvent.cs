namespace Common.Game;

public enum CalendarEvent
{
	Anniversary = 5,
	Halloween,
	NewYear
}
