using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public sealed class EABehavior2 : OneTimeBonus, IEventActionBehavior, IMPSerializable
{
	private void _007B6132_007D(WriterExtern _007B6133_007D)
	{
		WriteData(_007B6133_007D);
	}

	private void _007B6134_007D(WriterExtern _007B6135_007D)
	{
		ReadData(_007B6135_007D);
	}
}
