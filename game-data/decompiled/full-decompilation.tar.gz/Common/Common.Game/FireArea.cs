using System;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Helpers;

namespace Common.Game;

public class FireArea
{
	public const int DefaultDamage = 13;

	public const float SingleRadius = 5f;

	public const float AddRadius = 1.3f;

	public const float MaxSize = 14.5f;

	public const float Ttl = 11000f;

	public Vector2 Position;

	public float TtlToEnd;

	public float CurrentRadius;

	private Vector2 _007B5646_007D;

	public void Init(Vector2 _007B5642_007D)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		Position = _007B5642_007D;
		TtlToEnd = 11000f;
		CurrentRadius = 5f;
	}

	public void Extend(Vector2 _007B5643_007D)
	{
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		int num = 1;
		TtlToEnd = MathHelper.Lerp(TtlToEnd, 11000f, 0.15f);
		CurrentRadius += 1.3f * MathF.Pow((14.5f - CurrentRadius) / 14.5f, 1.4f) * (float)num;
		if (CurrentRadius > 14.5f)
		{
			CurrentRadius = 14.5f;
		}
		_007B5646_007D = (_007B5643_007D - Position + _007B5646_007D) / (1f + 0.5f * CurrentRadius) * (float)num;
	}

	public bool CanBeExtendedBy(ref Vector2 _007B5644_007D)
	{
		return CurrentRadius < 14.5f && VectorExternsionsDistanceTest.DTest(ref Position, ref _007B5644_007D, CurrentRadius + 1f);
	}

	public virtual bool Update(ref FrameTime _007B5645_007D)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		Position += _007B5646_007D * _007B5645_007D.secElapsed * 1f;
		_007B5646_007D.X = (float)Math.Sign(_007B5646_007D.X) * Math.Max(0f, Math.Abs(_007B5646_007D.X) - _007B5645_007D.secElapsed * 1f);
		_007B5646_007D.Y = (float)Math.Sign(_007B5646_007D.Y) * Math.Max(0f, Math.Abs(_007B5646_007D.Y) - _007B5645_007D.secElapsed * 1f);
		TtlToEnd -= _007B5645_007D.msElapsed;
		if (CurrentRadius > 5f)
		{
			CurrentRadius -= _007B5645_007D.secElapsed * 0.65f;
		}
		return TtlToEnd < 0f;
	}
}
