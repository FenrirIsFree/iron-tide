namespace Common.Game;

public enum QuestPortrait
{
	Filibuster,
	Villager,
	TraderMale,
	TraderFemale,
	Governor,
	Officier,
	Admiral,
	StartQuestMan
}
