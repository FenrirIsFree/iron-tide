using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct BattleSingleInfo : IMPSerializable
{
	public string Name;

	public float Damage;

	public float ReceivedDamage;

	public int Kills;

	private void _007B8679_007D(WriterExtern _007B8680_007D)
	{
		_007B8680_007D.Write(Name, (Encoding)null);
		_007B8680_007D.WriteStruct<float>(Damage);
		_007B8680_007D.WriteStruct<float>(ReceivedDamage);
		_007B8680_007D.WriteStruct<int>(Kills);
	}

	private void _007B8681_007D(WriterExtern _007B8682_007D)
	{
		_007B8682_007D.ReadString(ref Name, (Encoding)null);
		_007B8682_007D.ReadStruct<float>(ref Damage);
		_007B8682_007D.ReadStruct<float>(ref ReceivedDamage);
		_007B8682_007D.ReadStruct<int>(ref Kills);
	}
}
