using System;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;
using TheraEngine.Helpers;

namespace Common.Game;

public class PositionCorrector
{
	private struct CorrectionData
	{
		public Vector2 TotalPosOffset;

		public float TotalAxisOffset;

		public float LocalTimeMs;

		public float TotalTimeMs;

		private PhysicsLayerHardness _007B5070_007D;

		public Vector3 positionAddPerMS;

		public float Integral
		{
			get
			{
				float num = 1f - LocalTimeMs / TotalTimeMs;
				if (_007B5070_007D == PhysicsLayerHardness.Linear)
				{
					return MathF.Sqrt(1f - (2f * num - 1f) * (2f * num - 1f)) / ((float)Math.PI / 4f);
				}
				return 2f - num * 2f;
			}
		}

		public float RemainingMultiplier
		{
			get
			{
				float num = 1f - LocalTimeMs / TotalTimeMs;
				if (_007B5070_007D == PhysicsLayerHardness.Linear)
				{
					return 1f - (num * 0.4f + 0.6f * (0.5f + 0.5f * MathF.Cos((1f - num) * (float)Math.PI)));
				}
				return 1f - (2f * num - num * num);
			}
		}

		public CorrectionData(Vector2 _007B5066_007D, float _007B5067_007D, float _007B5068_007D, PhysicsLayerHardness _007B5069_007D)
		{
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_003e: Unknown result type (might be due to invalid IL or missing references)
			LocalTimeMs = _007B5068_007D;
			TotalTimeMs = _007B5068_007D;
			TotalPosOffset = _007B5066_007D;
			TotalAxisOffset = _007B5067_007D;
			_007B5070_007D = _007B5069_007D;
			positionAddPerMS.X = _007B5066_007D.X / _007B5068_007D;
			positionAddPerMS.Y = _007B5066_007D.Y / _007B5068_007D;
			positionAddPerMS.Z = _007B5067_007D / _007B5068_007D;
		}
	}

	private Tlist<CorrectionData> _007B5061_007D = new Tlist<CorrectionData>();

	public Vector2 RemainingPositionOffset
	{
		get
		{
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_0066: Unknown result type (might be due to invalid IL or missing references)
			//IL_006a: Unknown result type (might be due to invalid IL or missing references)
			Vector2 result = default(Vector2);
			Vector2 val = default(Vector2);
			for (int i = 0; i < _007B5061_007D.Size; i++)
			{
				Vector2.Multiply(ref _007B5061_007D.Array[i].TotalPosOffset, _007B5061_007D.Array[i].RemainingMultiplier, ref val);
				Vector2.Add(ref result, ref val, ref result);
			}
			return result;
		}
	}

	public float RemainingRotationOffset
	{
		get
		{
			float num = 0f;
			for (int i = 0; i < _007B5061_007D.Size; i++)
			{
				num = Geometry.AxisNormFast(num + _007B5061_007D.Array[i].TotalAxisOffset * _007B5061_007D.Array[i].RemainingMultiplier);
			}
			return num;
		}
	}

	public void Update(Ship _007B5052_007D, float _007B5053_007D)
	{
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < _007B5061_007D.Size; i++)
		{
			float num = Math.Min(_007B5061_007D.Array[i].LocalTimeMs, _007B5053_007D);
			_007B5061_007D.Array[i].LocalTimeMs = Math.Max(0f, _007B5061_007D.Array[i].LocalTimeMs - _007B5053_007D);
			num *= _007B5061_007D.Array[i].Integral;
			_007B5052_007D.Position += _007B5061_007D.Array[i].positionAddPerMS.XY() * num;
			_007B5052_007D.Rotation = Geometry.AxisNormFast(_007B5052_007D.Rotation + _007B5061_007D.Array[i].positionAddPerMS.Z * num);
			if (_007B5061_007D.Array[i].LocalTimeMs <= 0f)
			{
				_007B5061_007D.FastRemoveAt(i);
				i--;
			}
		}
	}

	public void Clean()
	{
		_007B5061_007D.Clear();
	}

	public void PushLinear(float _007B5054_007D, Vector2 _007B5055_007D, float _007B5056_007D)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		_007B5061_007D.Add(new CorrectionData(_007B5055_007D, _007B5054_007D, _007B5056_007D, PhysicsLayerHardness.Linear));
	}

	public void PushLinearFast(float _007B5057_007D, Vector2 _007B5058_007D)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		_007B5061_007D.Add(new CorrectionData(_007B5058_007D, _007B5057_007D, 1000f, PhysicsLayerHardness.Linear));
	}

	public void PushHard(float _007B5059_007D, Vector2 _007B5060_007D)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		_007B5061_007D.Add(new CorrectionData(_007B5060_007D, _007B5059_007D, 600f, PhysicsLayerHardness.Collision));
	}
}
