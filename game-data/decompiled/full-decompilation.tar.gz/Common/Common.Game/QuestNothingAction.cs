namespace Common.Game;

public class QuestNothingAction : QuestStepHeader
{
	public enum SAction
	{
		None,
		SampleAttackByNearPirates
	}

	public SAction Action;

	public override int ProgressComparand => -1;

	public QuestNothingAction(string _007B7668_007D, SAction _007B7669_007D = SAction.None)
		: base(_007B7668_007D)
	{
		Action = _007B7669_007D;
	}
}
