namespace Common.Game;

public class QuestArenaKillShip : QuestStepHeader
{
	public readonly int Count;

	public readonly ArenaMode[] Modes;

	public override int ProgressComparand => Count;

	public QuestArenaKillShip(string _007B7527_007D, int _007B7528_007D, params ArenaMode[] _007B7529_007D)
		: base(_007B7527_007D)
	{
		Modes = _007B7529_007D;
		Count = _007B7528_007D;
	}
}
