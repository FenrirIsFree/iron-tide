namespace Common.Game;

public struct GSILocalPair
{
	public readonly int ID;

	public int Count;

	public GSILocalPair(int _007B5426_007D, int _007B5427_007D)
	{
		ID = _007B5426_007D;
		Count = _007B5427_007D;
	}

	public override string ToString()
	{
		return ID + "x " + Count;
	}
}
