using System;

namespace Common.Game;

public static class CapturePortsRistrictionTypeWrapper
{
	public static string ToolTipText(this CapturePortsRistrictionType ristrictionType)
	{
		return ristrictionType switch
		{
			CapturePortsRistrictionType.LimitAchieved => Local.pirates_can_capture_only_one_city, 
			CapturePortsRistrictionType.FractionRule => Local.capture_ports_limit_3, 
			CapturePortsRistrictionType.NotProvidedPorts => Local.capture_ports_limit_1(WosbPbs.ProvidedPortMinLevel), 
			CapturePortsRistrictionType.None => string.Empty, 
			_ => throw new NotSupportedException(), 
		};
	}

	public static bool CanGrowTensityMoreThen50(this CapturePortsRistrictionType ristrictionType)
	{
		return ristrictionType != CapturePortsRistrictionType.NotProvidedPorts;
	}

	public static bool CanGetPortAfterWin(this CapturePortsRistrictionType ristrictionType)
	{
		return ristrictionType == CapturePortsRistrictionType.None;
	}

	public static bool DoubleConquerorBadges(this CapturePortsRistrictionType ristrictionType)
	{
		return false;
	}
}
