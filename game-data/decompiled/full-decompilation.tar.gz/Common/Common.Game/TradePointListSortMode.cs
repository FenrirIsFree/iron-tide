namespace Common.Game;

public enum TradePointListSortMode
{
	ByResId,
	ByResCount,
	BySingleCost
}
