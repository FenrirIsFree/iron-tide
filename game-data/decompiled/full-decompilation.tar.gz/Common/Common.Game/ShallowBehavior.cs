namespace Common.Game;

internal class ShallowBehavior
{
}
