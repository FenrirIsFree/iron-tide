namespace Common.Game;

public enum CapturePortsRistrictionType
{
	None,
	NotProvidedPorts,
	FractionRule,
	LimitAchieved
}
