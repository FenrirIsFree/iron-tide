using System;
using System.Collections.Generic;
using Common.Resources;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Game;

public class PortDevelopment : IMPSerializable, ITKSerializable
{
	public const int MaxLevelConst = 7;

	public byte PortID;

	private int _007B7927_007D = 1;

	private int _007B7928_007D = 0;

	public const int ConquerBadgeSupplyXp = 30000;

	public IslePortInfo PortInfo => Gameplay.WorldMap.Ports[PortID];

	public int MaxLevel => 7;

	public int PortLevel
	{
		get
		{
			return (PortInfo.FixedPortLevel > 0) ? PortInfo.FixedPortLevel : _007B7927_007D;
		}
		set
		{
			_007B7927_007D = Math.Clamp(value, 1, MaxLevel);
			_007B7928_007D = 0;
		}
	}

	public int Xp => _007B7928_007D;

	public float ProgressToNextLevel => (_007B7927_007D < MaxLevel) ? ((float)_007B7928_007D * 1f / (float)GetLevelCost(_007B7927_007D + 1)) : 0f;

	public PortDevelopment(int _007B7911_007D)
	{
		PortID = (byte)_007B7911_007D;
	}

	public PortDevelopment()
	{
	}

	public int GetLevelCost(int _007B7912_007D)
	{
		if (1 == 0)
		{
		}
		int num = _007B7912_007D switch
		{
			1 => 900000, 
			2 => 1080000, 
			3 => 1300000, 
			4 => 1680000, 
			5 => 2290000, 
			6 => 3180000, 
			7 => 4600000, 
			8 => 0, 
			_ => throw new InvalidOperationException($"Invalid level {_007B7912_007D}"), 
		};
		if (1 == 0)
		{
		}
		int num2 = num;
		int shallowUpperRang = PortInfo.ShallowUpperRang;
		if (1 == 0)
		{
		}
		double num3 = shallowUpperRang switch
		{
			-1 => 1.0, 
			1 => 1.0, 
			2 => 0.8, 
			3 => 0.6, 
			4 => 0.5, 
			5 => 0.4, 
			6 => 0.3, 
			7 => 0.3, 
			_ => throw new InvalidOperationException($"Invalid shallow rank {shallowUpperRang}"), 
		};
		if (1 == 0)
		{
		}
		double num4 = num3;
		return (int)Math.Round((double)num2 * num4);
	}

	public void AddXP(int _007B7913_007D)
	{
		if (_007B7927_007D != MaxLevel)
		{
			_007B7928_007D = Math.Max(0, _007B7928_007D + _007B7913_007D);
			while (_007B7928_007D >= GetLevelCost(_007B7927_007D + 1) && _007B7927_007D < MaxLevel)
			{
				_007B7928_007D -= GetLevelCost(_007B7927_007D + 1);
				_007B7927_007D++;
			}
		}
	}

	public static int GetSupplyXp(ResourceInfo _007B7914_007D)
	{
		float num = (_007B7914_007D.IsTradingItem ? 1.5f : ((_007B7914_007D.ID == 67) ? 2.5f : ((_007B7914_007D.ID == 37) ? 3f : ((_007B7914_007D.ID == 68) ? 3.5f : ((_007B7914_007D.ID == 38) ? 2.5f : ((_007B7914_007D.ID == 15) ? 2.5f : ((_007B7914_007D.ID == 43) ? 2f : ((_007B7914_007D.ID == 40) ? 2.5f : ((_007B7914_007D.ID == 33) ? 5f : ((_007B7914_007D.ID == 39) ? 1.5f : 1f))))))))));
		return (int)((float)_007B7914_007D.MediumCost.Value * num);
	}

	public float GetAvailableBonus(PortLevelBonusType _007B7915_007D, in Decorator _007B7916_007D, PortCaptureStatus _007B7917_007D, PortLevelBonus _007B7918_007D = null)
	{
		if (Gameplay.PortLevelBonuses.TryGetValue(_007B7915_007D, out ObservableTlist<PortLevelBonus> value))
		{
			IEnumerable<PortBonusCriteria> portBonusCriterias = _007B7916_007D.GetPortBonusCriterias(_007B7917_007D);
			foreach (PortLevelBonus item in (IEnumerable<PortLevelBonus>)value)
			{
				if (_007B7918_007D == null || _007B7918_007D == item)
				{
					PortBonusCriteria _007B3391_007D;
					int num = Math.Min(PortLevel, _007B7916_007D.GetPortBonusMaxLevel(portBonusCriterias, item, _007B7917_007D, out _007B3391_007D));
					if (num > 0)
					{
						return item.GetValue(num, _007B3410_007D: true);
					}
				}
			}
		}
		return 0f;
	}

	public float GetMaxBonus(PortLevelBonusType _007B7919_007D, PortCaptureStatus _007B7920_007D)
	{
		if (Gameplay.PortLevelBonuses.TryGetValue(_007B7919_007D, out ObservableTlist<PortLevelBonus> value))
		{
			using IEnumerator<PortLevelBonus> enumerator = ((IEnumerable<PortLevelBonus>)value).GetEnumerator();
			if (enumerator.MoveNext())
			{
				PortLevelBonus current = enumerator.Current;
				return current.GetValue(PortLevel, _007B3410_007D: true);
			}
		}
		return 0f;
	}

	public int GetTradeHqPrice()
	{
		int portLevel = PortLevel;
		if (1 == 0)
		{
		}
		int result = portLevel switch
		{
			1 => 2, 
			2 => 4, 
			3 => 6, 
			4 => 10, 
			5 => 14, 
			6 => 20, 
			7 => 24, 
			_ => throw new InvalidOperationException($"Invalid level {_007B7927_007D}"), 
		};
		if (1 == 0)
		{
		}
		return result;
	}

	public void Boxing(WriterExtern _007B7921_007D)
	{
		_007B7921_007D.WriteByte(PortID);
		_007B7921_007D.WriteStruct<int>(_007B7927_007D);
		_007B7921_007D.WriteStruct<int>(_007B7928_007D);
	}

	public void Unboxing(WriterExtern _007B7922_007D)
	{
		PortID = _007B7922_007D.ReadByte();
		_007B7922_007D.ReadStruct<int>(ref _007B7927_007D);
		_007B7922_007D.ReadStruct<int>(ref _007B7928_007D);
	}

	public void PreInit()
	{
	}

	public void PostInit()
	{
	}

	public void Load(short _007B7923_007D, WriterExtern _007B7924_007D, out bool _007B7925_007D)
	{
		_007B7925_007D = true;
		switch (_007B7923_007D)
		{
		case 1:
			PortID = _007B7924_007D.ReadByte();
			break;
		case 2:
		{
			float value = default(float);
			_007B7924_007D.ReadStruct<float>(ref value);
			_007B7927_007D = (int)Math.Clamp(value, 1f, MaxLevel);
			break;
		}
		case 3:
			_007B7924_007D.ReadStruct<int>(ref _007B7927_007D);
			break;
		case 4:
			_007B7924_007D.ReadStruct<int>(ref _007B7928_007D);
			break;
		default:
			_007B7925_007D = false;
			break;
		}
	}

	public void Boxing(TKWriterExtern _007B7926_007D)
	{
		((TKWriterExtern)(ref _007B7926_007D)).WriteByte((short)1, PortID);
		((TKWriterExtern)(ref _007B7926_007D)).WriteStruct<int>((short)3, ref _007B7927_007D);
		((TKWriterExtern)(ref _007B7926_007D)).WriteStruct<int>((short)4, ref _007B7928_007D);
	}
}
