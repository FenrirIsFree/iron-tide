using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;
using TheraEngine.Collections;
using TheraEngine.PacketValues;

namespace Common.Game;

public struct WeatherEngineState : IMPSerializable
{
	internal Bits8 serializationBits;

	internal Vector2 wavePoisition;

	internal Vector3 initWindDirection;

	internal Vector3 nextWindDirection;

	internal float windDirectionLerp;

	internal OceanStateEnum commonOceanInitState;

	internal OceanStateEnum commonOceanNextState;

	internal WaterStateEnum commonSkydomeInitState;

	internal WaterStateEnum commonSkydomeNextState;

	internal float commonOceanAndSkyStateLerp;

	internal Tlist<WeatherArea> stormAreas;

	internal void PartialMerge(ref WeatherEngineState _007B5891_007D)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		if (serializationBits[0])
		{
			_007B5891_007D.initWindDirection = initWindDirection;
			_007B5891_007D.nextWindDirection = nextWindDirection;
			_007B5891_007D.windDirectionLerp = windDirectionLerp;
		}
		if (serializationBits[1])
		{
			_007B5891_007D.commonOceanInitState = commonOceanInitState;
			_007B5891_007D.commonOceanNextState = commonOceanNextState;
			_007B5891_007D.commonSkydomeInitState = commonSkydomeInitState;
			_007B5891_007D.commonSkydomeNextState = commonSkydomeNextState;
			_007B5891_007D.commonOceanAndSkyStateLerp = commonOceanAndSkyStateLerp;
		}
		if (serializationBits[2])
		{
			_007B5891_007D.stormAreas = stormAreas;
		}
	}

	private void _007B5892_007D(WriterExtern _007B5893_007D)
	{
		_007B5893_007D.WriteByte(serializationBits.Value);
		_007B5893_007D.WriteStruct<Vector2>(ref wavePoisition);
		if (serializationBits[0])
		{
			_007B5893_007D.WriteStruct<Vector3>(ref initWindDirection);
			_007B5893_007D.WriteStruct<Vector3>(ref nextWindDirection);
			_007B5893_007D.WriteStruct<float>(ref windDirectionLerp);
		}
		if (serializationBits[1])
		{
			_007B5893_007D.WriteByte((byte)commonOceanInitState);
			_007B5893_007D.WriteByte((byte)commonOceanNextState);
			_007B5893_007D.WriteByte((byte)commonSkydomeInitState);
			_007B5893_007D.WriteByte((byte)commonSkydomeNextState);
			_007B5893_007D.WriteStruct<float>(ref commonOceanAndSkyStateLerp);
		}
		if (serializationBits[2])
		{
			_007B5893_007D.WriteTlistImps(stormAreas);
		}
	}

	private void _007B5894_007D(WriterExtern _007B5895_007D)
	{
		serializationBits.Value = _007B5895_007D.ReadByte();
		_007B5895_007D.ReadStruct<Vector2>(ref wavePoisition);
		if (serializationBits[0])
		{
			_007B5895_007D.ReadStruct<Vector3>(ref initWindDirection);
			_007B5895_007D.ReadStruct<Vector3>(ref nextWindDirection);
			_007B5895_007D.ReadStruct<float>(ref windDirectionLerp);
		}
		if (serializationBits[1])
		{
			commonOceanInitState = (OceanStateEnum)_007B5895_007D.ReadByte();
			commonOceanNextState = (OceanStateEnum)_007B5895_007D.ReadByte();
			commonSkydomeInitState = (WaterStateEnum)_007B5895_007D.ReadByte();
			commonSkydomeNextState = (WaterStateEnum)_007B5895_007D.ReadByte();
			_007B5895_007D.ReadStruct<float>(ref commonOceanAndSkyStateLerp);
		}
		if (serializationBits[2])
		{
			_007B5895_007D.ReadTlistImps(out stormAreas);
		}
	}
}
