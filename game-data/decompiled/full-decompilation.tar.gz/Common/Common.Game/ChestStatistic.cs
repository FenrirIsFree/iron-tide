using System;
using System.Collections.Generic;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class ChestStatistic : IMPSerializable
{
	public const byte TotalOpenedChests = 0;

	public const byte AssuranceForEmpireChestA = 2;

	public const byte AssuranceForEmpireChestB = 3;

	public const byte AssuranceForEmpireChestC = 4;

	public const byte AssuranceForEmpireChestD = 8;

	public const byte AssuranceForSimpleChestA = 5;

	public const byte AssuranceForSimpleChestB = 6;

	public const byte AssuranceIncasChestA = 7;

	public byte Server_LastOpenedChestReward;

	public float ShipFromChestSec;

	private Dictionary<byte, ushort> _007B8279_007D = new Dictionary<byte, ushort>();

	public int this[byte _007B8274_007D]
	{
		get
		{
			ushort value;
			return _007B8279_007D.TryGetValue(_007B8274_007D, out value) ? value : 0;
		}
		set
		{
			_007B8279_007D[_007B8275_007D] = (ushort)Math.Min(65535, value);
		}
	}

	public void Boxing(WriterExtern _007B8277_007D)
	{
		_007B8277_007D.WriteStruct<float>(ShipFromChestSec);
		_007B8277_007D.WriteByte((byte)_007B8279_007D.Count);
		foreach (KeyValuePair<byte, ushort> item in _007B8279_007D)
		{
			_007B8277_007D.WriteByte(item.Key);
			_007B8277_007D.WriteStruct<ushort>(item.Value);
		}
	}

	public void Unboxing(WriterExtern _007B8278_007D)
	{
		_007B8278_007D.ReadStruct<float>(ref ShipFromChestSec);
		byte b = _007B8278_007D.ReadByte();
		ushort value = default(ushort);
		for (byte b2 = 0; b2 < b; b2++)
		{
			byte key = _007B8278_007D.ReadByte();
			_007B8278_007D.ReadStruct<ushort>(ref value);
			_007B8279_007D[key] = value;
		}
	}
}
