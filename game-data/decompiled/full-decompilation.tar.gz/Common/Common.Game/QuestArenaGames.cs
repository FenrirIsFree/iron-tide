using System.Linq;
using TheraEngine;

namespace Common.Game;

public class QuestArenaGames : QuestStepHeader
{
	public readonly ArenaMode[] RequiredModes;

	public readonly RTI Count;

	public readonly float MinimumDamage;

	public readonly bool WinOnly;

	public readonly int[] AllowedShipRanks;

	public override int ProgressComparand => Count.Value;

	public QuestArenaGames(string _007B7507_007D, ArenaMode _007B7508_007D, int _007B7509_007D, float _007B7510_007D, bool _007B7511_007D, params int[] _007B7512_007D)
		: base(_007B7507_007D)
	{
		RequiredModes = new ArenaMode[1] { _007B7508_007D };
		Count = new RTI(_007B7509_007D);
		MinimumDamage = _007B7510_007D;
		WinOnly = _007B7511_007D;
		AllowedShipRanks = _007B7512_007D.ToArray();
	}

	public QuestArenaGames(string _007B7513_007D, ArenaMode[] _007B7514_007D, int _007B7515_007D, float _007B7516_007D, bool _007B7517_007D, params int[] _007B7518_007D)
		: base(_007B7513_007D)
	{
		RequiredModes = _007B7514_007D;
		Count = new RTI(_007B7515_007D);
		MinimumDamage = _007B7516_007D;
		WinOnly = _007B7517_007D;
		AllowedShipRanks = _007B7518_007D.ToArray();
	}

	public bool DoesGameFit(ArenaMode _007B7519_007D, ArenaBattleResult _007B7520_007D, ArenaPlayerShowing _007B7521_007D, int _007B7522_007D, float _007B7523_007D)
	{
		float num = _007B7521_007D.GetStat(ArenaShowingProperty.CargoPoints) + _007B7521_007D.GetStat(ArenaShowingProperty.LootedCargoPoints);
		return RequiredModes.Contains(_007B7519_007D) && (!WinOnly || _007B7520_007D == ArenaBattleResult.YourComandWin) && (_007B7523_007D > MinimumDamage || (_007B7519_007D == ArenaMode.Collecting && num >= 3f)) && (AllowedShipRanks.Length == 0 || AllowedShipRanks.Contains(_007B7522_007D));
	}

	public static ArenaMode[] AllNotDuel()
	{
		return new ArenaMode[3]
		{
			ArenaMode.Collecting,
			ArenaMode.TowerDefence,
			ArenaMode.WallVsWall
		};
	}
}
