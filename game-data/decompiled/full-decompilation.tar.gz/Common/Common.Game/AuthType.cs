namespace Common.Game;

public enum AuthType
{
	Direct,
	Vk,
	Steam
}
