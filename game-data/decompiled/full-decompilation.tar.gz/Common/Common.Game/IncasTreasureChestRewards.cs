using TheraEngine.Collections;
using World_Of_Sea_Battle.Constants;

namespace Common.Game;

internal static class IncasTreasureChestRewards
{
	public static readonly ChestRewardInfo[] Elements = ShopChestApplyHelper.ComposeByProbabilityGroup(new(float, ChestRewardInfo[])[5]
	{
		(0.1f, new ChestRewardInfo[1]
		{
			new ChestRewardInfo(3, ShopChestApplyHelper.Ship(65), _007B8261_007D: true, Local.chest_incas_ShipHuracan)
			{
				CheckShipID = new Tlist<int> { 65 },
				DisallowOnLowRang = true
			}
		}),
		(1f, new ChestRewardInfo[1]
		{
			new ChestRewardInfo(3, ShopChestApplyHelper.Monets(3000), _007B8261_007D: false, Local.chest_incas_Monets(3000))
		}),
		(2f, new ChestRewardInfo[1]
		{
			new ChestRewardInfo(3, ShopChestApplyHelper.Gold(1500000), _007B8261_007D: false, Local.chest_incas_Gold(StringHelper.BigValueHelper(1500000)))
		}),
		(25f, new ChestRewardInfo[9]
		{
			new ChestRewardInfo(2, ShopChestApplyHelper.Resource(72, 1000), _007B8261_007D: false, Local.chest_incas_PirateMonets(1000))
			{
				FirstOpenChestCategory = true
			},
			new ChestRewardInfo(2, ShopChestApplyHelper.Gold(150000), _007B8261_007D: false, Local.chest_incas_Gold(StringHelper.BigValueHelper(150000))),
			new ChestRewardInfo(2, ShopChestApplyHelper.Resource(15, 30), _007B8261_007D: false, Local.res_15_name)
			{
				FirstOpenChestCategory = true
			},
			new ChestRewardInfo(2, ShopChestApplyHelper.Resource(67, 8), _007B8261_007D: false, Local.chest_incas_BlueprintFragments(8))
			{
				FirstOpenChestCategory = true
			},
			new ChestRewardInfo(2, ShopChestApplyHelper.Cannon(33, 5), _007B8261_007D: false, Local.chest_incas_QualityCannons)
			{
				FirstOpenChestCategory = true
			},
			new ChestRewardInfo(2, ShopChestApplyHelper.Cannon(34, 5), _007B8261_007D: false, Local.chest_incas_QualityCannons)
			{
				FirstOpenChestCategory = true
			},
			new ChestRewardInfo(2, ShopChestApplyHelper.Cannon(31, 15), _007B8261_007D: false, Local.chest_incas_QualityCannons)
			{
				FirstOpenChestCategory = true
			},
			new ChestRewardInfo(2, ShopChestApplyHelper.Cannon(32, 15), _007B8261_007D: false, Local.chest_incas_QualityCannons)
			{
				FirstOpenChestCategory = true
			},
			new ChestRewardInfo(2, ShopChestApplyHelper.Cannon(30, 15), _007B8261_007D: false, Local.chest_incas_QualityCannons)
			{
				FirstOpenChestCategory = true
			}
		}),
		(71.9f, new ChestRewardInfo[15]
		{
			new ChestRewardInfo(1, ShopChestApplyHelper.Resource(72, 150), _007B8261_007D: false, Local.chest_incas_PirateMonets(150)),
			new ChestRewardInfo(1, ShopChestApplyHelper.Resource(67, 1), _007B8261_007D: false, Local.chest_incas_BlueprintFragments(1)),
			new ChestRewardInfo(1, ShopChestApplyHelper.TempGain(16, 5), _007B8261_007D: false, Local.chest_reward_Consumable),
			new ChestRewardInfo(1, ShopChestApplyHelper.TempGain(3, 35), _007B8261_007D: false, Local.chest_reward_Consumable),
			new ChestRewardInfo(1, ShopChestApplyHelper.TempGain(14, 8), _007B8261_007D: false, Local.chest_reward_Consumable),
			new ChestRewardInfo(1, ShopChestApplyHelper.TempGain(2, 40), _007B8261_007D: false, Local.chest_reward_Consumable),
			new ChestRewardInfo(1, ShopChestApplyHelper.TempGain(12, 120), _007B8261_007D: false, Local.chest_reward_Consumable),
			new ChestRewardInfo(1, ShopChestApplyHelper.Ammo(5, 500), _007B8261_007D: false, Local.chest_reward_HeavyAmmo),
			new ChestRewardInfo(1, ShopChestApplyHelper.Ammo(7, 800), _007B8261_007D: false, Local.chest_reward_SaxonAmmo),
			new ChestRewardInfo(1, ShopChestApplyHelper.Resource(37, 50), _007B8261_007D: false, Local.chest_incas_Materials),
			new ChestRewardInfo(1, ShopChestApplyHelper.Resource(38, 3), _007B8261_007D: false, Local.chest_incas_Materials),
			new ChestRewardInfo(1, ShopChestApplyHelper.Resource(4, 2500), _007B8261_007D: false, Local.chest_incas_Materials),
			new ChestRewardInfo(1, ShopChestApplyHelper.Resource(1, 12000), _007B8261_007D: false, Local.chest_incas_Materials),
			new ChestRewardInfo(1, ShopChestApplyHelper.Resource(12, 1500), _007B8261_007D: false, Local.chest_incas_Materials),
			new ChestRewardInfo(1, ShopChestApplyHelper.Resource(9, 1000), _007B8261_007D: false, Local.chest_incas_Materials)
		})
	});
}
