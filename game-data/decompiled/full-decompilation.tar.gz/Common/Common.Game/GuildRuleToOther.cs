using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public class GuildRuleToOther : IMPSerializable
{
	public string Tag;

	public bool IsConfirmed;

	internal float DelayToWorkMs;

	public bool HasAnyTimeout => DelayToWorkMs > 0f;

	public GuildRuleToOther()
	{
	}

	public GuildRuleToOther(string _007B6490_007D, float _007B6491_007D)
	{
		Tag = _007B6490_007D;
		DelayToWorkMs = _007B6491_007D;
	}

	private void _007B6492_007D(WriterExtern _007B6493_007D)
	{
		_007B6493_007D.Write(Tag, (Encoding)null);
		_007B6493_007D.Write(IsConfirmed);
		_007B6493_007D.WriteStruct<float>(DelayToWorkMs);
	}

	private void _007B6494_007D(WriterExtern _007B6495_007D)
	{
		_007B6495_007D.ReadString(ref Tag, (Encoding)null);
		_007B6495_007D.ReadBoolean(ref IsConfirmed);
		_007B6495_007D.ReadStruct<float>(ref DelayToWorkMs);
	}
}
