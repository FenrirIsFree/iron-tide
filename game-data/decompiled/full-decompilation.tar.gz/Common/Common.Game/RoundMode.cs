namespace Common.Game;

public enum RoundMode
{
	Floor,
	SoftFloor,
	Round,
	Rand,
	Ceiling,
	SoftCeiling
}
