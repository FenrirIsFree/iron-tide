namespace Common.Game;

public enum AuctionFilters
{
	Ships,
	CraftResources,
	RareResources,
	OtherResources,
	Weapons
}
