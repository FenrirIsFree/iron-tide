using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using Common.Account;
using Common.Resources;
using CommonDataTypes;
using TheraEngine.Collections;
using TheraEngine.Helpers;

namespace Common.Game;

public class ShopChestApplyHelper
{
	[CompilerGenerated]
	private sealed class _003CToStringAllChestOffers_003Ed__15 : IEnumerable<string>, IEnumerable, IEnumerator<string>, IEnumerator, IDisposable
	{
		private int _007B8377_007D;

		private string _007B8378_007D;

		private int _007B8379_007D;

		public ShopChestApplyHelper _003C_003E4__this;

		private float _007B8380_007D;

		private ChestRewardInfo[] _007B8381_007D;

		private int _007B8382_007D;

		private ChestRewardInfo _007B8383_007D;

		string IEnumerator<string>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B8378_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B8378_007D;
			}
		}

		[DebuggerHidden]
		public _003CToStringAllChestOffers_003Ed__15(int _007B8372_007D)
		{
			_007B8377_007D = _007B8372_007D;
			_007B8379_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B8373_007D()
		{
			_007B8381_007D = null;
			_007B8383_007D = default(ChestRewardInfo);
			_007B8377_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {8373}
			this._007B8373_007D();
		}

		private bool _007B8374_007D()
		{
			switch (_007B8377_007D)
			{
			default:
				return false;
			case 0:
				_007B8377_007D = -1;
				_007B8380_007D = _003C_003E4__this._007B8325_007D.Sum((ChestRewardInfo _007B8329_007D) => _007B8329_007D.Weight);
				_007B8381_007D = _003C_003E4__this._007B8325_007D;
				_007B8382_007D = 0;
				goto IL_0140;
			case 1:
				_007B8377_007D = -1;
				_007B8383_007D = default(ChestRewardInfo);
				_007B8382_007D++;
				goto IL_0140;
			case 2:
				_007B8377_007D = -1;
				_007B8378_007D = Local.chest_GeneralTt2(10);
				_007B8377_007D = 3;
				return true;
			case 3:
				{
					_007B8377_007D = -1;
					return false;
				}
				IL_0140:
				if (_007B8382_007D < _007B8381_007D.Length)
				{
					_007B8383_007D = _007B8381_007D[_007B8382_007D];
					_007B8378_007D = $"{Math.Round(_007B8383_007D.Weight / _007B8380_007D * 100f, 1)}%: " + _007B8383_007D.Complete(null, 1, DateTime.Now);
					_007B8377_007D = 1;
					return true;
				}
				_007B8381_007D = null;
				_007B8378_007D = Local.chest_GeneralTt1(12, 2);
				_007B8377_007D = 2;
				return true;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {8374}
			return this._007B8374_007D();
		}

		[DebuggerHidden]
		private void _007B8375_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {8375}
			this._007B8375_007D();
		}

		[DebuggerHidden]
		IEnumerator<string> IEnumerable<string>.GetEnumerator()
		{
			_003CToStringAllChestOffers_003Ed__15 result;
			if (_007B8377_007D == -2 && _007B8379_007D == Environment.CurrentManagedThreadId)
			{
				_007B8377_007D = 0;
				result = this;
			}
			else
			{
				result = new _003CToStringAllChestOffers_003Ed__15(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			return result;
		}

		[DebuggerHidden]
		private IEnumerator _007B8376_007D()
		{
			return ((IEnumerable<string>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {8376}
			return this._007B8376_007D();
		}
	}

	public static ShopChestApplyHelper BigChest = new ShopChestApplyHelper(BigChestRewards.Elements);

	public static ShopChestApplyHelper Atlar = new ShopChestApplyHelper(AltarRewards.Elements);

	public static ShopChestApplyHelper EmpireChest = new ShopChestApplyHelper(EmpireChestRewards.Elements);

	public static ShopChestApplyHelper IncasTreasureChest = new ShopChestApplyHelper(IncasTreasureChestRewards.Elements);

	public static ShopChestApplyHelper NewYearChest = new ShopChestApplyHelper(NewYearChestRewards.Elements);

	private const int premShipMaxIntervalHours = 12;

	private const int premShipReduceIntervalWithOpenNextChest = 2;

	private const int minRankForSomePositions = 10;

	private ChestRewardInfo[] _007B8325_007D;

	private float _007B8326_007D;

	public ChestRewardInfo[] Elements => _007B8325_007D;

	public float SummaryWeight => _007B8326_007D;

	internal ShopChestApplyHelper(ChestRewardInfo[] _007B8288_007D)
	{
		_007B8325_007D = _007B8288_007D;
		_007B8326_007D = _007B8288_007D.Sum((ChestRewardInfo _007B8327_007D) => _007B8327_007D.Weight);
		if (!_007B8288_007D.Any((ChestRewardInfo _007B8328_007D) => _007B8328_007D.FirstOpenChestCategory) && _007B8288_007D != AltarRewards.Elements)
		{
			throw new InvalidOperationException("There is no element with FirstOpenChestCategory flag");
		}
	}

	[IteratorStateMachine(typeof(_003CToStringAllChestOffers_003Ed__15))]
	public IEnumerable<string> ToStringAllChestOffers()
	{
		//yield-return decompiler failed: Method not found
		return new _003CToStringAllChestOffers_003Ed__15(-2)
		{
			_003C_003E4__this = this
		};
	}

	public LocalizedString Apply(PlayerAccount _007B8289_007D, byte _007B8290_007D, int _007B8291_007D, DateTime _007B8292_007D, out bool _007B8293_007D)
	{
		ChestRewardInfo chestRewardInfo = _007B8325_007D[_007B8290_007D];
		_007B8293_007D = chestRewardInfo.ShowInChat;
		if (_007B8289_007D != null)
		{
			if (chestRewardInfo.IsPremiumShip)
			{
				_007B8289_007D.ChestStat.ShipFromChestSec = 43200f;
			}
			else
			{
				_007B8289_007D.ChestStat.ShipFromChestSec *= 0.98f;
			}
			_007B8289_007D.ChestStat.Server_LastOpenedChestReward = _007B8290_007D;
		}
		if (_007B8289_007D != null)
		{
			_007B8289_007D.ChestStat[0]++;
			for (int i = 0; i < _007B8325_007D.Length; i++)
			{
				if (_007B8325_007D[i].AssuranceOpen.HasValue)
				{
					_007B8289_007D.ChestStat[_007B8325_007D[i].AssuranceOpen.Value.id]++;
				}
			}
			if (chestRewardInfo.AssuranceOpen.HasValue)
			{
				_007B8289_007D.ChestStat[chestRewardInfo.AssuranceOpen.Value.id] = 0;
			}
		}
		LocalizedString result = chestRewardInfo.Complete(_007B8289_007D, _007B8291_007D, _007B8292_007D);
		if (chestRewardInfo.OverrideChatMessage != null && CommonGlobal.IsServer)
		{
			return chestRewardInfo.OverrideChatMessage;
		}
		return result;
	}

	public LocalizedString ApplyAltar(PlayerAccount _007B8294_007D, int _007B8295_007D, byte _007B8296_007D)
	{
		ChestRewardInfo chestRewardInfo = _007B8325_007D[_007B8296_007D];
		return chestRewardInfo.Complete(_007B8294_007D, _007B8295_007D, default(DateTime));
	}

	internal static ShipDesignInfo? RandomDesign(Func<ShipDesignInfo, bool> _007B8297_007D, int _007B8298_007D, PlayerAccount _007B8299_007D)
	{
		Sequence customRandom = new Sequence(_007B8298_007D);
		ShipDesignInfo shipDesignInfo = null;
		for (int i = 0; i < 10; i++)
		{
			shipDesignInfo = Gameplay.DesignsInfo.Rand(delegate(ShipDesignInfo _007B8334_007D)
			{
				bool flag = _007B8297_007D(_007B8334_007D) && _007B8334_007D.InShop;
				bool flag2 = flag;
				if (flag2)
				{
					bool flag3 = _007B8334_007D.InShopByGold.Value == 0;
					bool flag4 = flag3;
					if (!flag4)
					{
						ShipDesignCategory category = _007B8334_007D.Category;
						bool flag5 = ((category == ShipDesignCategory.Satellite || (uint)(category - 4) <= 1u) ? true : false);
						flag4 = flag5;
					}
					flag2 = flag4;
				}
				return flag2;
			}, customRandom);
			if (_007B8299_007D == null || IsDesignAllowed(_007B8299_007D, shipDesignInfo))
			{
				return shipDesignInfo;
			}
		}
		return shipDesignInfo;
	}

	private static bool IsDesignAllowed(PlayerAccount _007B8300_007D, ShipDesignInfo _007B8301_007D)
	{
		if (_007B8300_007D.DesingElementsAtStorage[_007B8301_007D.ID] > 0)
		{
			return false;
		}
		if (_007B8301_007D.Category == ShipDesignCategory.ShipFullDesign && _007B8300_007D.Shipyard.List.Any((PlayerShipDynamicInfo _007B8335_007D) => _007B8335_007D.EnumerateDesignElements().Contains(_007B8301_007D)))
		{
			return false;
		}
		if (_007B8301_007D.Category == ShipDesignCategory.Satellite && _007B8301_007D.ID == 404 && !CalendarEvents.IsNewYear)
		{
			return false;
		}
		return true;
	}

	internal static void PremiumAdd(PlayerAccount _007B8302_007D, DateTime _007B8303_007D, int _007B8304_007D)
	{
		_007B8302_007D.AddPremium(_007B8304_007D, _007B8303_007D);
	}

	internal static string ShipAdd(PlayerAccount _007B8305_007D, int _007B8306_007D)
	{
		PlayerShipInfo playerShipInfo = Gameplay.PlayersInfo.FromID(_007B8306_007D);
		if (_007B8305_007D != null)
		{
			PlayerShipDynamicInfo playerShipDynamicInfo = _007B8305_007D.Shipyard.CreateNewShip(playerShipInfo, _007B8305_007D, null, _007B2038_007D: false, _007B2039_007D: false, _007B2040_007D: true);
			if (_007B8305_007D.ShipPlacesLeft == 0)
			{
				_007B8305_007D.MaxShipsCount.Value++;
			}
		}
		return playerShipInfo.ShipName;
	}

	internal static ChestRewardInfo[] ComposeByProbabilityGroup((float groupWeight, ChestRewardInfo[] groupOptions)[] _007B8307_007D)
	{
		Tlist<ChestRewardInfo> tlist = new Tlist<ChestRewardInfo>();
		for (int i = 0; i < _007B8307_007D.Length; i++)
		{
			(float, ChestRewardInfo[]) tuple = _007B8307_007D[i];
			float weight = tuple.Item1 / (float)tuple.Item2.Length;
			ChestRewardInfo[] item = tuple.Item2;
			foreach (ChestRewardInfo chestRewardInfo in item)
			{
				ChestRewardInfo item2 = chestRewardInfo;
				item2.Weight = weight;
				tlist.Add(in item2);
			}
		}
		return tlist.ToArray();
	}

	internal static ChestRewardInfo[] NormalizeWeightOfChestRewards(ChestRewardInfo[] _007B8308_007D)
	{
		float totalWeight = _007B8308_007D.Sum((ChestRewardInfo _007B8330_007D) => _007B8330_007D.Weight);
		return _007B8308_007D.Select(delegate(ChestRewardInfo _007B8336_007D)
		{
			_007B8336_007D.Weight = _007B8336_007D.Weight / totalWeight * 100f;
			return _007B8336_007D;
		}).ToArray();
	}

	internal static ActionDelegate RandomDesign(bool _007B8309_007D, params int[] _007B8310_007D)
	{
		ShipDesignCategory? shipDesignCategory = null;
		int[] array = _007B8310_007D;
		foreach (int num in array)
		{
			ShipDesignInfo shipDesignInfo = Gameplay.DesignsInfo[num];
			if (shipDesignInfo == null)
			{
				throw new InvalidOperationException($"Desing {num} is null");
			}
			ShipDesignCategory valueOrDefault = shipDesignCategory.GetValueOrDefault();
			if (!shipDesignCategory.HasValue)
			{
				valueOrDefault = shipDesignInfo.Category;
				shipDesignCategory = valueOrDefault;
			}
			if (!ShipDesignInfo.AliasEquals(shipDesignCategory.Value, shipDesignInfo.Category))
			{
				throw new InvalidOperationException("Check designs are from single category");
			}
		}
		return delegate(PlayerAccount _007B8337_007D, int _007B8338_007D, DateTime _007B8339_007D)
		{
			if (_007B8337_007D == null)
			{
				return new LocalizedString(string.Empty);
			}
			Tlist<ShipDesignInfo> tlist = new Tlist<ShipDesignInfo>(from _007B8331_007D in _007B8310_007D
				where _007B8309_007D || (_007B8337_007D.DesingElementsAtStorage[_007B8331_007D] == 0 && _007B8337_007D.Shipyard.List.All((PlayerShipDynamicInfo _007B8341_007D) => !_007B8341_007D.designEmenents.ContainsID(_007B8331_007D)))
				select Gameplay.DesignsInfo[_007B8331_007D]);
			if (tlist.Size == 0)
			{
				tlist.Add(_007B8310_007D.Select((int _007B8332_007D) => Gameplay.DesignsInfo[_007B8332_007D]));
			}
			ShipDesignInfo shipDesignInfo2 = tlist.Rand(new Sequence(_007B8338_007D));
			_007B8337_007D.DesingElementsAtStorage[shipDesignInfo2.ID]++;
			return (shipDesignInfo2.Category == ShipDesignCategory.ShipFullDesign) ? new LocalizedString(string.Empty, new LocalizedString(Local.GetKey(shipDesignInfo2.Category.ToStrLocal())), new LocalizedString(shipDesignInfo2.nameKey)) : new LocalizedString(string.Empty, new LocalizedString(shipDesignInfo2.nameKey));
		};
	}

	internal static ActionDelegate RandomShip(params int[] _007B8311_007D)
	{
		PlayerShipInfo[] infos = _007B8311_007D.Select((int _007B8333_007D) => Gameplay.PlayersInfo[_007B8333_007D]).ToArray();
		return delegate(PlayerAccount _007B8342_007D, int _007B8343_007D, DateTime _007B8344_007D)
		{
			if (_007B8342_007D == null)
			{
				return new LocalizedString("", Local.ship);
			}
			Tlist<PlayerShipInfo> tlist = new Tlist<PlayerShipInfo>(infos.Where((PlayerShipInfo _007B8345_007D) => !_007B8342_007D.Shipyard.ContainsInfo(_007B8345_007D) || infos.All((PlayerShipInfo _007B8346_007D) => _007B8342_007D.Shipyard.ContainsInfo(_007B8346_007D))));
			PlayerShipInfo playerShipInfo = tlist.Rand(new Sequence(_007B8343_007D));
			PlayerShipDynamicInfo playerShipDynamicInfo = _007B8342_007D.Shipyard.CreateNewShip(playerShipInfo, _007B8342_007D, null, _007B2038_007D: false, _007B2039_007D: false, _007B2040_007D: true);
			if (_007B8342_007D.ShipPlacesLeft == 0)
			{
				_007B8342_007D.MaxShipsCount.Value++;
			}
			return new LocalizedString(string.Empty, playerShipInfo.ShipName);
		};
	}

	internal static ActionDelegate Gold(int _007B8312_007D)
	{
		return delegate(PlayerAccount _007B8347_007D, int _007B8348_007D, DateTime _007B8349_007D)
		{
			if (_007B8347_007D != null)
			{
				_007B8347_007D.Gold += _007B8312_007D;
			}
			return (_007B8347_007D == null) ? new LocalizedString("chest_gold", _007B8312_007D) : new LocalizedString(string.Empty, _007B8312_007D + " ", new LocalizedString("gold2"));
		};
	}

	internal static ActionDelegate Monets(int _007B8313_007D)
	{
		return delegate(PlayerAccount _007B8350_007D, int _007B8351_007D, DateTime _007B8352_007D)
		{
			if (_007B8350_007D != null)
			{
				_007B8350_007D.Monets.Value += _007B8313_007D;
			}
			return new LocalizedString(string.Empty, $"{_007B8313_007D} ", new LocalizedString("monets"));
		};
	}

	internal static ActionDelegate Resource(int _007B8314_007D, int _007B8315_007D)
	{
		return delegate(PlayerAccount _007B8353_007D, int _007B8354_007D, DateTime _007B8355_007D)
		{
			if (_007B8353_007D != null)
			{
				_007B8353_007D.NearPortStorage.AddOrRemove(_007B8314_007D, _007B8315_007D);
				WosbTreasuryMaps.DetachMaps(_007B8353_007D);
			}
			return new LocalizedString(string.Empty, $"+{_007B8315_007D}x ", new LocalizedString(Gameplay.ItemsInfo.FromID(_007B8314_007D).nameKey));
		};
	}

	internal static ActionDelegate Ammo(int _007B8316_007D, int _007B8317_007D)
	{
		if (_007B8316_007D > Gameplay.BallsInfo.Count || Gameplay.BallsInfo[_007B8316_007D] == null)
		{
			throw new ArgumentException("id");
		}
		return delegate(PlayerAccount _007B8356_007D, int _007B8357_007D, DateTime _007B8358_007D)
		{
			_007B8356_007D?.CBallsAtStorage.AddOrRemove(_007B8316_007D, _007B8317_007D);
			return new LocalizedString(string.Empty, $"+{_007B8317_007D}x ", new LocalizedString(Gameplay.BallsInfo.FromID(_007B8316_007D).nameKey));
		};
	}

	internal static ActionDelegate PowderKeg(int _007B8318_007D, int _007B8319_007D)
	{
		if (_007B8318_007D > Gameplay.PowderKegsInfo.Count || Gameplay.PowderKegsInfo[_007B8318_007D] == null)
		{
			throw new ArgumentException("id");
		}
		return delegate(PlayerAccount _007B8359_007D, int _007B8360_007D, DateTime _007B8361_007D)
		{
			_007B8359_007D?.PowderKegsAtStorage.AddOrRemove(_007B8318_007D, _007B8319_007D);
			return new LocalizedString(string.Empty, $"+{_007B8319_007D}x ", new LocalizedString(Gameplay.PowderKegsInfo.FromID(_007B8318_007D).nameKey));
		};
	}

	internal static ActionDelegate TempGain(int _007B8320_007D, int _007B8321_007D)
	{
		return delegate(PlayerAccount _007B8362_007D, int _007B8363_007D, DateTime _007B8364_007D)
		{
			_007B8362_007D?.PowerupItemsAtStorage.AddOrRemove(_007B8320_007D, _007B8321_007D);
			return new LocalizedString(string.Empty, $"+{_007B8321_007D}x ", new LocalizedString(Gameplay.PowerupItems[_007B8320_007D].nameKey));
		};
	}

	internal static ActionDelegate Ship(int _007B8322_007D)
	{
		PlayerShipInfo info = Gameplay.PlayersInfo.FromID(_007B8322_007D);
		return delegate(PlayerAccount _007B8365_007D, int _007B8366_007D, DateTime _007B8367_007D)
		{
			if (_007B8365_007D != null)
			{
				PlayerShipDynamicInfo playerShipDynamicInfo = _007B8365_007D.Shipyard.CreateNewShip(info, _007B8365_007D, null, _007B2038_007D: false, _007B2039_007D: false, _007B2040_007D: true);
				if (_007B8365_007D.ShipPlacesLeft == 0)
				{
					_007B8365_007D.MaxShipsCount.Value++;
				}
			}
			return new LocalizedString(info.shipNameKey);
		};
	}

	internal static ActionDelegate Cannon(int _007B8323_007D, int _007B8324_007D)
	{
		if (_007B8323_007D > Gameplay.CannonsGameInfo.Count || Gameplay.CannonsGameInfo[_007B8323_007D] == null)
		{
			throw new ArgumentException("id");
		}
		return delegate(PlayerAccount _007B8368_007D, int _007B8369_007D, DateTime _007B8370_007D)
		{
			_007B8368_007D?.CannonsAtStorage.AddOrRemove(_007B8323_007D, _007B8324_007D);
			return new LocalizedString(string.Empty, $"+{_007B8324_007D}x ", new LocalizedString(Gameplay.CannonsGameInfo.FromID(_007B8323_007D).nameKey));
		};
	}
}
