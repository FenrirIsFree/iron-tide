namespace Common.Game;

public class QuestFishing : QuestStepHeader
{
	public int FishQuantity;

	public override int ProgressComparand => FishQuantity;

	public QuestFishing(string _007B7608_007D, int _007B7609_007D)
		: base(_007B7608_007D)
	{
		FishQuantity = _007B7609_007D;
	}
}
