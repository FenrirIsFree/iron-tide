namespace Common.Game;

public enum CannonsAttackMode
{
	SingleCannon,
	AllNormal,
	AllRandomized,
	X_AllAntiNormal
}
