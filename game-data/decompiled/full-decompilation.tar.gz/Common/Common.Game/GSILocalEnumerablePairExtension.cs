using System.Collections.Generic;
using System.Text;
using Common.Data;

namespace Common.Game;

public static class GSILocalEnumerablePairExtension
{
	public static string ToStringNC<T>(this GSILocalEnumerablePair<T> _007B5414_007D, bool _007B5415_007D = false) where T : IStorageAsset
	{
		return _007B5414_007D.Info.getName + ((_007B5414_007D.Count > 0 && !_007B5415_007D) ? (" +" + _007B5414_007D.Count) : (" " + _007B5414_007D.Count));
	}

	public static string ToStringCN<T>(this GSILocalEnumerablePair<T> _007B5416_007D, bool _007B5417_007D = false) where T : IStorageAsset
	{
		return ((_007B5416_007D.Count > 0 && !_007B5417_007D) ? ("+" + _007B5416_007D.Count) : _007B5416_007D.Count.ToString()) + " " + _007B5416_007D.Info.getName;
	}

	public static string ToStringClear<T>(this GSILocalEnumerablePair<T> _007B5418_007D) where T : IStorageAsset
	{
		return $"{_007B5418_007D.Count}x {_007B5418_007D.Info.getName}";
	}

	public static string ToStringWithComma<T>(this GSILocalEnumerable<T> _007B5419_007D) where T : IStorageAsset
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (GSILocalEnumerablePair<T> item in (IEnumerable<GSILocalEnumerablePair<T>>)_007B5419_007D/*cast due to .constrained prefix*/)
		{
			StringBuilder stringBuilder2 = stringBuilder;
			StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(4, 2, stringBuilder2);
			handler.AppendFormatted(item.Count);
			handler.AppendLiteral("x ");
			handler.AppendFormatted(item.Info.getName);
			handler.AppendLiteral(", ");
			stringBuilder2.Append(ref handler);
		}
		if (stringBuilder.Length > 2)
		{
			stringBuilder.Remove(stringBuilder.Length - 2, 2);
		}
		return stringBuilder.ToString();
	}
}
