namespace Common.Game;

public enum ArenaMode
{
	DuelTraning,
	DuelRating,
	TowerDefence,
	WallVsWall,
	Collecting
}
