using System;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;

namespace Common.Game;

public class WaterHazardLevelsInfo : WorldBitmap, IMPSerializable
{
	public const int c_sectionsCount = 22;

	public WaterHazardLevelsInfo()
		: base(22, Gameplay.WorldMapSizeXY)
	{
	}//IL_0003: Unknown result type (might be due to invalid IL or missing references)


	public void AddEvent(in Vector2 _007B5811_007D, int _007B5812_007D, bool _007B5813_007D)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		if (!Gameplay.WorldMap.IsInsideMap(in _007B5811_007D))
		{
			return;
		}
		Point _007B5931_007D = PositionToIndex2(in _007B5811_007D);
		int x = _007B5931_007D.X;
		int y = _007B5931_007D.Y;
		int _007B5815_007D = Index2Index(in _007B5931_007D);
		if (_007B5813_007D)
		{
			_007B5814_007D(_007B5815_007D, _007B5812_007D);
			int num = _007B5812_007D * 3 / 5;
			if (num > 0)
			{
				if (x < 21)
				{
					_007B5814_007D((x + 1) * 22 + y, num);
				}
				if (x > 1)
				{
					_007B5814_007D((x - 1) * 22 + y, num);
				}
				if (y < 21)
				{
					_007B5814_007D(x * 22 + (y + 1), num);
				}
				if (y > 1)
				{
					_007B5814_007D(x * 22 + (y - 1), num);
				}
			}
		}
		else
		{
			_007B5814_007D(_007B5815_007D, _007B5812_007D + _007B5812_007D * 2 / 5);
		}
	}

	private void _007B5814_007D(int _007B5815_007D, int _007B5816_007D)
	{
		bytes[_007B5815_007D] = (byte)Math.Min(254, bytes[_007B5815_007D] + _007B5816_007D);
	}

	public void ReduceEvents(int _007B5817_007D)
	{
		int num = bytes.Length;
		for (int i = 0; i < num; i++)
		{
			bytes[i] = (byte)Math.Max(0, bytes[i] - _007B5817_007D);
		}
	}

	public void ReduceEventsScaled(int _007B5818_007D)
	{
		int num = bytes.Length;
		for (int i = 0; i < num; i++)
		{
			bytes[i] = (byte)Math.Max(0, bytes[i] - ((bytes[i] > 50) ? _007B5818_007D : (_007B5818_007D / 2)));
		}
	}

	private void _007B5819_007D(WriterExtern _007B5820_007D)
	{
		_007B5820_007D.WriteBytes32bitSize(bytes);
	}

	private void _007B5821_007D(WriterExtern _007B5822_007D)
	{
		_007B5822_007D.ReadBytes32bitSize(ref bytes);
	}
}
