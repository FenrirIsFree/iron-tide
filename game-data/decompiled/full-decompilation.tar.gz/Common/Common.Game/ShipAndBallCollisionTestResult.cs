using Common.Resources;
using UWPhysicsWOSLib.Collision;

namespace Common.Game;

public struct ShipAndBallCollisionTestResult
{
	public CollisionTestResult BasicResult;

	public HitboxType NodeType;

	public byte NodeID;
}
