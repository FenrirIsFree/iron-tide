using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Game;

public class ArabPortCaptureStatus : PortCaptureStatus, IMPSerializable, ITKSerializable
{
	public ScoreDictionary<string> Points = new ScoreDictionary<string>();

	public ArabPortCaptureStatus(int _007B7774_007D)
		: base(_007B7774_007D)
	{
	}

	public ArabPortCaptureStatus()
	{
	}

	public virtual void AddPoints(uint _007B7775_007D, string _007B7776_007D, float _007B7777_007D)
	{
		Points.AddScore(_007B7776_007D, _007B7777_007D);
	}

	public virtual void SetStatusToCaptured(GuildCommon _007B7778_007D)
	{
		if (_007B7778_007D == null)
		{
			CapturedBy = string.Empty;
			CapturerFraction = FractionID.Empire;
		}
		else
		{
			CapturedBy = _007B7778_007D.Tag;
			CapturerFraction = _007B7778_007D.Fraction;
		}
	}

	public override void Boxing(WriterExtern _007B7779_007D)
	{
		base.Boxing(_007B7779_007D);
		_007B7779_007D.WriteStruct<short>((short)Points.Count);
		foreach (KeyValuePair<string, float> item in Points.BaseDictionary)
		{
			_007B7779_007D.Write(item.Key, (Encoding)null);
			_007B7779_007D.WriteStruct<float>(item.Value);
		}
	}

	public override void Unboxing(WriterExtern _007B7780_007D)
	{
		base.Unboxing(_007B7780_007D);
		short num = default(short);
		_007B7780_007D.ReadStruct<short>(ref num);
		Points = new ScoreDictionary<string>(10 + num);
		string key = default(string);
		float addScore = default(float);
		for (int i = 0; i < num; i++)
		{
			_007B7780_007D.ReadString(ref key, (Encoding)null);
			_007B7780_007D.ReadStruct<float>(ref addScore);
			Points.AddScore(key, addScore);
		}
	}

	public override void Boxing(TKWriterExtern _007B7781_007D)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		base.Boxing(_007B7781_007D);
		((TKWriterExtern)(ref _007B7781_007D)).WriteContent((short)5, (Action<WriterExtern>)delegate(WriterExtern _007B7786_007D)
		{
			_007B7786_007D.WriteStruct<int>(Points.Count);
			foreach (KeyValuePair<string, float> item in Points.BaseDictionary)
			{
				_007B7786_007D.Write(item.Key, (Encoding)null);
				_007B7786_007D.WriteStruct<float>(item.Value);
			}
		});
	}

	public override void Load(short _007B7782_007D, WriterExtern _007B7783_007D, out bool _007B7784_007D)
	{
		_007B7784_007D = true;
		base.Load(_007B7782_007D, _007B7783_007D, out var _007B7891_007D);
		if (_007B7891_007D)
		{
			return;
		}
		short num = _007B7782_007D;
		short num2 = num;
		if (num2 == 5)
		{
			int num3 = default(int);
			_007B7783_007D.ReadStruct<int>(ref num3);
			Points = new ScoreDictionary<string>(10 + num3);
			string key = default(string);
			float addScore = default(float);
			for (int i = 0; i < num3; i++)
			{
				_007B7783_007D.ReadString(ref key, (Encoding)null);
				_007B7783_007D.ReadStruct<float>(ref addScore);
				Points.AddScore(key, addScore);
			}
		}
		else
		{
			_007B7784_007D = false;
		}
	}

	[CompilerGenerated]
	private void _007B7785_007D(WriterExtern _007B7786_007D)
	{
		_007B7786_007D.WriteStruct<int>(Points.Count);
		foreach (KeyValuePair<string, float> item in Points.BaseDictionary)
		{
			_007B7786_007D.Write(item.Key, (Encoding)null);
			_007B7786_007D.WriteStruct<float>(item.Value);
		}
	}
}
