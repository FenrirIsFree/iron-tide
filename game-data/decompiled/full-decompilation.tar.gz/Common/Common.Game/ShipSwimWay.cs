namespace Common.Game;

public enum ShipSwimWay
{
	Zero,
	UnitRight,
	UnitLeft
}
