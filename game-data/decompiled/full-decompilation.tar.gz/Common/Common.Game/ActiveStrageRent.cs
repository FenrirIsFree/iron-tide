using System;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Game;

public struct ActiveStrageRent : IMPSerializable
{
	public byte OptionIndex;

	public byte PortID;

	public double RemainSec;

	public int CapacityBonus => WosbStorages.RentOptions[Math.Min(OptionIndex, WosbStorages.RentOptions.Length - 1)].bonus.Value;

	public ActiveStrageRent(byte _007B4308_007D, byte _007B4309_007D, double _007B4310_007D)
	{
		OptionIndex = _007B4308_007D;
		PortID = _007B4309_007D;
		RemainSec = _007B4310_007D;
	}

	public void Boxing(WriterExtern _007B4311_007D)
	{
		_007B4311_007D.WriteByte(OptionIndex);
		_007B4311_007D.WriteByte(PortID);
		_007B4311_007D.WriteStruct<double>(RemainSec);
	}

	public void Unboxing(WriterExtern _007B4312_007D)
	{
		OptionIndex = _007B4312_007D.ReadByte();
		PortID = _007B4312_007D.ReadByte();
		_007B4312_007D.ReadStruct<double>(ref RemainSec);
	}
}
