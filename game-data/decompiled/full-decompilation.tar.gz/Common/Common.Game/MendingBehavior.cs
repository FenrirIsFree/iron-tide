namespace Common.Game;

internal class MendingBehavior
{
}
