using System;
using CommonDataTypes;
using TheraEngine;
using TheraEngine.Assets.Graphics;

namespace Common.Game;

public class InterestPointInfo
{
	public readonly int ID;

	public VirtualTexture Texture;

	public readonly int ResearchRewardCoins;

	public readonly int ResearchRewardGold;

	public readonly GSI ResearchRewardRes;

	private static readonly string keyPrefix = "interest_point_";

	public string Name => Local.Current($"{keyPrefix}{ID}_name");

	public string Description => Local.Current($"{keyPrefix}{ID}_desc");

	public InterestPointInfo(int _007B5757_007D, InterestPointInfoToken _007B5758_007D)
	{
		ID = _007B5757_007D;
		Texture = new VirtualTexture(Engine.FillerTexture, "", "Textures\\InterestPoints\\" + _007B5758_007D.TextureName);
		ResearchRewardRes = new GSI();
		if (string.IsNullOrEmpty(_007B5758_007D.ResearchReward))
		{
			return;
		}
		string[] array = _007B5758_007D.ResearchReward.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
		for (int i = 0; i < array.Length; i += 2)
		{
			if (array[i] == "gold")
			{
				ResearchRewardGold = int.Parse(array[i + 1]);
			}
			else if (array[i] == "coins")
			{
				ResearchRewardCoins = int.Parse(array[i + 1]);
			}
			else
			{
				ResearchRewardRes.Exs(Gameplay.GetResIDByAnnotation(array[i]), int.Parse(array[i + 1]));
			}
		}
	}
}
