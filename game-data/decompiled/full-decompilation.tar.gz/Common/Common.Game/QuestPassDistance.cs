namespace Common.Game;

public class QuestPassDistance : QuestStepHeader
{
	public int RequiredDistance;

	public bool DisallowAnyPvpProtection;

	public override int ProgressComparand => RequiredDistance;

	public QuestPassDistance(string _007B7672_007D, int _007B7673_007D)
		: base(_007B7672_007D)
	{
		RequiredDistance = _007B7673_007D;
		DisallowAnyPvpProtection = true;
	}
}
