using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Data;
using Common.Resources;
using Microsoft.Xna.Framework.Graphics;
using TheraEngine;
using TheraEngine.Collections;

namespace Common.Game;

public class PowerupItemInfo : IGameResource
{
	[CompilerGenerated]
	private sealed class _003CEffectsFor_003Ed__42 : IEnumerable<ShipBonus>, IEnumerable, IEnumerator<ShipBonus>, IEnumerator, IDisposable
	{
		private int _007B7201_007D;

		private ShipBonus _007B7202_007D;

		private int _007B7203_007D;

		private Ship _007B7204_007D;

		public Ship _003C_003E3__ship;

		public PowerupItemInfo _003C_003E4__this;

		private int _007B7205_007D;

		private Player _007B7206_007D;

		private IEnumerator<ShipBonus> _007B7207_007D;

		private ShipBonus _007B7208_007D;

		ShipBonus IEnumerator<ShipBonus>.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B7202_007D;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _007B7202_007D;
			}
		}

		[DebuggerHidden]
		public _003CEffectsFor_003Ed__42(int _007B7195_007D)
		{
			_007B7201_007D = _007B7195_007D;
			_007B7203_007D = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		private void _007B7196_007D()
		{
			int num = _007B7201_007D;
			if (num == -3 || (uint)(num - 1) <= 4u)
			{
				try
				{
				}
				finally
				{
					_007B7198_007D();
				}
			}
			_007B7206_007D = null;
			_007B7207_007D = null;
			_007B7208_007D = default(ShipBonus);
			_007B7201_007D = -2;
		}

		void IDisposable.Dispose()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7196}
			this._007B7196_007D();
		}

		private bool _007B7197_007D()
		{
			try
			{
				switch (_007B7201_007D)
				{
				default:
					return false;
				case 0:
					_007B7201_007D = -1;
					_007B7206_007D = _007B7204_007D as Player;
					_007B7205_007D = ((_007B7206_007D != null) ? _007B7206_007D.UsedShipPlayer.CraftFrom.Rank : ((Npc)_007B7204_007D).UsedShipNpc.Information.BasedOn.Rank);
					_007B7207_007D = ((IEnumerable<ShipBonus>)_003C_003E4__this.CommonEffects).GetEnumerator();
					_007B7201_007D = -3;
					break;
				case 1:
					_007B7201_007D = -3;
					goto IL_02e7;
				case 2:
					_007B7201_007D = -3;
					goto IL_02e7;
				case 3:
					_007B7201_007D = -3;
					goto IL_02e7;
				case 4:
					_007B7201_007D = -3;
					goto IL_02e7;
				case 5:
					{
						_007B7201_007D = -3;
						goto IL_02e7;
					}
					IL_02e7:
					_007B7208_007D = default(ShipBonus);
					break;
				}
				if (_007B7207_007D.MoveNext())
				{
					_007B7208_007D = _007B7207_007D.Current;
					if (_007B7208_007D.Type == ShipBonusEffect.ServMendingStrength || _007B7208_007D.Type == ShipBonusEffect.ServMendingStrengthTemporal)
					{
						_007B7202_007D = new ShipBonus(_007B7208_007D.Type, _007B7208_007D.Value * (1f + _007B7204_007D.UsedShip.MendingKitEffectivityBonus) / (float)_003C_003E4__this.WorkTime.Value);
						_007B7201_007D = 1;
						return true;
					}
					if (_007B7208_007D.Type == ShipBonusEffect.ServMendingSailes)
					{
						_007B7202_007D = new ShipBonus(_007B7208_007D.Type, _007B7208_007D.Value * (1f + _007B7204_007D.UsedShip.MendingKitEffectivityBonus) / 100f / (float)_003C_003E4__this.WorkTime.Value);
						_007B7201_007D = 2;
						return true;
					}
					if (_007B7208_007D.Type == ShipBonusEffect.MSpeed && _007B7208_007D.Value > 1.5f)
					{
						_007B7202_007D = new ShipBonus(_007B7208_007D.Type, _007B7208_007D.Value + _007B7204_007D.UsedShip.EffectJerkBonusSpeed);
						_007B7201_007D = 3;
						return true;
					}
					if (_007B7208_007D.Type == ShipBonusEffect.MWeaponPenetration && _007B7204_007D.UsedShip.WeaponPenetrationBonus < 1f)
					{
						_007B7202_007D = new ShipBonus(_007B7208_007D.Type, _007B7208_007D.Value);
						_007B7201_007D = 4;
						return true;
					}
					_007B7202_007D = _007B7208_007D;
					_007B7201_007D = 5;
					return true;
				}
				_007B7198_007D();
				_007B7207_007D = null;
				return false;
			}
			catch
			{
				//try-fault
				_007B7196_007D();
				throw;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7197}
			return this._007B7197_007D();
		}

		private void _007B7198_007D()
		{
			_007B7201_007D = -1;
			if (_007B7207_007D != null)
			{
				_007B7207_007D.Dispose();
			}
		}

		[DebuggerHidden]
		private void _007B7199_007D()
		{
			throw new NotSupportedException();
		}

		void IEnumerator.Reset()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7199}
			this._007B7199_007D();
		}

		[DebuggerHidden]
		IEnumerator<ShipBonus> IEnumerable<ShipBonus>.GetEnumerator()
		{
			_003CEffectsFor_003Ed__42 _003CEffectsFor_003Ed__;
			if (_007B7201_007D == -2 && _007B7203_007D == Environment.CurrentManagedThreadId)
			{
				_007B7201_007D = 0;
				_003CEffectsFor_003Ed__ = this;
			}
			else
			{
				_003CEffectsFor_003Ed__ = new _003CEffectsFor_003Ed__42(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			_003CEffectsFor_003Ed__._007B7204_007D = _003C_003E3__ship;
			return _003CEffectsFor_003Ed__;
		}

		[DebuggerHidden]
		private IEnumerator _007B7200_007D()
		{
			return ((IEnumerable<ShipBonus>)this).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			//ILSpy generated this explicit interface implementation from .override directive in {7200}
			return this._007B7200_007D();
		}
	}

	public int Index;

	public readonly string UiCategory;

	public readonly Texture2D Icon;

	public readonly RTI Cooldown;

	public readonly RTI WorkTime;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private PowerupItemServerEffect _007B7188_007D;

	public readonly Tlist<ShipBonus> CommonEffects;

	public readonly Action<Ship> EffectWhenApplied;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private int? _007B7189_007D;

	public readonly CraftingRecipe? CraftOrShopOrNull;

	public int GroupDistanceLimit = int.MaxValue;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B7190_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B7191_007D;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private bool _007B7192_007D;

	public Tlist<ShipBonus> EffectsWhenInstalled;

	private bool _007B7193_007D;

	internal string overrideNameKey;

	internal string nameKey => overrideNameKey ?? ("item_name" + Index);

	public string Name => Local.Current(nameKey);

	public string Description => Local.Current("item_desc" + Index);

	public PowerupItemServerEffect ServerEffect
	{
		[CompilerGenerated]
		get
		{
			return _007B7188_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B7188_007D = value;
		}
	}

	public int? DisallowInLowRangShips
	{
		[CompilerGenerated]
		get
		{
			return _007B7189_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B7189_007D = value;
		}
	}

	public bool IsGroupEffect
	{
		[CompilerGenerated]
		get
		{
			return _007B7190_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B7190_007D = value;
		}
	}

	public bool AllowInterrupt
	{
		[CompilerGenerated]
		get
		{
			return _007B7191_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B7191_007D = value;
		}
	}

	public bool CanBeUsedByLegendaryNpc
	{
		[CompilerGenerated]
		get
		{
			return _007B7192_007D;
		}
		[CompilerGenerated]
		internal set
		{
			_007B7192_007D = value;
		}
	}

	public bool HideFromCraftUi
	{
		get
		{
			return _007B7193_007D || Name == Local.removed || PowerupItemsGenerator.SkillsIds.Contains(Index);
		}
		set
		{
			_007B7193_007D = true;
		}
	}

	short IGameResource.ID => (short)Index;

	public PowerupItemInfo(string _007B7178_007D, Texture2D _007B7179_007D, int _007B7180_007D, int _007B7181_007D, CraftingRecipe? _007B7182_007D, Action<Ship> _007B7183_007D, params ShipBonus[] _007B7184_007D)
	{
		UiCategory = _007B7178_007D;
		Icon = _007B7179_007D;
		Cooldown = new RTI(_007B7180_007D);
		WorkTime = new RTI(_007B7181_007D);
		CraftOrShopOrNull = _007B7182_007D;
		EffectWhenApplied = _007B7183_007D;
		IsGroupEffect = false;
		ServerEffect = PowerupItemServerEffect.NoEffect;
		CommonEffects = new Tlist<ShipBonus>(_007B7184_007D);
		if (WorkTime.Value == 0 && CommonEffects.Size > 0)
		{
			throw new InvalidOperationException();
		}
		EffectsWhenInstalled = new Tlist<ShipBonus>();
	}

	[IteratorStateMachine(typeof(_003CEffectsFor_003Ed__42))]
	internal IEnumerable<ShipBonus> EffectsFor(Ship _007B7185_007D)
	{
		//yield-return decompiler failed: Method not found
		return new _003CEffectsFor_003Ed__42(-2)
		{
			_003C_003E4__this = this,
			_003C_003E3__ship = _007B7185_007D
		};
	}

	public void StartOrApply(Ship _007B7186_007D)
	{
		foreach (ShipBonus item in EffectsFor(_007B7186_007D))
		{
			_007B7186_007D.UsedShip.DynamicBonus.AddEffect(item.Type, item.Value, WorkTime.Value * 1000, (byte)Index);
		}
		EffectWhenApplied?.Invoke(_007B7186_007D);
	}

	public void Reset(Ship _007B7187_007D)
	{
		_007B7187_007D.UsedShip.DynamicBonus.RemoveSameEffect((byte)Index);
	}
}
