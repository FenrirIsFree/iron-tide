using System;
using Common.Account;

namespace Common.Game;

public delegate LocalizedString ActionDelegate(PlayerAccount _007B8237_007D, int _007B8238_007D, DateTime _007B8239_007D);
