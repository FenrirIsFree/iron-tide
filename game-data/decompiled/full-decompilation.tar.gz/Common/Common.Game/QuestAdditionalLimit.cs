namespace Common.Game;

public enum QuestAdditionalLimit
{
	CDontDeath,
	CDontGetDamage,
	CDontUseCannons,
	RShipRankRelyOnPortPlusOne,
	RWithoutPeacefulFlag,
	RDontGetDamageFromTarget,
	RDontGetDamage,
	FVisibleInGuild,
	FHavingHoldUpgradeWarning
}
