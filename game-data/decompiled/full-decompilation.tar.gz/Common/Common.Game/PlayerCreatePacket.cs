using System.Text;
using Common.Account;
using Common.Resources;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;
using TheraEngine.Collections;
using TheraEngine.PacketValues;

namespace Common.Game;

public class PlayerCreatePacket : ShipCreatePacket
{
	public byte ControlCode;

	public byte PlayerInfoID;

	public ShipProperties FinalShipProperties;

	public float StaticMobility;

	public CannonCollection Cannons;

	public Map<CannonGameInstance> Mortars;

	public string Name;

	public bool DebugEnabled;

	public byte AccRank;

	public uint AccountSID;

	public SlottedMap<ShipDesignInfo> DesingElements;

	public OpenWorldFlag WorldFlags;

	public Vector2 DesignBigLampPosition;

	public Vector3 DesignBowFigurePosition;

	public Bits32 decal1SelectedSailes;

	public Bits32 decal2SelectedSailes;

	public float ProtectionSafeZoneTimeout;

	public float[] PrecompuredBonusEffects;

	public ShipVisualStatusFlags VisualFlags;

	public CaptainTitle TitleIcon;

	public float CurrentCapacitySpeedFactor;

	public bool CanUseWheel;

	public PlayerReputations Reputations;

	public bool FlagsTensityMode;

	public bool AggressorFlag;

	public PlayerCreatePacket()
	{
	}

	public PlayerCreatePacket(Player _007B4959_007D, string _007B4960_007D, int _007B4961_007D, uint _007B4962_007D, in GuildShortInfo _007B4963_007D, OpenWorldFlag _007B4964_007D, GSI _007B4965_007D, ShipVisualStatusFlags _007B4966_007D, Tlist<PublicDesignInfo> _007B4967_007D, bool _007B4968_007D)
		: base(_007B4959_007D, in _007B4963_007D, _007B4967_007D)
	{
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		PlayerShipDynamicInfo usedShipPlayer = _007B4959_007D.UsedShipPlayer;
		ControlCode = _007B4959_007D.FirstController.GetCode;
		PlayerInfoID = (byte)usedShipPlayer.CraftFrom.ID;
		FinalShipProperties = new ShipProperties(usedShipPlayer.MaxHpWithoutTempEffects, usedShipPlayer.Capacity, usedShipPlayer.ArmorWithoutTempEffects, usedShipPlayer.SpeedWithoutTempEffects);
		CurrentCapacitySpeedFactor = _007B4959_007D.basicCapacitySpeedFactor;
		Cannons = usedShipPlayer.Cannons;
		Mortars = usedShipPlayer.Mortars;
		Name = _007B4960_007D;
		DebugEnabled = _007B4959_007D.DebugEnabled;
		AccRank = (byte)_007B4961_007D;
		AccountSID = _007B4962_007D;
		DesingElements = usedShipPlayer.designEmenents;
		WorldFlags = _007B4964_007D;
		StaticMobility = usedShipPlayer.MobilityWithoutTempEffects;
		DesignBigLampPosition = usedShipPlayer.BigLampPosition;
		DesignBowFigurePosition = usedShipPlayer.BowFigurePosition;
		ItemsInHoldExemplary = _007B4965_007D;
		decal1SelectedSailes = _007B4959_007D.UsedShipPlayer.Decal1SelectedSailesBits;
		decal2SelectedSailes = _007B4959_007D.UsedShipPlayer.Decal2SelectedSailesBits;
		ProtectionSafeZoneTimeout = _007B4959_007D.ProtectionSafeZoneTimeout;
		VisualFlags = _007B4966_007D;
		PrecompuredBonusEffects = new float[14]
		{
			usedShipPlayer.MendingKitEffectivityBonus,
			usedShipPlayer.EffectJerkBonusSpeed,
			usedShipPlayer.SpeedChangeBonus,
			usedShipPlayer.MakeCrewInvisible ? 1 : 0,
			usedShipPlayer.CrewPlaces,
			usedShipPlayer.TiltReduce,
			_007B4959_007D.PlayerMarchingModeBonusBySkill,
			usedShipPlayer.MarchingModeSpeed,
			usedShipPlayer.HasExtraMortarUpgrade ? 1 : 0,
			usedShipPlayer.SpeedLossInMarchingMode,
			usedShipPlayer.ExtraCrewLimit,
			usedShipPlayer.MobilityWithLowHp,
			0f,
			_007B4959_007D.PlayerDisableDestructionTilt ? 1 : 0
		};
		TitleIcon = _007B4959_007D.AccountConnection.SelectedCaptainTitle;
		CanUseWheel = _007B4959_007D.physicsBody.CanUseWheel;
		Reputations = _007B4959_007D.AccountConnection.Reputations;
		FlagsTensityMode = _007B4959_007D.AccountConnection.TensityMode;
		AggressorFlag = _007B4968_007D;
	}

	public override void Boxing(WriterExtern _007B4969_007D)
	{
		base.Boxing(_007B4969_007D);
		_007B4969_007D.WriteByte(ControlCode);
		_007B4969_007D.WriteByte(PlayerInfoID);
		_007B4969_007D.Write<ShipProperties>(ref FinalShipProperties);
		PlayerShipInfo playerShipInfo = Gameplay.PlayersInfo.FromID(PlayerInfoID);
		Cannons.Boxing(_007B4969_007D, playerShipInfo.StaticInfo);
		_007B4969_007D.WriteMap(Mortars);
		_007B4969_007D.Write(Name, (Encoding)null);
		_007B4969_007D.Write(DebugEnabled);
		_007B4969_007D.WriteByte(AccRank);
		_007B4969_007D.WriteStruct<uint>(ref AccountSID);
		_007B4969_007D.WriteNoNull<SlottedMap<ShipDesignInfo>>(DesingElements);
		_007B4969_007D.WriteByte((byte)WorldFlags);
		_007B4969_007D.WriteStruct<float>(ref StaticMobility);
		if (DesingElements[2] != null)
		{
			_007B4969_007D.WriteStruct<Vector2>(ref DesignBigLampPosition);
		}
		if (DesingElements[1] != null)
		{
			_007B4969_007D.WriteStruct<int>(decal1SelectedSailes.Value);
		}
		if (DesingElements[3] != null)
		{
			_007B4969_007D.WriteStruct<int>(decal2SelectedSailes.Value);
		}
		if (DesingElements[5] != null)
		{
			_007B4969_007D.WriteStruct<Vector3>(ref DesignBowFigurePosition);
		}
		_007B4969_007D.WriteByte((byte)PrecompuredBonusEffects.Length);
		for (int i = 0; i < PrecompuredBonusEffects.Length; i++)
		{
			_007B4969_007D.WriteStruct<float>(PrecompuredBonusEffects[i]);
		}
		_007B4969_007D.WriteStruct<float>(ProtectionSafeZoneTimeout);
		_007B4969_007D.WriteByte((byte)VisualFlags);
		_007B4969_007D.WriteByte((byte)TitleIcon);
		_007B4969_007D.WriteStruct<float>(CurrentCapacitySpeedFactor);
		_007B4969_007D.Write(CanUseWheel);
		_007B4969_007D.WriteNoNull<PlayerReputations>(Reputations);
		_007B4969_007D.Write(FlagsTensityMode);
		_007B4969_007D.Write(AggressorFlag);
	}

	public override void Unboxing(WriterExtern _007B4970_007D)
	{
		base.Unboxing(_007B4970_007D);
		ControlCode = _007B4970_007D.ReadByte();
		PlayerInfoID = _007B4970_007D.ReadByte();
		_007B4970_007D.ReadIMPS_struct<ShipProperties>(ref FinalShipProperties);
		PlayerShipInfo playerShipInfo = Gameplay.PlayersInfo.FromID(PlayerInfoID);
		Cannons = new CannonCollection();
		Cannons.Unboxing(_007B4970_007D, null, playerShipInfo.StaticInfo);
		_007B4970_007D.ReadMap(out Mortars);
		_007B4970_007D.ReadString(ref Name, (Encoding)null);
		_007B4970_007D.ReadBoolean(ref DebugEnabled);
		AccRank = _007B4970_007D.ReadByte();
		_007B4970_007D.ReadStruct<uint>(ref AccountSID);
		_007B4970_007D.ReadIMPSNoNull<SlottedMap<ShipDesignInfo>>(ref DesingElements);
		WorldFlags = (OpenWorldFlag)_007B4970_007D.ReadByte();
		_007B4970_007D.ReadStruct<float>(ref StaticMobility);
		if (DesingElements[2] != null)
		{
			_007B4970_007D.ReadStruct<Vector2>(ref DesignBigLampPosition);
		}
		if (DesingElements[1] != null)
		{
			_007B4970_007D.ReadStruct<int>(ref decal1SelectedSailes.Value);
		}
		if (DesingElements[3] != null)
		{
			_007B4970_007D.ReadStruct<int>(ref decal2SelectedSailes.Value);
		}
		if (DesingElements[5] != null)
		{
			_007B4970_007D.ReadStruct<Vector3>(ref DesignBowFigurePosition);
		}
		byte b = _007B4970_007D.ReadByte();
		PrecompuredBonusEffects = new float[b];
		for (int i = 0; i < b; i++)
		{
			_007B4970_007D.ReadStruct<float>(ref PrecompuredBonusEffects[i]);
		}
		_007B4970_007D.ReadStruct<float>(ref ProtectionSafeZoneTimeout);
		VisualFlags = (ShipVisualStatusFlags)_007B4970_007D.ReadByte();
		TitleIcon = (CaptainTitle)_007B4970_007D.ReadByte();
		_007B4970_007D.ReadStruct<float>(ref CurrentCapacitySpeedFactor);
		_007B4970_007D.ReadBoolean(ref CanUseWheel);
		_007B4970_007D.ReadIMPSNoNull<PlayerReputations>(ref Reputations);
		_007B4970_007D.ReadBoolean(ref FlagsTensityMode);
		_007B4970_007D.ReadBoolean(ref AggressorFlag);
	}
}
