using System.CodeDom.Compiler;
using System.Threading;

namespace System.Text.RegularExpressions.Generated;

[GeneratedCode("System.Text.RegularExpressions.Generator", "7.0.10.26716")]
internal static class _003CRegexGenerator_g_003EF0C3BD9BB37024C1C1D9D4B7EE90EE7516B5C31DF06DF20770F21125BE4FD7C5D__Utilities
{
	internal static readonly TimeSpan s_defaultTimeout = ((AppContext.GetData("REGEX_DEFAULT_MATCH_TIMEOUT") is TimeSpan timeSpan) ? timeSpan : Regex.InfiniteMatchTimeout);

	internal static readonly bool s_hasTimeout = s_defaultTimeout != Timeout.InfiniteTimeSpan;
}
