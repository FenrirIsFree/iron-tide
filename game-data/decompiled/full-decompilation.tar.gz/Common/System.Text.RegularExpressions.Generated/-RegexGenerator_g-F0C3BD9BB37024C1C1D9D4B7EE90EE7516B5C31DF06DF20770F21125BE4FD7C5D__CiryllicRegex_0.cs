using System.CodeDom.Compiler;
using System.Runtime.CompilerServices;

namespace System.Text.RegularExpressions.Generated;

[GeneratedCode("System.Text.RegularExpressions.Generator", "7.0.10.26716")]
[SkipLocalsInit]
internal sealed class _003CRegexGenerator_g_003EF0C3BD9BB37024C1C1D9D4B7EE90EE7516B5C31DF06DF20770F21125BE4FD7C5D__CiryllicRegex_0 : Regex
{
	private sealed class RunnerFactory : RegexRunnerFactory
	{
		private sealed class Runner : RegexRunner
		{
			protected override void Scan(ReadOnlySpan<char> inputSpan)
			{
				if (TryFindNextPossibleStartingPosition(inputSpan))
				{
					int num = runtextpos;
					Capture(0, num, runtextpos = num + 1);
				}
			}

			private bool TryFindNextPossibleStartingPosition(ReadOnlySpan<char> inputSpan)
			{
				int num = runtextpos;
				if ((uint)num < (uint)inputSpan.Length)
				{
					ReadOnlySpan<char> readOnlySpan = inputSpan.Slice(num);
					for (int i = 0; i < readOnlySpan.Length; i++)
					{
						if (char.IsBetween(readOnlySpan[i], 'Ѐ', 'ӿ'))
						{
							runtextpos = num + i;
							return true;
						}
					}
				}
				runtextpos = inputSpan.Length;
				return false;
			}
		}

		protected override RegexRunner CreateInstance()
		{
			return new Runner();
		}
	}

	internal static readonly _003CRegexGenerator_g_003EF0C3BD9BB37024C1C1D9D4B7EE90EE7516B5C31DF06DF20770F21125BE4FD7C5D__CiryllicRegex_0 Instance = new _003CRegexGenerator_g_003EF0C3BD9BB37024C1C1D9D4B7EE90EE7516B5C31DF06DF20770F21125BE4FD7C5D__CiryllicRegex_0();

	private _003CRegexGenerator_g_003EF0C3BD9BB37024C1C1D9D4B7EE90EE7516B5C31DF06DF20770F21125BE4FD7C5D__CiryllicRegex_0()
	{
		pattern = "\\p{IsCyrillic}";
		roptions = RegexOptions.None;
		Regex.ValidateMatchTimeout(_003CRegexGenerator_g_003EF0C3BD9BB37024C1C1D9D4B7EE90EE7516B5C31DF06DF20770F21125BE4FD7C5D__Utilities.s_defaultTimeout);
		internalMatchTimeout = _003CRegexGenerator_g_003EF0C3BD9BB37024C1C1D9D4B7EE90EE7516B5C31DF06DF20770F21125BE4FD7C5D__Utilities.s_defaultTimeout;
		factory = new RunnerFactory();
		capsize = 1;
	}
}
