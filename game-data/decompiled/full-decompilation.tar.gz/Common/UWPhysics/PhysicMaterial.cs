namespace UWPhysics;

public struct PhysicMaterial
{
	public readonly float Dencity;

	public readonly float Elasticity;

	public readonly float Friction;

	public static PhysicMaterial Wood => new PhysicMaterial(690f, 14f, 0.5f);

	public static PhysicMaterial Iron => new PhysicMaterial(7800f, 22f, 0.5f);

	public PhysicMaterial(float _007B3_007D, float _007B4_007D, float _007B5_007D)
	{
		Dencity = _007B3_007D;
		Elasticity = _007B4_007D;
		Friction = _007B5_007D;
	}
}
