using System;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnChatMessageEvent : IPacketBase, IMPSerializable
{
	public ChatRoomType Room;

	public ChatMessageDefault Payload1;

	public LocalizedChatMessage Payload2;

	public bool IsLocalized;

	public bool IsOutdated;

	public DateTime OutdatedServerDateTime;

	public FlowOfPack Flow => FlowOfPack.Any;

	public uint SID => IsLocalized ? Payload2.SID : Payload1.SID;

	public string Name => IsLocalized ? Payload2.PlayerNameFetched : Payload1.PlayerName;

	public string Message => IsLocalized ? Payload2.MessageFetched : Payload1.Message;

	public OnChatMessageEvent(ChatRoomType _007B10408_007D, in ChatMessageDefault _007B10409_007D)
	{
		Room = _007B10408_007D;
		Payload1 = _007B10409_007D;
		Payload2 = default(LocalizedChatMessage);
		IsLocalized = false;
		IsOutdated = false;
		OutdatedServerDateTime = default(DateTime);
	}

	public OnChatMessageEvent(ChatRoomType _007B10410_007D, in LocalizedChatMessage _007B10411_007D)
	{
		Room = _007B10410_007D;
		Payload1 = default(ChatMessageDefault);
		Payload2 = _007B10411_007D;
		IsLocalized = true;
		IsOutdated = false;
		OutdatedServerDateTime = default(DateTime);
	}

	public void Boxing(WriterExtern _007B10412_007D)
	{
		_007B10412_007D.WriteEnum((object)Room);
		_007B10412_007D.Write(IsLocalized);
		if (IsLocalized)
		{
			_007B10412_007D.Write<LocalizedChatMessage>(ref Payload2);
		}
		else
		{
			_007B10412_007D.Write<ChatMessageDefault>(ref Payload1);
		}
		_007B10412_007D.Write(IsOutdated);
		if (IsOutdated)
		{
			_007B10412_007D.WriteStruct<long>(OutdatedServerDateTime.Ticks);
		}
	}

	public void Unboxing(WriterExtern _007B10413_007D)
	{
		_007B10413_007D.ReadEnum<ChatRoomType>(ref Room);
		_007B10413_007D.ReadBoolean(ref IsLocalized);
		if (IsLocalized)
		{
			_007B10413_007D.ReadIMPS_struct<LocalizedChatMessage>(ref Payload2);
		}
		else
		{
			_007B10413_007D.ReadIMPS_struct<ChatMessageDefault>(ref Payload1);
		}
		_007B10413_007D.ReadBoolean(ref IsOutdated);
		if (IsOutdated)
		{
			long ticks = default(long);
			_007B10413_007D.ReadStruct<long>(ref ticks);
			OutdatedServerDateTime = new DateTime(ticks);
		}
	}
}
