using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnNpcAsCaperActionMsg : IPacketBase, IMPSerializable
{
	public enum Type
	{
		DestroyForResources,
		RestoreShip,
		RefillUnits,
		RequestStatusAndStop,
		LetGo,
		Unbind,
		MoveResFrom,
		MoveResTo,
		MoveAmmoFrom,
		MoveAmmoTo,
		StoreToIsle,
		GetFromIsle,
		AgressiveMode,
		NeutralMode,
		PassiveMode,
		WaitMode
	}

	public int NpcUID;

	public Type Action;

	public GSI parameter;

	public CapturedShipIntance instanceOrNull;

	public FlowOfPack Flow => FlowOfPack.Any;

	public OnNpcAsCaperActionMsg(int _007B10078_007D, Type _007B10079_007D, CapturedShipIntance _007B10080_007D)
	{
		NpcUID = _007B10078_007D;
		Action = _007B10079_007D;
		parameter = null;
		instanceOrNull = _007B10080_007D;
	}

	public OnNpcAsCaperActionMsg(int _007B10081_007D, Type _007B10082_007D, GSI _007B10083_007D)
	{
		NpcUID = _007B10081_007D;
		Action = _007B10082_007D;
		parameter = _007B10083_007D;
		instanceOrNull = null;
	}

	public void Boxing(WriterExtern _007B10084_007D)
	{
		_007B10084_007D.WriteStruct<int>(NpcUID);
		_007B10084_007D.WriteByte((byte)Action);
		_007B10084_007D.Write<GSI>(parameter);
		_007B10084_007D.Write<CapturedShipIntance>(instanceOrNull);
	}

	public void Unboxing(WriterExtern _007B10085_007D)
	{
		_007B10085_007D.ReadStruct<int>(ref NpcUID);
		Action = (Type)_007B10085_007D.ReadByte();
		_007B10085_007D.ReadIMPS<GSI>(ref parameter);
		_007B10085_007D.ReadIMPS<CapturedShipIntance>(ref instanceOrNull);
	}
}
