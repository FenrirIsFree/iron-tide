using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnConsoleCommandExecuteAsOtherClient : IPacketBase, IMPSerializable
{
	public int uID;

	public string RawString;

	public FlowOfPack Flow => FlowOfPack.Any;

	public void Boxing(WriterExtern fieldWriter)
	{
		fieldWriter.WriteStruct<int>(uID);
		fieldWriter.Write(RawString, (Encoding)null);
	}

	public void Unboxing(WriterExtern fieldReader)
	{
		fieldReader.ReadStruct<int>(ref uID);
		fieldReader.ReadString(ref RawString, (Encoding)null);
	}
}
