using System;
using System.Collections.Generic;
using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;
using WOS.Server.Core;

namespace Common.Packets;

public struct OnBonusCodeEntryResultReceived : IPacketBase, IMPSerializable
{
	public Tlist<BonusCodeEntry> Entries;

	public DateTime ServerTime;

	public string Code;

	public FlowOfPack Flow => FlowOfPack.FromServerToClient;

	public OnBonusCodeEntryResultReceived(string _007B10577_007D, IEnumerable<BonusCodeEntry> _007B10578_007D, DateTime _007B10579_007D)
	{
		Code = _007B10577_007D;
		Entries = ((_007B10578_007D == null) ? Tlist<BonusCodeEntry>.EmptyReadonly : new Tlist<BonusCodeEntry>(_007B10578_007D));
		ServerTime = _007B10579_007D;
	}

	public void Boxing(WriterExtern _007B10580_007D)
	{
		_007B10580_007D.Write(Code, (Encoding)null);
		_007B10580_007D.WriteTlistStruct<BonusCodeEntry>(Entries);
		_007B10580_007D.WriteStruct<long>(ServerTime.Ticks);
	}

	public void Unboxing(WriterExtern _007B10581_007D)
	{
		_007B10581_007D.ReadString(ref Code, (Encoding)null);
		_007B10581_007D.ReadTlistStruct<BonusCodeEntry>(out Entries);
		long ticks = default(long);
		_007B10581_007D.ReadStruct<long>(ref ticks);
		ServerTime = new DateTime(ticks);
	}
}
