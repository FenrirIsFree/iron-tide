using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnAddGuildTitle : IPacketBase, IMPSerializable
{
	public byte TitleId;

	public bool UpdateCurrent;

	public FlowOfPack Flow => FlowOfPack.FromServerToClient;

	public OnAddGuildTitle(byte _007B9327_007D, bool _007B9328_007D = false)
	{
		UpdateCurrent = false;
		TitleId = _007B9327_007D;
		UpdateCurrent = _007B9328_007D;
	}

	public void Boxing(WriterExtern _007B9329_007D)
	{
		_007B9329_007D.WriteByte(TitleId);
		_007B9329_007D.Write(UpdateCurrent);
	}

	public void Unboxing(WriterExtern _007B9330_007D)
	{
		TitleId = _007B9330_007D.ReadByte();
		_007B9330_007D.ReadBoolean(ref UpdateCurrent);
	}
}
