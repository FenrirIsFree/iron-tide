using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnMakeCraftOnTraderInSea : IPacketBase, IMPSerializable
{
	public byte SpecialOfferId;

	public int Count;

	public FlowOfPack Flow => FlowOfPack.FromClientToServer;

	public OnMakeCraftOnTraderInSea(byte _007B9513_007D, int _007B9514_007D)
	{
		SpecialOfferId = _007B9513_007D;
		Count = _007B9514_007D;
	}

	public void Boxing(WriterExtern _007B9515_007D)
	{
		_007B9515_007D.WriteByte(SpecialOfferId);
		_007B9515_007D.WriteStruct<int>(Count);
	}

	public void Unboxing(WriterExtern _007B9516_007D)
	{
		SpecialOfferId = _007B9516_007D.ReadByte();
		_007B9516_007D.ReadStruct<int>(ref Count);
	}
}
