namespace Common.Packets;

public enum KillCase
{
	Npc,
	NpcLegendary,
	Player,
	PlayerNeutral,
	PlayerAlly,
	PlayerShipDiff,
	PlayerEvent,
	PlayerByGroup
}
