using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnRandomPvpZone : IPacketBase, IMPSerializable
{
	public enum RewardType
	{
		None,
		BeingInZone,
		DestructionOfEnemy
	}

	public int Gold;

	public bool Inside;

	public RewardType Type;

	public FlowOfPack Flow => FlowOfPack.FromServerToClient;

	public OnRandomPvpZone(int _007B9294_007D, bool _007B9295_007D, RewardType _007B9296_007D)
	{
		Gold = _007B9294_007D;
		Inside = _007B9295_007D;
		Type = _007B9296_007D;
	}

	public void Boxing(WriterExtern _007B9297_007D)
	{
		_007B9297_007D.WriteStruct<int>(Gold);
		_007B9297_007D.Write(Inside);
		_007B9297_007D.WriteByte((byte)Type);
	}

	public void Unboxing(WriterExtern _007B9298_007D)
	{
		_007B9298_007D.ReadStruct<int>(ref Gold);
		_007B9298_007D.ReadBoolean(ref Inside);
		Type = (RewardType)_007B9298_007D.ReadByte();
	}
}
