using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;

namespace Common.Packets;

public struct OnLocPlayerRespawnResultMsg : IPacketBase, IMPSerializable
{
	public bool entryToPort;

	public ShipPositionInfo PositionForSync;

	public int portId;

	public RespawnHealthAmount restoreFullHp;

	public int payGold;

	public bool setProtectionMode;

	public Vector3 protectionZoneCenterR;

	public FlowOfPack Flow => FlowOfPack.FromServerToClient;

	public OnLocPlayerRespawnResultMsg(bool _007B9760_007D, int _007B9761_007D, RespawnHealthAmount _007B9762_007D, ShipPositionInfo _007B9763_007D, int _007B9764_007D, bool _007B9765_007D, Vector3 _007B9766_007D)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		entryToPort = _007B9760_007D;
		PositionForSync = _007B9763_007D;
		portId = _007B9761_007D;
		restoreFullHp = _007B9762_007D;
		payGold = _007B9764_007D;
		setProtectionMode = _007B9765_007D;
		protectionZoneCenterR = _007B9766_007D;
	}

	public void Boxing(WriterExtern _007B9767_007D)
	{
		_007B9767_007D.Write(entryToPort);
		_007B9767_007D.Write<ShipPositionInfo>(ref PositionForSync);
		_007B9767_007D.WriteStruct<int>(portId);
		_007B9767_007D.WriteByte((byte)restoreFullHp);
		_007B9767_007D.WriteStruct<int>(ref payGold);
		_007B9767_007D.Write(setProtectionMode);
		_007B9767_007D.WriteStruct<Vector3>(ref protectionZoneCenterR);
	}

	public void Unboxing(WriterExtern _007B9768_007D)
	{
		_007B9768_007D.ReadBoolean(ref entryToPort);
		_007B9768_007D.ReadIMPS_struct<ShipPositionInfo>(ref PositionForSync);
		_007B9768_007D.ReadStruct<int>(ref portId);
		restoreFullHp = (RespawnHealthAmount)_007B9768_007D.ReadByte();
		_007B9768_007D.ReadStruct<int>(ref payGold);
		_007B9768_007D.ReadBoolean(ref setProtectionMode);
		_007B9768_007D.ReadStruct<Vector3>(ref protectionZoneCenterR);
	}
}
