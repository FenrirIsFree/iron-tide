using System;
using Common.Account;
using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Packets;

public struct OnStartStateMsg : IPacketBase, IMPSerializable
{
	public WeatherEngineState WeatherState;

	public int PlayerUID;

	public CommonGameConfig ProcessSettings;

	public float CurrentGameTime;

	public Tlist<EventActionBase> Actions;

	public Tlist<EventActionBase> WaitActions;

	public GuildCommon GuildInfo;

	public Tlist<OflineNotification> UnreadNotifications;

	public int UnreceivedSalary;

	public Tlist<PublicDesignInfo> MyPublicDesigns;

	public GSI CurrentPortAuctionResources;

	public float SecToReboot;

	public TimeSpan ServerTimezone;

	public FlowOfPack Flow => FlowOfPack.FromServerToClient;

	public OnStartStateMsg(CommonGameConfig _007B10252_007D, WeatherEngineState _007B10253_007D, int _007B10254_007D, float _007B10255_007D, Tlist<EventActionBase> _007B10256_007D, Tlist<EventActionBase> _007B10257_007D, GuildCommon _007B10258_007D, Tlist<OflineNotification> _007B10259_007D, int _007B10260_007D, Tlist<PublicDesignInfo> _007B10261_007D, GSI _007B10262_007D, float _007B10263_007D, TimeSpan _007B10264_007D)
	{
		WeatherState = _007B10253_007D;
		PlayerUID = _007B10254_007D;
		ProcessSettings = _007B10252_007D;
		CurrentGameTime = _007B10255_007D;
		Actions = _007B10256_007D;
		GuildInfo = _007B10258_007D;
		WaitActions = _007B10257_007D;
		UnreadNotifications = _007B10259_007D;
		if (UnreadNotifications == null)
		{
			UnreadNotifications = new Tlist<OflineNotification>(1);
		}
		UnreceivedSalary = _007B10260_007D;
		MyPublicDesigns = _007B10261_007D;
		CurrentPortAuctionResources = _007B10262_007D;
		SecToReboot = _007B10263_007D;
		ServerTimezone = _007B10264_007D;
	}

	public void Boxing(WriterExtern _007B10265_007D)
	{
		_007B10265_007D.Write<WeatherEngineState>(ref WeatherState);
		_007B10265_007D.WriteStruct<int>(ref PlayerUID);
		_007B10265_007D.Write<CommonGameConfig>(ProcessSettings);
		_007B10265_007D.WriteStruct<float>(ref CurrentGameTime);
		_007B10265_007D.WriteTlistImps(Actions);
		_007B10265_007D.Write<GuildCommon>(GuildInfo);
		_007B10265_007D.WriteTlistImps(WaitActions);
		_007B10265_007D.WriteTlistImps(UnreadNotifications);
		_007B10265_007D.WriteStruct<int>(UnreceivedSalary);
		_007B10265_007D.WriteTlistImps(MyPublicDesigns);
		_007B10265_007D.WriteNoNull<GSI>(CurrentPortAuctionResources);
		_007B10265_007D.WriteStruct<float>(ref SecToReboot);
		_007B10265_007D.WriteStruct<long>(ServerTimezone.Ticks);
	}

	public void Unboxing(WriterExtern _007B10266_007D)
	{
		_007B10266_007D.ReadIMPS_struct<WeatherEngineState>(ref WeatherState);
		_007B10266_007D.ReadStruct<int>(ref PlayerUID);
		_007B10266_007D.ReadIMPS<CommonGameConfig>(ref ProcessSettings);
		_007B10266_007D.ReadStruct<float>(ref CurrentGameTime);
		_007B10266_007D.ReadTlistImps(out Actions);
		_007B10266_007D.ReadIMPS<GuildCommon>(ref GuildInfo);
		_007B10266_007D.ReadTlistImps(out WaitActions);
		_007B10266_007D.ReadTlistImps(out UnreadNotifications);
		_007B10266_007D.ReadStruct<int>(ref UnreceivedSalary);
		_007B10266_007D.ReadTlistImps(out MyPublicDesigns);
		_007B10266_007D.ReadIMPSNoNull<GSI>(ref CurrentPortAuctionResources);
		_007B10266_007D.ReadStruct<float>(ref SecToReboot);
		long ticks = default(long);
		_007B10266_007D.ReadStruct<long>(ref ticks);
		ServerTimezone = new TimeSpan(ticks);
	}
}
