namespace Common.Packets;

public enum WorldRandomAction
{
	SouredResources,
	DetectionPirates,
	NpcRetreat,
	ShipOverturned,
	CaptureNpcItemFail,
	SetFlagWorld,
	SetFlagWarning,
	SetFlagSpeedInfo,
	PBFlagResetWarningWarning,
	PBRegisterToolTip,
	PBLabelSet,
	PBLabelReset,
	PBTowersCountDestructed,
	PBTowersCountCaptured,
	PBAllTowersDestroyedAndFortReady,
	PBFortDestructed,
	PBFortAllowToRob,
	PBFortRobbed,
	WarCompanyErrorOnceQuest,
	WarCompanyErrorGroup,
	Thundershot,
	FinshPlayerWorldActivityWithRes,
	ApplyWorldResearchPointByClient,
	CombatModeFailed,
	ChangeVisibleTitle,
	MakeTemporaryPeaceFlag,
	FishingBuff
}
