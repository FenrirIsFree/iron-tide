using Common.Resources;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public class TestServerShipStat : IMPSerializable
{
	public int ShipInfoId;

	public float Editor_Hp;

	public float Editor_Speed;

	public float Editor_Mobillity;

	public float Editor_Armor;

	public TestServerShipStat()
	{
	}

	public TestServerShipStat(int _007B10305_007D, float _007B10306_007D, float _007B10307_007D, float _007B10308_007D, float _007B10309_007D)
	{
		ShipInfoId = _007B10305_007D;
		Editor_Hp = _007B10306_007D;
		Editor_Speed = _007B10307_007D;
		Editor_Mobillity = _007B10308_007D;
		Editor_Armor = _007B10309_007D;
	}

	public TestServerShipStat(PlayerShipInfo _007B10310_007D)
	{
		ShipInfoId = _007B10310_007D.ID;
		Editor_Hp = _007B10310_007D.Editor_Hp.GetValueOrDefault();
		Editor_Speed = _007B10310_007D.Editor_Speed.GetValueOrDefault();
		Editor_Mobillity = _007B10310_007D.Editor_Mobillity.GetValueOrDefault();
		Editor_Armor = _007B10310_007D.Editor_Armor.GetValueOrDefault();
	}

	public void Set(PlayerShipInfo _007B10311_007D)
	{
		if (Editor_Hp != 0f)
		{
			_007B10311_007D.Editor_Hp = Editor_Hp;
		}
		if (Editor_Speed != 0f)
		{
			_007B10311_007D.Editor_Speed = Editor_Speed;
		}
		if (Editor_Mobillity != 0f)
		{
			_007B10311_007D.Editor_Mobillity = Editor_Mobillity;
		}
		if (Editor_Armor != 0f)
		{
			_007B10311_007D.Editor_Armor = Editor_Armor;
		}
	}

	private void _007B10312_007D(WriterExtern _007B10313_007D)
	{
		_007B10313_007D.WriteStruct<int>(ShipInfoId);
		_007B10313_007D.WriteStruct<float>(ref Editor_Hp);
		_007B10313_007D.WriteStruct<float>(ref Editor_Speed);
		_007B10313_007D.WriteStruct<float>(ref Editor_Mobillity);
		_007B10313_007D.WriteStruct<float>(ref Editor_Armor);
	}

	private void _007B10314_007D(WriterExtern _007B10315_007D)
	{
		_007B10315_007D.ReadStruct<int>(ref ShipInfoId);
		_007B10315_007D.ReadStruct<float>(ref Editor_Hp);
		_007B10315_007D.ReadStruct<float>(ref Editor_Speed);
		_007B10315_007D.ReadStruct<float>(ref Editor_Mobillity);
		_007B10315_007D.ReadStruct<float>(ref Editor_Armor);
	}
}
