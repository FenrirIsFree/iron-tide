using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnGMAddMsg : IPacketBase, IMPSerializable
{
	public GroupMemberInfo AddedMember;

	public FlowOfPack Flow => FlowOfPack.FromServerToClient;

	public OnGMAddMsg(GroupMemberInfo _007B9216_007D)
	{
		AddedMember = _007B9216_007D;
	}

	public void Boxing(WriterExtern _007B9217_007D)
	{
		_007B9217_007D.Write<GroupMemberInfo>(AddedMember);
	}

	public void Unboxing(WriterExtern _007B9218_007D)
	{
		_007B9218_007D.ReadIMPS<GroupMemberInfo>(ref AddedMember);
	}
}
