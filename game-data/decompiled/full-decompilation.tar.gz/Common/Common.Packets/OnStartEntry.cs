using System.Text;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnStartEntry : IPacketBase, IMPSerializable
{
	public bool DebugSpeed;

	public string TherashieldHash;

	public bool IsTestConfig;

	public FlowOfPack Flow => FlowOfPack.FromClientToServer;

	public OnStartEntry(bool _007B10234_007D, string _007B10235_007D, bool _007B10236_007D)
	{
		DebugSpeed = _007B10234_007D;
		TherashieldHash = _007B10235_007D;
		IsTestConfig = _007B10236_007D;
	}

	public void Boxing(WriterExtern _007B10237_007D)
	{
		_007B10237_007D.Write(DebugSpeed);
		_007B10237_007D.Write(TherashieldHash, (Encoding)null);
		_007B10237_007D.Write(IsTestConfig);
	}

	public void Unboxing(WriterExtern _007B10238_007D)
	{
		_007B10238_007D.ReadBoolean(ref DebugSpeed);
		_007B10238_007D.ReadString(ref TherashieldHash, (Encoding)null);
		_007B10238_007D.ReadBoolean(ref IsTestConfig);
	}
}
