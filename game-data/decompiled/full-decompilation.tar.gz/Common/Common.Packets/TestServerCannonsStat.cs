using Common.Resources;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public class TestServerCannonsStat : IMPSerializable
{
	public int CannonInfoId;

	public float Editor_Penetration;

	public float Editor_Distance;

	public float Editor_ReloadTime;

	public float Editor_Scatter;

	public TestServerCannonsStat()
	{
	}

	public TestServerCannonsStat(int _007B10322_007D, float _007B10323_007D, float _007B10324_007D, float _007B10325_007D, float _007B10326_007D)
	{
		CannonInfoId = _007B10322_007D;
		Editor_Penetration = _007B10323_007D;
		Editor_Distance = _007B10324_007D;
		Editor_ReloadTime = _007B10325_007D;
		Editor_Scatter = _007B10326_007D;
	}

	public TestServerCannonsStat(CannonGameInfo _007B10327_007D)
	{
		CannonInfoId = _007B10327_007D.ID;
		Editor_Penetration = _007B10327_007D.Editor_Penetration.GetValueOrDefault();
		Editor_Distance = _007B10327_007D.Editor_Distance.GetValueOrDefault();
		Editor_ReloadTime = _007B10327_007D.Editor_ReloadTime.GetValueOrDefault();
		Editor_Scatter = _007B10327_007D.Editor_Scatter.GetValueOrDefault();
	}

	public void Set(CannonGameInfo _007B10328_007D)
	{
		if (Editor_Penetration != 0f)
		{
			_007B10328_007D.Editor_Penetration = Editor_Penetration;
		}
		if (Editor_Distance != 0f)
		{
			_007B10328_007D.Editor_Distance = Editor_Distance;
		}
		if (Editor_ReloadTime != 0f)
		{
			_007B10328_007D.Editor_ReloadTime = Editor_ReloadTime;
		}
		if (Editor_Scatter != 0f)
		{
			_007B10328_007D.Editor_Scatter = Editor_Scatter;
		}
	}

	private void _007B10329_007D(WriterExtern _007B10330_007D)
	{
		_007B10330_007D.WriteStruct<int>(CannonInfoId);
		_007B10330_007D.WriteStruct<float>(Editor_Penetration);
		_007B10330_007D.WriteStruct<float>(Editor_Distance);
		_007B10330_007D.WriteStruct<float>(Editor_ReloadTime);
		_007B10330_007D.WriteStruct<float>(Editor_Scatter);
	}

	private void _007B10331_007D(WriterExtern _007B10332_007D)
	{
		_007B10332_007D.ReadStruct<int>(ref CannonInfoId);
		_007B10332_007D.ReadStruct<float>(ref Editor_Penetration);
		_007B10332_007D.ReadStruct<float>(ref Editor_Distance);
		_007B10332_007D.ReadStruct<float>(ref Editor_ReloadTime);
		_007B10332_007D.ReadStruct<float>(ref Editor_Scatter);
	}
}
