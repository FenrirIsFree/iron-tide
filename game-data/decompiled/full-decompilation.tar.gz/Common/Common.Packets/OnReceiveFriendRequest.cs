using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnReceiveFriendRequest : IPacketBase, IMPSerializable
{
	public FriendRequest IncomingRequest;

	public FlowOfPack Flow => FlowOfPack.FromServerToClient;

	public OnReceiveFriendRequest(FriendRequest _007B10513_007D)
	{
		IncomingRequest = _007B10513_007D;
	}

	public void Boxing(WriterExtern _007B10514_007D)
	{
		_007B10514_007D.Write<FriendRequest>(ref IncomingRequest);
	}

	public void Unboxing(WriterExtern _007B10515_007D)
	{
		_007B10515_007D.ReadIMPS_struct<FriendRequest>(ref IncomingRequest);
	}
}
