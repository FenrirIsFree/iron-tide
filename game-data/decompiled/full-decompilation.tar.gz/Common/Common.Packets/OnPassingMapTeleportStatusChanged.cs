using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;

namespace Common.Packets;

public struct OnPassingMapTeleportStatusChanged : IPacketBase, IMPSerializable
{
	public byte MapID;

	public Vector2 NewPosition;

	public int DiffLevel;

	public byte[] DiffCards;

	public bool showWaitPlayerMessage;

	public byte[] preinstallUpgrades;

	public FlowOfPack Flow => FlowOfPack.Any;

	public OnPassingMapTeleportStatusChanged(byte _007B9721_007D, Vector2 _007B9722_007D, int _007B9723_007D, byte[] _007B9724_007D, bool _007B9725_007D, byte[] _007B9726_007D)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		MapID = _007B9721_007D;
		NewPosition = _007B9722_007D;
		DiffLevel = _007B9723_007D;
		DiffCards = _007B9724_007D;
		showWaitPlayerMessage = _007B9725_007D;
		preinstallUpgrades = _007B9726_007D;
	}

	public void Boxing(WriterExtern _007B9727_007D)
	{
		_007B9727_007D.WriteByte(MapID);
		_007B9727_007D.WriteStruct<Vector2>(ref NewPosition);
		_007B9727_007D.WriteByte((byte)DiffLevel);
		_007B9727_007D.Write(showWaitPlayerMessage);
		_007B9727_007D.WriteBytes8bitSize(DiffCards);
		_007B9727_007D.WriteBytes8bitSize(preinstallUpgrades);
	}

	public void Unboxing(WriterExtern _007B9728_007D)
	{
		MapID = _007B9728_007D.ReadByte();
		_007B9728_007D.ReadStruct<Vector2>(ref NewPosition);
		DiffLevel = _007B9728_007D.ReadByte();
		_007B9728_007D.ReadBoolean(ref showWaitPlayerMessage);
		_007B9728_007D.ReadBytes8bitSize(ref DiffCards);
		_007B9728_007D.ReadBytes8bitSize(ref preinstallUpgrades);
	}
}
