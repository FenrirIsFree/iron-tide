using ManualPacketSerialization;

namespace Common.Packets;

public interface IPacketBase : IMPSerializable
{
	FlowOfPack Flow { get; }
}
