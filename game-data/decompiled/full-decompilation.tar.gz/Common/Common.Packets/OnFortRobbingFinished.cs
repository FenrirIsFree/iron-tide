using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnFortRobbingFinished : IPacketBase, IMPSerializable
{
	public int ShipUID;

	public GSI GivenResources;

	public int DisplayGoldToGuild;

	public FlowOfPack Flow => FlowOfPack.FromServerToClient;

	public OnFortRobbingFinished(int _007B9993_007D, GSI _007B9994_007D, int _007B9995_007D)
	{
		ShipUID = _007B9993_007D;
		GivenResources = _007B9994_007D;
		DisplayGoldToGuild = _007B9995_007D;
	}

	public void Boxing(WriterExtern _007B9996_007D)
	{
		_007B9996_007D.WriteStruct<int>(ShipUID);
		_007B9996_007D.WriteStruct<int>(DisplayGoldToGuild);
		_007B9996_007D.Write<GSI>(GivenResources);
	}

	public void Unboxing(WriterExtern _007B9997_007D)
	{
		_007B9997_007D.ReadStruct<int>(ref ShipUID);
		_007B9997_007D.ReadStruct<int>(ref DisplayGoldToGuild);
		_007B9997_007D.ReadIMPS<GSI>(ref GivenResources);
	}
}
