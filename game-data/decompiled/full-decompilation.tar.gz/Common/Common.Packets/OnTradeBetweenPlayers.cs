using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnTradeBetweenPlayers : IPacketBase, IMPSerializable
{
	public enum Flag
	{
		AskTarget,
		Accept,
		Fail
	}

	public Flag Status;

	public TradeOrderBetweenPlayers Order;

	public FlowOfPack Flow => FlowOfPack.Any;

	public OnTradeBetweenPlayers(Flag _007B9535_007D, TradeOrderBetweenPlayers _007B9536_007D)
	{
		Status = _007B9535_007D;
		Order = _007B9536_007D;
	}

	public void Boxing(WriterExtern _007B9537_007D)
	{
		_007B9537_007D.WriteByte((byte)Status);
		_007B9537_007D.Write<TradeOrderBetweenPlayers>(ref Order);
	}

	public void Unboxing(WriterExtern _007B9538_007D)
	{
		Status = (Flag)_007B9538_007D.ReadByte();
		_007B9538_007D.ReadIMPS_struct<TradeOrderBetweenPlayers>(ref Order);
	}
}
