using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnDebugSetMode : IPacketBase, IMPSerializable
{
	public int UID;

	public bool DebugEnabled;

	public FlowOfPack Flow => FlowOfPack.FromServerToClient;

	public OnDebugSetMode(int _007B10279_007D, bool _007B10280_007D)
	{
		UID = _007B10279_007D;
		DebugEnabled = _007B10280_007D;
	}

	public void Boxing(WriterExtern _007B10281_007D)
	{
		_007B10281_007D.WriteStruct<int>(ref UID);
		_007B10281_007D.Write(DebugEnabled);
	}

	public void Unboxing(WriterExtern _007B10282_007D)
	{
		_007B10282_007D.ReadStruct<int>(ref UID);
		_007B10282_007D.ReadBoolean(ref DebugEnabled);
	}
}
