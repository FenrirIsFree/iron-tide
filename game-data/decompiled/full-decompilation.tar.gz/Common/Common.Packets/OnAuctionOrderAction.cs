using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnAuctionOrderAction : IPacketBase, IMPSerializable
{
	public enum ActionType : byte
	{
		Create,
		Apply,
		Make,
		Undo
	}

	public ActionType action;

	public TradeOrderCommon content;

	public bool ByMonets;

	public FlowOfPack Flow => FlowOfPack.Any;

	public OnAuctionOrderAction(ActionType _007B9494_007D, TradeOrderCommon _007B9495_007D, bool _007B9496_007D = false)
	{
		action = _007B9494_007D;
		content = _007B9495_007D;
		ByMonets = _007B9496_007D;
	}

	public void Boxing(WriterExtern _007B9497_007D)
	{
		_007B9497_007D.WriteByte((byte)action);
		_007B9497_007D.Write<TradeOrderCommon>(content);
		_007B9497_007D.Write(ByMonets);
	}

	public void Unboxing(WriterExtern _007B9498_007D)
	{
		action = (ActionType)_007B9498_007D.ReadByte();
		_007B9498_007D.ReadIMPS<TradeOrderCommon>(ref content);
		_007B9498_007D.ReadBoolean(ref ByMonets);
	}
}
