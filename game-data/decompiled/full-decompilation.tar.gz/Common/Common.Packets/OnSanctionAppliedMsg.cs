using System;
using System.Text;
using System.Threading;
using Common.Account;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnSanctionAppliedMsg : IPacketBase, IMPSerializable
{
	public string SourceID;

	public string SourceName;

	public DateTime ServerTime;

	public SanctionType Type;

	public TimeSpan AddedTime;

	public string Message;

	public readonly bool IsIndefinite => AddedTime == Timeout.InfiniteTimeSpan;

	public FlowOfPack Flow => FlowOfPack.FromServerToClient;

	public OnSanctionAppliedMsg(string _007B8989_007D, string _007B8990_007D, DateTime _007B8991_007D, SanctionType _007B8992_007D, TimeSpan _007B8993_007D, string _007B8994_007D)
	{
		SourceID = _007B8989_007D;
		SourceName = (string.IsNullOrEmpty(_007B8990_007D) ? _007B8989_007D : _007B8990_007D);
		Type = _007B8992_007D;
		AddedTime = _007B8993_007D;
		ServerTime = _007B8991_007D;
		Message = _007B8994_007D;
	}

	public void Boxing(WriterExtern _007B8995_007D)
	{
		_007B8995_007D.Write(SourceID, (Encoding)null);
		_007B8995_007D.Write(SourceName, (Encoding)null);
		_007B8995_007D.WriteEnum((object)Type);
		long ticks = AddedTime.Ticks;
		_007B8995_007D.WriteStruct<long>(ref ticks);
		ticks = ServerTime.Ticks;
		_007B8995_007D.WriteStruct<long>(ref ticks);
		_007B8995_007D.Write(Message, (Encoding)null);
	}

	public void Unboxing(WriterExtern _007B8996_007D)
	{
		_007B8996_007D.ReadString(ref SourceID, (Encoding)null);
		_007B8996_007D.ReadString(ref SourceName, (Encoding)null);
		_007B8996_007D.ReadEnum<SanctionType>(ref Type);
		long ticks = default(long);
		_007B8996_007D.ReadStruct<long>(ref ticks);
		AddedTime = new TimeSpan(ticks);
		_007B8996_007D.ReadStruct<long>(ref ticks);
		ServerTime = new DateTime(ticks);
		_007B8996_007D.ReadString(ref Message, (Encoding)null);
	}
}
