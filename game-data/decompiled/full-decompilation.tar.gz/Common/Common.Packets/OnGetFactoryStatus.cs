using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnGetFactoryStatus : IPacketBase, IMPSerializable
{
	public byte placeIndex;

	public GSI totalStatus;

	public FlowOfPack Flow => FlowOfPack.Any;

	public OnGetFactoryStatus(byte _007B10538_007D, GSI _007B10539_007D)
	{
		placeIndex = _007B10538_007D;
		totalStatus = _007B10539_007D;
	}

	public void Boxing(WriterExtern _007B10540_007D)
	{
		_007B10540_007D.WriteByte(placeIndex);
		_007B10540_007D.Write<GSI>(totalStatus);
	}

	public void Unboxing(WriterExtern _007B10541_007D)
	{
		placeIndex = _007B10541_007D.ReadByte();
		_007B10541_007D.ReadIMPS<GSI>(ref totalStatus);
	}
}
