using CommonDataTypes;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnGiveAchievement : IPacketBase, IMPSerializable
{
	public AchievementEnum[] AchievementID;

	public FlowOfPack Flow => FlowOfPack.FromServerToClient;

	public OnGiveAchievement(AchievementEnum[] _007B8980_007D)
	{
		AchievementID = _007B8980_007D;
	}

	public void Boxing(WriterExtern _007B8981_007D)
	{
		_007B8981_007D.WriteStruct<short>((short)AchievementID.Length);
		for (int i = 0; i < AchievementID.Length; i++)
		{
			_007B8981_007D.WriteStruct<short>((short)AchievementID[i]);
		}
	}

	public void Unboxing(WriterExtern _007B8982_007D)
	{
		short num = default(short);
		_007B8982_007D.ReadStruct<short>(ref num);
		AchievementID = new AchievementEnum[num];
		short num2 = default(short);
		for (int i = 0; i < num; i++)
		{
			_007B8982_007D.ReadStruct<short>(ref num2);
			AchievementID[i] = (AchievementEnum)num2;
		}
	}
}
