using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnPremiumAddMsg : IPacketBase, IMPSerializable
{
	public enum Subscription
	{
		PremiumDays,
		PeaceSec,
		TradingSec,
		HoldProtectionSec,
		LegendaryFlagDays
	}

	public Subscription SubType;

	public int Amount;

	public int Cost;

	public FlowOfPack Flow => FlowOfPack.FromClientToServer;

	public OnPremiumAddMsg(Subscription _007B10469_007D, int _007B10470_007D, int _007B10471_007D)
	{
		SubType = _007B10469_007D;
		Amount = _007B10470_007D;
		Cost = _007B10471_007D;
	}

	public void Boxing(WriterExtern _007B10472_007D)
	{
		_007B10472_007D.WriteByte((byte)SubType);
		_007B10472_007D.WriteStruct<int>(ref Amount);
		_007B10472_007D.WriteStruct<int>(ref Cost);
	}

	public void Unboxing(WriterExtern _007B10473_007D)
	{
		SubType = (Subscription)_007B10473_007D.ReadByte();
		_007B10473_007D.ReadStruct<int>(ref Amount);
		_007B10473_007D.ReadStruct<int>(ref Cost);
	}
}
