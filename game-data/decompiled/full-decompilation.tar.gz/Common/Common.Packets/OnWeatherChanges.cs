using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnWeatherChanges : IPacketBase, IMPSerializable
{
	public WeatherEngineState state;

	public float gameTimeIfChanged;

	public bool setAsInitialState;

	public byte instanceId;

	public FlowOfPack Flow => FlowOfPack.FromServerToClient;

	public OnWeatherChanges(bool _007B9205_007D, byte _007B9206_007D, WeatherEngineState _007B9207_007D, float _007B9208_007D = -1f)
	{
		setAsInitialState = _007B9205_007D;
		state = _007B9207_007D;
		gameTimeIfChanged = _007B9208_007D;
		instanceId = _007B9206_007D;
	}

	public void Boxing(WriterExtern _007B9209_007D)
	{
		_007B9209_007D.Write(setAsInitialState);
		_007B9209_007D.WriteStruct<float>(ref gameTimeIfChanged);
		_007B9209_007D.Write<WeatherEngineState>(ref state);
		_007B9209_007D.WriteByte(instanceId);
	}

	public void Unboxing(WriterExtern _007B9210_007D)
	{
		_007B9210_007D.ReadBoolean(ref setAsInitialState);
		_007B9210_007D.ReadStruct<float>(ref gameTimeIfChanged);
		_007B9210_007D.ReadIMPS_struct<WeatherEngineState>(ref state);
		instanceId = _007B9210_007D.ReadByte();
	}
}
