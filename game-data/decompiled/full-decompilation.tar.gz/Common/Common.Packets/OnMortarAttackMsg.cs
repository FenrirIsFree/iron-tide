using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnMortarAttackMsg : IPacketBase, IMPSerializable
{
	public int[] shotUid;

	public int SenderUID;

	public MortarShotParameters Shot;

	public FlowOfPack Flow => FlowOfPack.FromServerToClient;

	public OnMortarAttackMsg(int[] _007B8796_007D, int _007B8797_007D, MortarShotParameters _007B8798_007D)
	{
		shotUid = _007B8796_007D;
		SenderUID = _007B8797_007D;
		Shot = _007B8798_007D;
	}

	public void Boxing(WriterExtern _007B8799_007D)
	{
		_007B8799_007D.WriteByte((byte)shotUid.Length);
		for (int i = 0; i < shotUid.Length; i++)
		{
			_007B8799_007D.WriteStruct<int>(shotUid[i]);
		}
		_007B8799_007D.WriteStruct<int>(ref SenderUID);
		_007B8799_007D.Write<MortarShotParameters>(ref Shot);
	}

	public void Unboxing(WriterExtern _007B8800_007D)
	{
		byte b = _007B8800_007D.ReadByte();
		shotUid = new int[b];
		for (int i = 0; i < b; i++)
		{
			_007B8800_007D.ReadStruct<int>(ref shotUid[i]);
		}
		_007B8800_007D.ReadStruct<int>(ref SenderUID);
		_007B8800_007D.ReadIMPS_struct<MortarShotParameters>(ref Shot);
	}
}
