using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnJoinOrLeaveArenaFaield : IPacketBase, IMPSerializable
{
	public int Error;

	public FlowOfPack Flow => FlowOfPack.FromClientToServer;

	public OnJoinOrLeaveArenaFaield(int _007B9638_007D)
	{
		Error = _007B9638_007D;
	}

	public void Boxing(WriterExtern _007B9639_007D)
	{
		_007B9639_007D.WriteStruct<int>(Error);
	}

	public void Unboxing(WriterExtern _007B9640_007D)
	{
		_007B9640_007D.ReadStruct<int>(ref Error);
	}
}
