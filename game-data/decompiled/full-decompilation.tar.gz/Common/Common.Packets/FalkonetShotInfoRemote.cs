using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using Microsoft.Xna.Framework;

namespace Common.Packets;

public struct FalkonetShotInfoRemote : IMPSerializable, IShootingInfo
{
	public Vector3 StartPosition;

	public Vector3 SightDirection;

	public int UID;

	public byte AmmoID;

	public int BoardingHookTargetUid;

	public int DisableInterruptParts => Gameplay.BallsInfo.FromID(AmmoID).CountParts;

	public FalkonetShotInfoRemote(Vector3 _007B8812_007D, Vector3 _007B8813_007D, int _007B8814_007D, byte _007B8815_007D, int _007B8816_007D)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		StartPosition = _007B8812_007D;
		SightDirection = _007B8813_007D;
		UID = _007B8814_007D;
		AmmoID = _007B8815_007D;
		BoardingHookTargetUid = _007B8816_007D;
	}

	private void _007B8817_007D(WriterExtern _007B8818_007D)
	{
		_007B8818_007D.WriteStruct<Vector3>(ref StartPosition);
		_007B8818_007D.WriteStruct<Vector3>(ref SightDirection);
		_007B8818_007D.WriteStruct<int>(ref UID);
		_007B8818_007D.WriteByte(AmmoID);
		_007B8818_007D.WriteStruct<int>(ref BoardingHookTargetUid);
	}

	private void _007B8819_007D(WriterExtern _007B8820_007D)
	{
		_007B8820_007D.ReadStruct<Vector3>(ref StartPosition);
		_007B8820_007D.ReadStruct<Vector3>(ref SightDirection);
		_007B8820_007D.ReadStruct<int>(ref UID);
		AmmoID = _007B8820_007D.ReadByte();
		_007B8820_007D.ReadStruct<int>(ref BoardingHookTargetUid);
	}
}
