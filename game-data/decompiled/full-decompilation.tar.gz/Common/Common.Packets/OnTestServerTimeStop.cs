using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnTestServerTimeStop : IPacketBase, IMPSerializable
{
	public bool value;

	public FlowOfPack Flow => FlowOfPack.FromClientToServer;

	public OnTestServerTimeStop(bool _007B10375_007D)
	{
		value = _007B10375_007D;
	}

	public void Boxing(WriterExtern _007B10376_007D)
	{
		_007B10376_007D.Write(value);
	}

	public void Unboxing(WriterExtern _007B10377_007D)
	{
		_007B10377_007D.ReadBoolean(ref value);
	}
}
