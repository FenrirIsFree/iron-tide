using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnAcceptLocGroupInviteMsg : IPacketBase, IMPSerializable
{
	public CreateGroupQueryResult QueryResult;

	public FlowOfPack Flow => FlowOfPack.FromServerToClient;

	public OnAcceptLocGroupInviteMsg(CreateGroupQueryResult _007B9212_007D)
	{
		QueryResult = _007B9212_007D;
	}

	public void Boxing(WriterExtern _007B9213_007D)
	{
		_007B9213_007D.WriteEnum((object)QueryResult);
	}

	public void Unboxing(WriterExtern _007B9214_007D)
	{
		_007B9214_007D.ReadEnum<CreateGroupQueryResult>(ref QueryResult);
	}
}
