using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnCrewChangesMsg : IPacketBase, IMPSerializable
{
	public int ShipUID;

	public GSI destructions;

	public int LossOfFortCount;

	public BoardingFinishMode mode;

	public UnitCollection serverUnitsTest;

	public FlowOfPack Flow => FlowOfPack.FromServerToClient;

	public OnCrewChangesMsg(int _007B10030_007D, GSI _007B10031_007D, BoardingFinishMode _007B10032_007D, UnitCollection _007B10033_007D)
	{
		ShipUID = _007B10030_007D;
		destructions = _007B10031_007D;
		LossOfFortCount = 0;
		mode = _007B10032_007D;
		serverUnitsTest = _007B10033_007D;
	}

	public OnCrewChangesMsg(int _007B10034_007D, GSI _007B10035_007D, int _007B10036_007D, UnitCollection _007B10037_007D)
	{
		ShipUID = _007B10034_007D;
		LossOfFortCount = _007B10036_007D;
		destructions = _007B10035_007D;
		mode = BoardingFinishMode.CaptureFort;
		serverUnitsTest = _007B10037_007D;
	}

	public void Boxing(WriterExtern _007B10038_007D)
	{
		_007B10038_007D.WriteByte((byte)mode);
		_007B10038_007D.WriteStruct<int>(ShipUID);
		_007B10038_007D.Write<GSI>(destructions);
		if (mode == BoardingFinishMode.CaptureFort)
		{
			_007B10038_007D.WriteStruct<int>(LossOfFortCount);
		}
		_007B10038_007D.Write<UnitCollection>(serverUnitsTest);
	}

	public void Unboxing(WriterExtern _007B10039_007D)
	{
		mode = (BoardingFinishMode)_007B10039_007D.ReadByte();
		_007B10039_007D.ReadStruct<int>(ref ShipUID);
		_007B10039_007D.ReadIMPS<GSI>(ref destructions);
		if (mode == BoardingFinishMode.CaptureFort)
		{
			_007B10039_007D.ReadStruct<int>(ref LossOfFortCount);
		}
		_007B10039_007D.ReadIMPS<UnitCollection>(ref serverUnitsTest);
	}
}
