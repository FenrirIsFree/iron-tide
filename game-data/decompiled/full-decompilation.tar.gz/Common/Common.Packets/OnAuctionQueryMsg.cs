using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnAuctionQueryMsg : IPacketBase, IMPSerializable
{
	public bool isShowAllPortsQuery;

	public FlowOfPack Flow => FlowOfPack.FromClientToServer;

	public OnAuctionQueryMsg(bool _007B9500_007D)
	{
		isShowAllPortsQuery = _007B9500_007D;
	}

	public void Boxing(WriterExtern _007B9501_007D)
	{
		_007B9501_007D.Write(isShowAllPortsQuery);
	}

	public void Unboxing(WriterExtern _007B9502_007D)
	{
		_007B9502_007D.ReadBoolean(ref isShowAllPortsQuery);
	}
}
