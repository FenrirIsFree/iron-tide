using System;

namespace Common.Packets;

[Flags]
public enum PbsEngageProblem : byte
{
	None = 0,
	TrustedGuilds = 1,
	NoRespawns = 2,
	TeamHaveFullFill = 4,
	NotPlacesForOtherParticipants = 8,
	HavingQuestsOrEffects = 0x10,
	ShallowOrShipRistrictions = 0x20,
	OnlyOneSuchShipCanBe = 0x40,
	Display_Allow = byte.MaxValue
}
