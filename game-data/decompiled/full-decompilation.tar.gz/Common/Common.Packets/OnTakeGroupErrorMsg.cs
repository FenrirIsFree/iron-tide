using ManualPacketSerialization;
using ManualPacketSerialization.Externs;

namespace Common.Packets;

public struct OnTakeGroupErrorMsg : IPacketBase, IMPSerializable
{
	public TakeGroupErrorType ErrorType;

	public FlowOfPack Flow => FlowOfPack.FromClientToServer;

	public OnTakeGroupErrorMsg(TakeGroupErrorType _007B9262_007D)
	{
		ErrorType = _007B9262_007D;
	}

	public void Boxing(WriterExtern _007B9263_007D)
	{
		_007B9263_007D.WriteEnum((object)ErrorType);
	}

	public void Unboxing(WriterExtern _007B9264_007D)
	{
		_007B9264_007D.ReadEnum<TakeGroupErrorType>(ref ErrorType);
	}
}
