using Common.Game;
using ManualPacketSerialization;
using ManualPacketSerialization.Externs;
using TheraEngine.Collections;

namespace Common.Packets;

public struct OnFriendStatusChangeMsg : IPacketBase, IMPSerializable
{
	public uint AccountSID;

	public bool IsOnline;

	public Tlist<FriendStatus> InitializeAllFriends;

	public FlowOfPack Flow => FlowOfPack.FromServerToClient;

	public OnFriendStatusChangeMsg(uint _007B10501_007D, bool _007B10502_007D, Tlist<FriendStatus> _007B10503_007D)
	{
		AccountSID = _007B10501_007D;
		IsOnline = _007B10502_007D;
		InitializeAllFriends = _007B10503_007D;
	}

	public void Boxing(WriterExtern _007B10504_007D)
	{
		_007B10504_007D.WriteStruct<uint>(ref AccountSID);
		_007B10504_007D.Write(IsOnline);
		_007B10504_007D.WriteTlistStruct<FriendStatus>(InitializeAllFriends);
	}

	public void Unboxing(WriterExtern _007B10505_007D)
	{
		_007B10505_007D.ReadStruct<uint>(ref AccountSID);
		_007B10505_007D.ReadBoolean(ref IsOnline);
		_007B10505_007D.ReadTlistStruct<FriendStatus>(out InitializeAllFriends);
	}
}
