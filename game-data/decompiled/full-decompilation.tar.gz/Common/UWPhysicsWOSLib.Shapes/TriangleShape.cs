using System;
using Microsoft.Xna.Framework;
using TheraEngine.Graphics;

namespace UWPhysicsWOSLib.Shapes;

public class TriangleShape
{
	internal Vector3 center;

	public Vector3 p0;

	public Vector3 p1;

	public Vector3 p2;

	internal float MaxRadius;

	public TriangleShape(ref VertexPositionNormal _007B262_007D, ref VertexPositionNormal _007B263_007D, ref VertexPositionNormal _007B264_007D)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		p0 = _007B262_007D.Position;
		p1 = _007B263_007D.Position;
		p2 = _007B264_007D.Position;
		center = (_007B262_007D.Position + _007B263_007D.Position + _007B264_007D.Position) / 3f;
		Vector3 val = _007B262_007D.Position - center;
		float val2 = ((Vector3)(ref val)).Length();
		val = _007B263_007D.Position - center;
		float val3 = ((Vector3)(ref val)).Length();
		val = _007B264_007D.Position - center;
		MaxRadius = Math.Max(val2, Math.Max(val3, ((Vector3)(ref val)).Length()));
	}
}
