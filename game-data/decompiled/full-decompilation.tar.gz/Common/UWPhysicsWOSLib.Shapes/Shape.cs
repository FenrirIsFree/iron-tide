using Microsoft.Xna.Framework;

namespace UWPhysicsWOSLib.Shapes;

public abstract class Shape
{
	protected BoundingSphere baseSphere;

	public BoundingSphere Sphere => baseSphere;

	protected Shape(BoundingSphere _007B235_007D)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		baseSphere = _007B235_007D;
	}
}
