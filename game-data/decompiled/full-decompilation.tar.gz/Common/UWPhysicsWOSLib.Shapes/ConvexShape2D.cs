using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using TheraEngine.Collections;

namespace UWPhysicsWOSLib.Shapes;

public class ConvexShape2D : Shape2D
{
	private class PolarAngleComparer : IComparer<Vector2>
	{
		private Vector2 _007B191_007D;

		public PolarAngleComparer(Vector2 _007B185_007D)
		{
			//IL_0009: Unknown result type (might be due to invalid IL or missing references)
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			_007B191_007D = _007B185_007D;
		}

		public int Compare(Vector2 _007B186_007D, Vector2 _007B187_007D)
		{
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Unknown result type (might be due to invalid IL or missing references)
			float num = _007B188_007D(_007B191_007D, _007B186_007D);
			float num2 = _007B188_007D(_007B191_007D, _007B187_007D);
			if (num < num2)
			{
				return -1;
			}
			if (num > num2)
			{
				return 1;
			}
			return 0;
		}

		private float _007B188_007D(Vector2 _007B189_007D, Vector2 _007B190_007D)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			float x = _007B190_007D.X - _007B189_007D.X;
			float y = _007B190_007D.Y - _007B189_007D.Y;
			return MathF.Atan2(y, x);
		}
	}

	public ConvexShape2D(Vector2[] _007B172_007D, bool _007B173_007D, bool _007B174_007D)
		: base(_007B173_007D ? Shape2D.ConvertToFiguresArr(FigureComposer(_007B172_007D, _007B174_007D).ToArray()) : Shape2D.ConvertToFiguresArr(_007B172_007D))
	{
	}

	private static Tlist<Vector2> FigureComposer(Vector2[] _007B175_007D, bool _007B176_007D)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		Tlist<Vector2> tlist = new Tlist<Vector2>();
		if (_007B175_007D.Length == 0)
		{
			return tlist;
		}
		Vector2 val = _007B175_007D[0];
		for (int i = 1; i < _007B175_007D.Length; i++)
		{
			if (_007B175_007D[i].Y < val.Y || (_007B175_007D[i].Y == val.Y && _007B175_007D[i].X < val.X))
			{
				val = _007B175_007D[i];
			}
		}
		Array.Sort(_007B175_007D, new PolarAngleComparer(val));
		tlist.Add(in _007B175_007D[0]);
		tlist.Add(in _007B175_007D[1]);
		if (_007B176_007D)
		{
			for (int j = 1; j < _007B175_007D.Length; j++)
			{
				int num = tlist.Size - 1;
				Vector2 _007B177_007D = tlist.Array[num];
				Vector2 item = _007B175_007D[j];
				while (tlist.Size >= 2 && ShouldCombineSegments(_007B177_007D, item, tlist.Array[tlist.Size - 2], 0.8f))
				{
					tlist.FastRemoveAt(num);
					num--;
					_007B177_007D = tlist.Array[num];
				}
				tlist.Add(in item);
			}
		}
		else
		{
			for (int k = 2; k < _007B175_007D.Length; k++)
			{
				while (tlist.Size >= 2 && !IsLeftTurn(tlist.Array[tlist.Size - 2], tlist.Array[tlist.Size - 1], _007B175_007D[k]))
				{
					tlist.RemoveAt(tlist.Size - 1);
				}
				tlist.Add(in _007B175_007D[k]);
			}
		}
		return tlist;
	}

	private static bool ShouldCombineSegments(Vector2 _007B177_007D, Vector2 _007B178_007D, Vector2 _007B179_007D, float _007B180_007D)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = _007B177_007D - _007B179_007D;
		Vector2 val2 = _007B178_007D - _007B177_007D;
		float num = Vector2.Dot(val, val2);
		return num < _007B180_007D;
	}

	private static bool IsLeftTurn(Vector2 _007B181_007D, Vector2 _007B182_007D, Vector2 _007B183_007D)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		float num = (_007B182_007D.X - _007B181_007D.X) * (_007B183_007D.Y - _007B181_007D.Y) - (_007B182_007D.Y - _007B181_007D.Y) * (_007B183_007D.X - _007B181_007D.X);
		return num > 0f;
	}
}
