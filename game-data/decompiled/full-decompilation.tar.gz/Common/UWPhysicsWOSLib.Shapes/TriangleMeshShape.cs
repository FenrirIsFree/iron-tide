#define DEBUG
using System;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using TheraEngine.Collections;
using TheraEngine.Graphics.Models;

namespace UWPhysicsWOSLib.Shapes;

public class TriangleMeshShape : Shape
{
	public struct HashVector3
	{
		public int X;

		public int Y;

		public int Z;

		public HashVector3(int _007B256_007D, int _007B257_007D, int _007B258_007D)
		{
			X = _007B256_007D;
			Y = _007B257_007D;
			Z = _007B258_007D;
		}
	}

	private const int minTriangles = 50;

	private float _007B249_007D;

	public Tlist<TriangleShape> AllTriangles;

	private Tlist<TriangleShape>[] _007B250_007D;

	private HashVector3 _007B251_007D;

	private HashVector3 _007B252_007D;

	internal Vector3 vmin;

	internal Vector3 vmax;

	private static int fastRound(float _007B239_007D)
	{
		if (_007B239_007D >= 0f)
		{
			return (int)((double)_007B239_007D + 0.5);
		}
		return (int)((double)_007B239_007D - 0.5);
	}

	public HashVector3 GetCellB(in Vector3 _007B240_007D)
	{
		return new HashVector3(fastRound(_007B240_007D.X / _007B249_007D), fastRound(_007B240_007D.Y / _007B249_007D), fastRound(_007B240_007D.Z / _007B249_007D));
	}

	public void Saturate(ref HashVector3 _007B241_007D)
	{
		_007B241_007D.X = Math.Min(_007B252_007D.X, Math.Max(_007B251_007D.X, _007B241_007D.X));
		_007B241_007D.Y = Math.Min(_007B252_007D.Y, Math.Max(_007B251_007D.Y, _007B241_007D.Y));
		_007B241_007D.Z = Math.Min(_007B252_007D.Z, Math.Max(_007B251_007D.Z, _007B241_007D.Z));
	}

	public HashVector3 GetCell(Vector3 _007B242_007D)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		HashVector3 result = new HashVector3(fastRound(_007B242_007D.X / _007B249_007D), fastRound(_007B242_007D.Y / _007B249_007D), fastRound(_007B242_007D.Z / _007B249_007D));
		result.X = Math.Min(_007B252_007D.X, Math.Max(_007B251_007D.X, result.X));
		result.Y = Math.Min(_007B252_007D.Y, Math.Max(_007B251_007D.Y, result.Y));
		result.Z = Math.Min(_007B252_007D.Z, Math.Max(_007B251_007D.Z, result.Z));
		return result;
	}

	private int _007B243_007D(in HashVector3 _007B244_007D)
	{
		return (_007B244_007D.Z - _007B251_007D.Z) * (_007B252_007D.X - _007B251_007D.X + 1) * (_007B252_007D.Y - _007B251_007D.Y + 1) + (_007B244_007D.Y - _007B251_007D.Y) * (_007B252_007D.X - _007B251_007D.X + 1) + (_007B244_007D.X - _007B251_007D.X);
	}

	public TriangleMeshShape()
		: base(default(BoundingSphere))
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		_007B249_007D = 1f;
		AllTriangles = new Tlist<TriangleShape>();
		_007B250_007D = new Tlist<TriangleShape>[1] { AllTriangles };
	}

	public unsafe TriangleMeshShape(UWOpenModel _007B245_007D, float _007B246_007D, float _007B247_007D)
		: base(_007B245_007D.CommonSphere)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ef: Unknown result type (might be due to invalid IL or missing references)
		_007B249_007D = _007B246_007D;
		AllTriangles = new Tlist<TriangleShape>(_007B245_007D.PrimitiveCount + 1);
		vmin = new Vector3(float.MaxValue);
		vmax = new Vector3(float.MinValue);
		int num = _007B245_007D.MeshPartsSource.Length;
		for (int i = 0; i < num; i++)
		{
			MeshPartOpenData meshPartOpenData = _007B245_007D.MeshPartsSource[i];
			fixed (ushort* ptr = &meshPartOpenData.IndexBuffer[0])
			{
				for (int j = 0; j < meshPartOpenData.PrimitiveCount; j++)
				{
					TriangleShape item = new TriangleShape(ref meshPartOpenData.VertexBuffer[ptr[j * 3]], ref meshPartOpenData.VertexBuffer[(ptr + j * 3)[1]], ref meshPartOpenData.VertexBuffer[(ptr + j * 3)[2]]);
					AllTriangles.Add(in item);
					Vector3.Min(ref vmin, ref item.p0, ref vmin);
					Vector3.Max(ref vmax, ref item.p0, ref vmax);
					Vector3.Min(ref vmin, ref item.p1, ref vmin);
					Vector3.Max(ref vmax, ref item.p1, ref vmax);
					Vector3.Min(ref vmin, ref item.p2, ref vmin);
					Vector3.Max(ref vmax, ref item.p2, ref vmax);
				}
			}
		}
		if (AllTriangles.Size >= 50)
		{
			_007B251_007D = GetCellB(in vmin);
			_007B252_007D = GetCellB(in vmax);
			_007B250_007D = new Tlist<TriangleShape>[(_007B252_007D.X - _007B251_007D.X + 1) * (_007B252_007D.Y - _007B251_007D.Y + 1) * (_007B252_007D.Z - _007B251_007D.Z + 1)];
			Vector3 _007B240_007D = default(Vector3);
			Vector3 _007B240_007D2 = default(Vector3);
			for (int k = 0; k < AllTriangles.Size; k++)
			{
				TriangleShape item2 = AllTriangles.Array[k];
				float num2 = item2.MaxRadius + _007B247_007D;
				((Vector3)(ref _007B240_007D))._002Ector(item2.center.X - num2, item2.center.Y - num2, item2.center.Z - num2);
				((Vector3)(ref _007B240_007D2))._002Ector(item2.center.X + num2, item2.center.Y + num2, item2.center.Z + num2);
				HashVector3 _007B241_007D = GetCellB(in _007B240_007D);
				HashVector3 _007B241_007D2 = GetCellB(in _007B240_007D2);
				Saturate(ref _007B241_007D);
				Saturate(ref _007B241_007D2);
				HashVector3 _007B244_007D = _007B241_007D;
				_007B244_007D.X = _007B241_007D.X;
				while (_007B244_007D.X <= _007B241_007D2.X)
				{
					_007B244_007D.Y = _007B241_007D.Y;
					while (_007B244_007D.Y <= _007B241_007D2.Y)
					{
						_007B244_007D.Z = _007B241_007D.Z;
						while (_007B244_007D.Z <= _007B241_007D2.Z)
						{
							int num3 = _007B243_007D(in _007B244_007D);
							Tlist<TriangleShape> tlist = _007B250_007D[num3];
							if (tlist == null)
							{
								tlist = new Tlist<TriangleShape>(48);
								_007B250_007D[num3] = tlist;
							}
							tlist.Add(in item2);
							_007B244_007D.Z++;
						}
						_007B244_007D.Y++;
					}
					_007B244_007D.X++;
				}
			}
			int num4 = 0;
			Tlist<TriangleShape>[] array = _007B250_007D;
			foreach (Tlist<TriangleShape> tlist2 in array)
			{
				if (tlist2 != null)
				{
					tlist2.Trim();
					if (tlist2.Size > 500)
					{
						num4 = Math.Max(tlist2.Size, num4);
					}
				}
			}
			if (num4 > 0)
			{
				Debug.WriteLine("Non-effecient triangleShape for " + _007B245_007D.ModelName + ", " + num4);
			}
			if (_007B250_007D.Length > 10000)
			{
				Debug.WriteLine("Non-effecient TableShape for " + _007B245_007D.ModelName + ", " + _007B250_007D.Length);
			}
		}
		AllTriangles.Trim();
		if (AllTriangles.Size == 0)
		{
			throw new ContentLoadException("TriangleMeshShape is empty");
		}
	}

	public Tlist<TriangleShape> GetCollisionArea(ref Vector3 _007B248_007D)
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		if (AllTriangles.Size < 50)
		{
			return AllTriangles;
		}
		return _007B250_007D[_007B243_007D(GetCell(_007B248_007D))];
	}
}
