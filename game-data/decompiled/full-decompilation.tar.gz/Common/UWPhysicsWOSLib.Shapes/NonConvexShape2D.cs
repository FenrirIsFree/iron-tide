using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;

namespace UWPhysicsWOSLib.Shapes;

public class NonConvexShape2D : Shape2D
{
	private struct ConnectedVector
	{
		public Vector2 P;

		public bool Connected;

		public ConnectedVector(Vector2 _007B207_007D, bool _007B208_007D)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			P = _007B207_007D;
			Connected = _007B208_007D;
		}
	}

	public NonConvexShape2D(Vector2[] _007B196_007D, bool _007B197_007D)
		: base(_007B197_007D ? Shape2D.ConvertToFiguresArr(FigureComposer(_007B196_007D).ToArray()) : Shape2D.ConvertToFiguresArr(_007B196_007D))
	{
	}

	public NonConvexShape2D(TriangleMeshShape _007B198_007D, float _007B199_007D)
		: base(FigureComposer2(_007B198_007D, _007B199_007D))
	{
	}

	private static Segment[] FigureComposer2(TriangleMeshShape _007B200_007D, float _007B201_007D)
	{
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		Tlist<Segment> segments = new Tlist<Segment>();
		Tlist<Vector2> points = new Tlist<Vector2>();
		int index = 0;
		ShapeHelper.ClipPlane(_007B200_007D, _007B201_007D, delegate(Vector3 _007B209_007D)
		{
			//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00da: Unknown result type (might be due to invalid IL or missing references)
			//IL_00df: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
			//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			//IL_0045: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
			//IL_0080: Unknown result type (might be due to invalid IL or missing references)
			//IL_0085: Unknown result type (might be due to invalid IL or missing references)
			if (index % 2 == 0)
			{
				if (segments.Size > 0 && Vector2.DistanceSquared(_007B209_007D.XZ(), segments.Array[segments.Size - 1].End) < 0.1f)
				{
					segments.Add(new Segment(segments.Array[segments.Size - 1].End, Vector2.Zero));
				}
				else
				{
					segments.Add(new Segment(_007B209_007D.XZ(), Vector2.Zero));
				}
			}
			else
			{
				segments.Array[segments.Size - 1].End = _007B209_007D.XZ();
			}
			points.Add(_007B209_007D.XZ());
			index++;
		});
		segments.Clear();
		for (int num = 0; num < points.Size; num += 2)
		{
			segments.Add(new Segment(points.Array[num], points.Array[num + 1]));
		}
		return RemoveIsolatedSegments(segments);
	}

	public static void FillHoles(Tlist<Segment> _007B202_007D)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		Dictionary<Vector2, int> dictionary = new Dictionary<Vector2, int>();
		foreach (Segment item in (IEnumerable<Segment>)_007B202_007D)
		{
			if (!dictionary.ContainsKey(item.Start))
			{
				dictionary[item.Start] = 1;
			}
			else
			{
				dictionary[item.Start]++;
			}
			if (!dictionary.ContainsKey(item.End))
			{
				dictionary[item.End] = 1;
			}
			else
			{
				dictionary[item.End]++;
			}
		}
		HashSet<Vector2> hashSet = new HashSet<Vector2>();
		foreach (KeyValuePair<Vector2, int> item2 in dictionary)
		{
			if (item2.Value == 1)
			{
				hashSet.Add(item2.Key);
			}
		}
		HashSet<Vector2> hashSet2 = new HashSet<Vector2>();
		foreach (Segment item3 in (IEnumerable<Segment>)_007B202_007D)
		{
			hashSet2.Add(item3.Start);
			hashSet2.Add(item3.End);
		}
		while (hashSet.Count > 1)
		{
			Vector2 val = hashSet.First();
			Vector2 val2 = Vector2.Zero;
			float num = float.MaxValue;
			foreach (Vector2 item4 in hashSet)
			{
				float num2 = Vector2.DistanceSquared(val, item4);
				if (num2 < num && item4 != val)
				{
					num = num2;
					val2 = item4;
				}
			}
			if (Vector2.DistanceSquared(val, val2) < 64f)
			{
				_007B202_007D.Add(new Segment(val, val2));
			}
			hashSet.Remove(val);
			hashSet.Remove(val2);
		}
	}

	public static Segment[] RemoveIsolatedSegments(Tlist<Segment> _007B203_007D)
	{
		return _007B203_007D.ToArray();
	}

	private static Tlist<Vector2> FigureComposer(Vector2[] _007B204_007D)
	{
		throw new Exception("Works not good");
	}
}
