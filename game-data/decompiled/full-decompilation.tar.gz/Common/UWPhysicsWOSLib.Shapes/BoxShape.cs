using System;
using Microsoft.Xna.Framework;
using TheraEngine.Graphics.Models;

namespace UWPhysicsWOSLib.Shapes;

public class BoxShape : Shape
{
	internal float width;

	internal float height;

	internal float length;

	internal Vector3 localCenter;

	public float FinalWidth => width;

	public float FinalHeight => height;

	public float FinalLength => length;

	public Vector3 LocalCenter => localCenter;

	public Vector3 MaxP => localCenter + new Vector3(length * 0.5f, height * 0.5f, width * 0.5f);

	public Vector3 MinP => localCenter - new Vector3(length * 0.5f, height * 0.5f, width * 0.5f);

	public Vector3 Size => new Vector3(length, height, width);

	public BoxShape(BoxShape _007B135_007D)
		: this(_007B135_007D.localCenter, _007B135_007D.width, _007B135_007D.height, _007B135_007D.length)
	{
	}//IL_0002: Unknown result type (might be due to invalid IL or missing references)


	public BoxShape(BoundingBox _007B136_007D, float _007B137_007D = 1f)
		: this(0.5f * (_007B136_007D.Min + _007B136_007D.Max), (_007B136_007D.Max.Z - _007B136_007D.Min.Z) * _007B137_007D, (_007B136_007D.Max.Y - _007B136_007D.Min.Y) * _007B137_007D, (_007B136_007D.Max.X - _007B136_007D.Min.X) * _007B137_007D)
	{
	}//IL_0006: Unknown result type (might be due to invalid IL or missing references)
	//IL_0007: Unknown result type (might be due to invalid IL or missing references)
	//IL_000c: Unknown result type (might be due to invalid IL or missing references)
	//IL_000d: Unknown result type (might be due to invalid IL or missing references)
	//IL_0012: Unknown result type (might be due to invalid IL or missing references)
	//IL_0017: Unknown result type (might be due to invalid IL or missing references)
	//IL_001c: Unknown result type (might be due to invalid IL or missing references)
	//IL_001d: Unknown result type (might be due to invalid IL or missing references)
	//IL_0027: Unknown result type (might be due to invalid IL or missing references)
	//IL_0028: Unknown result type (might be due to invalid IL or missing references)
	//IL_0035: Unknown result type (might be due to invalid IL or missing references)
	//IL_0036: Unknown result type (might be due to invalid IL or missing references)
	//IL_0040: Unknown result type (might be due to invalid IL or missing references)
	//IL_0041: Unknown result type (might be due to invalid IL or missing references)
	//IL_004e: Unknown result type (might be due to invalid IL or missing references)
	//IL_004f: Unknown result type (might be due to invalid IL or missing references)
	//IL_0059: Unknown result type (might be due to invalid IL or missing references)
	//IL_005a: Unknown result type (might be due to invalid IL or missing references)


	public BoxShape(BoundingBox _007B138_007D, Vector3 _007B139_007D)
		: this(0.5f * (_007B138_007D.Min + _007B138_007D.Max), (_007B138_007D.Max.Z - _007B138_007D.Min.Z) * _007B139_007D.Z, (_007B138_007D.Max.Y - _007B138_007D.Min.Y) * _007B139_007D.Y, (_007B138_007D.Max.X - _007B138_007D.Min.X) * _007B139_007D.X)
	{
	}//IL_0006: Unknown result type (might be due to invalid IL or missing references)
	//IL_0007: Unknown result type (might be due to invalid IL or missing references)
	//IL_000c: Unknown result type (might be due to invalid IL or missing references)
	//IL_000d: Unknown result type (might be due to invalid IL or missing references)
	//IL_0012: Unknown result type (might be due to invalid IL or missing references)
	//IL_0017: Unknown result type (might be due to invalid IL or missing references)
	//IL_001c: Unknown result type (might be due to invalid IL or missing references)
	//IL_001d: Unknown result type (might be due to invalid IL or missing references)
	//IL_0027: Unknown result type (might be due to invalid IL or missing references)
	//IL_0028: Unknown result type (might be due to invalid IL or missing references)
	//IL_0033: Unknown result type (might be due to invalid IL or missing references)
	//IL_003a: Unknown result type (might be due to invalid IL or missing references)
	//IL_003b: Unknown result type (might be due to invalid IL or missing references)
	//IL_0045: Unknown result type (might be due to invalid IL or missing references)
	//IL_0046: Unknown result type (might be due to invalid IL or missing references)
	//IL_0051: Unknown result type (might be due to invalid IL or missing references)
	//IL_0058: Unknown result type (might be due to invalid IL or missing references)
	//IL_0059: Unknown result type (might be due to invalid IL or missing references)
	//IL_0063: Unknown result type (might be due to invalid IL or missing references)
	//IL_0064: Unknown result type (might be due to invalid IL or missing references)
	//IL_006f: Unknown result type (might be due to invalid IL or missing references)


	public BoxShape(Vector3 _007B140_007D, float _007B141_007D, float _007B142_007D, float _007B143_007D)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = new Vector3(_007B143_007D, _007B142_007D, _007B141_007D);
		base._002Ector(new BoundingSphere(_007B140_007D, ((Vector3)(ref val)).Length()));
		localCenter = _007B140_007D;
		width = _007B141_007D;
		height = _007B142_007D;
		length = _007B143_007D;
	}

	public BoxShape(UWOpenModel _007B144_007D)
		: base(_007B144_007D.CommonSphere)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = default(Vector3);
		((Vector3)(ref val))._002Ector(float.MaxValue);
		Vector3 val2 = default(Vector3);
		((Vector3)(ref val2))._002Ector(float.MinValue);
		int num = _007B144_007D.MeshParts.Length;
		for (short num2 = 0; num2 < num; num2++)
		{
			MeshPartOpenData meshPartOpenData = _007B144_007D.MeshPartsSource[num2];
			int num3 = meshPartOpenData.VertexBuffer.Length;
			for (int i = 0; i < num3; i++)
			{
				Vector3 position = meshPartOpenData.VertexBuffer[i].Position;
				Vector3.Max(ref val2, ref position, ref val2);
				Vector3.Min(ref val, ref position, ref val);
			}
		}
		if (float.IsNaN(val2.X) || float.IsNaN(val2.Y) || float.IsNaN(val2.Z))
		{
			throw new Exception();
		}
		length = val2.X - val.X;
		height = val2.Y - val.Y;
		width = val2.Z - val.Z;
	}
}
