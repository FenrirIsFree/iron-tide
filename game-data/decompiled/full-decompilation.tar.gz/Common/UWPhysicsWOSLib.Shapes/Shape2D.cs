using System;
using Microsoft.Xna.Framework;
using TheraEngine;
using TheraEngine.Collections;

namespace UWPhysicsWOSLib.Shapes;

public abstract class Shape2D
{
	public struct Segment
	{
		public Vector2 Start;

		public Vector2 End;

		public Segment(Vector2 _007B167_007D, Vector2 _007B168_007D)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			//IL_0009: Unknown result type (might be due to invalid IL or missing references)
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			Start = _007B167_007D;
			End = _007B168_007D;
		}
	}

	public Segment[] Segments;

	public Vector2 Min;

	public Vector2 Max;

	public Vector2 Center;

	public float Radius;

	public Shape2D(Segment[] _007B146_007D)
	{
		Segments = _007B146_007D;
		_007B150_007D();
	}

	public void Transform(Matrix _007B147_007D)
	{
		for (int i = 0; i < Segments.Length; i++)
		{
			Transform2D(ref Segments[i].Start, ref _007B147_007D);
			Transform2D(ref Segments[i].End, ref _007B147_007D);
		}
		_007B150_007D();
	}

	private static void Transform2D(ref Vector2 _007B148_007D, ref Matrix _007B149_007D)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = default(Vector3);
		((Vector3)(ref val))._002Ector(_007B148_007D.X, 0f, _007B148_007D.Y);
		Vector3.Transform(ref val, ref _007B149_007D, ref val);
		_007B148_007D.X = val.X;
		_007B148_007D.Y = val.Z;
	}

	private void _007B150_007D()
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		if (Segments.Length == 0)
		{
			Min = Vector2.Zero;
			Max = Vector2.Zero;
			Center = Vector2.Zero;
			Radius = 0f;
			return;
		}
		Min = Segments[0].Start;
		Max = Segments[0].Start;
		for (int i = 1; i < Segments.Length; i++)
		{
			Vector2.Min(ref Min, ref Segments[i].Start, ref Min);
			Vector2.Max(ref Max, ref Segments[i].End, ref Max);
		}
		Center = (Min + Max) / 2f;
		Radius = Vector2.Distance(Max, Min) / 2f;
	}

	public void Draw(float _007B151_007D, Rectangle _007B152_007D)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = default(Vector3);
		((Vector3)(ref val))._002Ector(0f, _007B151_007D, 0f);
		for (int i = 0; i < Segments.Length; i++)
		{
			Vector3 _007B14965_007D = Segments[i].Start.X0Y() + val;
			Vector3 _007B14965_007D2 = Segments[i].End.X0Y() + val;
			if (Engine.GS.Camera.IsVisible(in _007B14965_007D, 0f) || Engine.GS.Camera.IsVisible(in _007B14965_007D2, 0f))
			{
				Engine.GS.Line2D(_007B152_007D, Engine.GS.Camera.GetProjection(_007B14965_007D), Engine.GS.Camera.GetProjection(_007B14965_007D2), Color.White, 2);
			}
		}
	}

	public static Tlist<Vector2> OptimizeFigure(Vector2[] _007B153_007D, float _007B154_007D)
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		Tlist<Vector2> tlist = new Tlist<Vector2>();
		if (_007B153_007D.Length == 0)
		{
			return tlist;
		}
		int i = 0;
		int num = _007B153_007D.Length - 1;
		for (; i < _007B153_007D.Length; i++)
		{
			int num2 = (i + 1) % _007B153_007D.Length;
			float num3 = CalculateAngle(_007B153_007D[i], _007B153_007D[num2], _007B153_007D[num]);
			if (num3 <= _007B154_007D)
			{
				num = num2;
			}
			if (num3 > _007B154_007D || i == 0)
			{
				tlist.Add(in _007B153_007D[i]);
				num = i;
			}
		}
		return tlist;
	}

	public static Tlist<Segment> ConvertToFigures(Tlist<Vector2> _007B155_007D)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		Tlist<Segment> tlist = new Tlist<Segment>();
		if (_007B155_007D.Size < 2)
		{
			return tlist;
		}
		for (int i = 0; i < _007B155_007D.Size - 1; i++)
		{
			tlist.Add(new Segment(_007B155_007D.Array[i], _007B155_007D.Array[i + 1]));
		}
		tlist.Add(new Segment(_007B155_007D.Array[_007B155_007D.Size - 1], _007B155_007D.Array[0]));
		return tlist;
	}

	public static Segment[] ConvertToFiguresArr(Vector2[] _007B156_007D)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		if (_007B156_007D.Length < 2)
		{
			return new Segment[0];
		}
		int num = _007B156_007D.Length;
		Segment[] array = new Segment[num];
		for (int i = 0; i < num - 1; i++)
		{
			array[i] = new Segment(_007B156_007D[i], _007B156_007D[i + 1]);
		}
		array[num - 1] = new Segment(_007B156_007D[num - 1], _007B156_007D[0]);
		return array;
	}

	public bool IsPointInsideFigure(Vector2 _007B157_007D)
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		int num = Segments.Length;
		bool flag = false;
		int num2 = 0;
		int num3 = num - 1;
		while (num2 < num)
		{
			if (Segments[num2].Start.Y > _007B157_007D.Y != Segments[num3].Start.Y > _007B157_007D.Y && _007B157_007D.X < (Segments[num3].Start.X - Segments[num2].Start.X) * (_007B157_007D.Y - Segments[num2].Start.Y) / (Segments[num3].Start.Y - Segments[num2].Start.Y) + Segments[num2].Start.X)
			{
				flag = !flag;
			}
			num3 = num2++;
		}
		return flag;
	}

	private static float CalculateAngle(Vector2 _007B158_007D, Vector2 _007B159_007D, Vector2 _007B160_007D)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		float num = _007B158_007D.X - _007B159_007D.X;
		float num2 = _007B158_007D.Y - _007B159_007D.Y;
		float num3 = _007B160_007D.X - _007B159_007D.X;
		float num4 = _007B160_007D.Y - _007B159_007D.Y;
		float x = num * num3 + num2 * num4;
		float y = num * num4 - num3 * num2;
		return MathF.Atan2(y, x);
	}

	public float GetDistanceToFigure(Vector2 _007B161_007D)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		float num = float.MaxValue;
		int num2 = Segments.Length;
		int num3 = 0;
		int num4 = num2 - 1;
		while (num3 < num2)
		{
			Vector2 _007B163_007D = Segments[num3].Start;
			Vector2 _007B164_007D = Segments[num4].Start;
			float distanceToSegment = GetDistanceToSegment(in _007B161_007D, in _007B163_007D, in _007B164_007D);
			num = Math.Min(num, distanceToSegment);
			num4 = num3++;
		}
		return num;
	}

	private static float GetDistanceToSegment(in Vector2 _007B162_007D, in Vector2 _007B163_007D, in Vector2 _007B164_007D)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = _007B164_007D - _007B163_007D;
		Vector2 val2 = _007B163_007D - _007B162_007D;
		float num = val.X * val.X + val.Y * val.Y;
		float num2 = Vector2.Dot(val, val2) / num;
		if (num2 < 0f)
		{
			return Vector2.Distance(_007B162_007D, _007B163_007D);
		}
		if (num2 > 1f)
		{
			return Vector2.Distance(_007B162_007D, _007B164_007D);
		}
		Vector2 val3 = _007B163_007D + num2 * val;
		return Vector2.Distance(_007B162_007D, val3);
	}
}
