using System.Collections.Generic;
using Microsoft.Xna.Framework;
using TheraEngine.Collections;

namespace UWPhysicsWOSLib.Shapes;

internal class TopologyHelper
{
	public class Node
	{
		public Vector2 Start;

		public Vector2 End;

		public Tlist<Node> ConnectedWith;

		public int Flags;

		public Node(Vector2 _007B218_007D, Vector2 _007B219_007D)
		{
			//IL_0009: Unknown result type (might be due to invalid IL or missing references)
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
			Start = _007B218_007D;
			End = _007B219_007D;
			ConnectedWith = new Tlist<Node>(2);
		}
	}

	public Tlist<Node> nodes = new Tlist<Node>();

	public void Append(Vector2 _007B210_007D, Vector2 _007B211_007D)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		foreach (Node item3 in (IEnumerable<Node>)nodes)
		{
			Node item = item3;
			Node item2 = null;
			if (_007B213_007D(item.Start, _007B210_007D))
			{
				item2 = new Node(_007B211_007D, item.Start);
			}
			if (_007B213_007D(item.End, _007B210_007D))
			{
				item2 = new Node(item.End, _007B211_007D);
			}
			if (_007B213_007D(item.Start, _007B211_007D))
			{
				item2 = new Node(_007B210_007D, item.Start);
			}
			if (_007B213_007D(item.End, _007B211_007D))
			{
				item2 = new Node(item.End, _007B210_007D);
			}
			if (item2 != null)
			{
				item.ConnectedWith.Add(in item2);
				item2.ConnectedWith.Add(in item);
				nodes.Add(in item2);
				return;
			}
		}
		nodes.Add(new Node(_007B210_007D, _007B211_007D));
	}

	public void FillHoles(float _007B212_007D)
	{
	}

	private bool _007B213_007D(Vector2 _007B214_007D, Vector2 _007B215_007D)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		return Vector2.DistanceSquared(_007B214_007D, _007B215_007D) < 1f;
	}
}
