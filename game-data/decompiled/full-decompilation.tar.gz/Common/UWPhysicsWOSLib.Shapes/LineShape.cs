using Microsoft.Xna.Framework;

namespace UWPhysicsWOSLib.Shapes;

public class LineShape : Shape
{
	public Vector3 start;

	public Vector3 end;

	public float radius;

	public LineShape(Vector3 _007B229_007D, Vector3 _007B230_007D, float _007B231_007D)
		: base(default(BoundingSphere))
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		SetData(_007B229_007D, _007B230_007D);
		radius = _007B231_007D * 0.5f;
	}

	public void SetData(Vector3 _007B232_007D, Vector3 _007B233_007D)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		start = _007B232_007D;
		end = _007B233_007D;
		OnUpdate();
	}

	public void OnUpdate()
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = default(Vector3);
		Vector3.Add(ref start, ref end, ref val);
		Vector3.Multiply(ref val, 0.5f, ref val);
		float num = default(float);
		Vector3.Distance(ref start, ref end, ref num);
		baseSphere = new BoundingSphere(val, num * 0.5f + radius * 1.4142135f);
	}
}
